/* Visual GTK - (C) 1999 Patrick Lambert, see the LICENSE file */
#include "visualgtk.h"

const gchar *list_item_data_key = "list_item_data";

void compile_project()
{
 sprintf(temp, "gcc `gtk-config --cflags` -o %s %s.c `gtk-config --libs` >make.log 2>&1", project_name, project_name);
 system(temp);

 if(GTK_IS_WIDGET(win)) gtk_widget_destroy(win);
 win = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize(GTK_WIDGET(win), 400, 300);
 gtk_signal_connect (GTK_OBJECT (win), "delete_event",
  GTK_SIGNAL_FUNC(CB_kill_win), &win);
 gtk_window_set_title (GTK_WINDOW (win), "Result");
 gtk_widget_set_uposition (GTK_WIDGET(win), 100, 150);
 gtk_container_border_width (GTK_CONTAINER (win), 0);
 gtk_widget_show(win);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (win), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 table = gtk_table_new (2, 2, FALSE);
 gtk_table_set_row_spacing (GTK_TABLE (table), 0, 2);
 gtk_table_set_col_spacing (GTK_TABLE (table), 0, 2);
 gtk_box_pack_start (GTK_BOX (vbox), table, TRUE, TRUE, 0);
 gtk_widget_show (table);

 text = gtk_text_new(NULL, NULL);
 gtk_text_set_editable (GTK_TEXT (text), FALSE);
 gtk_text_set_word_wrap(GTK_TEXT (text), TRUE);
 gtk_table_attach_defaults (GTK_TABLE (table), text, 0, 1, 0, 1);
 gtk_widget_show (text);

 gtk_text_freeze(GTK_TEXT(text));
 gtk_widget_realize(text);
 gtk_text_insert (GTK_TEXT (text), NULL, NULL, NULL, "Compiling...\n", -1);
 fd = fopen("make.log", "r");
 if(fd!=NULL)
 {
  while(fgets(temp, 1000, fd)!=NULL)
  {
   gtk_text_insert (GTK_TEXT (text), NULL, NULL, NULL, temp, -1);
  }
  fclose(fd);
 }
 gtk_text_insert (GTK_TEXT (text), NULL, NULL, NULL, "\nDone.\n", -1);
 gtk_text_thaw(GTK_TEXT(text));

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
 gtk_widget_show(hbox);

 button = gtk_button_new_with_label ("Close");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_kill_win), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
}

void run_project()
{
 sprintf(temp, "./%s & ", project_name);
 system(temp);
}

void CB_edit_includes(GtkWidget *w, GtkWidget *e)
{
 char *alltext;
 alltext = gtk_editable_get_chars(GTK_EDITABLE (text), 0,
 gtk_text_get_length(GTK_TEXT(text)));
 memcpy(more_includes, alltext, 4000);
 g_free(alltext);
 gtk_widget_destroy(win);
}

void edit_includes()
{
 if(GTK_IS_WIDGET(win)) gtk_widget_destroy(win);
 win = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize(GTK_WIDGET(win), 400, 300);
 gtk_signal_connect (GTK_OBJECT (win), "delete_event",
  GTK_SIGNAL_FUNC(CB_kill_win), &win);
 gtk_window_set_title (GTK_WINDOW (win), "Includes");
 gtk_widget_set_uposition (GTK_WIDGET(win), 100, 150);
 gtk_container_border_width (GTK_CONTAINER (win), 0);
 gtk_widget_show(win);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (win), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 table = gtk_table_new (2, 2, FALSE);
 gtk_table_set_row_spacing (GTK_TABLE (table), 0, 2);
 gtk_table_set_col_spacing (GTK_TABLE (table), 0, 2);
 gtk_box_pack_start (GTK_BOX (vbox), table, TRUE, TRUE, 0);
 gtk_widget_show (table);

 text = gtk_text_new(NULL, NULL);
 gtk_text_set_editable (GTK_TEXT (text), TRUE);
 gtk_text_set_word_wrap(GTK_TEXT (text), TRUE);
 gtk_table_attach_defaults (GTK_TABLE (table), text, 0, 1, 0, 1);
 gtk_widget_show (text);

 gtk_text_freeze(GTK_TEXT(text));
 gtk_widget_realize(text);
 gtk_text_insert (GTK_TEXT (text), NULL, NULL, NULL, more_includes, -1);
 gtk_text_thaw(GTK_TEXT(text));

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
 gtk_widget_show(hbox);

 button = gtk_button_new_with_label ("Cancel");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_kill_win), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_edit_includes), NULL);
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
}

void CB_edit_main(GtkWidget *w, GtkWidget *e)
{
 char *alltext;
 alltext = gtk_editable_get_chars(GTK_EDITABLE (text), 0,
 gtk_text_get_length(GTK_TEXT(text)));
 memcpy(main_text, alltext, 4000);
 g_free(alltext);
 gtk_widget_destroy(win);
}

void edit_main()
{
 if(!strcmp(main_text,""))
 strcpy(main_text, "\nint main(int argc, char *argv[])\n{\n\tgtk_init(&argc, &argv);\n\t/* put here the first frame you want to call: */\n\tmake_myframe();\n\tgtk_main();\n\treturn(0);\n}\n");
 if(GTK_IS_WIDGET(win)) gtk_widget_destroy(win);
 win = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize(GTK_WIDGET(win), 400, 300);
 gtk_signal_connect (GTK_OBJECT (win), "delete_event",
  GTK_SIGNAL_FUNC(CB_kill_win), &win);
 gtk_window_set_title (GTK_WINDOW (win), "Main");
 gtk_widget_set_uposition (GTK_WIDGET(win), 100, 150);
 gtk_container_border_width (GTK_CONTAINER (win), 0);
 gtk_widget_show(win);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (win), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 table = gtk_table_new (2, 2, FALSE);
 gtk_table_set_row_spacing (GTK_TABLE (table), 0, 2);
 gtk_table_set_col_spacing (GTK_TABLE (table), 0, 2);
 gtk_box_pack_start (GTK_BOX (vbox), table, TRUE, TRUE, 0);
 gtk_widget_show (table);

 text = gtk_text_new(NULL, NULL);
 gtk_text_set_editable (GTK_TEXT (text), TRUE);
 gtk_text_set_word_wrap(GTK_TEXT (text), TRUE);
 gtk_table_attach_defaults (GTK_TABLE (table), text, 0, 1, 0, 1);
 gtk_widget_show (text);

 gtk_text_freeze(GTK_TEXT(text));
 gtk_widget_realize(text);
 gtk_text_insert (GTK_TEXT (text), NULL, NULL, NULL, main_text, -1);
 gtk_text_thaw(GTK_TEXT(text));

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
 gtk_widget_show(hbox);

 button = gtk_button_new_with_label ("Cancel");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_kill_win), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_edit_main), NULL);
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
}

void print_widgets()
{
 int i;
 for(i = 0; i < 500; i++)
 {
  if(vgtk_callbacks[i].created)
  {
   printf("Callback %d: %s\n", i, vgtk_callbacks[i].name);
  }
 }
 for(i = 0; i < 200; i++)
 {
  if(vgtk_frames[i].created)
  {
   printf("Frame %d: %s\n", i, vgtk_frames[i].name);
  }
 }
 for(i = 0; i < 400; i++)
 {
  if(vgtk_boxes[i].created)
  {
   printf("Boxes %d: %s\n", i, vgtk_boxes[i].name);
  }
 }
}

void new_vgtk()
{
 system("visualgtk &");
}

void about()
{
 sprintf(temp, "Visual GTK %s (C) 1999 Patrick Lambert - See http://devplanet.fastethernet.net/visualgtk", VERSION);
 msgbox(temp);
}

void save()
{
 int i;
 sprintf(temp, "%s.prj", project_name);
 fd = fopen(temp, "w");
 if(fd==NULL)
 {
  msgbox("Could not open file for saving");
  return;
 }
 sprintf(temp, "name: %s\n", project_name);
 fputs(temp, fd);
 sprintf(temp, "path: %s\n", project_dir);
 fputs(temp, fd);
 fputs("main_text:\n", fd);
 fputs(main_text, fd);
 fputs("\nmain_end_of_text\n", fd);
 fputs("more_includes:\n", fd);
 fputs(more_includes, fd);
 fputs("\nend_of_includes\n", fd);
 for(i = 0; i < 500; i++)
 {
  if(vgtk_callbacks[i].created)
  {
   sprintf(temp, "callback: %d\n", i);
   fputs(temp, fd);
   sprintf(temp, "callback_name: %s\n", vgtk_callbacks[i].name);
   fputs(temp, fd);
   sprintf(temp, "callback_text:\n%s\n", vgtk_callbacks[i].text);
   fputs(temp, fd);
   fputs("\ncallback_end_of_text\n", fd);
  }
 }
 for(i = 0; i < 200; i++)
 {
  if(vgtk_frames[i].created)
  {
   sprintf(temp, "frame: %d\n", i);
   fputs(temp, fd);
   sprintf(temp, "frame_name: %s\n", vgtk_frames[i].name);
   fputs(temp, fd);
   sprintf(temp, "frame_title: %s\n", vgtk_frames[i].title);
   fputs(temp, fd);
   sprintf(temp, "frame_size_x: %d\n", vgtk_frames[i].size_x);
   fputs(temp, fd);
   sprintf(temp, "frame_size_y: %d\n", vgtk_frames[i].size_y);
   fputs(temp, fd);
   sprintf(temp, "frame_pos_x: %d\n", vgtk_frames[i].pos_x);
   fputs(temp, fd);
   sprintf(temp, "frame_pos_y: %d\n", vgtk_frames[i].pos_y);
   fputs(temp, fd);
   sprintf(temp, "frame_signal_destroy: %s\n", vgtk_frames[i].signal_destroy);
   fputs(temp, fd);
   sprintf(temp, "frame_signal_delete_event: %s\n", vgtk_frames[i].signal_delete_event);
   fputs(temp, fd);
  }
 }
 for(i = 0; i < 400; i++)
 {
  if(vgtk_boxes[i].created)
  {
   sprintf(temp, "box: %d\n", i);
   fputs(temp, fd);
   sprintf(temp, "box_name: %s\n", vgtk_boxes[i].name);
   fputs(temp, fd);
   sprintf(temp, "box_parent_win: %s\n", vgtk_boxes[i].parent_win);
   fputs(temp, fd);
   sprintf(temp, "box_parent_box: %s\n", vgtk_boxes[i].parent_box);
   fputs(temp, fd);
   sprintf(temp, "box_size_x: %d\n", vgtk_boxes[i].size_x);
   fputs(temp, fd);
   sprintf(temp, "box_size_y: %d\n", vgtk_boxes[i].size_y);
   fputs(temp, fd);
   sprintf(temp, "box_type: %d\n", vgtk_boxes[i].type);
   fputs(temp, fd);
  }
 }
 for(i = 0; i < 200; i++)
 {
  if(vgtk_buttons[i].created)
  {
   sprintf(temp, "button: %d\n", i);
   fputs(temp, fd);
   sprintf(temp, "button_name: %s\n", vgtk_buttons[i].name);
   fputs(temp, fd);
   sprintf(temp, "button_parent_win: %s\n", vgtk_buttons[i].parent_win);
   fputs(temp, fd);
   sprintf(temp, "button_parent_box: %s\n", vgtk_buttons[i].parent_box);
   fputs(temp, fd);
   sprintf(temp, "button_label: %s\n", vgtk_buttons[i].label);
   fputs(temp, fd);
   sprintf(temp, "button_signal_clicked: %s\n", vgtk_buttons[i].signal_clicked);
   fputs(temp, fd);
  }
 }
 for(i = 0; i < 200; i++)
 {
  if(vgtk_labels[i].created)
  {
   sprintf(temp, "label: %d\n", i);
   fputs(temp, fd);
   sprintf(temp, "label_name: %s\n", vgtk_labels[i].name);
   fputs(temp, fd);
   sprintf(temp, "label_parent_win: %s\n", vgtk_labels[i].parent_win);
   fputs(temp, fd);
   sprintf(temp, "label_parent_box: %s\n", vgtk_labels[i].parent_box);
   fputs(temp, fd);
   sprintf(temp, "label_label: %s\n", vgtk_labels[i].label);
   fputs(temp, fd);
   sprintf(temp, "label_is_var: %d\n", vgtk_labels[i].is_var);
   fputs(temp, fd);
  }
 }
 for(i = 0; i < 200; i++)
 {
  if(vgtk_entries[i].created)
  {
   sprintf(temp, "entry: %d\n", i);
   fputs(temp, fd);
   sprintf(temp, "entry_name: %s\n", vgtk_entries[i].name);
   fputs(temp, fd);
   sprintf(temp, "entry_parent_win: %s\n", vgtk_entries[i].parent_win);
   fputs(temp, fd);
   sprintf(temp, "entry_parent_box: %s\n", vgtk_entries[i].parent_box);
   fputs(temp, fd);
   sprintf(temp, "entry_text: %s\n", vgtk_entries[i].text);
   fputs(temp, fd);
   sprintf(temp, "entry_is_var: %d\n", vgtk_entries[i].is_var);
   fputs(temp, fd);
  }
 }
 for(i = 0; i < 200; i++)
 {
  if(vgtk_text[i].created)
  {
   sprintf(temp, "text: %d\n", i);
   fputs(temp, fd);
   sprintf(temp, "text_name: %s\n", vgtk_text[i].name);
   fputs(temp, fd);
   sprintf(temp, "text_parent_win: %s\n", vgtk_text[i].parent_win);
   fputs(temp, fd);
   sprintf(temp, "text_parent_box: %s\n", vgtk_text[i].parent_box);
   fputs(temp, fd);
   sprintf(temp, "text_initial_text: %s\n", vgtk_text[i].initial_text);
   fputs(temp, fd);
   sprintf(temp, "text_signal_changed: %s\n", vgtk_text[i].signal_changed);
   fputs(temp, fd);
  }
 }

 /*
 WIDGET:
 add here a for, to browse tru all the array, and save all info
 */
 fclose(fd);
}

void CB_kill_win(GtkWidget *window, GtkWidget *event)
{
 int i;
 for(i = 0; i < 200; i++)
 {
  if(widgets_list[i]!=NULL && GTK_LIST(widgets_list[i])!=NULL)
  gtk_list_unselect_all(GTK_LIST(widgets_list[i]));
 }
 if(callbacks_list!=NULL && GTK_LIST(callbacks_list)!=NULL)
 gtk_list_unselect_all(GTK_LIST(callbacks_list));

 gtk_widget_destroy(win);
}

void new_project_start()
{
 strncpy(project_name, gtk_entry_get_text(GTK_ENTRY(e1)), 500);
 strncpy(project_dir, gtk_entry_get_text(GTK_ENTRY(e2)), 500);
 sprintf(temp, "mkdir -p %s", project_dir);
 system(temp);
 chdir(project_dir);
 sprintf(temp, "%s.prj", project_name);
 fd = fopen(temp, "w");
 if(fd==NULL)
 {
  printf("Critical error: Could not write to %s\n", project_dir);
  exit(1);
 }
 sprintf(temp, "name: %s\n", project_name);
 fputs(temp, fd);
 sprintf(temp, "path: %s\n", project_dir);
 fputs(temp, fd);
 fclose(fd);
 strcpy(main_text, "\nint main(int argc, char *argv[])\n{\n\tgtk_init(&argc, &argv);\n\t/* put here the first frame you want to call: */\n\tmake_myframe();\n\tgtk_main();\n\treturn(0);\n}\n");
 gtk_widget_destroy(win);
}

void CB_new_project_click(GtkWidget *w, gint t)
{
 tmp_choice = t;
} 

void CB_new_project(GtkWidget *window, GtkWidget *event)
{
 if(tmp_choice == 0)
 {
  printf("That option is not available yet!");
  exit(1);
 }
 if(tmp_choice == 1) new_project_start();
 if(tmp_choice == 2) open_project();
}

void new_project()
{
 if(GTK_IS_WIDGET(win)) gtk_widget_destroy(win);
 win = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize(GTK_WIDGET(win), 300, 300);
 gtk_signal_connect (GTK_OBJECT (win), "delete_event",
  GTK_SIGNAL_FUNC(CB_exit), &win);
 gtk_window_set_title (GTK_WINDOW (win), "Project Settings");
 gtk_widget_set_uposition (GTK_WIDGET(win), 200, 150);
 gtk_container_border_width (GTK_CONTAINER (win), 0);
 gtk_widget_show(win);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (win), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 label = gtk_label_new ("Welcome to Visual GTK !");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 button = gtk_radio_button_new_with_label (NULL, "Open an existing project");
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(button), TRUE);
 tmp_choice = 2;
 gtk_signal_connect(GTK_OBJECT(button), "toggled",
 (GtkSignalFunc)CB_new_project_click, (gpointer)2);
 gtk_widget_show (button);

 group = gtk_radio_button_group(GTK_RADIO_BUTTON(button));
 button = gtk_radio_button_new_with_label(group, "Start a new project :");
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_signal_connect(GTK_OBJECT(button), "toggled",
 (GtkSignalFunc)CB_new_project_click, (gpointer)1);
 gtk_widget_show (button);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start(GTK_BOX(vbox), hbox, TRUE, TRUE, 0);
 gtk_container_border_width (GTK_CONTAINER (hbox), 2);
 gtk_widget_show (hbox);

 label = gtk_label_new ("  ");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 vbox2 = gtk_vbox_new (FALSE, 0);
 gtk_box_pack_start(GTK_BOX(hbox), vbox2, TRUE, TRUE, 0);
 gtk_container_border_width (GTK_CONTAINER (vbox2), 2);
 gtk_widget_show (vbox2);

 label = gtk_label_new ("New project's name:");
 gtk_box_pack_start (GTK_BOX (vbox2), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e1 = gtk_entry_new();
 gtk_box_pack_start(GTK_BOX(vbox2), e1, TRUE, TRUE, 0);
 gtk_widget_show(e1);

 label = gtk_label_new ("Project directory (full path):");
 gtk_box_pack_start (GTK_BOX (vbox2), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e2 = gtk_entry_new();
 gtk_box_pack_start(GTK_BOX(vbox2), e2, TRUE, TRUE, 0);
 gtk_widget_show(e2);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_new_project), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(vbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
}

void parse_project(char *file)
{
 fd = fopen(file, "r");
 if(fd==NULL)
 {
  printf("Critical error: Could not read %s\n", file);
  exit(1);
 }
 while(fgets(temp, 1000, fd)!=NULL)
 {
  temp[strlen(temp)-1] = ' ';
  if(!strcasecmp(lindex(temp,0),"path:")) strncpy(project_dir, lindex(temp,1), 500);
  if(!strcasecmp(lindex(temp,0),"name:")) strncpy(project_name, lindex(temp,1), 500);
  if(!strcasecmp(lindex(temp,0),"main_text:"))
  {
   while(fgets(temp, 1000, fd)!=NULL)
   {
    if(!strcasecmp(lindex(temp,0),"main_end_of_text\n")) break;
    strcat(main_text, temp);
   }
  }
  if(!strcasecmp(lindex(temp,0),"more_includes:"))
  {
   while(fgets(temp, 1000, fd)!=NULL)
   {
    if(!strcasecmp(lindex(temp,0),"end_of_includes\n")) break;
    strcat(more_includes, temp);
   }
  }
  if(!strcasecmp(lindex(temp,0),"callback:"))
  {
   cur_w = atoi(lindex(temp,1));
   vgtk_callbacks[cur_w].created = 1;
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_callbacks[cur_w].name, lindex(temp,1), 500);
   strcpy(vgtk_callbacks[cur_w].text, "");
   fgets(temp, 1000, fd);
   while(fgets(temp, 1000, fd)!=NULL)
   {
    if(!strcasecmp("callback_end_of_text\n", temp)) break;
    strcat(vgtk_callbacks[cur_w].text, temp);
   }
   create_new_callback();
  }
  if(!strcasecmp(lindex(temp,0),"frame:"))
  {
   cur_w = atoi(lindex(temp,1));
   vgtk_frames[cur_w].created = 1;
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_frames[cur_w].name, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   if(lindex(temp,1)!=NULL)
   strncpy(vgtk_frames[cur_w].title, lrange(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   vgtk_frames[cur_w].size_x = atoi(lindex(temp,1));
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   vgtk_frames[cur_w].size_y = atoi(lindex(temp,1));
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   vgtk_frames[cur_w].pos_x = atoi(lindex(temp,1));
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   vgtk_frames[cur_w].pos_y = atoi(lindex(temp,1));
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   if(lindex(temp,1)!=NULL)
   strncpy(vgtk_frames[cur_w].signal_destroy, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   if(lindex(temp,1)!=NULL)
   strncpy(vgtk_frames[cur_w].signal_delete_event, lindex(temp,1), 500);
   create_new_frame();
#ifdef TRY_IT
   make_frame();
#endif
  }
  if(!strcasecmp(lindex(temp,0),"box:"))
  {
   cur_w = atoi(lindex(temp,1));
   vgtk_boxes[cur_w].created = 1;
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_boxes[cur_w].name, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_boxes[cur_w].parent_win, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_boxes[cur_w].parent_box, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   vgtk_boxes[cur_w].size_x = atoi(lindex(temp,1));
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   vgtk_boxes[cur_w].size_y = atoi(lindex(temp,1));
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   vgtk_boxes[cur_w].type = atoi(lindex(temp,1));
   create_new_box();
#ifdef TRY_IT
   make_box();
#endif
  }
  if(!strcasecmp(lindex(temp,0),"button:"))
  {
   cur_w = atoi(lindex(temp,1));
   vgtk_buttons[cur_w].created = 1;
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_buttons[cur_w].name, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_buttons[cur_w].parent_win, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_buttons[cur_w].parent_box, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   if(lindex(temp,1)!=NULL)
   strncpy(vgtk_buttons[cur_w].label, lrange(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   if(lindex(temp,1)!=NULL)
   strncpy(vgtk_buttons[cur_w].signal_clicked, lindex(temp,1), 500);
   create_new_button();
#ifdef TRY_IT
   make_button();
#endif
  }
  if(!strcasecmp(lindex(temp,0),"label:"))
  {
   cur_w = atoi(lindex(temp,1));
   vgtk_labels[cur_w].created = 1;
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_labels[cur_w].name, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_labels[cur_w].parent_win, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_labels[cur_w].parent_box, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   if(lindex(temp,1)!=NULL)
   strncpy(vgtk_labels[cur_w].label, lrange(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   vgtk_labels[cur_w].is_var = atoi(lindex(temp,1));
   create_new_label();
#ifdef TRY_IT
   make_label();
#endif
  }
  if(!strcasecmp(lindex(temp,0),"entry:"))
  {
   cur_w = atoi(lindex(temp,1));
   vgtk_entries[cur_w].created = 1;
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_entries[cur_w].name, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_entries[cur_w].parent_win, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_entries[cur_w].parent_box, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   if(lindex(temp,1)!=NULL)
   strncpy(vgtk_entries[cur_w].text, lrange(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   vgtk_entries[cur_w].is_var = atoi(lindex(temp,1));
   create_new_entry();
#ifdef TRY_IT
   make_entry();
#endif
  }
  if(!strcasecmp(lindex(temp,0),"text:"))
  {
   cur_w = atoi(lindex(temp,1));
   vgtk_text[cur_w].created = 1;
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_text[cur_w].name, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_text[cur_w].parent_win, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   strncpy(vgtk_text[cur_w].parent_box, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   if(lindex(temp,1)!=NULL)
   strncpy(vgtk_text[cur_w].initial_text, lindex(temp,1), 500);
   fgets(temp, 1000, fd);
   temp[strlen(temp)-1] = ' ';
   if(lindex(temp,1)!=NULL)
   strncpy(vgtk_text[cur_w].signal_changed, lindex(temp,1), 500);
   create_new_text();
#ifdef TRY_IT
   make_text();
#endif
  }

 /*
 WIDGET:
 add here the parsing stuff to read info
 */
 }
 fclose(fd);
 chdir(project_dir);
}

void CB_open_project(GtkWidget *window, GtkFileSelection *fs)
{
 parse_project(gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)));
 gtk_widget_destroy(win);
}

void open_project()
{
 if(GTK_IS_WIDGET(win)) gtk_widget_destroy(win);
 win = gtk_file_selection_new("Select .prj Project File");
 gtk_signal_connect (GTK_OBJECT (win), "delete_event",
 GTK_SIGNAL_FUNC(CB_kill_win), &win);
 gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION(win)->ok_button),
 "clicked", GTK_SIGNAL_FUNC(CB_open_project), win);
 gtk_signal_connect (GTK_OBJECT(GTK_FILE_SELECTION(win)->cancel_button),
 "clicked", GTK_SIGNAL_FUNC(CB_kill_win), &win);
 gtk_widget_set_uposition (win, 200, 100);
 gtk_file_selection_hide_fileop_buttons(GTK_FILE_SELECTION(win));
 gtk_widget_show (win);
}

void  new_callback()
{
 int i;
 for(i = 0; i < 500; i++)
 {
  if(!vgtk_callbacks[i].created) break;
 }
 if(vgtk_callbacks[i].created)
 {
  msgbox("Maximum number of callbacks reached");
  return;
 }
 cur_w = i;
 callback_settings(TRUE);
}

void create_new_callback()
{
 char *string;
 label = gtk_label_new(vgtk_callbacks[cur_w].name);
 list_item = gtk_list_item_new_with_label(vgtk_callbacks[cur_w].name);
 gtk_container_add(GTK_CONTAINER(callbacks_list), list_item);
 gtk_widget_show(list_item);
 gtk_label_get(GTK_LABEL(label), &string);
 gtk_object_set_data(GTK_OBJECT(list_item), list_item_data_key, string);
}

void CB_callback_settings(gint create, GtkWidget *event)
{
 char *alltext;
 vgtk_callbacks[cur_w].created = 1;
 if(callbacks_list!=NULL && GTK_LIST(callbacks_list)!=NULL)
 gtk_list_unselect_all(GTK_LIST(callbacks_list));
 strncpy(vgtk_callbacks[cur_w].name, gtk_entry_get_text(GTK_ENTRY(e1)), 500);
 alltext = gtk_editable_get_chars(GTK_EDITABLE (text), 0,
 gtk_text_get_length(GTK_TEXT(text)));
 memcpy(vgtk_callbacks[cur_w].text, alltext, 4000);
 g_free(alltext);
 if(GTK_IS_WIDGET(win)) gtk_widget_destroy(win);
 if(create) create_new_callback();
}

void CB_callback_remove(GtkWidget *window, GtkWidget *event)
{
 GList *clear_list = NULL;
 GList *work = NULL;

 vgtk_callbacks[cur_w].created = 0;
 strcpy(vgtk_callbacks[cur_w].name, "");
 strcpy(vgtk_callbacks[cur_w].text, "");

 for (work = GTK_LIST(callbacks_list)->selection; work; work = work->next)
 clear_list = g_list_prepend (clear_list, work->data);

 clear_list = g_list_reverse(clear_list);
 gtk_list_remove_items(GTK_LIST(callbacks_list), clear_list);
 g_list_free(clear_list);

 gtk_widget_destroy(win);
}

void CB_callback_common(GtkWidget *w, GtkWidget *e)
{
 sprintf(temp, "\n%s\n", gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(e0)->entry)));

 gtk_text_insert(GTK_TEXT(text), NULL, NULL, NULL, temp, -1);
}

void callback_settings(int create)
{
 GList *cbitems = NULL;
 if(GTK_IS_WIDGET(win)) gtk_widget_destroy(win);
 win = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize(GTK_WIDGET(win), 400, 300);
 gtk_signal_connect (GTK_OBJECT (win), "delete_event",
  GTK_SIGNAL_FUNC(CB_kill_win), &win);
 gtk_window_set_title (GTK_WINDOW (win), "Callback");
 gtk_widget_set_uposition (GTK_WIDGET(win), 100, 150);
 gtk_container_border_width (GTK_CONTAINER (win), 0);
 gtk_widget_show(win);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (win), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 cbitems = g_list_append(cbitems, "gtk_entry_get_text(GTK_ENTRY(widget));");
 cbitems = g_list_append(cbitems, "gtk_editable_get_chars(GTK_EDITABLE(widget), start_pos, end_pos);");
 cbitems = g_list_append(cbitems, "gtk_widget_destroy(widget);");
 cbitems = g_list_append(cbitems, "gtk_text_freeze(GTK_TEXT(widget));");
 cbitems = g_list_append(cbitems, "gtk_text_insert(GTK_TEXT(widget), NULL, NULL, NULL, string, -1);");
 cbitems = g_list_append(cbitems, "gtk_text_thaw(GTK_TEXT(widget));");

 e0 = gtk_combo_new();
 gtk_combo_set_popdown_strings(GTK_COMBO(e0), cbitems);
 gtk_entry_set_text(GTK_ENTRY(GTK_COMBO(e0)->entry), "Common GTK functions");
 gtk_signal_connect(GTK_OBJECT(GTK_COMBO(e0)->entry), "changed",
 GTK_SIGNAL_FUNC(CB_callback_common), NULL);
 gtk_box_pack_start(GTK_BOX(vbox), e0, TRUE, TRUE, 0);
 gtk_widget_show(e0);

 label = gtk_label_new ("Function unique name (1 word only):");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e1 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e1), vgtk_callbacks[cur_w].name);
 gtk_box_pack_start(GTK_BOX(vbox), e1, TRUE, TRUE, 0);
 if(!create) gtk_widget_set_sensitive(e1, FALSE);
 gtk_widget_show(e1);

 table = gtk_table_new (2, 2, FALSE);
 gtk_table_set_row_spacing (GTK_TABLE (table), 0, 2);
 gtk_table_set_col_spacing (GTK_TABLE (table), 0, 2);
 gtk_box_pack_start (GTK_BOX (vbox), table, TRUE, TRUE, 0);
 gtk_widget_show (table);

 text = gtk_text_new(NULL, NULL);
 gtk_text_set_editable (GTK_TEXT (text), TRUE);
 gtk_text_set_word_wrap(GTK_TEXT (text), TRUE);
 gtk_table_attach_defaults (GTK_TABLE (table), text, 0, 1, 0, 1);
 gtk_widget_show (text);

 gtk_text_freeze(GTK_TEXT(text));
 gtk_widget_realize(text);
 gtk_text_insert (GTK_TEXT (text), NULL, NULL, NULL, vgtk_callbacks[cur_w].text, -1);
 gtk_text_thaw(GTK_TEXT(text));

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
 gtk_widget_show(hbox);

 button = gtk_button_new_with_label ("Remove");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_callback_remove), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("Cancel");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_kill_win), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_callback_settings), (gpointer)create);
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
}

void callbacks_click(char *str)
{
 int i;
 for(i = 0; i < 500; i++)
 {
  if(!strcasecmp(str, vgtk_callbacks[i].name))
  {
   cur_w = i;
   callback_settings(0);
   return;
  }
 }
}

void CB_callbacks_click(GtkWidget *window, GtkWidget *event)
{
 GList *dlist;
 dlist = GTK_LIST(callbacks_list)->selection;
 while (dlist)
 {
  GtkObject *list_item;
  gchar *item_data_string;
  list_item = GTK_OBJECT(dlist->data);
  item_data_string = gtk_object_get_data(list_item, list_item_data_key);
  callbacks_click(g_strdup(item_data_string));
  dlist = dlist->next;
 }
}

void widgets_click(char *str)
{
 int i;
 if(!strcasecmp(str, vgtk_frames[cur_l].name))
 {
  frame_settings(0);
  return;
 }
 for(i=0; i < 400; i++)
 {
  if(!strcasecmp(str, vgtk_boxes[i].name))
  {
   cur_w = i;
   box_settings(0);
   return;
  }
 }
 for(i=0; i < 200; i++)
 {
  if(!strcasecmp(str, vgtk_buttons[i].name))
  {
   cur_w = i;
   button_settings(0);
   return;
  }
 }
 for(i=0; i < 200; i++)
 {
  if(!strcasecmp(str, vgtk_labels[i].name))
  {
   cur_w = i;
   label_settings(0);
   return;
  }
 }
 for(i=0; i < 200; i++)
 {
  if(!strcasecmp(str, vgtk_entries[i].name))
  {
   cur_w = i;
   entry_settings(0);
   return;
  }
 }
 for(i=0; i < 200; i++)
 {
  if(!strcasecmp(str, vgtk_text[i].name))
  {
   cur_w = i;
   text_settings(0);
   return;
  }
 }

 /*
 WIDGET:
 add here a loop to go tru the whole array and check if the name is yours,
 then call widget_settings(0)
 */
}

void CB_widgets_click(GtkWidget *window, GtkWidget *event)
{
 int i;
 GList *dlist;
 for(i=0; i < 200; i++)
 {
  if(widgets_list[i]!=NULL)
  {
   dlist = GTK_LIST(widgets_list[i])->selection;
   while (dlist)
   {
    GtkObject *list_item;
    gchar *item_data_string;
    list_item = GTK_OBJECT(dlist->data);
    item_data_string = gtk_object_get_data(list_item, list_item_data_key);
    cur_w = i;
    cur_l = i;
    widgets_click(g_strdup(item_data_string));
    dlist = dlist->next;
   }
  }
 }
}

void CB_frame_remove(GtkWidget *window, GtkWidget *event)
{
 GList *clear_list = NULL;
 GList *work = NULL;

 vgtk_frames[cur_w].created = 0;
 strcpy(vgtk_frames[cur_w].name, "");
 strcpy(vgtk_frames[cur_w].signal_destroy, "");
 strcpy(vgtk_frames[cur_w].signal_delete_event, "");

 for (work = GTK_LIST(widgets_list[cur_w])->selection; work; work = work->next)
 clear_list = g_list_prepend (clear_list, work->data);

 clear_list = g_list_reverse(clear_list);
 gtk_list_remove_items(GTK_LIST(widgets_list[cur_w]), clear_list);
 g_list_free(clear_list);

 if(GTK_IS_WIDGET(vgtk_frames[cur_w].widget))
 {
  gtk_widget_destroy(vgtk_frames[cur_w].widget);
  gtk_widget_destroy(vgtk_frames[cur_w].vbox);
 }
 gtk_widget_destroy(win);
}

void new_frame()
{
 int i;
 for(i = 0; i < 200; i++)
 {
  if(!vgtk_frames[i].created) break;
 }
 if(vgtk_frames[i].created)
 {
  msgbox("Maximum number of frames reached");
  return;
 }
 cur_w = i;
 vgtk_frames[i].pos_x = 10;
 vgtk_frames[i].pos_y = 10;
 frame_settings(TRUE);
}

void CB_frame_settings(gint create, GtkWidget *event)
{
 vgtk_frames[cur_w].created = 1;
 if(widgets_list[cur_l]!=NULL && GTK_LIST(widgets_list[cur_l])!=NULL)
 gtk_list_unselect_all(GTK_LIST(widgets_list[cur_l]));
 strncpy(vgtk_frames[cur_w].name, gtk_entry_get_text(GTK_ENTRY(e1)), 500);
 strncpy(vgtk_frames[cur_w].title, gtk_entry_get_text(GTK_ENTRY(e8)), 500);
 strncpy(vgtk_frames[cur_w].signal_destroy, gtk_entry_get_text(GTK_ENTRY(e6)), 500);
 strncpy(vgtk_frames[cur_w].signal_delete_event, gtk_entry_get_text(GTK_ENTRY(e7)), 500);
 vgtk_frames[cur_w].size_x = atoi(gtk_entry_get_text(GTK_ENTRY(e2)));
 vgtk_frames[cur_w].size_y = atoi(gtk_entry_get_text(GTK_ENTRY(e3)));
 vgtk_frames[cur_w].pos_x = atoi(gtk_entry_get_text(GTK_ENTRY(e4)));
 vgtk_frames[cur_w].pos_y = atoi(gtk_entry_get_text(GTK_ENTRY(e5)));
 if(create) create_new_frame();
#ifdef TRY_IT
 make_frame();
#endif
 gtk_widget_destroy(win);
}

void frame_settings(int create)
{
 if(GTK_IS_WIDGET(win)) gtk_widget_destroy(win);
 win = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize(GTK_WIDGET(win), 400, 300);
 gtk_signal_connect (GTK_OBJECT (win), "delete_event",
  GTK_SIGNAL_FUNC(CB_kill_win), &win);
 gtk_window_set_title (GTK_WINDOW (win), "Frame");
 gtk_widget_set_uposition (GTK_WIDGET(win), 100, 150);
 gtk_container_border_width (GTK_CONTAINER (win), 0);
 gtk_widget_show(win);

 vbox2 = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (win), vbox2);
 gtk_container_border_width (GTK_CONTAINER (vbox2), 2);
 gtk_widget_show (vbox2);

 notebook = gtk_notebook_new();
 gtk_notebook_set_tab_pos(GTK_NOTEBOOK(notebook), GTK_POS_TOP);
 gtk_box_pack_start(GTK_BOX(vbox2), notebook, TRUE, TRUE, 0);
 gtk_widget_set_usize(GTK_WIDGET(notebook), 350, 400);
 gtk_notebook_set_scrollable(GTK_NOTEBOOK(notebook), TRUE);
 gtk_widget_show(notebook);

 frame = gtk_frame_new("Settings");
 gtk_container_border_width(GTK_CONTAINER(frame), 10);
 gtk_widget_show(frame);

 label = gtk_label_new("Settings");
 gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (frame), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 label = gtk_label_new ("Widget unique name (1 word only):");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e1 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e1), vgtk_frames[cur_w].name);
 gtk_box_pack_start(GTK_BOX(vbox), e1, TRUE, TRUE, 0);
 if(!create)  gtk_widget_set_sensitive(e1, FALSE);
 gtk_widget_show(e1);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Title:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e8 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e8), vgtk_frames[cur_w].title);
 gtk_box_pack_start(GTK_BOX(hbox), e8, TRUE, TRUE, 0);
 gtk_widget_show(e8);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("X size:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e2 = gtk_entry_new();
 sprintf(temp, "%d", vgtk_frames[cur_w].size_x);
 gtk_entry_set_text(GTK_ENTRY(e2), temp);
 gtk_box_pack_start(GTK_BOX(hbox), e2, TRUE, TRUE, 0);
 gtk_widget_show(e2);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Y size:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e3 = gtk_entry_new();
 sprintf(temp, "%d", vgtk_frames[cur_w].size_y);
 gtk_entry_set_text(GTK_ENTRY(e3), temp);
 gtk_box_pack_start(GTK_BOX(hbox), e3, TRUE, TRUE, 0);
 gtk_widget_show(e3);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("X position:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e4 = gtk_entry_new();
 sprintf(temp, "%d", vgtk_frames[cur_w].pos_x);
 gtk_entry_set_text(GTK_ENTRY(e4), temp);
 gtk_box_pack_start(GTK_BOX(hbox), e4, TRUE, TRUE, 0);
 gtk_widget_show(e4);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Y position:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e5 = gtk_entry_new();
 sprintf(temp, "%d", vgtk_frames[cur_w].pos_y);
 gtk_entry_set_text(GTK_ENTRY(e5), temp);
 gtk_box_pack_start(GTK_BOX(hbox), e5, TRUE, TRUE, 0);
 gtk_widget_show(e5);

 frame = gtk_frame_new("Callback functions");
 gtk_container_border_width(GTK_CONTAINER(frame), 10);
 gtk_widget_show(frame);

 label = gtk_label_new("Callbacks");
 gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (frame), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("destroy:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e6 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e6), vgtk_frames[cur_w].signal_destroy);
 gtk_box_pack_start(GTK_BOX(hbox), e6, TRUE, TRUE, 0);
 gtk_widget_show(e6);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("delete_event:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e7 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e7), vgtk_frames[cur_w].signal_delete_event);
 gtk_box_pack_start(GTK_BOX(hbox), e7, TRUE, TRUE, 0);
 gtk_widget_show(e7);

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start(GTK_BOX(vbox2), hbox, FALSE, FALSE, 0);
 gtk_widget_show(hbox);

 button = gtk_button_new_with_label ("Remove");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_frame_remove), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("Cancel");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_kill_win), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_frame_settings), (gpointer)create);
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
}

void create_new_frame()
{
 char *string;
 frame = gtk_frame_new("Widgets for this frame");
 gtk_container_border_width(GTK_CONTAINER(frame), 10);
 gtk_widget_show(frame);

 label = gtk_label_new(vgtk_frames[cur_w].name);
 gtk_notebook_append_page(GTK_NOTEBOOK(mnotebook), frame, label);

 vbox = gtk_vbox_new(FALSE, 0);
 gtk_container_add(GTK_CONTAINER(frame), vbox);
 gtk_container_border_width(GTK_CONTAINER(vbox), 5);
 gtk_widget_show(vbox);

 scrolled_window = gtk_scrolled_window_new(NULL, NULL);
 gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window),
 GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
 gtk_container_add(GTK_CONTAINER(vbox), scrolled_window);
 gtk_widget_set_usize(GTK_WIDGET(scrolled_window), 350, 450);
 gtk_widget_show(scrolled_window);
 
 widgets_list[cur_w] = gtk_list_new();
 gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(scrolled_window),
 widgets_list[cur_w]);
 gtk_widget_show(widgets_list[cur_w]);
 gtk_container_set_focus_vadjustment(GTK_CONTAINER(widgets_list[cur_w]),
 gtk_scrolled_window_get_vadjustment(GTK_SCROLLED_WINDOW(scrolled_window)));
 gtk_signal_connect(GTK_OBJECT(widgets_list[cur_w]), "selection_changed",
 GTK_SIGNAL_FUNC(CB_widgets_click), NULL);

 label = gtk_label_new(vgtk_frames[cur_w].name);
 list_item = gtk_list_item_new_with_label(vgtk_frames[cur_w].name);
 gtk_container_add(GTK_CONTAINER(widgets_list[cur_w]), list_item);
 gtk_widget_show(list_item);
 gtk_label_get(GTK_LABEL(label), &string);
 gtk_object_set_data(GTK_OBJECT(list_item), list_item_data_key, string);
}

void make_frame()
{
 if(!GTK_IS_WIDGET(vgtk_frames[cur_w].widget))
 {
  vgtk_frames[cur_w].widget = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  vgtk_frames[cur_w].vbox = gtk_vbox_new (FALSE, 0);
  gtk_container_add (GTK_CONTAINER (vgtk_frames[cur_w].widget), vgtk_frames[cur_w].vbox);
  gtk_container_border_width (GTK_CONTAINER (vgtk_frames[cur_w].vbox), 2);
  gtk_widget_show (vgtk_frames[cur_w].vbox);
 }
 gtk_widget_set_usize(GTK_WIDGET(vgtk_frames[cur_w].widget), vgtk_frames[cur_w].size_x, vgtk_frames[cur_w].size_y);
 gtk_widget_set_uposition(GTK_WIDGET(vgtk_frames[cur_w].widget), vgtk_frames[cur_w].pos_x, vgtk_frames[cur_w].pos_y);
 gtk_window_set_title(GTK_WINDOW(vgtk_frames[cur_w].widget), vgtk_frames[cur_w].title);
 gtk_signal_connect(GTK_OBJECT(vgtk_frames[cur_w].widget), "destroy",
 GTK_SIGNAL_FUNC (gtk_widget_destroyed), &vgtk_frames[cur_w].widget);
 gtk_widget_show(vgtk_frames[cur_w].widget);
}

void new_box()
{
 int i;
 for(i = 0; i < 400; i++)
 {
  if(!vgtk_boxes[i].created) break;
 }
 if(vgtk_boxes[i].created)
 {
  msgbox("Maximum number of boxes reached");
  return;
 }
 cur_w = i;
 box_settings(TRUE);
}

void box_settings(int create)
{
 if(GTK_IS_WIDGET(win)) gtk_widget_destroy(win);
 win = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize(GTK_WIDGET(win), 400, 300);
 gtk_signal_connect (GTK_OBJECT (win), "delete_event",
  GTK_SIGNAL_FUNC(CB_kill_win), &win);
 gtk_window_set_title (GTK_WINDOW (win), "Box");
 gtk_widget_set_uposition (GTK_WIDGET(win), 100, 150);
 gtk_container_border_width (GTK_CONTAINER (win), 0);
 gtk_widget_show(win);

 vbox2 = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (win), vbox2);
 gtk_container_border_width (GTK_CONTAINER (vbox2), 2);
 gtk_widget_show (vbox2);

 notebook = gtk_notebook_new();
 gtk_notebook_set_tab_pos(GTK_NOTEBOOK(notebook), GTK_POS_TOP);
 gtk_box_pack_start(GTK_BOX(vbox2), notebook, TRUE, TRUE, 0);
 gtk_widget_set_usize(GTK_WIDGET(notebook), 350, 400);
 gtk_notebook_set_scrollable(GTK_NOTEBOOK(notebook), TRUE);
 gtk_widget_show(notebook);

 frame = gtk_frame_new("Settings");
 gtk_container_border_width(GTK_CONTAINER(frame), 10);
 gtk_widget_show(frame);

 label = gtk_label_new("Settings");
 gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (frame), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 label = gtk_label_new ("Widget unique name (1 word only):");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e1 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e1), vgtk_boxes[cur_w].name);
 gtk_box_pack_start(GTK_BOX(vbox), e1, TRUE, TRUE, 0);
 if(!create) gtk_widget_set_sensitive(e1, FALSE);
 gtk_widget_show(e1);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Parent frame:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e2 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e2), vgtk_boxes[cur_w].parent_win);
 gtk_box_pack_start(GTK_BOX(hbox), e2, TRUE, TRUE, 0);
 gtk_widget_show(e2);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Parent box:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e3 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e3), vgtk_boxes[cur_w].parent_box);
 gtk_box_pack_start(GTK_BOX(hbox), e3, TRUE, TRUE, 0);
 gtk_widget_show(e3);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("X size:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e7 = gtk_entry_new();
 sprintf(temp, "%d", vgtk_boxes[cur_w].size_x);
 gtk_entry_set_text(GTK_ENTRY(e7), temp);
 gtk_box_pack_start(GTK_BOX(hbox), e7, TRUE, TRUE, 0);
 gtk_widget_show(e7);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Y size:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e8 = gtk_entry_new();
 sprintf(temp, "%d", vgtk_boxes[cur_w].size_y);
 gtk_entry_set_text(GTK_ENTRY(e8), temp);
 gtk_box_pack_start(GTK_BOX(hbox), e8, TRUE, TRUE, 0);
 gtk_widget_show(e8);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Type (0=hor, 1=ver, 2=buttons):");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e4 = gtk_entry_new();
 sprintf(temp, "%d", vgtk_boxes[cur_w].type);
 gtk_entry_set_text(GTK_ENTRY(e4), temp);
 gtk_box_pack_start(GTK_BOX(hbox), e4, TRUE, TRUE, 0);
 gtk_widget_show(e4);

 frame = gtk_frame_new("Callback functions");
 gtk_container_border_width(GTK_CONTAINER(frame), 10);
 gtk_widget_show(frame);

 label = gtk_label_new("Callbacks");
 gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (frame), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start(GTK_BOX(vbox2), hbox, FALSE, FALSE, 0);
 gtk_widget_show(hbox);

 button = gtk_button_new_with_label ("Remove");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_box_remove), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("Cancel");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_kill_win), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_box_settings), (gpointer)create);
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
}

void CB_box_remove(GtkWidget *window, GtkWidget *event)
{
 GList *clear_list = NULL;
 GList *work = NULL;

 vgtk_boxes[cur_w].created = 0;
 strcpy(vgtk_boxes[cur_w].name, "");
 strcpy(vgtk_boxes[cur_w].parent_win, "");
 strcpy(vgtk_boxes[cur_w].parent_box, "");

 for (work = GTK_LIST(widgets_list[cur_l])->selection; work; work = work->next)
 clear_list = g_list_prepend (clear_list, work->data);

 clear_list = g_list_reverse(clear_list);
 gtk_list_remove_items(GTK_LIST(widgets_list[cur_l]), clear_list);
 g_list_free(clear_list);

 if(GTK_IS_WIDGET(vgtk_boxes[cur_w].widget))
 {
  gtk_widget_destroy(vgtk_boxes[cur_w].widget);
 }
 gtk_widget_destroy(win);
}

void CB_box_settings(gint create, GtkWidget *event)
{
 vgtk_boxes[cur_w].created = 1;
 if(widgets_list[cur_l]!=NULL && GTK_LIST(widgets_list[cur_l])!=NULL)
 gtk_list_unselect_all(GTK_LIST(widgets_list[cur_l]));
 strncpy(vgtk_boxes[cur_w].name, gtk_entry_get_text(GTK_ENTRY(e1)), 500);
 strncpy(vgtk_boxes[cur_w].parent_win, gtk_entry_get_text(GTK_ENTRY(e2)), 500);
 strncpy(vgtk_boxes[cur_w].parent_box, gtk_entry_get_text(GTK_ENTRY(e3)), 500);
vgtk_boxes[cur_w].size_x = atoi(gtk_entry_get_text(GTK_ENTRY(e7)));
vgtk_boxes[cur_w].size_y = atoi(gtk_entry_get_text(GTK_ENTRY(e8)));
 vgtk_boxes[cur_w].type = atoi(gtk_entry_get_text(GTK_ENTRY(e4)));
 if(create) create_new_box();
#ifdef TRY_IT
 make_box();
#endif
 gtk_widget_destroy(win);
}

void make_box()
{
 int i;
 for(i=0; i<200; i++)
 {
  if(!strcmp(vgtk_boxes[cur_w].parent_win, vgtk_frames[i].name))
  {
   if(!GTK_IS_WIDGET(vgtk_frames[i].widget)) return;
  }
 }
 if(!GTK_IS_WIDGET(vgtk_boxes[cur_w].widget))
 {
  if(vgtk_boxes[cur_w].type==1)
  vgtk_boxes[cur_w].widget = gtk_vbox_new(FALSE, 0);
  if(vgtk_boxes[cur_w].type==0)
  vgtk_boxes[cur_w].widget = gtk_hbox_new(FALSE, 0);
  if(vgtk_boxes[cur_w].type==2)
  {
   vgtk_boxes[cur_w].widget = gtk_hbutton_box_new();
   gtk_button_box_set_layout(GTK_BUTTON_BOX(vgtk_boxes[cur_w].widget), GTK_BUTTONBOX_SPREAD);
   gtk_button_box_set_spacing(GTK_BUTTON_BOX(vgtk_boxes[cur_w].widget), 5);
  }
 }
 gtk_widget_set_usize(GTK_WIDGET(vgtk_boxes[cur_w].widget), vgtk_boxes[cur_w].size_x, vgtk_boxes[cur_w].size_y);
 for(i=0; i<200; i++)
 {
  sprintf(temp, "%s_vbox", vgtk_frames[i].name);
  if(!strcmp(temp, vgtk_boxes[cur_w].parent_box))
  {
   gtk_box_pack_start(GTK_BOX(vgtk_frames[i].vbox), vgtk_boxes[cur_w].widget, TRUE, TRUE, 0);
   break;
  }
 }
 for(i=0; i<400; i++)
 {
  if(!strcmp(vgtk_boxes[i].name, vgtk_boxes[cur_w].parent_box))
  {
   gtk_box_pack_start(GTK_BOX(vgtk_boxes[i].widget), vgtk_boxes[cur_w].widget, TRUE, TRUE, 0);
   break;
  }
 }
 gtk_widget_show(vgtk_boxes[cur_w].widget);
}

void create_new_box()
{
 char *string;
 int i;
 for(i=0; i<200; i++)
 {
  if(!strcasecmp(vgtk_frames[i].name, vgtk_boxes[cur_w].parent_win))
  {
   label = gtk_label_new(vgtk_boxes[cur_w].name);
   list_item = gtk_list_item_new_with_label(vgtk_boxes[cur_w].name);
   gtk_container_add(GTK_CONTAINER(widgets_list[i]), list_item);
   gtk_widget_show(list_item);
   gtk_label_get(GTK_LABEL(label), &string);
   gtk_object_set_data(GTK_OBJECT(list_item), list_item_data_key, string);
  }
 }
}

void new_button()
{
 int i;
 for(i = 0; i < 200; i++)
 {
  if(!vgtk_buttons[i].created) break;
 }
 if(vgtk_buttons[i].created)
 {
  msgbox("Maximum number of buttons reached");
  return;
 }
 cur_w = i;
 button_settings(TRUE);
}

void button_settings(int create)
{
 if(GTK_IS_WIDGET(win)) gtk_widget_destroy(win);
 win = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize(GTK_WIDGET(win), 400, 300);
 gtk_signal_connect (GTK_OBJECT (win), "delete_event",
  GTK_SIGNAL_FUNC(CB_kill_win), &win);
 gtk_window_set_title (GTK_WINDOW (win), "Button");
 gtk_widget_set_uposition (GTK_WIDGET(win), 100, 150);
 gtk_container_border_width (GTK_CONTAINER (win), 0);
 gtk_widget_show(win);

 vbox2 = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (win), vbox2);
 gtk_container_border_width (GTK_CONTAINER (vbox2), 2);
 gtk_widget_show (vbox2);

 notebook = gtk_notebook_new();
 gtk_notebook_set_tab_pos(GTK_NOTEBOOK(notebook), GTK_POS_TOP);
 gtk_box_pack_start(GTK_BOX(vbox2), notebook, TRUE, TRUE, 0);
 gtk_widget_set_usize(GTK_WIDGET(notebook), 350, 400);
 gtk_notebook_set_scrollable(GTK_NOTEBOOK(notebook), TRUE);
 gtk_widget_show(notebook);

 frame = gtk_frame_new("Settings");
 gtk_container_border_width(GTK_CONTAINER(frame), 10);
 gtk_widget_show(frame);

 label = gtk_label_new("Settings");
 gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (frame), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 label = gtk_label_new ("Widget unique name (1 word only):");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e1 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e1), vgtk_buttons[cur_w].name);
 gtk_box_pack_start(GTK_BOX(vbox), e1, TRUE, TRUE, 0);
 if(!create) gtk_widget_set_sensitive(e1, FALSE);
 gtk_widget_show(e1);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Parent frame:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e2 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e2), vgtk_buttons[cur_w].parent_win);
 gtk_box_pack_start(GTK_BOX(hbox), e2, TRUE, TRUE, 0);
 gtk_widget_show(e2);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Parent box:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e3 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e3), vgtk_buttons[cur_w].parent_box);
 gtk_box_pack_start(GTK_BOX(hbox), e3, TRUE, TRUE, 0);
 gtk_widget_show(e3);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Button label:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e4 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e4), vgtk_buttons[cur_w].label);
 gtk_box_pack_start(GTK_BOX(hbox), e4, TRUE, TRUE, 0);
 gtk_widget_show(e4);

 frame = gtk_frame_new("Callback functions");
 gtk_container_border_width(GTK_CONTAINER(frame), 10);
 gtk_widget_show(frame);

 label = gtk_label_new("Callbacks");
 gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (frame), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Clicked:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e5 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e5), vgtk_buttons[cur_w].signal_clicked);
 gtk_box_pack_start(GTK_BOX(hbox), e5, TRUE, TRUE, 0);
 gtk_widget_show(e5);

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start(GTK_BOX(vbox2), hbox, FALSE, FALSE, 0);
 gtk_widget_show(hbox);

 button = gtk_button_new_with_label ("Remove");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_button_remove), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("Cancel");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_kill_win), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_button_settings), (gpointer)create);
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
}

void CB_button_settings(gint create, GtkWidget *event)
{
 vgtk_buttons[cur_w].created = 1;
 if(widgets_list[cur_l]!=NULL && GTK_LIST(widgets_list[cur_l])!=NULL)
 gtk_list_unselect_all(GTK_LIST(widgets_list[cur_l]));
 strncpy(vgtk_buttons[cur_w].name, gtk_entry_get_text(GTK_ENTRY(e1)), 500);
 strncpy(vgtk_buttons[cur_w].parent_win, gtk_entry_get_text(GTK_ENTRY(e2)), 500);
 strncpy(vgtk_buttons[cur_w].parent_box, gtk_entry_get_text(GTK_ENTRY(e3)), 500);
 strncpy(vgtk_buttons[cur_w].label, gtk_entry_get_text(GTK_ENTRY(e4)), 500);
 strncpy(vgtk_buttons[cur_w].signal_clicked, gtk_entry_get_text(GTK_ENTRY(e5)), 500);
 if(create) create_new_button();
#ifdef TRY_IT
 make_button();
#endif
 gtk_widget_destroy(win);
}

void make_button()
{
 int i;
 for(i=0; i<200; i++)
 {
  if(!strcmp(vgtk_buttons[cur_w].parent_win, vgtk_frames[i].name))
  {
   if(!GTK_IS_WIDGET(vgtk_frames[i].widget)) return;
  }
 }
 if(!GTK_IS_WIDGET(vgtk_buttons[cur_w].widget))
 {
  vgtk_buttons[cur_w].widget = gtk_button_new_with_label(vgtk_buttons[cur_w].label);
 }
 for(i=0; i<200; i++)
 {
  sprintf(temp, "%s_vbox", vgtk_frames[i].name);
  if(!strcmp(temp, vgtk_buttons[cur_w].parent_box))
  {
   gtk_box_pack_start(GTK_BOX(vgtk_frames[i].vbox), vgtk_buttons[cur_w].widget, TRUE, TRUE, 0);
   break;
  }
 }
 for(i=0; i<400; i++)
 {
  if(!strcmp(vgtk_boxes[i].name, vgtk_buttons[cur_w].parent_box))
  {
   gtk_box_pack_start(GTK_BOX(vgtk_boxes[i].widget), vgtk_buttons[cur_w].widget, TRUE, TRUE, 0);
   break;
  }
 }
 gtk_widget_show(vgtk_buttons[cur_w].widget);
}

void make_label()
{
 int i;
 for(i=0; i<200; i++)
 {
  if(!strcmp(vgtk_labels[cur_w].parent_win, vgtk_frames[i].name))
  {
   if(!GTK_IS_WIDGET(vgtk_frames[i].widget)) return;
  }
 }
 if(!GTK_IS_WIDGET(vgtk_labels[cur_w].widget))
 {
  vgtk_labels[cur_w].widget = gtk_label_new(vgtk_labels[cur_w].label);
 }
 for(i=0; i<200; i++)
 {
  sprintf(temp, "%s_vbox", vgtk_frames[i].name);
  if(!strcmp(temp, vgtk_labels[cur_w].parent_box))
  {
   gtk_box_pack_start(GTK_BOX(vgtk_frames[i].vbox), vgtk_labels[cur_w].widget, TRUE, TRUE, 0);
   break;
  }
 }
 for(i=0; i<400; i++)
 {
  if(!strcmp(vgtk_boxes[i].name, vgtk_labels[cur_w].parent_box))
  {
   gtk_box_pack_start(GTK_BOX(vgtk_boxes[i].widget), vgtk_labels[cur_w].widget, TRUE, TRUE, 0);
   break;
  }
 }
 gtk_widget_show(vgtk_labels[cur_w].widget);
}

void make_entry()
{
 int i;
 for(i=0; i<200; i++)
 {
  if(!strcmp(vgtk_entries[cur_w].parent_win, vgtk_frames[i].name))
  {
   if(!GTK_IS_WIDGET(vgtk_frames[i].widget)) return;
  }
 }
 if(!GTK_IS_WIDGET(vgtk_entries[cur_w].widget))
 {
  vgtk_entries[cur_w].widget = gtk_entry_new();
 }
 for(i=0; i<200; i++)
 {
  sprintf(temp, "%s_vbox", vgtk_frames[i].name);
  if(!strcmp(temp, vgtk_entries[cur_w].parent_box))
  {
   gtk_box_pack_start(GTK_BOX(vgtk_frames[i].vbox), vgtk_entries[cur_w].widget, TRUE, TRUE, 0);
   break;
  }
 }
 for(i=0; i<400; i++)
 {
  if(!strcmp(vgtk_boxes[i].name, vgtk_entries[cur_w].parent_box))
  {
   gtk_box_pack_start(GTK_BOX(vgtk_boxes[i].widget), vgtk_entries[cur_w].widget, TRUE, TRUE, 0);
   break;
  }
 }
 gtk_entry_set_text(GTK_ENTRY(vgtk_entries[cur_w].widget), vgtk_entries[cur_w].text);
 gtk_widget_show(vgtk_entries[cur_w].widget);
}

void make_text()
{
 int i;
 for(i=0; i<200; i++)
 {
  if(!strcmp(vgtk_text[cur_w].parent_win, vgtk_frames[i].name))
  {
   if(vgtk_frames[i].widget==NULL || !GTK_IS_WIDGET(vgtk_frames[i].widget)) return;
  }
 }
 if(!GTK_IS_WIDGET(vgtk_text[cur_w].widget))
 {
  vgtk_text[cur_w].table = gtk_table_new(2, 2, FALSE);
  gtk_table_set_row_spacing(GTK_TABLE(vgtk_text[cur_w].table), 0, 2);
  gtk_table_set_col_spacing(GTK_TABLE(vgtk_text[cur_w].table), 0, 2);
  vgtk_text[cur_w].widget = gtk_text_new(NULL,NULL);
 }
 for(i=0; i<200; i++)
 {
  sprintf(temp, "%s_vbox", vgtk_frames[i].name);
  if(!strcmp(temp, vgtk_text[cur_w].parent_box))
  {
   gtk_box_pack_start(GTK_BOX(vgtk_frames[i].vbox), vgtk_text[cur_w].table, TRUE, TRUE, 0);
   break;
  }
 }
 for(i=0; i<400; i++)
 {
  if(!strcmp(vgtk_boxes[i].name, vgtk_text[cur_w].parent_box))
  {
   gtk_box_pack_start(GTK_BOX(vgtk_boxes[i].widget), vgtk_text[cur_w].table, TRUE, TRUE, 0);
   break;
  }
 }
 gtk_table_attach_defaults(GTK_TABLE(vgtk_text[cur_w].table), vgtk_text[cur_w].widget, 0, 1, 0, 1);
 gtk_text_freeze(GTK_TEXT(vgtk_text[cur_w].widget));
 gtk_widget_realize(vgtk_text[cur_w].widget);
 gtk_text_insert(GTK_TEXT(vgtk_text[cur_w].widget), NULL, NULL, NULL, vgtk_text[cur_w].initial_text, -1);
 gtk_text_thaw(GTK_TEXT(vgtk_text[cur_w].widget));
 gtk_widget_show(vgtk_text[cur_w].table);
 gtk_widget_show(vgtk_text[cur_w].widget);
}

void create_new_button()
{
 char *string;
 int i;
 for(i=0; i<200; i++)
 {
  if(!strcasecmp(vgtk_frames[i].name, vgtk_buttons[cur_w].parent_win))
  {
   label = gtk_label_new(vgtk_buttons[cur_w].name);
   list_item = gtk_list_item_new_with_label(vgtk_buttons[cur_w].name);
   gtk_container_add(GTK_CONTAINER(widgets_list[i]), list_item);
   gtk_widget_show(list_item);
   gtk_label_get(GTK_LABEL(label), &string);
   gtk_object_set_data(GTK_OBJECT(list_item), list_item_data_key, string);
  }
 }
}

void CB_button_remove(GtkWidget *window, GtkWidget *event)
{
 GList *clear_list = NULL;
 GList *work = NULL;

 vgtk_buttons[cur_w].created = 0;
 strcpy(vgtk_buttons[cur_w].name, "");
 strcpy(vgtk_buttons[cur_w].parent_win, "");
 strcpy(vgtk_buttons[cur_w].parent_box, "");
 strcpy(vgtk_buttons[cur_w].label, "");
 strcpy(vgtk_buttons[cur_w].signal_clicked, "");

 for (work = GTK_LIST(widgets_list[cur_l])->selection; work; work = work->next)
 clear_list = g_list_prepend (clear_list, work->data);

 clear_list = g_list_reverse(clear_list);
 gtk_list_remove_items(GTK_LIST(widgets_list[cur_l]), clear_list);
 g_list_free(clear_list);

 if(GTK_IS_WIDGET(vgtk_buttons[cur_w].widget))
 {
  gtk_widget_destroy(vgtk_buttons[cur_w].widget);
 }
 gtk_widget_destroy(win);
}

void new_label()
{
 int i;
 for(i = 0; i < 200; i++)
 {
  if(!vgtk_labels[i].created) break;
 }
 if(vgtk_labels[i].created)
 {
  msgbox("Maximum number of labels reached");
  return;
 }
 cur_w = i;
 label_settings(TRUE);
}

void CB_label_is_var(GtkWidget *widget, GtkWidget *entry)
{
 vgtk_labels[cur_w].is_var = GTK_TOGGLE_BUTTON(widget)->active;
}

void CB_entry_is_var(GtkWidget *widget, GtkWidget *entry)
{
 vgtk_entries[cur_w].is_var = GTK_TOGGLE_BUTTON(widget)->active;
}

void label_settings(int create)
{
 if(GTK_IS_WIDGET(win)) gtk_widget_destroy(win);
 win = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize(GTK_WIDGET(win), 400, 300);
 gtk_signal_connect (GTK_OBJECT (win), "delete_event",
  GTK_SIGNAL_FUNC(CB_kill_win), &win);
 gtk_window_set_title (GTK_WINDOW (win), "Label");
 gtk_widget_set_uposition (GTK_WIDGET(win), 100, 150);
 gtk_container_border_width (GTK_CONTAINER (win), 0);
 gtk_widget_show(win);

 vbox2 = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (win), vbox2);
 gtk_container_border_width (GTK_CONTAINER (vbox2), 2);
 gtk_widget_show (vbox2);

 notebook = gtk_notebook_new();
 gtk_notebook_set_tab_pos(GTK_NOTEBOOK(notebook), GTK_POS_TOP);
 gtk_box_pack_start(GTK_BOX(vbox2), notebook, TRUE, TRUE, 0);
 gtk_widget_set_usize(GTK_WIDGET(notebook), 350, 400);
 gtk_notebook_set_scrollable(GTK_NOTEBOOK(notebook), TRUE);
 gtk_widget_show(notebook);

 frame = gtk_frame_new("Settings");
 gtk_container_border_width(GTK_CONTAINER(frame), 10);
 gtk_widget_show(frame);

 label = gtk_label_new("Settings");
 gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (frame), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 label = gtk_label_new ("Widget unique name (1 word only):");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e1 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e1), vgtk_labels[cur_w].name);
 gtk_box_pack_start(GTK_BOX(vbox), e1, TRUE, TRUE, 0);
 if(!create) gtk_widget_set_sensitive(e1, FALSE);
 gtk_widget_show(e1);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Parent frame:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e2 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e2), vgtk_labels[cur_w].parent_win);
 gtk_box_pack_start(GTK_BOX(hbox), e2, TRUE, TRUE, 0);
 gtk_widget_show(e2);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Parent box:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e3 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e3), vgtk_labels[cur_w].parent_box);
 gtk_box_pack_start(GTK_BOX(hbox), e3, TRUE, TRUE, 0);
 gtk_widget_show(e3);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Label text or var name:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e4 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e4), vgtk_labels[cur_w].label);
 gtk_box_pack_start(GTK_BOX(hbox), e4, TRUE, TRUE, 0);
 gtk_widget_show(e4);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 cb1 = gtk_check_button_new_with_label("The label is a variable name");
 gtk_signal_connect (GTK_OBJECT(cb1), "toggled",
 GTK_SIGNAL_FUNC(CB_label_is_var), cb1);
 gtk_box_pack_start (GTK_BOX (hbox), cb1, TRUE, TRUE, 0);
 if(vgtk_labels[cur_w].is_var) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(cb1), TRUE);
 gtk_widget_show (cb1);

 frame = gtk_frame_new("Callback functions");
 gtk_container_border_width(GTK_CONTAINER(frame), 10);
 gtk_widget_show(frame);

 label = gtk_label_new("Callbacks");
 gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (frame), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start(GTK_BOX(vbox2), hbox, FALSE, FALSE, 0);
 gtk_widget_show(hbox);

 button = gtk_button_new_with_label ("Remove");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_label_remove), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("Cancel");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_kill_win), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_label_settings), (gpointer)create);
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
}

void CB_label_settings(gint create, GtkWidget *event)
{
 vgtk_labels[cur_w].created = 1;
 if(widgets_list[cur_l]!=NULL && GTK_LIST(widgets_list[cur_l])!=NULL)
 gtk_list_unselect_all(GTK_LIST(widgets_list[cur_l]));
 strncpy(vgtk_labels[cur_w].name, gtk_entry_get_text(GTK_ENTRY(e1)), 500);
 strncpy(vgtk_labels[cur_w].parent_win, gtk_entry_get_text(GTK_ENTRY(e2)), 500);
 strncpy(vgtk_labels[cur_w].parent_box, gtk_entry_get_text(GTK_ENTRY(e3)), 500);
 strncpy(vgtk_labels[cur_w].label, gtk_entry_get_text(GTK_ENTRY(e4)), 500);
 if(create) create_new_label();
#ifdef TRY_IT
 make_label();
#endif
 gtk_widget_destroy(win);
}

void create_new_label()
{
 char *string;
 int i;
 for(i=0; i<200; i++)
 {
  if(!strcasecmp(vgtk_frames[i].name, vgtk_labels[cur_w].parent_win))
  {
   label = gtk_label_new(vgtk_labels[cur_w].name);
   list_item = gtk_list_item_new_with_label(vgtk_labels[cur_w].name);
   gtk_container_add(GTK_CONTAINER(widgets_list[i]), list_item);
   gtk_widget_show(list_item);
   gtk_label_get(GTK_LABEL(label), &string);
   gtk_object_set_data(GTK_OBJECT(list_item), list_item_data_key, string);
  }
 }
}

void CB_label_remove(GtkWidget *window, GtkWidget *event)
{
 GList *clear_list = NULL;
 GList *work = NULL;

 vgtk_labels[cur_w].created = 0;
 strcpy(vgtk_labels[cur_w].name, "");
 strcpy(vgtk_labels[cur_w].parent_win, "");
 strcpy(vgtk_labels[cur_w].parent_box, "");
 strcpy(vgtk_labels[cur_w].label, "");

 for (work = GTK_LIST(widgets_list[cur_l])->selection; work; work = work->next)
 clear_list = g_list_prepend (clear_list, work->data);

 clear_list = g_list_reverse(clear_list);
 gtk_list_remove_items(GTK_LIST(widgets_list[cur_l]), clear_list);
 g_list_free(clear_list);

 if(GTK_IS_WIDGET(vgtk_labels[cur_w].widget))
 {
  gtk_widget_destroy(vgtk_labels[cur_w].widget);
 }
 gtk_widget_destroy(win);
}

void new_entry()
{
 int i;
 for(i = 0; i < 200; i++)
 {
  if(!vgtk_entries[i].created) break;
 }
 if(vgtk_entries[i].created)
 {
  msgbox("Maximum number of entries reached");
  return;
 }
 cur_w = i;
 entry_settings(TRUE);
}

void entry_settings(int create)
{
 if(GTK_IS_WIDGET(win)) gtk_widget_destroy(win);
 win = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize(GTK_WIDGET(win), 400, 300);
 gtk_signal_connect (GTK_OBJECT (win), "delete_event",
  GTK_SIGNAL_FUNC(CB_kill_win), &win);
 gtk_window_set_title (GTK_WINDOW (win), "Entry");
 gtk_widget_set_uposition (GTK_WIDGET(win), 100, 150);
 gtk_container_border_width (GTK_CONTAINER (win), 0);
 gtk_widget_show(win);

 vbox2 = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (win), vbox2);
 gtk_container_border_width (GTK_CONTAINER (vbox2), 2);
 gtk_widget_show (vbox2);

 notebook = gtk_notebook_new();
 gtk_notebook_set_tab_pos(GTK_NOTEBOOK(notebook), GTK_POS_TOP);
 gtk_box_pack_start(GTK_BOX(vbox2), notebook, TRUE, TRUE, 0);
 gtk_widget_set_usize(GTK_WIDGET(notebook), 350, 400);
 gtk_notebook_set_scrollable(GTK_NOTEBOOK(notebook), TRUE);
 gtk_widget_show(notebook);

 frame = gtk_frame_new("Settings");
 gtk_container_border_width(GTK_CONTAINER(frame), 10);
 gtk_widget_show(frame);

 label = gtk_label_new("Settings");
 gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (frame), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 label = gtk_label_new ("Widget unique name (1 word only):");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e1 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e1), vgtk_entries[cur_w].name);
 gtk_box_pack_start(GTK_BOX(vbox), e1, TRUE, TRUE, 0);
 if(!create) gtk_widget_set_sensitive(e1, FALSE);
 gtk_widget_show(e1);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Parent frame:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e2 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e2), vgtk_entries[cur_w].parent_win);
 gtk_box_pack_start(GTK_BOX(hbox), e2, TRUE, TRUE, 0);
 gtk_widget_show(e2);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Parent box:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e3 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e3), vgtk_entries[cur_w].parent_box);
 gtk_box_pack_start(GTK_BOX(hbox), e3, TRUE, TRUE, 0);
 gtk_widget_show(e3);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Initial text or var name:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e4 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e4), vgtk_entries[cur_w].text);
 gtk_box_pack_start(GTK_BOX(hbox), e4, TRUE, TRUE, 0);
 gtk_widget_show(e4);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 cb1 = gtk_check_button_new_with_label("The label is a variable name");
 gtk_signal_connect (GTK_OBJECT(cb1), "toggled",
 GTK_SIGNAL_FUNC(CB_entry_is_var), cb1);
 gtk_box_pack_start (GTK_BOX (hbox), cb1, TRUE, TRUE, 0);
 if(vgtk_entries[cur_w].is_var) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(cb1), TRUE);
 gtk_widget_show (cb1);

 frame = gtk_frame_new("Callback functions");
 gtk_container_border_width(GTK_CONTAINER(frame), 10);
 gtk_widget_show(frame);

 label = gtk_label_new("Callbacks");
 gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (frame), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start(GTK_BOX(vbox2), hbox, FALSE, FALSE, 0);
 gtk_widget_show(hbox);

 button = gtk_button_new_with_label ("Remove");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_entry_remove), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("Cancel");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_kill_win), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_entry_settings), (gpointer)create);
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
}

void CB_entry_settings(gint create, GtkWidget *event)
{
 vgtk_entries[cur_w].created = 1;
 if(widgets_list[cur_l]!=NULL && GTK_LIST(widgets_list[cur_l])!=NULL)
 gtk_list_unselect_all(GTK_LIST(widgets_list[cur_l]));
 strncpy(vgtk_entries[cur_w].name, gtk_entry_get_text(GTK_ENTRY(e1)), 500);
 strncpy(vgtk_entries[cur_w].parent_win, gtk_entry_get_text(GTK_ENTRY(e2)), 500);
 strncpy(vgtk_entries[cur_w].parent_box, gtk_entry_get_text(GTK_ENTRY(e3)), 500);
 strncpy(vgtk_entries[cur_w].text, gtk_entry_get_text(GTK_ENTRY(e4)), 500);
 if(create) create_new_entry();
#ifdef TRY_IT
 make_entry();
#endif
 gtk_widget_destroy(win);
}

void create_new_entry()
{
 char *string;
 int i;
 for(i=0; i<200; i++)
 {
  if(!strcasecmp(vgtk_frames[i].name, vgtk_entries[cur_w].parent_win))
  {
   label = gtk_label_new(vgtk_entries[cur_w].name);
   list_item = gtk_list_item_new_with_label(vgtk_entries[cur_w].name);
   gtk_container_add(GTK_CONTAINER(widgets_list[i]), list_item);
   gtk_widget_show(list_item);
   gtk_label_get(GTK_LABEL(label), &string);
   gtk_object_set_data(GTK_OBJECT(list_item), list_item_data_key, string);
  }
 }
}

void CB_entry_remove(GtkWidget *window, GtkWidget *event)
{
 GList *clear_list = NULL;
 GList *work = NULL;

 vgtk_entries[cur_w].created = 0;
 strcpy(vgtk_entries[cur_w].name, "");
 strcpy(vgtk_entries[cur_w].parent_win, "");
 strcpy(vgtk_entries[cur_w].parent_box, "");
 strcpy(vgtk_entries[cur_w].text, "");

 for (work = GTK_LIST(widgets_list[cur_l])->selection; work; work = work->next)
 clear_list = g_list_prepend (clear_list, work->data);

 clear_list = g_list_reverse(clear_list);
 gtk_list_remove_items(GTK_LIST(widgets_list[cur_l]), clear_list);
 g_list_free(clear_list);

 if(GTK_IS_WIDGET(vgtk_entries[cur_w].widget))
 {
  gtk_widget_destroy(vgtk_entries[cur_w].widget);
 }
 gtk_widget_destroy(win);
}

void new_text()
{
 int i;
 for(i = 0; i < 200; i++)
 {
  if(!vgtk_text[i].created) break;
 }
 if(vgtk_text[i].created)
 {
  msgbox("Maximum number of texts reached");
  return;
 }
 cur_w = i;
 text_settings(TRUE);
}

void text_settings(int create)
{
 if(GTK_IS_WIDGET(win)) gtk_widget_destroy(win);
 win = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize(GTK_WIDGET(win), 400, 300);
 gtk_signal_connect (GTK_OBJECT (win), "delete_event",
  GTK_SIGNAL_FUNC(CB_kill_win), &win);
 gtk_window_set_title (GTK_WINDOW (win), "Text");
 gtk_widget_set_uposition (GTK_WIDGET(win), 100, 150);
 gtk_container_border_width (GTK_CONTAINER (win), 0);
 gtk_widget_show(win);

 vbox2 = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (win), vbox2);
 gtk_container_border_width (GTK_CONTAINER (vbox2), 2);
 gtk_widget_show (vbox2);

 notebook = gtk_notebook_new();
 gtk_notebook_set_tab_pos(GTK_NOTEBOOK(notebook), GTK_POS_TOP);
 gtk_box_pack_start(GTK_BOX(vbox2), notebook, TRUE, TRUE, 0);
 gtk_widget_set_usize(GTK_WIDGET(notebook), 350, 400);
 gtk_notebook_set_scrollable(GTK_NOTEBOOK(notebook), TRUE);
 gtk_widget_show(notebook);

 frame = gtk_frame_new("Settings");
 gtk_container_border_width(GTK_CONTAINER(frame), 10);
 gtk_widget_show(frame);

 label = gtk_label_new("Settings");
 gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (frame), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 label = gtk_label_new ("Widget unique name (1 word only):");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e1 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e1), vgtk_text[cur_w].name);
 gtk_box_pack_start(GTK_BOX(vbox), e1, TRUE, TRUE, 0);
 if(!create) gtk_widget_set_sensitive(e1, FALSE);
 gtk_widget_show(e1);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Parent frame:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e2 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e2), vgtk_text[cur_w].parent_win);
 gtk_box_pack_start(GTK_BOX(hbox), e2, TRUE, TRUE, 0);
 gtk_widget_show(e2);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Parent box:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e3 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e3), vgtk_text[cur_w].parent_box);
 gtk_box_pack_start(GTK_BOX(hbox), e3, TRUE, TRUE, 0);
 gtk_widget_show(e3);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Initial text variable:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e4 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e4), vgtk_text[cur_w].initial_text);
 gtk_box_pack_start(GTK_BOX(hbox), e4, TRUE, TRUE, 0);
 gtk_widget_show(e4);

 frame = gtk_frame_new("Callback functions");
 gtk_container_border_width(GTK_CONTAINER(frame), 10);
 gtk_widget_show(frame);

 label = gtk_label_new("Callbacks");
 gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (frame), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Signal changed:");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 e5 = gtk_entry_new();
 gtk_entry_set_text(GTK_ENTRY(e5), vgtk_text[cur_w].signal_changed);
 gtk_box_pack_start(GTK_BOX(hbox), e5, TRUE, TRUE, 0);
 gtk_widget_show(e5);

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start(GTK_BOX(vbox2), hbox, FALSE, FALSE, 0);
 gtk_widget_show(hbox);

 button = gtk_button_new_with_label ("Remove");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_text_remove), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("Cancel");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_kill_win), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_text_settings), (gpointer)create);
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
}

void CB_text_settings(gint create, GtkWidget *event)
{
 vgtk_text[cur_w].created = 1;
 if(widgets_list[cur_l]!=NULL && GTK_LIST(widgets_list[cur_l])!=NULL)
 gtk_list_unselect_all(GTK_LIST(widgets_list[cur_l]));
 strncpy(vgtk_text[cur_w].name, gtk_entry_get_text(GTK_ENTRY(e1)), 500);
 strncpy(vgtk_text[cur_w].parent_win, gtk_entry_get_text(GTK_ENTRY(e2)), 500);
 strncpy(vgtk_text[cur_w].parent_box, gtk_entry_get_text(GTK_ENTRY(e3)), 500);
 strncpy(vgtk_text[cur_w].initial_text, gtk_entry_get_text(GTK_ENTRY(e4)), 500);
 strncpy(vgtk_text[cur_w].signal_changed, gtk_entry_get_text(GTK_ENTRY(e5)), 500);
 if(create) create_new_text();
#ifdef TRY_IT
 make_text();
#endif
 gtk_widget_destroy(win);
}

void create_new_text()
{
 char *string;
 int i;
 for(i=0; i<200; i++)
 {
  if(!strcasecmp(vgtk_frames[i].name, vgtk_text[cur_w].parent_win))
  {
   label = gtk_label_new(vgtk_text[cur_w].name);
   list_item = gtk_list_item_new_with_label(vgtk_text[cur_w].name);
   gtk_container_add(GTK_CONTAINER(widgets_list[i]), list_item);
   gtk_widget_show(list_item);
   gtk_label_get(GTK_LABEL(label), &string);
   gtk_object_set_data(GTK_OBJECT(list_item), list_item_data_key, string);
  }
 }
}

void CB_text_remove(GtkWidget *window, GtkWidget *event)
{
 GList *clear_list = NULL;
 GList *work = NULL;

 vgtk_text[cur_w].created = 0;
 strcpy(vgtk_text[cur_w].name, "");
 strcpy(vgtk_text[cur_w].parent_win, "");
 strcpy(vgtk_text[cur_w].parent_box, "");
 strcpy(vgtk_text[cur_w].initial_text, "");
 strcpy(vgtk_text[cur_w].signal_changed, "");

 for (work = GTK_LIST(widgets_list[cur_l])->selection; work; work = work->next)
 clear_list = g_list_prepend (clear_list, work->data);

 clear_list = g_list_reverse(clear_list);
 gtk_list_remove_items(GTK_LIST(widgets_list[cur_l]), clear_list);
 g_list_free(clear_list);

 gtk_widget_destroy(win);
}



/*
 WIDGET:
 Add here:
 new_widget: find a free entry, call widget_settings
 widget_settings: display settings box
 CB_widget_settings: set proper info
 CB_box_remove: remove from the list
 create_new_widget: add an entry to the proper list
 make_widget: for the try_it feature
*/

