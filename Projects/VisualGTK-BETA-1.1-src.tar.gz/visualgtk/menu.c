/* Visual GTK - (C) 1999 Patrick Lambert, see the LICENSE file */
#include "visualgtk.h"

void future(GtkWidget *w, GtkWidget *e)
{}

static GtkItemFactoryEntry menu_items[] = {
 {"/_File", NULL, NULL, 0, "<Branch>" },
 {"/File/New Project", "<control>N", new_vgtk, 0, NULL },
 {"/File/Save Project", "<control>S", save, 0, NULL },
 {"/File/Exit Visual GTK", "<control>X", CB_exit, 0, NULL },
 {"/_Project", NULL, NULL, 0, "<Branch>" },
 {"/Project/Build Project", "<control>B", generate_code, 0, NULL },
 {"/Project/Compile Project", "<control>C", compile_project, 0, NULL },
 {"/Project/Run Project", "<control>R", run_project, 0, NULL },
 {"/_Tools", NULL, NULL, 0, "<Branch>" },
 {"/Tools/Edit Includes", "<control>I", edit_includes, 0, NULL },
 {"/Tools/Edit Main", "<control>M", edit_main, 0, NULL },
 {"/Tools/Create Manual", "<control>U", future, 0, NULL },
 {"/_Help", NULL, NULL, 0, "<Branch>" },
 {"/Help/About Visual GTK", "<control>A", about, 0, NULL },
};

void create_menu(GtkWidget *window, GtkWidget **menubar)
{
 gint nmenu_items=sizeof(menu_items)/sizeof(menu_items[0]);
 accel_group = gtk_accel_group_new ();
 item_factory = gtk_item_factory_new(GTK_TYPE_MENU_BAR, "<main>", accel_group);
 gtk_item_factory_create_items(item_factory, nmenu_items, menu_items, NULL);
 gtk_accel_group_attach(accel_group, GTK_OBJECT(window));
 *menubar = gtk_item_factory_get_widget(item_factory, "<main>");
}

