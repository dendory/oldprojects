/* Visual GTK - (C) 1999 Patrick Lambert, see the LICENSE file */

#define INTRO "\
Welcome to Visual GTK\n\n\
\
The purpose of this program is to ease the use of making graphical interfaces in Linux. There \
are only a few ground rules you need to know about graphical interfaces before you can start \
working on making your own, full featured programs.\n\nFirst you need to know what widgets \
are. A widget is any piece of interface. A button is a widget, so is a label, a text area, and even \
a window.\n\nNext, the widgets must be placed together. You first need to create a frame to \
show widgets to the user. Then you need to place them inside boxes. There are 2 kinds of boxes: \
vertical and horizontal. Let's say you want to create a window, with a label in the top and 2 buttons \
in the bottom. You could create one frame, with a vertical box attached to it, and then make an \
horizontal box in the bottom to put the 2 buttons in it.\n\n\
Here is a quick tutorial on how to use \
Visual GTK. You will create a small program that shows a frame, asking you for your name. Then \
an other frame will show the label \"Hello name!\" where name is what you entered on the first \
frame.\n\n\
First, create a new project and name it hello, in a directory of your choice. Then, make \
2 frames. Click on the Frame button to create a frame. Name the first frame \"win0\", and set the \
size to 400 horizontal and 200 vertical. Click on the Callbacks pane and enter \"CB_exit\" in the \
\"delete_event\" signal. The callback signals are used to link a widget to a C function. For \
example, a button has the \"clicked\" signal to call a C function when you click on the button. \
Here, \"delete_event\" means that when you close the frame, the function CB_exit will be called. \
We'll create the actual functions later. For the second frame, call it \"win1\" and set it the same size \
with the same signal. Something you need to remember is that when you create a frame, Visual \
GTK will automatically create a vertical box called framename_vbox which needs to be the ancestor \
of all your widgets. In our case here, the main vertical box for win0 is \"win0_vbox\" and for the \
win1 frame it is called \"win1_vbox\".\n\n\
Now that the frames have been created, we will make \
2 horizontal boxes for each frame. Make a new box by clicking on the Box button. Call the first box \
\"main_box0\" and set its parent frame to \"win0\" and parent window to \"win0_vbox\" which is the \
main vertical box for the win0 frame. Set the sizes to 400 and 150. Call the second one \
\"buttons_box0\" and set the same parents. Set the sizes for this one to 400 and 50. Do the same \
for the win1 frame by calling them \"main_box1\" and \"buttons_box1\" with the same sizes, and \
parents \"win1\" and \"win1_vbox\". Now let's add a few buttons. We want a Cancel button and a \
Next button for the first frame, and a button that simply Quits for the second. Create a button by \
clicking on the button named Button. Name the first one \"cancel\", set the label to \"Cancel\", its \
parents to \"win0\" and \"buttons_box0\", and set a callback to \"CB_exit\". This tells Visual GTK \
to make a new button that will have the word Cancel on it, that should be attached to the \
buttons_box0 that we created, and that should call the function CB_exit when clicked. Make the \
second button with the same parents, but named \"next\" and with a label of \"Next\". The signal for \
this button should be \"CB_next\". We only need 1 button for the second frame. Make that button \
with the name \"quit\" and the label \"Quit\". Its frame parent should be \"win1\" and the box parent \
should be \"buttons_box1\". The \"clicked\" signal should be set to \"CB_exit\" because we want to \
quit the program at that point.\n\n\
Now we will create the labels and entry text. Create a label with \
the name \"name_label\" and the label \"Enter your name:\". Its parents should be \"win0\" and \
\"main_box0\". The second label should be named \"result_label\" and have the label \"name\". Set \
the last option to 1 instead of 0. This is a way to tell Visual GTK that this label won't contain \
literal text. It will contain whatever is in the variable \"name\". Set the parents to \"win1\" and \
\"main_box1\". Now create an entry text. Set the name to \"name_entry\" and the parents to \"win0\" \
and \"main_box0\". Set no initial text.\n\nNow it's time to add the actual functions. Add a callback \
named \"CB_exit\" with the following text in it:\n\n\
void CB_exit(GtkWidget *window, GtkWidget *event)\n\
{\n\
 exit(0);\n\
}\n\n\
This simply tells the program to exit when this callback function is called. Create the second \
callback we need and name it \"CB_next\". Enter this text:\n\n\
void CB_next(GtkWidget *window, GtkWidget *event)\n\
{\n\
 sprintf(name, \"Hello %s!\n\", gtk_entry_get_text(GTK_ENTRY(name_entry)));\n\
 gtk_widget_destroy(win0);\n\
 make_win1();\n\
}\n\n\
You will notice several non-standard C statements. The ones that start with gtk_ are built-in \
functions that tell GTK to do things. Here, gtk_entry_get_text means that you want whatever \
the user entered in the entry we named \"name_entry\" to be copied into the variable \"name\". \
The gtk_widget_destroy function means that you don't want the \"win0\" frame on the screen \
anymore. The last entry, make_win1(), means that we want to show the frame \"win1\" on the \
screen.\n\nThe program is nearly done. Click on the Projects menu and then edit includes. You need \
to add the \"name\" variable. Add the following to the text area:\n\n\
char name[100];\n\n\
Then edit the main function, from the same menu, and change \"make_myframe()\" to \
\"make_win0()\". You now need to build the project, compile the project and run the project. Pick \
all of these commands from the Projects menu. You should now have your working application \
on the screen!\n"


#define REF "Commands and functions:\n\n\
Initial project screen:\n\
When you launch Visual GTK, an initial project screen appears. From there, you must decide if you \
want to create a new project, by selecting that option and entering the requested information, \
or if you want to open a project, in which case you will see a browse window, from which \
you can pick a project file ending with the .prj extension.\n\n\
File menu:\n\
In the file menu, you can launch an other instance of Visual GTK, you can save your current \
project, or quit Visual GTK.\n\n\
Project menu:\n\
The project menu has options needed to to create source code, compile it, and make \
a program out of the widgets. Visual GTK uses the GCC compiler to try to compile \
the source code. It also needs the GTK library version 1.2 to be installed.\n\n\
Tools menu:\n\
The tools menu contains tools to help you create software. From that menu you can edit \
the includes file and the main function. In the includes, you should add any \
global variable you are going to require. You also need to edit the main function. A default main \
is provided, but you need to launch the frame you want to see first. If you create \"win0\", then \
you need to put \"make_win0();\" in your main. You can also build the project source code, \
compile it, and run the resulting program.\n\n\
Help menu:\n\
In the help menu you can get the about box. Actual help is available from the main Visual GTK \
window.\n\n"


#define LICENSE "(C) 1999 Patrick Lambert. See the about box.\n\n\
Visual GTK is free for non-commercial use. To make commercial products with \
Visual GTK, you must pay a one time registration fee of $30. It is only fair to contribute a small \
fee needed to keep this project alive if you are going to make money with your work. \
See the web page for details."

