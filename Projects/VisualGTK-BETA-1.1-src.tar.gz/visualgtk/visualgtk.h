/* Visual GTK - (C) 1999 Patrick Lambert, see the LICENSE file */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <gtk/gtk.h>

#include "help.h"
#define TRY_IT
#define VERSION "BETA RELEASE 1.1"

GtkWidget *window, *menubar, *mnotebook, *vbox, *hbox, *handle_box, *frame, *label, *hbox2, *callbacks_list, *scrolled_window, *win, *e0, *e1, *e2, *e3, *e4, *e5, *e6, *e7, *e8, *button, *help_table, *widgets_list[200], *text, *table, *list_item, *help, *help_list, *sb, *help_text, *notebook, *vbox2, *cb1;
GSList *group;
GtkItemFactory *item_factory;
GtkAccelGroup *accel_group;
GdkPixmap *pixm;
GdkColor color;
GdkColormap *cmap;

FILE *fd, *fd0;
int cur_w, cur_l, tmp_choice;
char project_name[512];
char project_dir[512];
char temp[1024];
const gchar *list_item_data_key;
char main_text[4096];
char more_includes[4096];
char global_var[1024];

struct callback_s
{
 int created;
 char name[512];
 char text[4096];
};
struct callback_s vgtk_callbacks[500];

struct frame_s
{
 int created;
 char name[512];
 char title[512];
 int size_x;
 int size_y;
 int pos_x;
 int pos_y;
 char signal_destroy[512];
 char signal_delete_event[512];
 GtkWidget *widget, *vbox;
};
struct frame_s vgtk_frames[200];

struct box_s
{
 int created;
 char name[512];
 char parent_win[512];
 char parent_box[512];
 int size_x;
 int size_y;
 int type;
 GtkWidget *widget;
};
struct box_s vgtk_boxes[400];

struct button_s
{
 int created;
 char name[512];
 char parent_win[512];
 char parent_box[512];
 char label[512];
 char signal_clicked[512];
 GtkWidget *widget;
};
struct button_s vgtk_buttons[200];

struct label_s
{
 int created;
 char name[512];
 char parent_win[512];
 char parent_box[512];
 char label[512];
 int is_var;
 GtkWidget *widget;
};
struct label_s vgtk_labels[200];

struct entry_s
{
 int created;
 char name[512];
 char parent_win[512];
 char parent_box[512];
 char text[512];
 int is_var;
 GtkWidget *widget;
};
struct entry_s vgtk_entries[200];

struct text_s
{
 int created;
 char name[512];
 char parent_win[512];
 char parent_box[512];
 char initial_text[512];
 char signal_changed[512];
 GtkWidget *table, *widget;
};
struct text_s vgtk_text[200];

/*
WIDGET:
struct: needed components
*/

void future(GtkWidget *w, GtkWidget *e);
void main_gui();
void create_menu(GtkWidget *window, GtkWidget **menubar);
void CB_exit(GtkWidget *widget, GtkWidget *event);
GtkWidget *new_pixmap_from_file (char *filename, GdkWindow *window, GdkColor *background);
GtkWidget *new_pixmap(int type, GdkWindow *window, GdkColor *background);
gushort convert_color(unsigned c);
void extract_color(GdkColor *color, unsigned red, unsigned green, unsigned blue);
void new_project();
void CB_kill_win(GtkWidget *window, GtkWidget *event);
void CB_new_project(GtkWidget *window, GtkWidget *event);
void open_project();
void CB_open_project(GtkWidget *window, GtkFileSelection *fs);
void parse_project(char *file);
char *lindex(char *input_string, int word_number);
void CB_msgbox(GtkWidget *window, GtkWidget *event);
void msgbox(char *string);
void CB_callback_settings(gint create, GtkWidget *event);
void new_callback();
void callback_settings(int create);
void callbacks_click(char *str);
void CB_callbacks_click(GtkWidget *window, GtkWidget *event);
void save();
void widgets_click(char *str);
void CB_widgets_click(GtkWidget *window, GtkWidget *event);
void new_vgtk();
void about();
void show_help();
void CB_kill_help(GtkWidget *window, GtkWidget *event);
void CB_help_click(GtkWidget *window, GtkWidget *event);
void new_frame();
void CB_frame_settings(gint create, GtkWidget *event);
void frame_settings(int create);
void create_new_callback();
void create_new_frame();
void edit_includes();
void generate_code();
void print_widgets();
void new_box();
void box_settings(int create);
void CB_box_remove(GtkWidget *window, GtkWidget *event);
void CB_box_settings(gint create, GtkWidget *event);
void create_new_box();
void CB_edit_includes(GtkWidget *w, GtkWidget *e);
void edit_includes();
void CB_edit_main(GtkWidget *w, GtkWidget *e);
void edit_main();
void CB_button_remove(GtkWidget *window, GtkWidget *event);
void create_new_button();
void CB_button_settings(gint create, GtkWidget *event);
void button_settings(int create);
void new_button();
void new_project_start();
void CB_new_project_click(GtkWidget *w, gint t);
void compile_project();
void run_project();
void CB_callback_common(GtkWidget *w, GtkWidget *e);
char *lrange(char *input_string, int starting_at);
void CB_label_remove(GtkWidget *window, GtkWidget *event);
void label_settings(int create);
void CB_label_settings(gint create, GtkWidget *event);
void create_new_label();
void new_label();
void CB_entry_remove(GtkWidget *window, GtkWidget *event);
void entry_settings(int create);
void CB_entry_settings(gint create, GtkWidget *event);
void create_new_entry();
void new_entry();
void CB_label_is_var(GtkWidget *widget, GtkWidget *entry);
void CB_entry_is_var(GtkWidget *widget, GtkWidget *entry);
void new_text();
void text_settings(int create);
void CB_text_settings(gint create, GtkWidget *event);
void create_new_text();
void CB_text_remove(GtkWidget *window, GtkWidget *event);
void make_frame();
void make_box();
void make_button();
void make_label();
void make_entry();
void make_text();
