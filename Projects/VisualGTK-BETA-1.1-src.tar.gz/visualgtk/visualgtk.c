/* Visual GTK - (C) 1999 Patrick Lambert, see the LICENSE file */
#include "visualgtk.h"

void CB_exit(GtkWidget *widget, GtkWidget *event)
{
 exit(0);
}

void main_gui()
{
 char *string;
 window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize (GTK_WIDGET (window), 400, 500);
 gtk_signal_connect (GTK_OBJECT (window), "delete_event",
  GTK_SIGNAL_FUNC(CB_exit), &window);
 gtk_window_set_title (GTK_WINDOW (window), "Visual GTK");
 gtk_widget_set_uposition (GTK_WIDGET(window), 50, 10);
 gtk_container_border_width (GTK_CONTAINER (window), 0);
 gtk_widget_show(window);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 create_menu(window, &menubar);
 gtk_box_pack_start(GTK_BOX(vbox),menubar,FALSE,TRUE,0);
 gtk_widget_show (menubar);

 gtk_window_set_policy (GTK_WINDOW (window), FALSE, TRUE, TRUE);
 gtk_widget_realize (window);

 hbox = gtk_toolbar_new (GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);
 gtk_toolbar_set_button_relief (GTK_TOOLBAR (hbox), GTK_RELIEF_NONE);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, FALSE, FALSE, 0);
 gtk_widget_show (hbox);

 gtk_toolbar_append_item (GTK_TOOLBAR (hbox), NULL, "New project",
 "", new_pixmap (0, window->window, &color),
 GTK_SIGNAL_FUNC(new_vgtk), GTK_OBJECT(window));

 gtk_toolbar_append_item (GTK_TOOLBAR (hbox), NULL, "Save project",
 "", new_pixmap (2, window->window, &color),
 GTK_SIGNAL_FUNC(save), GTK_OBJECT(window));

 gtk_toolbar_append_item (GTK_TOOLBAR (hbox), NULL, "Generate code",
 "", new_pixmap (3, window->window, &color),
 GTK_SIGNAL_FUNC(generate_code), GTK_OBJECT(window));

 gtk_toolbar_append_item (GTK_TOOLBAR (hbox), NULL, "Help",
 "", new_pixmap (4, window->window, &color),
 GTK_SIGNAL_FUNC(about), GTK_OBJECT(window));

 gtk_toolbar_append_item (GTK_TOOLBAR (hbox), NULL, "Exit",
 "", new_pixmap (1, window->window, &color),
 GTK_SIGNAL_FUNC(CB_exit), GTK_OBJECT(window));

 hbox2 = gtk_hbox_new(FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox2, FALSE, FALSE, 0);
 gtk_widget_show(hbox2);

 gtk_window_set_policy (GTK_WINDOW (window), FALSE, TRUE, TRUE);
 gtk_widget_realize (window);

 hbox = gtk_toolbar_new (GTK_ORIENTATION_VERTICAL, GTK_TOOLBAR_BOTH);
 gtk_toolbar_set_button_relief (GTK_TOOLBAR (hbox), GTK_RELIEF_NORMAL);
 gtk_box_pack_start (GTK_BOX (hbox2), hbox, FALSE, FALSE, 0);
 gtk_widget_show (hbox);

 gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Callback", "Write a new callback function",
 "", NULL, GTK_SIGNAL_FUNC(new_callback), GTK_OBJECT(window));

 gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Frame", "Create a new frame",
 "", NULL, GTK_SIGNAL_FUNC(new_frame), GTK_OBJECT(window));

 gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Box", "Create an horizontal box",
 "", NULL, GTK_SIGNAL_FUNC(new_box), GTK_OBJECT(window));

 gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Button", "Add a button",
 "", NULL, GTK_SIGNAL_FUNC(new_button), GTK_OBJECT(window));

 gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Label", "Add a label",
 "", NULL, GTK_SIGNAL_FUNC(new_label), GTK_OBJECT(window));

 gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Entry", "Add an entry",
 "", NULL, GTK_SIGNAL_FUNC(new_entry), GTK_OBJECT(window));

 gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Text", "Add an text box",
 "", NULL, GTK_SIGNAL_FUNC(new_text), GTK_OBJECT(window));

 mnotebook = gtk_notebook_new();
 gtk_notebook_set_tab_pos(GTK_NOTEBOOK(mnotebook), GTK_POS_TOP);
 gtk_box_pack_start(GTK_BOX(hbox2), mnotebook, TRUE, TRUE, 0);
 gtk_widget_set_usize(GTK_WIDGET(mnotebook), 350, 450);
 gtk_notebook_set_scrollable(GTK_NOTEBOOK(mnotebook), TRUE);
 gtk_widget_show(mnotebook);

 frame = gtk_frame_new("Callback functions");
 gtk_container_border_width(GTK_CONTAINER(frame), 10);
 gtk_widget_show(frame);

 label = gtk_label_new("Functions");
 gtk_notebook_append_page(GTK_NOTEBOOK(mnotebook), frame, label);

 vbox = gtk_vbox_new(FALSE, 0);
 gtk_container_add(GTK_CONTAINER(frame), vbox);
 gtk_container_border_width(GTK_CONTAINER(vbox), 5);
 gtk_widget_show(vbox);

 scrolled_window = gtk_scrolled_window_new(NULL, NULL);
 gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window),
 GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
 gtk_container_add(GTK_CONTAINER(vbox), scrolled_window);
 gtk_widget_set_usize(GTK_WIDGET(scrolled_window), 350, 450);
 gtk_widget_show(scrolled_window);
 
 callbacks_list = gtk_list_new();
 gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(scrolled_window),
 callbacks_list);
 gtk_widget_show(callbacks_list);
 gtk_container_set_focus_vadjustment(GTK_CONTAINER(callbacks_list),
 gtk_scrolled_window_get_vadjustment(GTK_SCROLLED_WINDOW(scrolled_window)));
 gtk_signal_connect(GTK_OBJECT(callbacks_list), "selection_changed",
 GTK_SIGNAL_FUNC(CB_callbacks_click), NULL);

 frame = gtk_frame_new("Documentation topics");
 gtk_container_border_width(GTK_CONTAINER(frame), 10);
 gtk_widget_show(frame);

 label = gtk_label_new("Help");
 gtk_notebook_append_page(GTK_NOTEBOOK(mnotebook), frame, label);

 vbox = gtk_vbox_new(FALSE, 0);
 gtk_container_add(GTK_CONTAINER(frame), vbox);
 gtk_container_border_width(GTK_CONTAINER(vbox), 5);
 gtk_widget_show(vbox);

 scrolled_window = gtk_scrolled_window_new(NULL, NULL);
 gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window),
 GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
 gtk_container_add(GTK_CONTAINER(vbox), scrolled_window);
 gtk_widget_set_usize(GTK_WIDGET(scrolled_window), 350, 450);
 gtk_widget_show(scrolled_window);
 
 help_list = gtk_list_new();
 gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(scrolled_window),
 help_list);
 gtk_widget_show(help_list);
 gtk_container_set_focus_vadjustment(GTK_CONTAINER(help_list),
 gtk_scrolled_window_get_vadjustment(GTK_SCROLLED_WINDOW(scrolled_window)));
 gtk_signal_connect(GTK_OBJECT(help_list), "selection_changed",
 GTK_SIGNAL_FUNC(CB_help_click), NULL);

 label = gtk_label_new("Introduction to Visual GTK");
 list_item = gtk_list_item_new_with_label("Introduction to Visual GTK");
 gtk_container_add(GTK_CONTAINER(help_list), list_item);
 gtk_widget_show(list_item);
 gtk_label_get(GTK_LABEL(label), &string);
 gtk_object_set_data(GTK_OBJECT(list_item), list_item_data_key, string);

 label = gtk_label_new("References and commands");
 list_item = gtk_list_item_new_with_label("References and commands");
 gtk_container_add(GTK_CONTAINER(help_list), list_item);
 gtk_widget_show(list_item);
 gtk_label_get(GTK_LABEL(label), &string);
 gtk_object_set_data(GTK_OBJECT(list_item), list_item_data_key, string);

 label = gtk_label_new("License and copyright");
 list_item = gtk_list_item_new_with_label("License and copyright");
 gtk_container_add(GTK_CONTAINER(help_list), list_item);
 gtk_widget_show(list_item);
 gtk_label_get(GTK_LABEL(label), &string);
 gtk_object_set_data(GTK_OBJECT(list_item), list_item_data_key, string);
}

void CB_help_click(GtkWidget *window, GtkWidget *event)
{
 GList *dlist;
 dlist = GTK_LIST(help_list)->selection;
 while (dlist)
 {
  GtkObject *list_item;
  gchar *item_data_string;
  list_item = GTK_OBJECT(dlist->data);
  item_data_string = gtk_object_get_data(list_item, list_item_data_key);
  show_help(g_strdup(item_data_string));
  dlist = dlist->next;
 }
}

void CB_kill_help(GtkWidget *window, GtkWidget *event)
{
 gtk_list_unselect_all(GTK_LIST(help_list));
 gtk_widget_destroy(help);
}

void show_help(char *topic)
{
 if(GTK_IS_WIDGET(help)) gtk_widget_destroy(help);
 help = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize (GTK_WIDGET (help), 500, 300);
 gtk_signal_connect (GTK_OBJECT (help), "delete_event",
  GTK_SIGNAL_FUNC(CB_kill_help), &help);
 gtk_window_set_title (GTK_WINDOW (help), "Visual GTK Help System");
 gtk_widget_set_uposition (GTK_WIDGET(help), 100, 100);
 gtk_container_border_width (GTK_CONTAINER (help), 0);
 gtk_widget_show(help);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (help), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 2);
 gtk_widget_show (vbox);

 help_table = gtk_table_new (2, 2, FALSE);
 gtk_table_set_row_spacing (GTK_TABLE (help_table), 0, 2);
 gtk_table_set_col_spacing (GTK_TABLE (help_table), 0, 2);
 gtk_box_pack_start (GTK_BOX (vbox), help_table, TRUE, TRUE, 0);
 gtk_widget_show (help_table);

 help_text = gtk_text_new(NULL, NULL);
 gtk_text_set_editable (GTK_TEXT (help_text), FALSE);
 gtk_text_set_word_wrap(GTK_TEXT (help_text), TRUE);
 gtk_table_attach_defaults (GTK_TABLE (help_table), help_text, 0, 1, 0, 1);
 gtk_widget_show (help_text);

 gtk_text_freeze(GTK_TEXT(help_text));
 gtk_widget_realize(help_text);
 if(!strcmp(topic, "Introduction to Visual GTK"))
 gtk_text_insert (GTK_TEXT (help_text), NULL, NULL, NULL, INTRO, -1);
 if(!strcmp(topic, "References and commands"))
 gtk_text_insert (GTK_TEXT (help_text), NULL, NULL, NULL, REF, -1);
 if(!strcmp(topic, "License and copyright"))
 gtk_text_insert (GTK_TEXT (help_text), NULL, NULL, NULL, LICENSE, -1);
 gtk_text_thaw(GTK_TEXT(help_text));

 sb = gtk_vscrollbar_new(GTK_TEXT(help_text)->vadj);
 gtk_table_attach(GTK_TABLE(help_table), sb, 1, 2, 0, 1,
 GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
 gtk_widget_show(sb);

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
 gtk_widget_show(hbox);

 button = gtk_button_new_with_label ("Close");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_kill_help), GTK_OBJECT(help));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
}

int main(int argc, char *argv[])
{
 gtk_init(&argc, &argv);
 gtk_set_locale();
 cmap = gdk_colormap_get_system();
 extract_color(&color, 0, 0, 0);
 gdk_color_alloc(cmap, &color);
 main_gui();
 new_project();
 gtk_main();
 return(0);
}
