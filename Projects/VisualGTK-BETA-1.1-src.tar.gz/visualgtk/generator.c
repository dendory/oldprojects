/* Visual GTK - (C) 1999 Patrick Lambert, see the LICENSE file */
#include "visualgtk.h"

void generate_code()
{
 int f, i, blah;
 sprintf(temp, "%s.h", project_name);
 fd0 = fopen(temp, "w");
 sprintf(temp, "%s.c", project_name);
 fd = fopen(temp, "w");
 fputs("#include <gtk/gtk.h>\n", fd0);
 fputs("#include <stdio.h>\n\n", fd0);
 fputs(more_includes, fd0);
 sprintf(temp, "#include \"%s.h\"\n\n", project_name);
 fputs(temp, fd);
 /* callbacks */
 for(i = 0; i < 500; i++)
 {
  if(vgtk_callbacks[i].created)
  {
   fputs(vgtk_callbacks[i].text, fd);
   fputs("\n\n", fd);
  }
 }
 /* frames */
 for(f = 0; f < 200; f++)
 {
  i = f;
  if(vgtk_frames[i].created)
  {
   sprintf(temp, "int make_%s()\n{\n", vgtk_frames[i].name);
   fputs(temp, fd);
   /*frame*/
   sprintf(temp, "\tif(GTK_IS_WIDGET(%s)) gtk_widget_destroy(%s);\n", vgtk_frames[i].name,
   vgtk_frames[i].name);
   fputs(temp, fd);
   sprintf(temp, "\t%s = gtk_window_new(GTK_WINDOW_TOPLEVEL);\n", vgtk_frames[i].name);
   fputs(temp, fd);
   sprintf(temp, "\tgtk_widget_set_usize(GTK_WIDGET(%s), %d, %d);\n", vgtk_frames[i].name,
   vgtk_frames[i].size_x, vgtk_frames[i].size_y);
   fputs(temp, fd);
   sprintf(temp, "\tgtk_widget_set_uposition(GTK_WIDGET(%s), %d, %d);\n", vgtk_frames[i].name,
   vgtk_frames[i].pos_x, vgtk_frames[i].pos_y);
   fputs(temp, fd);
   if(strcmp(vgtk_frames[i].signal_destroy, ""))
   {
    sprintf(temp, "\tgtk_signal_connect(GTK_OBJECT(%s), \"destroy\", GTK_SIGNAL_FUNC(%s), NULL);\n", vgtk_frames[i].name, vgtk_frames[i].signal_destroy);
    fputs(temp, fd);
   }
   if(strcmp(vgtk_frames[i].signal_delete_event, ""))
   {
    sprintf(temp, "\tgtk_signal_connect(GTK_OBJECT(%s), \"delete_event\", GTK_SIGNAL_FUNC(%s), NULL);\n", vgtk_frames[i].name, vgtk_frames[i].signal_delete_event);
    fputs(temp, fd);
   }
   sprintf(temp, "\tgtk_widget_show(%s);\n\n", vgtk_frames[i].name);
   fputs(temp, fd);
   /*main vbox*/
   sprintf(temp, "\t%s_vbox = gtk_vbox_new(FALSE, 0);\n", vgtk_frames[i].name);
   fputs(temp, fd);
   sprintf(temp, "\tgtk_container_add(GTK_CONTAINER(%s), %s_vbox);\n", vgtk_frames[i].name,
   vgtk_frames[i].name);
   fputs(temp, fd);
   sprintf(temp, "\tgtk_container_border_width(GTK_CONTAINER(%s_vbox), 2);\n",
   vgtk_frames[i].name);
   fputs(temp, fd);
   sprintf(temp, "\tgtk_widget_show(%s_vbox);\n\n", vgtk_frames[i].name);
   fputs(temp, fd);
   sprintf(temp, "GtkWidget *%s, *%s_vbox;\n", vgtk_frames[i].name, vgtk_frames[i].name);
   fputs(temp, fd0);
   /* boxes */
   for(i = 0; i < 400; i++)
   {
    if(vgtk_boxes[i].created && (!strcmp(vgtk_frames[f].name, vgtk_boxes[i].parent_win)))
    {
     if(vgtk_boxes[i].type==1)
     sprintf(temp, "\t%s = gtk_vbox_new(FALSE, 0);\n", vgtk_boxes[i].name);
     if(vgtk_boxes[i].type==0)
     sprintf(temp, "\t%s = gtk_hbox_new(FALSE, 0);\n", vgtk_boxes[i].name);
     if(vgtk_boxes[i].type==2)
     sprintf(temp, "\t%s = gtk_hbutton_box_new();\n", vgtk_boxes[i].name);
     fputs(temp, fd);
     sprintf(temp, "\tgtk_box_pack_start(GTK_BOX(%s), %s, TRUE, TRUE, 0);\n",
     vgtk_boxes[i].parent_box, vgtk_boxes[i].name);
     fputs(temp, fd);
     sprintf(temp, "\tgtk_widget_show(%s);\n", vgtk_boxes[i].name);
     fputs(temp, fd);
     sprintf(temp, "\tgtk_widget_set_usize(GTK_WIDGET(%s), %d, %d);\n\n", vgtk_boxes[i].name,
     vgtk_boxes[i].size_x, vgtk_boxes[i].size_y);
     fputs(temp, fd);
     sprintf(temp, "GtkWidget *%s;\n", vgtk_boxes[i].name);
     fputs(temp, fd0);
    }
   }
   /* buttons */
   for(i = 0; i < 200; i++)
   {
    if(vgtk_buttons[i].created && (!strcmp(vgtk_frames[f].name, vgtk_buttons[i].parent_win)))
    {
     sprintf(temp, "\t%s = gtk_button_new_with_label(\"%s\");\n", vgtk_buttons[i].name,
     vgtk_buttons[i].label);
     fputs(temp, fd);
     sprintf(temp, "\tgtk_box_pack_start(GTK_BOX(%s), %s, TRUE, TRUE, 0);\n",
     vgtk_buttons[i].parent_box, vgtk_buttons[i].name);
     fputs(temp, fd);
     if(strcmp(vgtk_buttons[i].signal_clicked, ""))
     {
      sprintf(temp, "\tgtk_signal_connect(GTK_OBJECT(%s), \"clicked\", GTK_SIGNAL_FUNC(%s), NULL);\n", vgtk_buttons[i].name, vgtk_buttons[i].signal_clicked);
      fputs(temp, fd);
     }
     sprintf(temp, "\tgtk_widget_show(%s);\n\n", vgtk_buttons[i].name);
     fputs(temp, fd);
     sprintf(temp, "GtkWidget *%s;\n", vgtk_buttons[i].name);
     fputs(temp, fd0);
    }
   }
   /* labels */
   for(i = 0; i < 200; i++)
   {
    if(vgtk_labels[i].created && (!strcmp(vgtk_frames[f].name, vgtk_labels[i].parent_win)))
    {
     if(vgtk_labels[i].is_var)
      sprintf(temp, "\t%s = gtk_label_new(%s);\n", vgtk_labels[i].name, vgtk_labels[i].label);
     if(!vgtk_labels[i].is_var)
      sprintf(temp, "\t%s = gtk_label_new(\"%s\");\n", vgtk_labels[i].name, vgtk_labels[i].label);
     fputs(temp, fd);
     sprintf(temp, "\tgtk_box_pack_start(GTK_BOX(%s), %s, TRUE, TRUE, 0);\n",
     vgtk_labels[i].parent_box, vgtk_labels[i].name);
     fputs(temp, fd);
     sprintf(temp, "\tgtk_widget_show(%s);\n\n", vgtk_labels[i].name);
     fputs(temp, fd);
     sprintf(temp, "GtkWidget *%s;\n", vgtk_labels[i].name);
     fputs(temp, fd0);
    }
   }
   /* entries */
   for(i = 0; i < 200; i++)
   {
    if(vgtk_entries[i].created && (!strcmp(vgtk_frames[f].name, vgtk_entries[i].parent_win)))
    {
     sprintf(temp, "\t%s = gtk_entry_new();\n", vgtk_entries[i].name);
     fputs(temp, fd);
     if(vgtk_entries[i].is_var)
      sprintf(temp, "\tgtk_entry_set_text(GTK_ENTRY(%s), %s);\n", vgtk_entries[i].name,
     vgtk_entries[i].text);
     if(!vgtk_entries[i].is_var)
      sprintf(temp, "\tgtk_entry_set_text(GTK_ENTRY(%s), \"%s\");\n", vgtk_entries[i].name,
     vgtk_entries[i].text);
     fputs(temp, fd);
     sprintf(temp, "\tgtk_box_pack_start(GTK_BOX(%s), %s, TRUE, TRUE, 0);\n",
     vgtk_entries[i].parent_box, vgtk_entries[i].name);
     fputs(temp, fd);
     sprintf(temp, "\tgtk_widget_show(%s);\n\n", vgtk_entries[i].name);
     fputs(temp, fd);
     sprintf(temp, "GtkWidget *%s;\n", vgtk_entries[i].name);
     fputs(temp, fd0);
    }
   }
   /* text */
   blah = 0;
   for(i = 0; i < 200; i++)
   {
    if(vgtk_text[i].created && (!strcmp(vgtk_frames[f].name, vgtk_text[i].parent_win)))
    {
     fputs("\ttable = gtk_table_new(2, 2, FALSE);\n", fd);
     fputs("\tgtk_table_set_row_spacing(GTK_TABLE(table), 0, 2);\n", fd);
     fputs("\tgtk_table_set_col_spacing(GTK_TABLE(table), 0, 2);\n", fd);
     sprintf(temp, "\tgtk_box_pack_start(GTK_BOX(%s), table, TRUE, TRUE, 0);\n",
     vgtk_text[i].parent_box);
     fputs(temp, fd);
     fputs("\tgtk_widget_show(table);\n\n", fd);
     sprintf(temp, "\t%s = gtk_text_new(NULL,NULL);\n", vgtk_text[i].name);
     fputs(temp, fd);
     sprintf(temp, "\tgtk_text_set_editable(GTK_TEXT(%s), TRUE);\n", vgtk_text[i].name);
     fputs(temp, fd);
     sprintf(temp, "\tgtk_text_set_word_wrap(GTK_TEXT(%s), TRUE);\n", vgtk_text[i].name);
     fputs(temp, fd);
     sprintf(temp, "\tgtk_table_attach_defaults(GTK_TABLE(table), %s, 0, 1, 0, 1);\n",
     vgtk_text[i].name);
     fputs(temp, fd);
     if(strcmp(vgtk_text[i].signal_changed, ""))
     {
      sprintf(temp, "gtk_signal_connect(GTK_OBJECT(%s), \"changed\", GTK_SIGNAL_FUNC(%s),
      NULL);\n", vgtk_text[i].name, vgtk_text[i].signal_changed);
      fputs(temp, fd);
     }
     sprintf(temp, "\tgtk_widget_show(%s);\n\n", vgtk_text[i].name);
     fputs(temp, fd);
     sprintf(temp, "\tgtk_text_freeze(GTK_TEXT(%s));\n", vgtk_text[i].name);
     fputs(temp, fd);
     sprintf(temp, "\tgtk_widget_realize(%s);\n", vgtk_text[i].name);
     fputs(temp, fd);
     if(strcmp(vgtk_text[i].initial_text, ""))
     {
      sprintf(temp, "\tgtk_text_insert(GTK_TEXT(%s), NULL, NULL, NULL, %s, -1);\n",
      vgtk_text[i].name, vgtk_text[i].initial_text);
      fputs(temp, fd);
     }
     sprintf(temp, "\tgtk_text_thaw(GTK_TEXT(%s));\n\n", vgtk_text[i].name);
     fputs(temp, fd);
     sprintf(temp, "GtkWidget *%s;\n", vgtk_text[i].name);
     fputs(temp, fd0);
     if(blah==0)
     {
      blah = 1;
      fputs("GtkWidget *table;\n", fd0);
     }
    }
   }


   /*
   WIDGET:
   Add code here
   */

   fputs("\n}\n", fd);
  }
 }/*frames*/
 fputs(main_text, fd);
 fclose(fd);
 fclose(fd0);
}

