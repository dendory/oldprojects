/* Visual GTK - (C) 1999 Patrick Lambert, see the LICENSE file */
#include "visualgtk.h"
#include "pixmaps/new.xpm"
#include "pixmaps/help.xpm"
#include "pixmaps/settings.xpm"
#include "pixmaps/save.xpm"
#include "pixmaps/exit.xpm"

void CB_msgbox(GtkWidget *window, GtkWidget *event)
{
 gtk_widget_destroy(win);
}

void msgbox(char *string)
{
 if(GTK_IS_WIDGET(win)) gtk_widget_destroy(win);

 win = gtk_dialog_new();
 gtk_widget_set_usize(GTK_WIDGET(win), strlen(string)+600, 120);
 gtk_signal_connect(GTK_OBJECT(win), "delete_event",
 GTK_SIGNAL_FUNC(CB_msgbox), &win);
 gtk_window_set_title(GTK_WINDOW(win), "Message");
 gtk_container_border_width(GTK_CONTAINER(win), 0);
 gtk_widget_set_uposition(win, 50, 200);
 gtk_widget_show(win);

 label = gtk_label_new(string);
 gtk_box_pack_start(GTK_BOX(GTK_DIALOG(win)->vbox), label, TRUE, TRUE, 0);
 gtk_widget_show(label);

 button = gtk_button_new_with_label("OK");
 gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
 GTK_SIGNAL_FUNC(CB_msgbox), GTK_OBJECT(win));
 gtk_box_pack_start(GTK_BOX(GTK_DIALOG(win)->action_area), button,
 TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default(button);
 gtk_widget_show(button);
}

char *lindex(char *input_string, int word_number)
{
 char *tokens[1024];
 static char tmpstring[1024];
 int i;
 strncpy(tmpstring,input_string,1024);
 (char *)tokens[i=0] = (char *)strtok(tmpstring, " ");
 while (((char *)tokens[++i] = (char *)strtok(NULL, " ")));
 tokens[i] = NULL;
 return(tokens[word_number]);
}

char *lrange(char *input_string, int starting_at)
{
 char *tokens[1024];
 static char tmpstring[1024]="";
 int i;
 char out_string[1024]="";
 strcpy(out_string,"");   
 if(input_string==NULL) { 
  strcpy(out_string," "); 
  strcat(out_string,NULL);
  strcpy(global_var,out_string);
  return (char *)global_var; }  
 strncpy(tmpstring,input_string,1024);
 (char *)tokens[i=0] = (char *)strtok(tmpstring, " ");
 while(((char *)tokens[++i] = (char *)strtok(NULL, " ")));
 tokens[i] = NULL;
 i++;
 if(i<starting_at)
 {
  return (char *)"";
 }
 while(tokens[starting_at] != NULL)
 {
  strncat(out_string,tokens[starting_at],1024);
  strcat(out_string, " ");
  starting_at++;
 }
 strncpy(global_var,out_string,511);
 return (char *)global_var;
}

GtkWidget *new_pixmap(int type, GdkWindow *window, GdkColor *background)
{
 GtkWidget *wpixmap;
 /* GdkPixmap *pixm; */
 GdkBitmap *mask;
 if(type==0)
  pixm = gdk_pixmap_create_from_xpm_d(window, &mask, background, new_xpm);
 if(type==1)
  pixm = gdk_pixmap_create_from_xpm_d(window, &mask, background, exit_xpm);
 if(type==2)
  pixm = gdk_pixmap_create_from_xpm_d(window, &mask, background, save_xpm);
 if(type==3)
  pixm = gdk_pixmap_create_from_xpm_d(window, &mask, background, settings_xpm);
 if(type==4)
  pixm = gdk_pixmap_create_from_xpm_d(window, &mask, background, help_xpm);
 wpixmap = gtk_pixmap_new (pixm, mask);
 return wpixmap;
}

gushort convert_color(unsigned c)
{
 if (c==0) return(0);
 c *= 257;
 return(c > 0xffff)? 0xffff : c;
}

void extract_color(GdkColor *color, unsigned red, unsigned green, unsigned blue)
{
 color->red = convert_color(red);
 color->green = convert_color(green);
 color->blue = convert_color(blue);
}


