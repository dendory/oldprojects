#include "easygtk.h"
#define VERSION "0.1"

/* widgets */
GtkWidget *init_win, *vbox, *hbox, *com_port;

/* variables */
char port[50], temp[512];

/* functions */
void init_screen();
void check_setup();
void client();
void server();





