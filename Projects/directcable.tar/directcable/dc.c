#include "dc.h"

int main(int argc, char *argv[])
{
 gtk_init(&argc, &argv);
 init_screen();
 gtk_main();
 return(0);
}

void init_screen()
{
 char *coms[] = { "/dev/ttyS0", "/dev/ttyS1", "/dev/ttyS2", "/dev/ttyS3" };
 char *types[] = { "Client side", "Server side" };
 init_win = e_window_create("Direct Cable Connection", 300, 325, 0, 0, exit);
 vbox = e_box_create(init_win, E_VERTICAL, 5);
 e_text_create(vbox, FALSE, "This utility allows you to connect with a remote Linux/UNIX computer using a null-modem serial cable. Here you have to select if you are going to be the client side, accessing remote resources, or the server side.\n\nBefore going further, make sure you have the PPPd server installed suid root, and the NFS client/server installed.", E_NO_FUNC);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Port:");
 com_port = e_combo_create(hbox, "/dev/ttyS1", coms, 4, E_NO_FUNC);
 e_radiobuttons_create(vbox, types, 2);
 e_buttonbox_create(vbox, E_SPREAD, "Ok", "Cancel", check_setup, exit);
}

void check_setup()
{
 int i = e_radiobuttons_get();
 strcpy(port, e_combo_get(com_port));
 gtk_widget_destroy(init_win);
 if(i==0) client();
 else server();
}

void client()
{
 printf("Checking setup...\n");
 sprintf(temp, "/usr/sbin/pppd -detach crtscts lock 192.168.234.2:192.168.234.1 %s 115200 &", port);
 printf("Running: %s\n", temp);
 system(temp);
 e_show_textbox("Direct Cable Connection", "The connection should be done now. To access a directory on the server side, type:\n\nmount -tnfs 192.168.234.1:/dir /mnt/other\n\nassuming you want to mount the remote directory /dir into the local directory /mnt/other.\n\nTo kill the connection, kill the pppd process.", exit);
}

void server()
{
 printf("Checking setup...\n");
 sprintf(temp, "/usr/sbin/pppd -detach crtscts lock 192.168.234.1:192.168.234.2 %s 115200 &", port);
 printf("Running: %s\n", temp);
 system(temp);
 e_show_textbox("Direct Cable Connection", "The connection should be done now. Make sure your /etc/exports file allows the client to mount the required directories. Type man exports for full documentation about the file.\n\nTo kill the connection, kill the pppd process.", exit);
}
