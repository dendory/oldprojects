/* (C) 1999 Patrick Lambert <drow@darkelf.net>
   This program is provided under the GPL license */
#include "sis.h"

void cb_add_create()
{
 sprintf(file, "%s/.sis/%s/%s", home, ddb, e_entry_get(e1));
 dbf = fopen(file, "w+");
 if(dbf == NULL)
 {
  e_show_message("Error", "Could not create database. You do not have permission, or bad name.", cb_abort);
 }
 else fclose(dbf);
 insert("name", e_entry_get(e1));
 insert("description", "");
 insert("type", "Workstation");
 insert("OS", "Linux 2.2");
 insert("IP", "");
 lt=time(NULL);
 insert("date", ctime(&lt));
 insert("machine", "PC AT/ATX");
 insert("CPU", "");
 insert("network", "");
 insert("users", "");
 gtk_clist_clear(GTK_CLIST(list));
 fill_list();
 gtk_widget_destroy(add_win);
 add_win = NULL;
}

void cb_add_abort()
{
 gtk_widget_destroy(add_win);
 add_win = NULL;
}

void add_system()
{
 if(add_win!=NULL) gtk_widget_destroy(add_win);
 add_win = e_window_create("Add a system to the list", 400, 200, 50, 150, cb_add_abort);
 vbox = e_box_create(add_win, E_VERTICAL, 5);
 label = e_label_create(vbox, "Enter the name for this system:");
 e1 = e_entry_create(vbox, "");
 e_buttonbox_create(vbox, E_SPREAD, "Cancel", "Create", cb_add_abort, cb_add_create);
}

void cb_remove()
{
 sprintf(temp, "rm -f \"%s/.sis/%s/%s\"", home, ddb, e_entry_get(e1));
 system(temp);
 gtk_widget_destroy(rem_win);
 rem_win = NULL;
 gtk_clist_clear(GTK_CLIST(list));
 fill_list();
}

void cb_remove_abort()
{
 gtk_widget_destroy(rem_win);
 rem_win = NULL;
}

void remove_system()
{
 if(rem_win!=NULL) gtk_widget_destroy(rem_win);
 rem_win = e_window_create("Add a system to the list", 400, 200, 50, 150, cb_remove_abort);
 vbox = e_box_create(rem_win, E_VERTICAL, 5);
 label = e_label_create(vbox, "Enter the name for this system:");
 e1 = e_entry_create(vbox, "");
 e_buttonbox_create(vbox, E_SPREAD, "Cancel", "Remove", cb_add_abort, cb_remove);
}
