/* (C) 1999 Patrick Lambert <drow@darkelf.net>
   This program is provided under the GPL license */
#include "sis.h"

void cb_help()
{
 gtk_widget_destroy(hlp_win);
 hlp_win = NULL;
}

void help(gchar *title, gchar *msg)
{
 if(hlp_win!=NULL) gtk_widget_destroy(hlp_win);
 hlp_win = e_window_create(title, 300, 200, 100, 100, cb_help);
 vbox = e_box_create(hlp_win, E_VERTICAL, 5);
 text = e_text_create(vbox, FALSE, msg, E_NO_FUNC);
}

void module_vnc()
{
 sprintf(temp, "vncviewer %s:1 &", current_ip);
 system(temp);
}

void module_vnc_help()
{
 help("Help on VNC", "VNC is a program used to see and manage the desktop of an other system. The VNC server must be running on that other system, on display 1, and you must have a VNC client on this system.\n\nThe client must be in your path and called vncviewer.\n\nThe VNC package is available on the web from http://www.uk.research.att.com/vnc");
}

void module_rexec()
{
 sprintf(temp, "xterm -e 'rsh %s' &", current_ip);
 system(temp);
}

void module_rexec_help()
{
 help("Help on rsh", "The remote shell program (rsh) is an insecure way of communicating with a remote system.");
}
