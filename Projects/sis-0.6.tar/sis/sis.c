/* (C) 1999 Patrick Lambert <drow@darkelf.net>
   This program is provided under the GPL license */

#include "sis.h"

void cb_exit()
{
 system("rm -f /tmp/.sis 2>/dev/null");
 exit(0);
}

void cb_abort()
{
 system("rm -f /tmp/.sis 2>/dev/null");
 exit(1);
}

void insert_list(gchar *name, gchar *type, gchar *description)
{
 gchar *elements[3] = { name, type, description };
 e_list_insert(list, elements);
}

gint insert(gchar *key, gchar *data)
{
 return e_config_update(file, key, data);
}

gchar *fetch(gchar *key)
{
 return e_config_fetch(file, key);
}

void fill_list()
{
 sprintf(temp, "ls -1 %s/.sis/%s/ > /tmp/.sis 2>&1", home, ddb);
 system(temp);
 fd = fopen("/tmp/.sis", "r");
 if(fd==NULL)
 {
  e_show_message("Error", "Can't open temporary file in /tmp, or the directory for the default group does not exist.", cb_abort);
 }
 while(fgets(line, 500, fd)!=NULL)
 {
  line[strlen(line)-1] = '\0';
  sprintf(file, "%s/.sis/%s/%s", home, ddb, line);
  dbf = fopen(file, "r+");
  if(dbf == NULL)
  {
   e_show_message("Error", "Group file corrupted or directory for the default group does not exist.", cb_abort);
  }
  else fclose(dbf);
  insert_list(fetch("name"), fetch("type"), fetch("description"));
 }
 fclose(fd);
}

void cb_about()
{
 sprintf(temp, "System Indexing Service v%s (C) 1999 Patrick Lambert", VERSION);
 e_show_message("About", temp, gtk_widget_destroy);
}

int main(int argc, char *argv[])
{
 if(getenv("HOME")==NULL || strlen(getenv("HOME"))>500)
 {
  printf("sis: HOME env value not set.\n");
  cb_abort();
 }
 strncpy(home, getenv("HOME"), 500);
 sprintf(temp, "%s/.sis/defaultdb", home);
 fd = fopen(temp, "r");
 if(fd == NULL)
 {
  printf("sis: Did not find the ~/.sis/defaultdb file. You must create that file and put a default group name in it, and create its sub-directory in the ~/.sis/ directory.\n");
  cb_abort();
 }
 fgets(ddb, 100, fd);
 if(ddb[strlen(ddb)-1]=='\n') ddb[strlen(ddb)-1]='\0';
 fclose(fd);
 gtk_init(&argc, &argv);
 sprintf(temp, "System Indexing Service (Group: %s)", ddb);
 win = e_window_create(temp, 400, 400, 100, 100, cb_exit);
 mbox = e_box_create(win, E_VERTICAL, 1);
 mbar = e_menu_create(mbox);
 menu = e_menu_insert_menu(mbar, "File", E_LEFT);
 e_menu_insert_item(menu, "About", cb_about);
 e_menu_insert_item(menu, "Exit", cb_exit);
 menu = e_menu_insert_menu(mbar, "Systems", E_LEFT);
 e_menu_insert_item(menu, "Add System", add_system);
 e_menu_insert_item(menu, "Remove System", remove_system);
 menu = e_menu_insert_menu(mbar, "Groups", E_LEFT);
 e_menu_insert_item(menu, "Change current group", change_group);
 e_menu_insert_item(menu, "Add a new group", add_group);
 list = e_list_create(mbox, 3, list_click);
 e_set_size(list, 400, 350);
 e_list_setup(list, 0, "Name", 100);
 e_list_setup(list, 1, "Type", 100);
 e_list_setup(list, 2, "Description", 200);
 fill_list();
 gtk_main();
 return 0;
}
