/* (C) 1999 Patrick Lambert <drow@darkelf.net>
   This program is provided under the GPL license */

#include "sis.h"

void cb_change_group_ok()
{
 strncpy(ddb, e_entry_get(e1), 100);
 gtk_clist_clear(GTK_CLIST(list));
 fill_list();
 sprintf(temp, "System Indexing Service (Group: %s)", ddb);
 gtk_window_set_title(GTK_WINDOW(win), temp);
 gtk_widget_destroy(cg_win);
 cg_win = NULL;
}

void cb_change_group_abort()
{
 gtk_widget_destroy(cg_win);
 cg_win = NULL;
}

void change_group()
{
 if(cg_win!=NULL) gtk_widget_destroy(cg_win);
 cg_win = e_window_create("Change the current group", 400, 200, 50, 150, cb_change_group_abort);
 vbox = e_box_create(cg_win, E_VERTICAL, 5);
 label = e_label_create(vbox, "Enter the name of the group:");
 e1 = e_entry_create(vbox, "");
 e_buttonbox_create(vbox, E_SPREAD, "Cancel", "Change", cb_change_group_abort, cb_change_group_ok);
}

void cb_add_group_ok()
{
 sprintf(temp, "mkdir -p %s/.sis/%s", home, e_entry_get(e1));
 system(temp);
 gtk_widget_destroy(ag_win);
 ag_win = NULL;
}

void cb_add_group_abort()
{
 gtk_widget_destroy(ag_win);
 ag_win = NULL;
}

void add_group()
{
 if(ag_win!=NULL) gtk_widget_destroy(ag_win);
 ag_win = e_window_create("Change the current group", 400, 200, 50, 150, cb_add_group_abort);
 vbox = e_box_create(ag_win, E_VERTICAL, 5);
 label = e_label_create(vbox, "Enter the name of the group:");
 e1 = e_entry_create(vbox, "");
 e_buttonbox_create(vbox, E_SPREAD, "Cancel", "Create", cb_add_group_abort, cb_add_group_ok);
}

