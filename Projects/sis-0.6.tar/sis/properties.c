/* (C) 1999 Patrick Lambert <drow@darkelf.net>
   This program is provided under the GPL license */
#include "sis.h"

gchar *os_list[15] = { "Linux 2.2", "Linux 2.0", "Solaris", "SunOS", "IRIX", "AIX", "Ultrix", "BeOS", "MacOS", "Windows 3.x", "Windows 95", "Windows 98", "Windows NT", "DOS", "OS/2" };
gchar *type_list[4] = { "Workstation", "Server", "Laptop", "Device" };
gchar *machine_list[10] = { "PC AT/ATX", "PC XT", "UltraSparc", "SGI/Origin", "DEC/Alpha", "Apple/G3", "AS/400", "RS/6000", "Router", "Other" };

void list_click()
{
 int i;
 strncpy(temp, e_list_get(), 1000);
 strcpy(line, "");
 for(i = 1; strcmp(lindex(temp,i),"|"); i++)
 {
  strcat(line, lindex(temp,i));
  if(strcmp(lindex(temp,i+1),"|")) strcat(line, " ");
 }
 sprintf(file, "%s/.sis/%s/%s", home, ddb, line);
 properties();
}

void cb_properties_cancel()
{
 gtk_widget_destroy(pro_win);
 pro_win = NULL;
}

void cb_properties_save()
{
 insert("name", e_entry_get(e2));
 insert("description", e_entry_get(e3));
 insert("type", e_combo_get(c1));
 insert("OS", e_combo_get(c2));
 insert("IP", e_entry_get(e4));
 insert("date", e_entry_get(e5));
 insert("machine", e_combo_get(c3));
 insert("CPU", e_entry_get(e6));
 insert("network", e_entry_get(e7));
 insert("users", e_entry_get(e8));
 gtk_widget_destroy(pro_win);
 pro_win = NULL;
 gtk_clist_clear(GTK_CLIST(list));
 fill_list();
}

void properties()
{
 strncpy(current_ip, fetch("IP"), 100);
 if(pro_win!=NULL) gtk_widget_destroy(pro_win);
 pro_win = e_window_create(fetch("name"), 350, 400, 200, 100, cb_properties_cancel);
 vbox = e_box_create(pro_win, E_VERTICAL, 5);
 notebook = e_notebook_create(vbox, E_TOP);
 page = e_notebook_new_page(notebook, "Info", "General Information");
 label = e_label_create(page, "System Name:");
 e2 = e_entry_create(page, fetch("name"));
 gtk_widget_set_sensitive(e2, FALSE);
 label = e_label_create(page, "System Description:");
 e3 = e_entry_create(page, fetch("description"));
 label = e_label_create(page, "Type of System:");
 c1 = e_combo_create(page, fetch("type"), type_list, 4, E_NO_FUNC);
 label = e_label_create(page, "Operating System:");
 c2 = e_combo_create(page, fetch("OS"), os_list, 15, E_NO_FUNC);
 label = e_label_create(page, "Hostname or IP:");
 e4 = e_entry_create(page, fetch("IP"));
 page = e_notebook_new_page(notebook, "Advanced", "Advanced Information");
 label = e_label_create(page, "Added On:");
 e5 = e_entry_create(page, fetch("date"));
 label = e_label_create(page, "Machine Type:");
 c3 = e_combo_create(page, fetch("machine"), machine_list, 10, E_NO_FUNC);
 label = e_label_create(page, "Processor Speed:");
 e6 = e_entry_create(page, fetch("CPU"));
 label = e_label_create(page, "Network Interface:");
 e7 = e_entry_create(page, fetch("network"));
 label = e_label_create(page, "Authorized Users:");
 e8 = e_entry_create(page, fetch("users"));
 page = e_notebook_new_page(notebook, "Tools", "Administration Tools");
 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), E_SPREAD);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 10);
 gtk_box_pack_start(GTK_BOX(page), hbox, FALSE, FALSE, 0);
 gtk_widget_show(hbox);
 e_label_create(hbox, "Remote desktop with VNC");
 button = e_toolbar_create(hbox, E_HORIZONTAL);
 e_toolbar_insert(button, NULL, NULL, e_icon_create(pro_win, "ok.xpm"), module_vnc);
 e_toolbar_insert(button, NULL, NULL, e_icon_create(pro_win, "help.xpm"), module_vnc_help);
 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), E_SPREAD);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 10);
 gtk_box_pack_start(GTK_BOX(page), hbox, FALSE, FALSE, 0);
 gtk_widget_show(hbox);
 e_label_create(hbox, "Remote execute");
 button = e_toolbar_create(hbox, E_HORIZONTAL);
 e_toolbar_insert(button, NULL, NULL, e_icon_create(pro_win, "ok.xpm"), module_rexec);
 e_toolbar_insert(button, NULL, NULL, e_icon_create(pro_win, "help.xpm"), module_rexec_help);
 button = e_buttonbox_create(vbox, E_END, "Close", "Save", cb_properties_cancel, cb_properties_save);
}

