/* (C) 1999 Patrick Lambert <drow@darkelf.net>
   This program is provided under the GPL license */
#include "easygtk.h"
#include <time.h>
#include <stdio.h>
#define VERSION "0.6"

GtkWidget *win, *vbox, *hbox, *mbox, *notebook, *page, *label, *menu, *list, *button, *add_win, *pro_win, *rem_win, *mbar, *ag_win, *cg_win, *hlp_win, *q_win, *text;
GtkWidget *e1, *e2, *e3, *e4, *e5, *e6, *e7, *e8, *c1, *c2, *c3;

gchar current_ip[128];
gchar temp[1024];
gchar line[512];
gchar result[1024];
gchar home[512];
gchar file[512];
gchar ddb[128];
FILE *fd, *dbf;
time_t lt;

void cb_properties_save();
void properties();
void cb_remove();
void remove_system();
char *lrange(char *input_string, int starting_at);
char *lindex(char *input_string, int word_number);
void list_click();
void add_system();
void fill_list();
void cb_exit();
gchar *fetch(gchar *key);
gint insert(gchar *key, gchar *data);
void cb_abort();
void cb_add_abort();
void insert_list(gchar *name, gchar *type, gchar *description);
void cb_remove_abort();
void change_group();
void add_group();
void cb_add_group_abort();
void cb_add_group_ok();
void cb_change_group_abort();
void cb_change_group_ok();
void cb_about();
void module_vnc();
void module_vnc_help();
void module_rexec();
void module_rexec_help();
