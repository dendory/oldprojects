#!/bin/sh
echo "I will now compile and install System Indexing Server on this station."
echo "Make sure you run this as root."
echo "Press CTRL+C to cancel, ENTER to continue."
read ans
make
make install
echo "Enter the user name under which you will be running System Indexing Server:"
read ans
echo "Creating /home/$ans/.sis files"
mkdir -p /home/$ans/.sis
echo "mygroup" > /home/$ans/.sis/defaultdb
echo "Creating default group name \"mygroup\""
mkdir -p /home/$ans/.sis/mygroup
echo "Done."
