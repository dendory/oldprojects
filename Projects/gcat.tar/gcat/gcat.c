/* gcat 0.2 - graphical cat program - Created in 1999 by Patrick Lambert
 * This program is in the public domain
*/
 
#include <gnome.h>
#include "easygtk.h"

int main(int argc, char *argv[])
{
 GtkWidget *gl, *app;
 GdkFont *font;
 if(argc<2)
 {
  fprintf(stderr, "gcat - Created in 1999 by Patrick Lambert\nSyntax: gcat <filename>\n");
  return 1;
 }
 gnome_init("gcat", "0.1", argc, argv);
 app = gnome_app_new("gcat", argv[1]);
 gtk_window_set_policy(GTK_WINDOW(app), TRUE, TRUE, FALSE);
 e_set_size(GTK_WIDGET(app), 300, 200);
 gtk_window_set_position(GTK_WINDOW(app), GTK_WIN_POS_CENTER);
 gtk_signal_connect(GTK_OBJECT(app), "delete_event", GTK_SIGNAL_FUNC(exit), NULL);
 gl = gnome_less_new();
 font = gdk_font_load("-adobe-helvetica-bold-o-normal-*-*-140-*-*-p-*-iso8859-1");
 gnome_less_set_font(GNOME_LESS(gl), font);
 gnome_less_show_file(GNOME_LESS(gl), argv[1]);
 gnome_app_set_contents(GNOME_APP(app), gl);
 gtk_widget_show_all(app);
 gtk_main();
 return 0;
}
