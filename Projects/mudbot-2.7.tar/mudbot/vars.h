/* vars.h - Most of these defines are for internal use, and debug. */
#include <time.h>
/* debug, compatibility */
/* random cryptpass letters */
#define CRYPTA 'z'
#define CRYPTB '0'
/* timeout from server */
#define TIMEOUT_VALUE 200
/* TCL program name */
#define TCL_INT "tclsh"
/* view everything (debug option) */
#undef DEBUG_OUT
/* check if the bot is running as root */
#define CHECK_ROOT
/* system is POSIX compatible */
#define POSIX
/* check the system limits */
#define CHECK_SYSTEM_MAX
/* use ircu server login */
#undef IRCU_2_10
/* Show server notices as numeric */
#undef SHOW_NOTICES_AS_NUMERIC

/* End of debug, compatibility part */

#define VERSION_MAJOR 2
#define VERSION_MINOR 7
typedef unsigned long IP;
extern char *token[];
extern char *linetok[];
extern char ltok[][30];
extern char buf[];
char buff[];
char bufc[];
extern char sockbuf[];
char servbuf[];
char chanbuf[];
extern char defchan[512];
char spying[255];
char spyto[255];
int antiidle;
extern int  botsck[];
int servsck;
int chansck;
int global_write_html;
extern int CONNECT;
extern long starttime;
int service_off;
char *servtok[];
char reports_names[512];
char reports_chan[512];
char clearchan[100];
int go_alias;
char banlist_nick[40];
char timers[200][516];
int MASSKILL_FLAG;
int by_nick;
int global_stats_lines;
char masskill_msg[512];
