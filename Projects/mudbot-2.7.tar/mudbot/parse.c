#include <stdio.h>
#include "vars.h"
#include "config.h"
/* parse.c
**      The socket's core of this code has been made by wildthang
**      <danny@wildstar.net>. You can modify it but not distribute it
**      modified. This file is part of Mudbot and is (C) 1997 by Drow
**      <drow@wildstar.net> All rights reserved.    
*/

extern char global_buf[];

int bot_parse(sck,fromhost,k)
int sck;
char *fromhost;
int k;
{ int level,i;
  token[0]++;
/*  token[3]++;*/
/*  if(k < 4) return; */

  /* Here is where you process privmsg send to bot or channels */
#ifdef BITCH
if (!cas_cmp(token[1],"MODE"))
{
 do_bitch(sck);
}
#endif              

#ifdef SHARE_USERFILE
if(token[1]!=NULL) {
 if(!cas_cmp(token[1],"PRIVMSG")) {
  if(token[2]!=NULL) {
   if(token[3]!=NULL) {
    if(!cas_cmp(token[3],":share-add")) do_shared(sck);
   }
  }
 }
}
#endif

if(token[1]!=NULL && token[2]!=NULL && token[3]!=NULL) {
 if(chklevel(fromhost)>0) {
  if(!cas_cmp(token[1],"PRIVMSG")) {
   if(*(token[3]+2)=='P' && *(token[3]+3)=='I' && *(token[3]+4)=='N' && *(token[3]+5)=='G') {
    if(token[4]!=NULL) 
    sprintf(buf,"NOTICE %s :\001PING %s\001\n",token[0],token[4]);
    else
    sprintf(buf,"NOTICE %s :\001PING %d\001\n",token[0],time(NULL));
    writeln(sck,buf); 
#ifdef REPORTS
    sprintf(buf,"PRIVMSG %s :%s did a PING on me...\n",REPORTS,token[0]);
    writeln(sck,buf);
#endif
   }
   if(*(token[3]+2)=='V' && *(token[3]+3)=='E' && *(token[3]+4)=='R' && *(token[3]+5)=='S' && *(token[3]+6)=='I') {
    sprintf(buf,"NOTICE %s :\001VERSION MudBot %d.%d\001\n",token[0],VERSION_MAJOR,VERSION_MINOR);
    writeln(sck,buf); 
#ifdef REPORTS
    sprintf(buf,"PRIVMSG %s :%s did a VERSION on me...\n",REPORTS,token[0]);
    writeln(sck,buf);
#endif
   }
  }
 }
}

#ifdef USE_BINDS
if(token[1] != NULL) {
#ifdef BIND_JOIN
 if(!cas_cmp(token[1],"JOIN")) bind_join(sck);
#endif
#ifdef BIND_PRIVMSG
 if(!cas_cmp(token[1],"PRIVMSG")) bind_msg(sck);
#endif
#ifdef BIND_NOTICE
 if(!cas_cmp(token[1],"NOTICE")) bind_notice(sck);
#endif
#ifdef BIND_PART
 if(!cas_cmp(token[1],"PART")) bind_part(sck);
#endif
#ifdef BIND_MODE
 if(!cas_cmp(token[1],"MODE")) bind_mode(sck);
#endif
}
#endif

#ifdef MASSDEOP
if(token[1]!=NULL) {
if(token[3]!=NULL) {
 if(!cas_cmp(token[1],"MODE")) {
  if(!cas_cmp(token[3],"-oooooo")&&*token[3]=='-') {
   sprintf(buf,"KICK %s %s :MASS-DEOP Protection!\n",token[2],token[0]);
   writeln(sck,buf);
  }
 }
} }
#endif

#ifdef VIEW
if(token[1] != NULL) {
 if(!cas_cmp(token[1],"PRIVMSG")) client_msg(sck);
 else if(!cas_cmp(token[1],"NOTICE")) client_notice(sck);
 else if(!cas_cmp(token[1],"TOPIC")) client_topic(sck);
 else if(!cas_cmp(token[1],"KICK")) client_kick(sck);
 else if(!cas_cmp(token[1],"JOIN")) client_join(sck);
 else if(!cas_cmp(token[1],"PART")) client_part(sck);
 else if(!cas_cmp(token[1],"NICK")) client_nick(sck);
 else if(!cas_cmp(token[1],"WALLOPS")) client_wallops(sck);
 else if(!cas_cmp(token[1],"INVITE")) printf("[INVITE] %s invites you to %s\n",token[2],token[3]);
}
#endif

if(cas_cmp(spying,"dummy") && token[1]!=NULL && token[2]!=NULL) {
 if(!cas_cmp(token[2],spying)) spy_report(sck);
}

#ifdef USE_ALIASES
  show_aliases(sck,fromhost,0);
#endif


 if(k < 4) return;

#ifdef LOGFILE_MSG
 if(!cas_cmp(token[1],"PRIVMSG") && token[2][0]!='#')
  writelog(fromhost,0);
#endif
#ifdef LOGFILE_PUB
 if(!cas_cmp(token[1],"PRIVMSG") && token[2][0]=='#')
 writelog(fromhost,1);
#endif

token[3]++;
  if(*token[3]==CMDCHAR)  do_check_command(sck,fromhost,k);
   else 
{
 sev_stuff(sck,k); 
}
}

sev_stuff(sck,k)
int sck;
int k;
{ 
  int i,j;
  FILE *fpa;
  char temp[512] = "Closing link ";
  char temp1[512] = "Closing link ";
  char local_buf[512];
  j=chk_num(0);
  if (!cas_cmp(token[0],"ERROR"))
  {
  if (!cas_cmp(token[1],":Closing")) {
  if(token[2]!=NULL) {
  if(token[3]!=NULL) {
   if (j>3)
   for(i=3;i<j;i++) {
    strcat(temp,token[i]);
    strcat(temp," "); } } }
  printf("*** Error from server: [%s]\n",temp);
#ifdef LOGERRORS
  strcpy(temp1,"Error from server: ");
  strcat(temp1,temp);
  logerr(temp1);
#endif 
#ifdef JUMPONERROR
  do_jump(sck,NULL,0);
#else
  exit(0);
#endif
 } }

#ifdef USE_ALIASES
#ifndef SHOW_NOTICES_AS_NUMERIC
 if(*token[1]=='1' || *token[1]=='2' || *token[1]=='3' || *token[1]=='4' || *token[1]=='5' || *token[1]=='6' || *token[1]=='7' || *token[1]=='8' || *token[1]=='9')
#endif
  show_aliases(sck,token[0],1);
#endif

  if((*token[1]=='3')&&(*(token[1]+1)=='2')&&(*(token[1]+2)=='4'))
  { do_clearmodes2(sck); }

  if((*token[1]=='3')&&(*(token[1]+1)=='5')&&(*(token[1]+2)=='2'))
  { do_masskill2(sck); }

 if(cas_cmp(reports_names,".")) {
  if((*token[1]=='3')&&(*(token[1]+1)=='5')&&(*(token[1]+2)=='3'))
  { report_clients(sck,0); }
  if((*token[1]=='3')&&(*(token[1]+1)=='6')&&(*(token[1]+2)=='6'))
  { report_clients(sck,1); } }

#ifdef VIEW
  if((*token[1]=='3')&&(*(token[1]+1)=='5')&&(*(token[1]+2)=='3'))
  { client_names(sck); } 

  if((*token[1]=='3')&&(*(token[1]+1)=='7')&&(*(token[1]+2)=='2'))
  { client_motd(sck); }

  if((*token[1]=='3')&&(*(token[1]+1)=='6')&&(*(token[1]+2)=='4'))
  { client_links(sck); }
  if((*token[1]=='0')&&(*(token[1]+1)=='0')&&(*(token[1]+2)=='5'))
  { client_links(sck); }

  if((*token[1]=='4')&&(*(token[1]+1)=='2')&&(*(token[1]+2)=='1'))
  { printf("Unknown command\n");; }  

  if((*token[1]=='4')&&(*(token[1]+1)=='3')&&(*(token[1]+2)=='3'))
  { printf("[0;35m[NICK][0;37m already taken\n"); }  

  if((*token[1]=='3')&&(*(token[1]+1)=='7')&&(*(token[1]+2)=='1'))
  { client_info(sck); }

  if((*token[1]=='3')&&(*(token[1]+1)=='5')&&(*(token[1]+2)=='1'))
  { client_version(sck); }

  if((*token[1]=='2')&&(*(token[1]+1)=='5')&&(*(token[1]+2)=='1'))
  { client_lusers(sck); }
  if((*token[1]=='2')&&(*(token[1]+1)=='5')&&(*(token[1]+2)=='2'))
  { client_lusers(sck); }
  if((*token[1]=='2')&&(*(token[1]+1)=='5')&&(*(token[1]+2)=='3'))
  { client_lusers(sck); }
  if((*token[1]=='2')&&(*(token[1]+1)=='5')&&(*(token[1]+2)=='4'))
  { client_lusers(sck); }
  if((*token[1]=='2')&&(*(token[1]+1)=='5')&&(*(token[1]+2)=='5'))
  { client_lusers(sck); }

  if((*token[1]=='4')&&(*(token[1]+1)=='0')&&(*(token[1]+2)=='1'))
  { client_no_whois(sck); }

  if((*token[1]=='3')&&(*(token[1]+1)=='1')&&(*(token[1]+2)=='1'))
  { client_whois_who(sck); }
  if((*token[1]=='3')&&(*(token[1]+1)=='1')&&(*(token[1]+2)=='9'))
  { client_whois_channels(sck); }
  if((*token[1]=='3')&&(*(token[1]+1)=='1')&&(*(token[1]+2)=='2'))
  { client_whois_server(sck); }
  if((*token[1]=='3')&&(*(token[1]+1)=='0')&&(*(token[1]+2)=='1'))
  { client_whois_away(sck); }
  if((*token[1]=='3')&&(*(token[1]+1)=='1')&&(*(token[1]+2)=='3'))
  { client_whois_oper(sck); }

  if((*token[1]=='3')&&(*(token[1]+1)=='1')&&(*(token[1]+2)=='4'))
  { client_whowas(sck); } 

  if((*token[1]=='4')&&(*(token[1]+1)=='0')&&(*(token[1]+2)=='6'))
  { printf("[WHOWAS] There was no such nickname.\n"); } 

  if((*token[1]=='4')&&(*(token[1]+1)=='7')&&(*(token[1]+2)=='4'))
  { printf("[BANNED] Cannot join channel %s\n",token[3]); }
  if((*token[1]=='4')&&(*(token[1]+1)=='7')&&(*(token[1]+2)=='5'))
  { printf("[KEY] Cannot join channel %s\n",token[3]); }
  if((*token[1]=='4')&&(*(token[1]+1)=='7')&&(*(token[1]+2)=='1'))
  { printf("[FULL] Cannot join channel %s\n",token[3]); }
  if((*token[1]=='4')&&(*(token[1]+1)=='7')&&(*(token[1]+2)=='3'))
  { printf("[INVITE] Cannot join channel %s\n",token[3]); }

  if((*token[1]=='2')&&(*(token[1]+1)=='4')&&(*(token[1]+2)=='3'))
  { client_stats(sck); }     
  if((*token[1]=='2')&&(*(token[1]+1)=='1')&&(*(token[1]+2)=='1'))
  { client_stats(sck); } 
  if((*token[1]=='2')&&(*(token[1]+1)=='1')&&(*(token[1]+2)=='3'))
  { client_stats(sck); } 
  if((*token[1]=='2')&&(*(token[1]+1)=='1')&&(*(token[1]+2)=='4'))
  { client_stats(sck); } 
  if((*token[1]=='2')&&(*(token[1]+1)=='4')&&(*(token[1]+2)=='4'))
  { client_stats(sck); } 
  if((*token[1]=='2')&&(*(token[1]+1)=='1')&&(*(token[1]+2)=='5'))
  { client_stats(sck); } 
  if((*token[1]=='2')&&(*(token[1]+1)=='1')&&(*(token[1]+2)=='6'))
  { client_stats(sck); } 
  if((*token[1]=='2')&&(*(token[1]+1)=='1')&&(*(token[1]+2)=='2'))
  { client_stats(sck); } 
  if((*token[1]=='2')&&(*(token[1]+1)=='4')&&(*(token[1]+2)=='9'))
  { client_stats(sck); } 
  if((*token[1]=='2')&&(*(token[1]+1)=='4')&&(*(token[1]+2)=='8'))
  { client_stats(sck); } 
  if((*token[1]=='2')&&(*(token[1]+1)=='1')&&(*(token[1]+2)=='8'))
  { client_stats(sck); } 
  if((*token[1]=='2')&&(*(token[1]+1)=='4')&&(*(token[1]+2)=='2'))
  { client_uptime(sck); } 

  if((*token[1]=='0')&&(*(token[1]+1)=='0')&&(*(token[1]+2)=='2'))
  { client_welcome_to_irc(sck); }
  if((*token[1]=='9')&&(*(token[1]+1)=='9')&&(*(token[1]+2)=='9'))
  { client_welcome_to_irc(sck); }

#endif

  if((*token[1]=='4')&&(*(token[1]+1)=='6')&&(*(token[1]+2)=='5')) 
  { printf("*** Ops! I'm banned from this server (K-Lined or G-Lined)\n");
#ifdef JUMPONERROR
 do_jump(sck,NULL,0);
#endif
#ifdef LOGERRORS
    logerr("I'm banned from this server (K-Lined or G-Lined)");
#endif 
    exit(0); }

  if((*token[1]=='3')&&(*(token[1]+1)=='0')&&(*(token[1]+2)=='2'))
  { do_userhost(sck); }

 if((*token[1]=='3')&&(*(token[1]+1)=='6')&&(*(token[1]+2)=='7'))   
 { do_clearbans2(sck); }

 if((*token[1]=='0')&&(*(token[1]+1)=='0')&&(*(token[1]+2)=='4'))
  { if(token[3]!=NULL && token[4]!=NULL) 
     printf("*** Connected on %s %s\n",token[3],token[4]); }

 if((*token[1]=='3')&&(*(token[1]+1)=='7')&&(*(token[1]+2)=='6'))
  {
start_chan(sck);
#ifdef MAX_CONNECT_COUNT
fpa=fopen(".connect.count","w");
fputs("0 0\n",fpa);
if(fpa!=NULL) fclose(fpa);
#endif
fpa=fopen("stats.file","a");
fputs("L\n",fpa);
fclose(fpa);
#ifdef VIEW
printf("\n\n\n\n\n\n-----------------------------------------------------------------\nMudBot IRC Client\n\n");
#endif
  sprintf(buf,"MODE %s %s\n",BOTNAME,UMODES);
  writeln(sck,buf);      
}   
 if((*token[1]=='4')&&(*(token[1]+1)=='2')&&(*(token[1]+2)=='2'))
  {
start_chan(sck);
#ifdef VIEW
printf("\n\n\n\n\n\n------------------------------------------------------------\nMudBot IRC Client\n\n");
#endif  
  sprintf(buf,"MODE %s %s\n",BOTNAME,UMODES);
  writeln(sck,buf);
}

     if((*token[1]=='4')&&(*(token[1]+1)=='3')&&(*(token[1]+2)=='3'))
  {  
 sprintf(buf,"NICK %s\n",BOTSECNAME); writeln(sck,buf);
}

  if((*token[1]=='4')&&(*(token[1]+1)=='6')&&(*(token[1]+2)=='5'))
  {
   sprintf(buf,"QUIT :Closed link\n");
   printf("*** Link closed by server (K-Lined or G-Lined)\n");
   writeln(sck,buf);
#ifdef JUMPONERROR
   do_jump(sck,NULL,0);
#endif
   exit(0);
  }
  if(*token[0]==':') token[0]++; if(*token[2]==':') token[2]++;
  if(k < 3) return;

/*  finishline(0);
*/
}

