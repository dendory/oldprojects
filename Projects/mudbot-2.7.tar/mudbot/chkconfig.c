#include "config.h"
#include <stdio.h>

main()
{ chk_config(); }

chk_config()
{
FILE *fpa;
char temp[255]; 
 if(chdir(PATH)) printf("ERROR path is not valid!\n");
 printf("\nChecking config options...\n");
#ifdef TERMINAL 
 printf("terminal... on\n");
#else
 printf("terminal... off\n");
#endif
#ifdef BACKGROUND
 printf("background... on\n");
#else
 printf("background... off\n");
#endif   
#ifdef UMODES
 if(cas_cmp(UMODES,"")) printf("umodes... %s\n",UMODES);
 else printf("umodes... ERROR no umodes defined!\n");
#else
 printf("umodes... ERROR no umodes defined!\n");
#endif
#ifdef ACCOUNTNAME
 if(cas_cmp(ACCOUNTNAME,"")) printf("account name... %s\n",ACCOUNTNAME);
 else printf("account name... ERROR no accountname defined!\n");
#else 
 printf("account name... WARNING no accountname defined!\n");
#endif
#ifdef REPORTS
 if(cas_cmp(REPORTS,"")) printf("main channel... %s\n",REPORTS);
 else printf("main channel... ERROR no main channel defined!\n");
#else
 printf("main channel... WARNING no main channel defined!\n");
#endif
#ifdef PATH
 if(cas_cmp(PATH,"")) printf("path... %s\n",PATH);
 else printf("path... ERROR no path defined!\n");
 if(*PATH=='~') printf("WARNING path is not in full-path format!\n");
#else 
 printf("path... ERROR no path defined!\n");
#endif
#ifdef DEFAULTPORT
 printf("port... %d\n",DEFAULTPORT);
 if(DEFAULTPORT < 0) printf("WARNING port is not valid!\n");
 if(DEFAULTPORT > 12000) printf("WARNING port is not valid!\n");
#else
 printf("port... ERROR no port defined!\n");
#endif
#ifdef BOTNAME
 if(cas_cmp(BOTNAME,"")) printf("bot nick... %s\n",BOTNAME);
 else printf("bot nick... ERROR no bot nick defined!\n");
#else
 printf("bot nick... ERROR no bot nick defined!\n");
#endif
#ifdef OPERVIEW
 if(cas_cmp(OPERVIEW,"")) printf("operview in channel... %s\n",OPERVIEW);
 else printf("operview... ERROR operview need a channel defined!\n");
#else
 printf("operview... not defined\n");
#endif
#ifdef VIEWKILLS
#ifdef OPERVIEW
 printf("viewkills... defined\n");
#endif
#ifndef OPERVIEW
 printf("viewkills... ERROR viewkills defined when OPERVIEW is not!\n");
#endif
#endif
#ifdef WARNINGS
 if(cas_cmp(WARNINGS,"")) printf("warnings in channel... %s\n",WARNINGS);
 else printf("warnings... ERROR warnings must be defined in a channel!\n");
#else
 printf("warnings... not defined\n");
#endif
#ifndef USERFILE
 printf("ERROR no user file defined!\n");
#endif
 fpa=fopen(USERFILE,"r");
 fgets(temp,255,fpa);
 if(!cas_cmp(temp,"")) printf("ERROR user file is empty!\n");   
 fclose(fpa);
 fpa=fopen("channels.file","r");
 fgets(temp,255,fpa);
 if(!cas_cmp(temp,"")) printf("ERROR channels file empty!\n");
 fclose (fpa);
 printf("Check completed.\n");
}

int cas_cmp(char *case1,char *case2)
{
   return (strcasecmp(case1,case2,strlen(case1)));
}
