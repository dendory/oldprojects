/* commands.c
**      The socket's core of this code has been made by wildthang
**      <danny@wildstar.net>. You can modify it but not distribute it
**      modified. This file is part of MudBot and is (C) 1997 by Drow
**      <drow@wildstar.net> all rights reserved.     
*/

#include <stdio.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <math.h>
#include <netinet/in.h>
#include <unistd.h>      
#include <errno.h>
#include "vars.h"
#include "config.h"
#ifdef POSIX
#include <sys/resource.h>
#include <sys/utsname.h>
#endif
FILE *fpalias;

int do_check_command(sck,fromhost,k)
int sck;
char *fromhost;
int k;
{ int level = 0;
  int secure = 0;
  int ismaster;
  FILE *fpa;
  char temp[512]="";
#ifdef INTER_WEB
  if(global_write_html==1) {
  strcpy(temp,HTMLDIR);
  strcat(temp,"/command.results");
  if((fpa=fopen(temp,"w"))!=NULL) fputs("",fpa);
  if(fpa!=NULL) fclose(fpa); }
#endif
  if(k!=(-775)) token[3]++;
  fpa=fopen("stats.file","a");
  fputs("C\n",fpa);
  if(fpa!=NULL) fclose(fpa);
  level = chklevel(fromhost,k); 

#ifdef REPORTS
#ifdef REPORT_COMMANDS
 sprintf(buf,"PRIVMSG %s :[%s] From %s[%s] Level %d\n",REPORTS,token[3],token[0],fromhost,level);
 writeln(sck,buf);
#endif
#endif

#ifdef LOGFILE_CMD
 if(cas_cmp(token[3],"validate")) {
  if(cas_cmp(token[3],"unvalidate")) { writelog(fromhost,2); } }
#endif
  if (level > -1) /* level 0 */
  {
   if (!cas_cmp(token[3],"up")) do_up(sck);
#ifdef BAR
     else if(!cas_cmp(token[3],"tip")) bar_tip(sck);
     else if(!cas_cmp(token[3],"drink")) bar_drink(sck); 
     else if(!cas_cmp(token[3],"beer")) bar_beer(sck);
     else if(!cas_cmp(token[3],"fortune")) do_fortune(sck);
     else if(!cas_cmp(token[3],"country")) do_country(sck);
     else if(!cas_cmp(token[3],"ircaddict")) do_ircaddict(sck);
     else if(!cas_cmp(token[3],"dice")) do_dice(sck);
     else if(!cas_cmp(token[3],"dns")) do_dns(sck); 
     else if(!cas_cmp(token[3],"uwhois")) do_uwhois(sck);
     else if(!cas_cmp(token[3],"uping")) do_uping(sck);
     else if(!cas_cmp(token[3],"unixtime")) do_unixtime(sck);
     else if(!cas_cmp(token[3],"listnames")) do_rep(sck);
     else if(!cas_cmp(token[3],"sv")) do_sv(sck);
#endif
#ifdef CHANSERV
   else if(!cas_cmp(token[3],"chanserv")) chanserv(sck,level,fromhost);
#endif
   else if(!cas_cmp(token[3],"vote")) do_vote(sck, fromhost);
#ifdef NICKSERV
   else if(!cas_cmp(token[3],"regnick")) do_regnick(sck);
   else if(!cas_cmp(token[3],"enforce")) do_enfnick(sck, fromhost);
#endif
#ifndef QUIET
   else if(!cas_cmp(token[3],"botauth")) do_botauth(sck);
#endif
#ifdef SERVICE
   else if(!cas_cmp(token[3],"operhelp")) do_operhelp(sck,level);
#endif
   else if(!cas_cmp(token[3],"validate")) 
   {
    do_validate(sck);
    return;
   }
   #ifdef SPY
    do_spy(sck);
   #endif
  }
  if(level > 0) /* level 1 */
  {
     if(!cas_cmp(token[3],"info")) do_hi(sck);
#ifndef QUIET
     else if(!cas_cmp(token[3],"update")) do_update(sck);
     else if(!cas_cmp(token[3],"help")) do_help(sck, level); 
#endif
     else if(!cas_cmp(token[3],"unvalidate")) do_unvalidate(sck); 
     else if(!cas_cmp(token[3],"news")) do_news(sck);
     else if(!cas_cmp(token[3],"tell")) do_tell(sck, fromhost);
     else if(!cas_cmp(token[3],"readmsg")) chk_msgs(sck);
     else if(!cas_cmp(token[3],"finger")) do_finger(sck);
     else if(!cas_cmp(token[3],"clearmsg")) clr_msgs(sck);
     else if(!cas_cmp(token[3],"description")) do_descript(sck);
/*     else if(!cas_cmp(token[3],"getemail")) do_getemail(sck); */
     else if(!cas_cmp(token[3],"kiss")) do_kiss(sck);
     else if(!cas_cmp(token[3],"access")) do_access(sck);
     else if(!cas_cmp(token[3],"seen")) do_seen(sck);
     else if(!cas_cmp(token[3],"newpass")) do_newpass(sck, level);
     else if(!cas_cmp(token[3],"voteresults")) do_voteresults(sck);
     else if(!cas_cmp(token[3],"whoami")) do_whoami(sck, level, fromhost);
#ifndef BAR
     else if(!cas_cmp(token[3],"tip")) bar_tip(sck);
     else if(!cas_cmp(token[3],"drink")) bar_drink(sck);
     else if(!cas_cmp(token[3],"beer")) bar_beer(sck);
     else if(!cas_cmp(token[3],"fortune")) do_fortune(sck);
     else if(!cas_cmp(token[3],"country")) do_country(sck);
     else if(!cas_cmp(token[3],"ircaddict")) do_ircaddict(sck);
     else if(!cas_cmp(token[3],"dice")) do_dice(sck);
     else if(!cas_cmp(token[3],"dns")) do_dns(sck);
     else if(!cas_cmp(token[3],"uwhois")) do_uwhois(sck);
     else if(!cas_cmp(token[3],"uping")) do_uping(sck);
     else if(!cas_cmp(token[3],"unixtime")) do_unixtime(sck);
     else if(!cas_cmp(token[3],"listnames")) do_rep(sck);
     else if(!cas_cmp(token[3],"sv")) do_sv(sck);
#endif
 }
  if (level > 1) /* level 2 */
{   
  if(!cas_cmp(token[3],"uptime")) do_uptime(sck);           
  else if(!cas_cmp(token[3],"topic")) do_topic(sck);  
  else if(!cas_cmp(token[3],"away")) do_away(sck);
  else  if(!cas_cmp(token[3],"invite")) do_invite(sck);     
  else if(!cas_cmp(token[3],"stats")) do_stats(sck);
  else if(!cas_cmp(token[3],"insult")) do_insult(sck);
}
  if(level > 2) /* level 3 */
{
     if(!cas_cmp(token[3],"kick")) do_kick(sck);
     else if(!cas_cmp(token[3],"ban")) do_ban(sck);
     else if(!cas_cmp(token[3],"unban")) do_unban(sck);
     else if(!cas_cmp(token[3],"voice")) do_voice(sck);
     else if(!cas_cmp(token[3],"unvoice")) do_unvoice(sck);
     else if(!cas_cmp(token[3],"kb")) do_kb(sck);
     else if(!cas_cmp(token[3],"teaseop")) do_tease(sck);
}
 if (level > 3) /* level 4 */
{
    if(!cas_cmp(token[3],"op")) do_op(sck);          
    else if(!cas_cmp(token[3],"deop")) do_deop(sck);
    else if(!cas_cmp(token[3],"msg")) do_msg(sck);            
    else if(!cas_cmp(token[3],"status")) do_status(sck, level);
    else if(!cas_cmp(token[3],"updatehtml")) do_updatehtml(sck);
    else if(!cas_cmp(token[3],"addtimer")) do_addtimer(sck);
    else if(!cas_cmp(token[3],"deltimer")) do_deltimer(sck);
    else if(!cas_cmp(token[3],"showtimers")) do_showtimers(sck);
}
 if (level > 4) /* level 5 */
{
    if(!cas_cmp(token[3],"mode")) do_mode(sck);       
    else if(!cas_cmp(token[3],"xauth")) do_xauth(sck);
    else if(!cas_cmp(token[3],"wauth")) do_wauth(sck);
    else if(!cas_cmp(token[3],"xkick")) do_xkick(sck);
    else if(!cas_cmp(token[3],"wkick")) do_wkick(sck);
    else if(!cas_cmp(token[3],"system")) do_system(sck);
    else if(!cas_cmp(token[3],"netblock")) do_netblock(sck);
}
 if (level > 5) /* level 6 */
{
    if(!cas_cmp(token[3],"join")) do_join(sck);          
    else if(!cas_cmp(token[3],"part")) do_part(sck);     
    else if(!cas_cmp(token[3],"userlist")) do_userlist(sck);     
    else if(!cas_cmp(token[3],"addlocal")) do_addlocal(sck);
    else if(!cas_cmp(token[3],"remlocal")) do_remlocal(sck);
    else if(!cas_cmp(token[3],"findlocal")) do_findlocal(sck);
    else if(!cas_cmp(token[3],"locallist")) do_locallist(sck);
    else if(!cas_cmp(token[3],"scan")) do_scan(sck);
    else if(!cas_cmp(token[3],"addscan")) do_addscan(sck);
    else if(!cas_cmp(token[3],"clearscan")) do_clearscan(sck);
}
 if (level > 6) /* level 7 */
{
    if(!cas_cmp(token[3],"nick")) do_nick(sck);    
    else if(!cas_cmp(token[3],"play")) do_play(sck);
    else if(!cas_cmp(token[3],"checkpopmail")) do_getpopmail(sck);
    else if(!cas_cmp(token[3],"cset")) do_cset(sck);
    else if(!cas_cmp(token[3],"readmail")) do_readmail(sck);
    else if(!cas_cmp(token[3],"jumpserv")) {
     if(token[5]==NULL || token[4]==NULL) {
      sprintf(buf,"NOTICE %s :Syntax: !jumpserv <server> <port>\n",token[0]);
      writeln(sck,buf);
      return 0; }
#ifdef CHANSERV
      close(chansck);
#endif
#ifdef SERVICE
      close(servsck);
#endif
      do_jump(sck,token[4],atoi(token[5])); }
    else if(!cas_cmp(token[3],"autoban")) do_addban(sck,fromhost);
    else if(!cas_cmp(token[3],"rautoban")) do_remban(sck);
    else if(!cas_cmp(token[3],"listautobans")) do_listautobans(sck);
    else if(!cas_cmp(token[3],"clearbans")) do_clearbans(sck);
    else if(!cas_cmp(token[3],"clearmodes")) do_clearmodes(sck);
    else if(!cas_cmp(token[3],"addsilence")) do_addsilence(sck);
    else if(!cas_cmp(token[3],"remsilence")) do_remsilence(sck);
}
 if (level > 7) /* level 8 */
{
     if(!cas_cmp(token[3],"adduser")) do_adduser(sck, level);
     else if(!cas_cmp(token[3],"close")) do_close(sck);
     else if(!cas_cmp(token[3],"operkill")) do_kill(sck);
     else if(!cas_cmp(token[3],"operwall")) do_wallops(sck);
     else if(!cas_cmp(token[3],"operup")) do_operup(sck);
     else if(!cas_cmp(token[3],"operrehash")) do_oprehash(sck);
     else if(!cas_cmp(token[3],"masskill")) do_masskill(sck);
     else if(!cas_cmp(token[3],"rehash")) 
     {
      sprintf(buf,"NOTICE %s :Rehashing config... Don't forget to revalidate\n",token[0]);
      writeln(sck,buf);
      loadusr(USERFILE);
     }      
#ifdef SERVICE
     if(service_off!=1) {
      if(!cas_cmp(token[3],"opcom")) do_opcom(sck);
      if(!cas_cmp(token[3],"serverstats")) do_operstats(sck);
      if(!cas_cmp(token[3],"gline")) do_gline(sck,1);
      if(!cas_cmp(token[3],"remgline")) do_gline(sck,0);
      if(!cas_cmp(token[3],"clearchan")) do_clearchan(sck);
      if(!cas_cmp(token[3],"lock")) do_lock(sck);
      if(!cas_cmp(token[3],"unlock")) do_unlock(sck); 
      if(!cas_cmp(token[3],"operin")) do_operin(sck);
      if(!cas_cmp(token[3],"jupe")) do_jupe(sck);
      if(!cas_cmp(token[3],"jupenick")) do_jupenick(sck);
      if(!cas_cmp(token[3],"operjoin")) do_operjoin(sck);
      if(!cas_cmp(token[3],"operpart")) do_operpart(sck);
      if(!cas_cmp(token[3],"wibble")) do_wibble(sck); 
      if(!cas_cmp(token[3],"killservice")) close(servsck);
      if(!cas_cmp(token[3],"makeoperserv")) {
#ifdef IRCU_2_10
       sprintf(buff,"NICK OperServ 1 1 OperServ %s %s :Oper Service\n",SERVICE_SERVER_NAME,SERVICE_SERVER_NAME);
#else
       sprintf(buff,"NICK OperServ 1 1 OperServ %s :Oper Service\n",SERVICE_SERVER_NAME);
#endif
       writeln(servsck,buff);
       sprintf(buff,":OperServ MODE OperServ +ko\n");
       writeln(servsck,buff); }
}
#endif
}

 if (level > 8) /* level 9 */
{
    if(!cas_cmp(token[3],"addchan")) do_addchan(sck);
    else if(!cas_cmp(token[3],"remchan")) do_remchan(sck);     
    else if(!cas_cmp(token[3],"countmail")) do_countmail(sck,NULL);
    else if(!cas_cmp(token[3],"remuser")) do_remuser(sck);
    else if(!cas_cmp(token[3],"spy")) do_spyo(sck);
    else if(!cas_cmp(token[3],"showaliases")) do_sa(sck);
    else if(!cas_cmp(token[3],"stopspy")) do_stopspy(sck);
#ifdef ALLOW_EXEC
    else if(!cas_cmp(token[3],"exec")) do_exec(sck);
#endif
#ifdef FTPMGR
    else if(!cas_cmp(token[3],"ftp")) ftpmgr(sck);
#endif
}
 if (level > 9) /* level 10 */
{
  if(!cas_cmp(token[3],"do")) do_scmd(sck);
#ifdef ALLOW_EXIT
  else if(!cas_cmp(token[3],"exit")) c_exit(sck);   
#endif
  else if(!cas_cmp(token[3],"history")) do_history(sck);
  else if(!cas_cmp(token[3],"cryptpass")) {
   if(token[4]!=NULL) {
    sprintf(buf,"NOTICE %s :%s\n",token[0],do_cryptpass(token[4]));
    writeln(sck,buf); } }
  else if(!cas_cmp(token[3],"clearmess")) do_clearmess(sck);
  else if(!cas_cmp(token[3],"notepad")) do_notepad(sck);
#ifdef SHARE_USERFILE
  else if(!cas_cmp(token[3],"leaf")) do_leaf(sck);
  else if(!cas_cmp(token[3],"share")) do_share(sck);
#endif
}
}

do_close(sck)
int sck;
{
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: close <channel>\n",token[0]);
  writeln(sck,buf); 
  return 0; }
 sprintf(buf,"MODE %s +mints-lpr\n",token[4]);
 writeln(sck,buf);
 sprintf(buf,"TOPIC %s :Closed channel.. Please be on your way\n",token[4]);
 writeln(sck,buf);
}

do_tease(sck)
int sck;
{
 if(token[4] == NULL || token[5] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: teaseop <channel> <nick>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 if(!cas_cmp(token[5],BOTNAME)|| !cas_cmp(token[5],BOTSECNAME)) {
  sprintf(buf,"KICK %s %s :What? You wanna tease me??\n",token[4],token[0]);
  writeln(sck,buf);
  return 0; }
 sprintf(buf,"MODE %s +o-o %s %s\n",token[4],token[5],token[5]);
 writeln(sck,buf);
}

do_kiss(sck)
int sck;
{
 if(token[4] == NULL || token[5] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: kiss <channel|nick> <nick>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 sprintf(buf,"PRIVMSG %s :KIIIIIIIIIIIIIIIIIISS for %s from %s :) Are you free tonight?\n",token[4],token[5],token[0]);
 writeln(sck,buf);
}

do_descript(sck)
int sck;
{
 FILE *fp;
 char temp[512];
 strcpy(temp,"");
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !description <channel>\n",token[0]); 
  writeln(sck,buf); 
  return 0; }
 fp = fopen("channels.file","r");
 while(fgets(temp,255,fp) != NULL)
 {
  if(!cas_cmp(lindex(temp,0),token[4])) {
   sprintf(buf,"NOTICE %s :%s\n",token[0],temp);
   writeln(sck,buf); }
 }
 if(fp!=NULL) fclose(fp);
}

do_clearbans(sck)
int sck;
{
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !clearbans <channel>\n",token[0]);
  writeln(sck,buf);
  return 0; }         
 sprintf(buf,"MODE %s +b\n",token[4]);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :Trying to clear...\n",token[0]);
 writeln(sck,buf);
}

do_clearbans2(sck)
int sck;
{
 if(token[4] != NULL) {
 sprintf(buf,"MODE %s -b %s\n",token[3],token[4]);
 writeln(sck,buf);
} }

do_readmsg(sck)
int sck;
{
 FILE *fp;
 char temp[512];
 strcpy(temp,"");
 fp = fopen("tell.file","r");
 sprintf(buf,"NOTICE %s :-Content of tell.file-\n",token[0]);
 writeln(sck,buf); 
 while(fgets(temp,255,fp) != NULL)
 {
  sprintf(buf,"NOTICE %s :- %s\n",token[0],temp);
  writeln(sck,buf);
 }
 sprintf(buf,"NOTICE %s :-End of tell.file-\n",token[0]);
 writeln(sck,buf);
 if(fp!=NULL) fclose(fp);
}

do_kb(sck)
int sck;
{
 char *s;
 char blah[255]="1";
 FILE *fp;
 if (token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !kb <channel> <nick>\n",token[0]);
  writeln(sck,buf);
  return 0; }         
 if(token[5]==NULL) strcpy(blah,token[2]);
 if(token[5]!=NULL)
 if(!cas_cmp(token[5],BOTNAME))
 {
  sprintf(buf,"KICK %s %s :Trying to kick me hey?\n",token[4],token[0]);
  writeln(sck,buf);
  return 0;
 }
 if (!cas_cmp(token[4],BOTNAME))
 {
  sprintf(buf,"KICK %s %s :What?? You think I'm LAME or something?!\n",token[4],token[0]);
  writeln(sck,buf);
  return 0;
 }     
 if(token[5]!=NULL)
 if(!cas_cmp(token[5],BOTSECNAME))   
 {
  sprintf(buf,"KICK %s %s :Trying to kick me hey?\n",token[4],token[0]);
  writeln(sck,buf);
  return 0;
 } 
 if(!cas_cmp(blah,"1")) sprintf(buf,"USERHOST %s\n",token[5]);
 else sprintf(buf,"USERHOST %s\n",token[4]);
 writeln(sck,buf);
 fp = fopen("tempo.temp","w");
 if(!cas_cmp(blah,"1")) {
  fputs(token[4],fp);
  fputs(" ",fp);
  fputs(token[5],fp); }
 else {
  fputs(blah,fp);
  fputs(" ",fp);
  fputs(token[4],fp); }
 fputs(" dummy\n",fp);
 if(fp!=NULL) fclose(fp);
 sprintf(buf,"MODE %s -o %s\n",token[4],token[5]);
 writeln(sck,buf);
}

do_userhost(sck)
int sck;
{
 FILE *fp;
 char s2[255]="";
 char s3[255]="";
 int z=0,i,j;
 char temp[512];
 strcpy(temp,"");
 if(!cas_cmp(token[3],":")) return 0;
/*s2 = malloc(200);*/
 strcpy(s2,token[3]);
 for(i=0;s2[i]!='@';i++) { }
 i++;
 j=i;
 if((fp=fopen("tempo.temp","r"))==NULL) return 0;
 fgets(temp,100,fp);
 for(i=i;s2[i]!=NULL;i++) {
  if(s2[i]=='0') s2[i]='?';
  if(s2[i]=='1') s2[i]='?';
  if(s2[i]=='2') s2[i]='?';
  if(s2[i]=='3') s2[i]='?';
  if(s2[i]=='4') s2[i]='?';
  if(s2[i]=='5') s2[i]='?';
  if(s2[i]=='6') s2[i]='?';
  if(s2[i]=='7') s2[i]='?';
  if(s2[i]=='8') s2[i]='?';
  if(s2[i]=='9') s2[i]='?'; }
 for(j=j;s2[j]!=NULL;j++) { s3[z]=s2[j]; z++; }
 sprintf(buf,"MODE %s +b *!*@%s\n",lindex(temp,0),s3);
 writeln(sck,buf);
 sprintf(buf,"KICK %s %s :%s\n",lindex(temp,0),lindex(temp,1),KB_MSG);
 writeln(sck,buf);
 if(fp!=NULL) fclose(fp);
}

do_kill(sck)
int sck;
{
#ifdef ALLOW_KILL
 char temp[255];
 int i;
 if(token[4]==NULL) return 0;
 strcpy(temp,"");
 if(token[5]!=NULL) {
  for(i=5;token[i]!=NULL;i++) {
   strcat(temp," ");
   strcat(temp,token[i]); } }
 sprintf(buf,"KILL %s :Kill requested by %s (%s )\n",token[4],token[0],temp);
 writeln(sck,buf);
#endif
}

do_oprehash(sck)
int sck;
{
#ifdef OPER_CMDS
 sprintf(buf,"REHASH\n");
 writeln(sck,buf);
#endif
}   

do_operup(sck)
int sck;
{
 if (token[4] == NULL || token[5] == NULL) return 0;
#ifdef OPER_CMDS
 sprintf(buf,"OPER %s %s\n",token[4],token[5]);
 writeln(sck,buf);
#endif
}  

do_wallops(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if(token[4] == NULL) return 0;
 if (j>3)
 for(i=4;i<j;i++) {
  strcat(temp,token[i]);
  strcat(temp," ");
 }                       
#ifdef OPER_CMDS
 sprintf(buf,"WALLOPS :%s\n",temp);
 writeln(sck,buf);
#endif
}  

do_locallist(sck)
int sck;
{
 FILE *fp;
 char temp[512];
 strcpy(temp,"");
 fp = fopen(LOCALFILE,"r");
 while(fgets(temp,255,fp) != NULL)
 {
  sprintf(buf,"NOTICE %s :%s\n",token[0],temp);
  writeln(sck,buf);
 }
 if(fp!=NULL) fclose(fp);
}

do_findlocal(sck)
int sck;
{
 int i;
 FILE *fp;
 char temp[512];
 strcpy(temp,"");
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !findlocal <channel>\n",token[0]);
  writeln(sck,buf);
  return 0; }         
 fp = fopen(LOCALFILE,"r");
 while(fgets(temp,255,fp) != NULL)
 {
  i=0;
  while(lindex(temp,i)!=NULL)
  {
   if(!cas_cmp(lindex(temp,i),token[4]))
   {
    sprintf(buf,"NOTICE %s :Found match: %s\n",token[0],temp);
    writeln(sck,buf);
   }
  i++;
  }
 }
 if(fp!=NULL) fclose(fp);
}

do_addban(sck, fromhost)
int sck;
char *fromhost;
{
 FILE *fp;
 int i,j;
 char temp[512];
 char temp2[612];
 strcpy(temp,"");
 j=chk_num(0);
 if(token[4]==NULL || token[5]==NULL || token[6]==NULL || atoi(token[5])<1) {
  sprintf(buf,"NOTICE %s :Syntax: !autoban <nick!user@host> <time in secs> <reason>\n",token[0]);
  writeln(sck,buf);
  return 0; }         
 strcpy(temp,"");
 if (j>5)
 for(i=6;i<j;i++) {
  strcat(temp,token[i]);
  strcat(temp," ");
 }                         
 fp = fopen(AUTOBAN,"a");
 sprintf(temp2,"%s %ld [by %s!%s] %s\n",token[4],(time(NULL)+atol(token[5])),token[0],fromhost,temp);
 fputs(temp2,fp);
 sprintf(buf,"NOTICE %s :Adding...\n",token[0]);
 writeln(sck,buf);
 if(fp!=NULL) fclose(fp);
}

do_remban(sck)
int sck;
{
 FILE *fpa;
 FILE *fpb;
 char temp[512];
 char temp2[512];
 char temp3[512];
 strcpy(temp,"");
 strcpy(temp2,"");
 strcpy(temp3,"");
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !rautoban <user@host>\n",token[0]);
  writeln(sck,buf);
  return 0; }         
 fpa = fopen("temp.temp","w");
 fpb = fopen(AUTOBAN,"r");
 while(fgets(temp,255,fpb) != NULL)
 {
  strcpy(temp2,temp);
  if (cas_cmp(lindex(temp,0),token[4]))
  {
   fputs(temp2,fpa);
  }
 }
 if(fpa!=NULL) fclose(fpa);
 if(fpb!=NULL) fclose(fpb);
 strcpy(temp3,"mv temp.temp ");
 strcat(temp3,AUTOBAN);
 system(temp3);
 sprintf(buf,"NOTICE %s :Removing...\n",token[0]);
 writeln(sck,buf);
}

do_remlocal(sck)
int sck;
{
 FILE *fpa;
 FILE *fpb;
 char temp[512];
 char temp2[512];
 char temp3[512];
 strcpy(temp,"");
 strcpy(temp2,"");
 strcpy(temp3,"");
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !remlocal <nick>\n",token[0]);
  writeln(sck,buf);
  return 0; }         
 fpa = fopen("temp.temp","w");
 fpb = fopen(LOCALFILE,"r");
 while(fgets(temp,255,fpb) != NULL)
 {
  strcpy(temp2,temp);
  if (cas_cmp(lindex(temp,0),token[4]))
  {
   fputs(temp2,fpa);
  }
 }
 if(fpa!=NULL) fclose(fpa);
 if(fpb!=NULL) fclose(fpb);            
 strcpy(temp3,"mv temp.temp ");
 strcat(temp3,LOCALFILE);
 system(temp3);
 sprintf(buf,"NOTICE %s :Removing...\n",token[0]);
 writeln(sck,buf);
} 

do_addlocal(sck)
int sck;
{
 FILE *fp;
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);  
 if(token[4] == NULL) {
 sprintf(buf,"NOTICE %s :!addlocal <nick> <channel1> <channel2>...\n",token[0]);
 writeln(sck,buf);
 return 0; }
 if (j>4)
 for(i=4;i<j;i++) {
  strcat(temp,token[i]);
  strcat(temp," ");
 }              
 strcat(temp," dummy");
 sprintf(buf,"NOTICE %s :Adding...\n",token[0]);
 writeln(sck,buf);         
 fp = fopen(LOCALFILE,"a");
 fputs(temp,fp);
 fputs("\n",fp);
 if(fp!=NULL) fclose(fp);
}

do_voice(sck)
int sck;
{
 sprintf(buf,"NOTICE %s :Voicing %s in channel %s\n",token[0],token[5],token[4]);
 writeln(sck,buf);
 sprintf(buf,"MODE %s +v %s\n",token[4],token[5]);
 writeln(sck,buf);
}

do_unvoice(sck)
int sck;
{
 sprintf(buf,"NOTICE %s :UnVoicing %s in channel %s\n",token[0],token[5],token[4]);
 writeln(sck,buf);
 sprintf(buf,"MODE %s -v %s\n",token[4],token[5]);
 writeln(sck,buf);
}  

do_tell(sck, fromhost)
int sck;
char *fromhost;
{
 time_t lt;
 long uptime = time(NULL);
 int i,j,k;
 FILE *ifp;
 char temp[512];
 if(token[4]==NULL || token[5]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !tell <nick> <msg>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 k=chknick(token[4]);
 if(k==0) {
  sprintf(buf,"NOTICE %s :Nick %s is not in userlist!\n",token[0],token[4]);
  writeln(sck,buf);
  return 0; }
 strcpy(temp,token[4]);
 strcat(temp,".notes");
 ifp = fopen(temp,"a");
 strcpy(temp,"From ");
 strcat(temp," [");
 strcat(temp,token[0]);
 strcat(temp,"!");
 strcat(temp,fromhost);
 strcat(temp,"] ");
 j=chk_num(0);
 if (j>4)
  for(i=4;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," ");
  }                      
 strcat(temp," - Recorded: ");
 fputs(temp,ifp);
 lt = time(NULL);
 fputs(ctime(&lt),ifp);
 fputs("\n",ifp);
 sprintf(buf,"NOTICE %s :Message for %s sent! Thanks for using %s Tell service!\n",token[0],token[4],BOTNAME);
 writeln(sck,buf);
 if(ifp!=NULL) fclose(ifp);
}

do_status(sck, ismaster)
int sck;
int ismaster;
{
 FILE *fp;
 char tempida[100];
 sprintf(buf,"NOTICE %s :- Bot Status -\n",token[0]);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :Bot Name: %s   Bot Desc: %s\n",token[0],BOTNAME,BOTDESC);
 writeln(sck,buf);
#ifdef URL
 sprintf(buf,"NOTICE %s :My URL is: %s\n",token[0],URL);
 writeln(sck,buf);
#endif
 sprintf(buf,"NOTICE %s :My master is: %s   Command char is: %c\n",token[0],MASTER,CMDCHAR);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :Default servers: %s - %s - %s - %s   Default port: %d\n",token[0],SERVERA,SERVERB,SERVERC,SERVERD,DEFAULTPORT);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :I'm supposed to watch:\n",token[0]);
 writeln(sck,buf);
 fp = fopen("channels.file","r");
 while(fgets(tempida,100,fp) != NULL)
 {
  sprintf(buf,"NOTICE %s :%s\n",token[0],tempida);
  writeln(sck,buf);
 }
 if(fp!=NULL) fclose(fp);
 if (ismaster > 7)
 {
  sprintf(buf,"NOTICE %s :Users file: %s   Startup script: %s\n",token[0],USERFILE,STARTSCRIPT);
  writeln(sck,buf);
#ifdef SPY
  sprintf(buf,"NOTICE %s :Spy on level 0 users: Yes\n",token[0]);
#else
  sprintf(buf,"NOTICE %s :Spy on level 0 users: No\n",token[0]);
#endif
  writeln(sck,buf);
#ifdef JUMPONERROR
  sprintf(buf,"NOTICE %s :Jump on server error: Yes\n",token[0]);
#else
  sprintf(buf,"NOTICE %s :Jump on server error: No\n",token[0]);
#endif
  writeln(sck,buf);
#ifdef BACKGROUND
  sprintf(buf,"NOTICE %s :Goto background on startup: Yes\n",token[0]);
#else
  sprintf(buf,"NOTICE %s :Goto background on startup: No\n",token[0]);
#endif
  writeln(sck,buf);
 }
 sprintf(buf,"NOTICE %s :- End of status -\n",token[0]);
 writeln(sck,buf);
}

do_spy(sck)
int sck;
{
 int i = 0;
 int j = 0;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if (j>3)
 {
  for(i=3;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," ");
   if (token[i] == NULL)
   {
    break;
   }
  }                          
 }
 sprintf(buf,"NOTICE %s :[%s] %s\n",MASTER,token[0],temp);
 writeln(sck,buf);
}

char *lrange(char *input_string, int starting_at)
{
 char *tokens[555];
 static char tmpstring[512];
 int i;
 char out_string[512];
/* out_string=malloc(512); */
 strcpy(out_string,"");
 if(input_string==NULL) {
  strcpy(out_string," ");
  strcat(out_string,NULL);
  return(out_string); }
 strcpy(tmpstring,input_string);
 tokens[i=0] = strtok(tmpstring, " ");
 while((tokens[++i] = strtok(NULL, " "))); 
 tokens[i] = NULL;
 i++;
 if(i<starting_at) { logerr("ERROR! Lrange bigger than actual string");
                     return NULL; }
 while(tokens[starting_at] != NULL) 
 {
  strcat(out_string,tokens[starting_at]);
  strcat(out_string, " ");
  starting_at++;
 }
 return(out_string); 
/*
 for(i=0;*(input_string+i)!='\0';i++)
 {
  if(z==starting_at)
  {
   f=1;
   break;
  }
  if(*(input_string+i)==' ') z++;
 }
 if(f!=1) return NULL;
 for(i=i;*(input_string+i)!='\0';i++) tmpstring[i]=*(input_string+i);
 i++;
 tmpstring[i]='\0';
 return(tmpstring);
*/
} 

char *lindex(char *input_string, int word_number)
{ 
 char *tokens[255];
 static char tmpstring[512]; 
 int i; 
 strcpy(tmpstring,input_string);
 tokens[i=0] = strtok(tmpstring, " ");
 while ((tokens[++i] = strtok(NULL, " ")));
 tokens[i] = NULL;
 return(tokens[word_number]);
/*
 for(i=0;*(input_string+i)!='\0';i++) 
 {
  if(z==word_number) 
  { 
   f=1; 
   break; 
  }
  if(*(input_string+i)==' ') z++; 
 }
 if(f!=1) return NULL;
 for(i=i;*(input_string+i)!=' ';i++) tmpstring[i]=*(input_string+i);
 i++;
 tmpstring[i]='\0';
 return(tmpstring);
*/
}

do_xauth(sck)
int sck;
{
 FILE *ifp;
 char pass[100];
 char chan[100];
 char dummy[200];
 ifp = fopen(CSFILE,"r");
 fgets(dummy,sizeof(dummy),ifp);
 fgets(dummy,sizeof(dummy),ifp);
 strcpy(chan,lindex(dummy,0));
 strcpy(pass,lindex(dummy,1));
 if(ifp!=NULL) fclose(ifp);
 sprintf(buf,"NOTICE %s :Sending AUTH request to X\n",token[0]);
 writeln(sck,buf);
 sprintf(buf,"PRIVMSG x@channels.undernet.org :PASS %s %s\n",chan,pass);
 writeln(sck,buf);
 sprintf(buf,"PRIVMSG x :OP %s %s\n",chan, BOTNAME);
 writeln(sck,buf);
}

do_wauth(sck)
int sck;
{
 FILE *ifp;
 char pass[100];
 char chan[100];
 char dummy[200];
 ifp = fopen(CSFILE,"r");
 fgets(dummy,sizeof(dummy),ifp);
 fgets(dummy,sizeof(dummy),ifp);
 strcpy(chan,lindex(dummy,0));
 strcpy(pass,lindex(dummy,1));      
 if(ifp!=NULL) fclose(ifp);
 sprintf(buf,"NOTICE %s :Sending AUTH request to W\n",token[0]);
 writeln(sck,buf);
 sprintf(buf,"PRIVMSG w@channels2.undernet.org :PASS %s %s\n",chan,pass);
 writeln(sck,buf);
 sprintf(buf,"PRIVMSG w :OP %s %s\n",chan, BOTNAME);
 writeln(sck,buf);
} 

do_xkick(sck)
int sck;
{
 FILE *ifp;
 int i;
 int j;
 char pass[100];
 char chan[100];
 char dummy[200];
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if (j>4)
  for(i=5;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," ");
 }                           
 ifp = fopen(CSFILE,"r");
 fgets(dummy,sizeof(dummy),ifp);
 fgets(dummy,sizeof(dummy),ifp);
 strcpy(chan,lindex(dummy,0));
 strcpy(pass,lindex(dummy,1));      
 if(ifp!=NULL) fclose(ifp);
 sprintf(buf,"NOTICE %s :Kicking *!*@%s from %s\n",token[0],token[4],chan);
 writeln(sck,buf);       
 sprintf(buf,"PRIVMSG X :kick %s *!*@%s %s\n",chan,token[4],temp);
 writeln(sck,buf);
}

do_wkick(sck)
int sck;
{
 FILE *ifp;
 int i;
 int j;
 char pass[100];
 char chan[100];
 char dummy[200];
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if (j>4)
  for(i=5;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," ");
 }
 ifp = fopen(CSFILE,"r");
 fgets(dummy,sizeof(dummy),ifp);
 fgets(dummy,sizeof(dummy),ifp);
 strcpy(chan,lindex(dummy,0));
 strcpy(pass,lindex(dummy,1));      
 if(ifp!=NULL) fclose(ifp);
 sprintf(buf,"NOTICE %s :Kicking *!*@%s from %s\n",token[0],token[4],chan);
 writeln(sck,buf);
 sprintf(buf,"PRIVMSG W :kick %s *!*@%s %s\n",chan,token[4],temp);
 writeln(sck,buf);
} 

do_news(sck)
int sck;
{
 FILE *ifpa;
 char temp[512];
 strcpy(temp,"");
 ifpa = fopen(NEWSFILE,"r");
 while(fgets(temp,sizeof(temp),ifpa) != NULL)
 {
  sprintf(buf,"NOTICE %s :%s\n",token[0],temp);
  writeln(sck,buf);
 }
 if(ifpa!=NULL) fclose(ifpa);
}

do_remchan(sck)
int sck;
{
 FILE *ifpa;
 FILE *ifpb;
 char str[255];
 char temp[512];
 strcpy(temp,"");
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !remchan <channel>\n",token[0]);
  writeln(sck,buf);
  return 0; }         
 system("mv channels.file channels.old");
 ifpa = fopen("channels.old","r");
 ifpb = fopen("channels.file","w");
 strcat(token[4],"\n");
 while(fgets(temp,sizeof(temp),ifpa) != NULL)
 {
  strcpy(str,token[4]);
  str[strlen(str)-1]='\0'   ;
  if(cas_cmp(str,lindex(temp,0)))
  {
   fputs(temp,ifpb);
  }         
 }
 if(ifpa!=NULL) fclose(ifpa);
 if(ifpb!=NULL) fclose(ifpb);
 sprintf(buf,"NOTICE %s :Removing...\n",token[0]);
 writeln(sck,buf);
} 

do_remuser(sck)
int sck;
{
 FILE *fp;
 FILE *fpb;
 char line[255];
 char line2[255];
 int i,j;
 char tempa[100] = "";
 char tempb[100] = "";
 char *tempp = "";
 char another[100] = "cp user.new ";
 if(token[4] == NULL) return 0;
 if(!cas_cmp(token[4],MASTER)) {
  sprintf(buf,"NOTICE %s :Error: You cannot remove your master.\n",token[0]);
  writeln(sck,buf);
  return 0; }
 fp = fopen(USERFILE,"r");
 fpb = fopen("user.new","w");
 for (i=0;fgets(line, 255, fp);i++)
 {
  strcpy(line2,line);
  if(tempp = strtok(line,":"))    /* level */
   strcpy(tempa,tempp);

  if(tempp = strtok(NULL,":"))    /* nick */
   strcpy(tempb,tempp);                       
 if (cas_cmp(tempb,token[4]))
 {
   fputs(line2,fpb);
 }
 }
 if(fp!=NULL) fclose(fp);
 if(fpb!=NULL) fclose(fpb);
 strcat(another,USERFILE);
 system(another);
 sprintf(buf,"NOTICE %s :Removing...\n",token[0]);
 writeln(sck,buf);
}

do_addchan(sck)
int sck;
{
 FILE *ifpa;
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !addchan <channel> <descr>\n",token[0]);
  writeln(sck,buf);
  return 0; }         
 if(token[5] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !addchan <channel> <descr>\n",token[0]);
  writeln(sck,buf);
  return 0; }         
 if (j>4)
 for(i=4;i<j;i++) {
  strcat(temp,token[i]);
  strcat(temp," ");
 }                     
 ifpa = fopen("channels.file","a");
 fputs(temp,ifpa);
 fputs("\n",ifpa);
 if(ifpa!=NULL) fclose(ifpa);
 sprintf(buf,"NOTICE %s :Adding...\n",token[0]);
 writeln(sck,buf);
}

do_userlist(sck)
int sck;
{
 FILE *fp;
#ifdef MEMLEAK
 char list1[200];
 char list2[200];
 char list3[200];
 char list4[200];
 char list5[200];
 char list6[200];
 char list7[200];
#else
 char uselist[100][30][50] ={ "" };
#endif
 char line[255];
 int i,j;
 char *tempi = "";
 sprintf(buf,"NOTICE %s :User list:\n");
 writeln(sck,buf);
 if( (fp = fopen(USERFILE,"r"))==NULL) return 0;
 for (i=0;fgets(line, 255, fp);i++)
 {
#ifdef MEMLEAK
  if(tempi = strtok(line,":"))    /* level */
  strcpy(list1,tempi);
 if(tempi = strtok(NULL,":"))    /* nick */
  strcpy(list2,tempi);   
 if(tempi = strtok(NULL,":"))    /* u@h */
  strcpy(list3,tempi);    
 if(tempi = strtok(NULL,":"))    /* pass */
  strcpy(list4,tempi);    
 if(tempi = strtok(NULL,":"))    /* validate */
  strcpy(list5,tempi);    
 if(tempi = strtok(NULL,":"))    /* autoop */
  strcpy(list6,tempi);    
 if(tempi = strtok(NULL,":"))    /* email */
  strcpy(list7,tempi);    
#else
  if(tempi = strtok(line,":"))    /* level */
  strcpy(uselist[i][1],tempi);
 if(tempi = strtok(NULL,":"))    /* nick */
  strcpy(uselist[i][2],tempi); 
 if(tempi = strtok(NULL,":"))    /* u@h */
  strcpy(uselist[i][3],tempi); 
 if(tempi = strtok(NULL,":"))    /* pass */
  strcpy(uselist[i][4],tempi);                 
 if(tempi = strtok(NULL,":"))    /* validate */
  strcpy(uselist[i][5],tempi);                 
 if(tempi = strtok(NULL,":"))    /* autoop */
  strcpy(uselist[i][6],tempi);                 
 if(tempi = strtok(NULL,":"))    /* email */
  strcpy(uselist[i][7],tempi);                 
 sprintf(buf,"NOTICE %s :Nick: %s UserHost: %s Level: %s Email: %s\n",token[0],uselist[i][2],uselist[i][3],uselist[i][1],uselist[i][7]);
#endif
#ifdef MEMLEAK
 sprintf(buf,"NOTICE %s :Nick: %s UserHost: %s Level: %s Email: %s\n",token[0],list2,list3,list1,list7);
#endif
 writeln(sck,buf);
 }
 if(fp!=NULL) fclose(fp);                             
}

do_uptime(sck)
int sck;
{
 FILE *ifp;
 char loctime[100];
 long runningsince;
 long oldtimed;
 long uptimed = time(NULL);
 char temp[512];
 strcpy(temp,"");
 ifp = fopen("uptime.file","r");
 fgets(loctime,sizeof(loctime),ifp);
 fgets(temp,100,ifp); 
 oldtimed = atol(temp);
 runningsince = uptimed - oldtimed; 
 sprintf(buf,"NOTICE %s :This bot is up and running since:\n",token[0]);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :%s\n",token[0],loctime);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :[%ld secs]\n",token[0],runningsince);
 writeln(sck,buf);
 if(ifp!=NULL) fclose(ifp);
}

do_adduser(sck, level)
int sck;
{
 FILE *ifpa;
 FILE *ifpb;
 char tempstring[300];
 if (token[4] == NULL)
 {
  sprintf(buf,"NOTICE %s :Syntax: !adduser <nick> <u@h> <level> <pass> <autoop [1|0]> <email>\n",token[0]);
  writeln(sck,buf);
  return 0;
 }   
 if (token[9]==NULL || token[8]==NULL || token[7]==NULL || token[6]==NULL || token[5]==NULL)
 {
  sprintf(buf,"NOTICE %s :Syntax: !adduser <nick> <u@h> <level> <pass> <autoop [1|0]> <email>\n",token[0]);
  writeln(sck,buf);
  return 0;
 }    
 if (atoi(token[6]) <= 0)
 {
  sprintf(buf,"NOTICE %s :Syntax: !adduser <nick> <u@h> <level> <pass> <autoop [1|0]> <email>\n",token[0]);
  writeln(sck,buf);
  return 0;
 }
 if (atoi(token[6]) >= level)
 {
  sprintf(buf,"NOTICE %s :Syntax: !adduser <nick> <u@h> <level> <pass> <autoop [1|0]> <email>\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :You can't add a user with a higher level then you\n",token[0]);
  writeln(sck,buf);
  return 0;
 }    
 if(*(token[5]+1)=='!') {
  sprintf(buf,"NOTICE %s :You must add users with user@host and not nick!user@host\n",token[0]);
  writeln(sck,buf);
  return 0; }
 if(*token[8]!='0') {
  if(*token[8]!='1') {
   sprintf(buf,"NOTICE %s :Autoop field must be 0 or 1. 0 for no autoop or 1 for autoop.\n",token[0]);
   writeln(sck,buf);
   return 0; } }
 sprintf(buf,"NOTICE %s :Adding... Don't forget to rehash\n",token[0]);
 writeln(sck,buf);
 strcpy(tempstring,token[6]);
 strcat(tempstring,":");
 strcat(tempstring,token[4]);
 strcat(tempstring,":");
 strcat(tempstring,token[5]);
 strcat(tempstring,":");
#ifdef USE_CRYPT_PASSWD
 strcat(tempstring,do_cryptpass(token[7]));
#else
 strcat(tempstring,token[7]);
#endif
#ifdef USE_VALIDATE
 strcat(tempstring,":0");
#else
 strcat(tempstring,":1");
#endif
 strcat(tempstring,":");
 strcat(tempstring,token[8]);     
 strcat(tempstring,":");
 strcat(tempstring,token[9]);   
 strcat(tempstring,":\n");
 ifpa = fopen(USERFILE,"a");
 fputs(tempstring,ifpa);        
 if(ifpa!=NULL) fclose(ifpa);
}

do_msg(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if (token[5] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !msg <channel> <msg>\n",token[0]);
  writeln(sck,buf);
  return 0; }         
 if (token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !msg <channel> <msg>\n",token[0]);
  writeln(sck,buf);
  return 0; }         
 strcpy(temp,"PRIVMSG ");
 strcat(temp,token[4]);
 strcat(temp," :[");
 strcat(temp,token[0]);
 strcat(temp,"] ");
 if (j>4)
  for(i=5;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," ");
  }
  sprintf(buf,"%s\n",temp); writeln(sck,buf);       
}

do_mode(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !mode <channel> <modes>\n",token[0]);
  writeln(sck,buf);
  return 0; }         
 if(token[5] == NULL) {
  strcpy(temp,"MODE ");
  strcat(temp,token[2]);
  strcat(temp," ");
  if (j>3)
  for(i=4;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," ");   
  }
  sprintf(buf,"%s\n",temp); writeln(sck,buf);
 }         
 strcpy(temp,"MODE ");
 strcat(temp,token[4]);
 strcat(temp," ");
 if (j>4)
  for(i=5;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," ");
  }
  sprintf(buf,"%s\n",temp); writeln(sck,buf);        
}

do_join(sck)
int sck;
{
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !join <channel> [key]\n",token[0]);
  writeln(sck,buf);
  return 0; }
 if(!cas_cmp(token[4],"0")) return 0;
 sprintf(buf,"NOTICE %s :Joining %s\n",token[0], token[4]);
 writeln(sck,buf);
 if(token[5]!=NULL) sprintf(buf,"JOIN %s %s\n",token[4],token[5]);
 else sprintf(buf,"JOIN %s\n",token[4]);
 writeln(sck,buf);
}

do_whoami(sck, level, fromhost)
int sck;
{
/* int level;
 char *fromhost;*/
 sprintf(buf,"NOTICE %s :You are %s from %s\n",token[0],token[0],fromhost);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :You are level %d\n",token[0],level);
 writeln(sck,buf);
}

do_invite(sck)
int sck;
{
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !invite <channel>\n",token[0]);
  writeln(sck,buf);
  return 0; }                
 sprintf(buf,"NOTICE %s :Inviting you to %s\n",token[0], token[4]);
 writeln(sck,buf);
 sprintf(buf,"INVITE %s :%s\n",token[0],token[4]);
 writeln(sck,buf);
}  

do_part(sck)
int sck;
{
 sprintf(buf,"NOTICE %s :Leaving %s\n",token[0], token[4]);
 writeln(sck,buf);
 sprintf(buf,"PART %s\n",token[4]);
 writeln(sck,buf);
}       

do_kick(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if (token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !kick <channel> <nick> <reason>\n",token[0]);
  writeln(sck,buf);
  return 0; }              
 if(token[5] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !kick <channel> <nick> <reason>\n",token[0]);
  writeln(sck,buf);
  return 0; }         
 if (!cas_cmp(token[5],BOTNAME) || !cas_cmp(token[4],BOTNAME))
 {
  sprintf(buf,"KICK %s %s :What?? You think I'm LAME or something?!\n",token[4],token[0]);
  writeln(sck,buf);
  return 0;
 }
 if (!cas_cmp(token[5],token[2]))
 {
  sprintf(buf,"KICK %s %s :What?? You think I'm LAME or something?!\n",token[4],token[0]);
  writeln(sck,buf);
  return 0;
 }     
 if(*token[4]!='#') {
  if (j>5)
  for(i=6;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 else {
  if(j>4)
  for(i=5;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } } 
 if(*token[4]=='#') {
 sprintf(buf,"KICK %s %s :%s\n",token[4],token[5],temp); }
 else {
 sprintf(buf,"KICK %s %s :%s %s\n",token[2],token[4],token[5],temp); }
 writeln(sck,buf);
 if(*token[4]!='#') {
 sprintf(buf,"NOTICE %s :Kicking %s from %s\n",token[0],token[4],token[2]); }
 else {
 sprintf(buf,"NOTICE %s :Kicking %s from %s\n",token[0],token[5],token[4]); }
 writeln(sck,buf);
}

do_deop(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0); 
 if (token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !deop <channel> <nick>\n",token[0]);
  writeln(sck,buf);
  return 0; }              
 if(token[5]!=NULL) {
 if(!cas_cmp(token[5],BOTNAME))
 {
  sprintf(buf,"KICK %s %s :What?? You think I'm LAME?!\n",token[2],token[0]);  
  writeln(sck,buf);
  return 0; } }
 if(!cas_cmp(token[4],BOTNAME))
 {
  sprintf(buf,"KICK %s %s :What?? You think I'm LAME or something?!\n",token[4],token[0]);
  writeln(sck,buf);
  return 0;
 }
 if(*token[2]!='#') {
 if (!cas_cmp(token[4],token[2]))
 {
  sprintf(buf,"KICK %s %s :What?? You think I'm LAME or something?!\n",token[4],token[0]);
  writeln(sck,buf);
  return 0;
 }     }
  if (j>3)
  for(i=4;i<j;i++) {
 if (!cas_cmp(token[i],BOTNAME))
 {
  sprintf(buf,"KICK %s %s :You think I'm LAME or something?!\n",token[4],token[0]);
  writeln(sck,buf);
  return 0;
 }                
 if(i != 4) {
 if (!cas_cmp(token[i],token[2]))
 {
  sprintf(buf,"KICK %s %s :What?? No way!\n",token[4],token[0]);
  writeln(sck,buf);
  return 0;
 } }     
   strcat(temp,token[i]);
   strcat(temp," ");
  }    
 if(*token[2]=='#') {
 sprintf(buf,"MODE %s -oooooo %s\n",token[2],temp);
 writeln(sck,buf); }
 else {
 sprintf(buf,"MODE %s -oooooo %s\n",token[4],temp);
 writeln(sck,buf); }
}      

do_ban(sck)
int sck;
{
 sprintf(buf,"MODE %s +b %s\n",token[4],token[5]);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :Banning %s from %s at your request\n",token[0],token[5],token[4]);
 writeln(sck,buf);
}

do_unban(sck)
int sck;
{
 sprintf(buf,"MODE %s -b %s\n",token[4],token[5]);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :Un-Banning %s from %s at your request\n",token[0],token[5],token[4]);
 writeln(sck,buf);
} 

do_topic(sck)
int sck;
{
 int i=0;
 int j=0;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !topic <channel> <topic>\n",token[0]);
  writeln(sck,buf);
  return 0; }         
 strcpy(temp,"TOPIC ");
 if(*token[2]=='#') {
  strcat(temp,token[2]); }
 else {
  strcat(temp,token[4]); }
 strcat(temp," :");

 if(*token[2]=='#') {
  for(i=4;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," ");  } } 
 else {
  if(token[5]!=NULL)
  for(i=5;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
  sprintf(buf,"%s\n",temp);
  writeln(sck,buf);
}

c_exit(sck)
int sck;
{ int i;
FILE *fpa;
fpa=fopen("stats.file","a");
fputs("E\n",fpa);
if(fpa!=NULL) fclose(fpa);
#ifdef VIEW
printf("\n\n----------------------------------------------------------------------------\n");
#endif
  sprintf(buf,"QUIT :Shut down by %s\n",token[0]);
  writeln(sck,buf);
  close(sck);
  exit(0);  
}

do_hi(sck)
int sck;
{
 sprintf(buf,"NOTICE %s :hello there %s!\n",token[0],token[0]);
 writeln(sck,buf);       
 sprintf(buf,"NOTICE %s :I am a MudBot v%d.%d\n",token[0],VERSION_MAJOR,VERSION_MINOR);
 writeln(sck,buf);       
 sprintf(buf,"NOTICE %s :My master is: %s\n",token[0], MASTER);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :You can download this bot from http://www.mudbot.org\n",token[0]);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :You can also get on the mailing list by mailing 'subscribe mudbot-irc' to majordomo@sn.no\n",token[0]);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :For more info contact Drow at drow@undernet.org\n",token[0]);
 writeln(sck,buf);
}

do_op(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0); 
 if (token[4] == NULL) {
  sprintf(buf,"MODE %s +o %s\n",token[2],token[0]);
  writeln(sck,buf);
  }              
 if (token[5] == NULL)
 {
  sprintf(buf,"MODE %s +o %s\n",token[4],token[0]);
  writeln(sck,buf);
  sprintf(buf,"MODE %s +o %s\n",token[2],token[4]);
  writeln(sck,buf);
 }
 else
 {
  if (j>3)
  for(i=4;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," ");
  }    
  sprintf(buf,"MODE %s +oooooo %s\n",token[4],temp);
  writeln(sck,buf);   
 }
}

do_help(sck, ismaster)
int sck;
{
#ifdef USE_AS_NICKSERV_ONLY
 sprintf(buf,"NOTICE %s :HELP about MudBot's NickServ\n",token[0]);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :Syntax: regnick <nick> <password>\n",token[0]);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :Use enforce to kill your nick: enforce <nick> <password>\n",token[0]);
 writeln(sck,buf);
 return 0;
#endif
#ifdef USE_AS_OPERSERV_ONLY
 do_operhelp(sck, 8);
 return 0;
#endif
 if (token[4] == NULL || atoi(token[4])>0) {
  sprintf(buf,"NOTICE %s :\002 MudBot HELP \002 - Here are the commands available: ",token[0]);
 writeln(sck,buf);       
  sprintf(buf,"Use %c before every command\n", CMDCHAR);
 writeln(sck,buf);
if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :\002 Level 0 commands: (unknown user) \002 ",token[0]);
 writeln(sck,buf);
  sprintf(buf,"validate <pass>, up <channel> <passwd>, botauth, vote\n");
 writeln(sck,buf);    
#ifdef NICKSERV
  sprintf(buf,"NOTICE %s :\002 Level 0 commands: (NickServ commands) \002 ",token[0]);
 writeln(sck,buf);
  sprintf(buf,"regnick <nick to register> <passwd>, enforce <nick to kill> <passwd>\n");
 writeln(sck,buf);
#endif
}
if(token[4]==NULL || atoi(token[4])==1) {
  sprintf(buf,"NOTICE %s :\002 Level 1 commands: (known user) \002 ",token[0]);
 writeln(sck,buf);
  sprintf(buf,"whoami, info, help [level|command], unvalidate <pass>, news, tell <nick> <msg>, readmsg <nick> <pass>, clearmsg <nick> <pass>, description <chan>, kiss <chan> <nick>, ");
 writeln(sck,buf);
  sprintf(buf,"access <nick>, seen <nick>, newpass <nick> <old pass> <new pass>, voteresults, update, finger <user> <hostname>\n");
 writeln(sck,buf);
  sprintf(buf,"NOTICE %s :\002 Level 1 commands: (should be typed in channel) \002 ",token[0]);
 writeln(sck,buf);
  sprintf(buf,"tip <$$$>, drink <nick> <brand>, beer <brand>, fortune, ircaddict, dice <max number>, dns <host>, uwhois <domain>, uping <host>, unixtime <time>, listnames <channel>, country <c>, sv\n",token[0]);
 writeln(sck,buf);  
}
if(token[4]==NULL || atoi(token[4])==2) {
  sprintf(buf,"NOTICE %s :\002 Level 2 commands: (new regular) \002 ",token[0]);
 writeln(sck,buf);
  sprintf(buf,"uptime, topic <chan> <topic>, away <awaymsg>, invite <channel>, stats, insult <nick>\n");
 writeln(sck,buf);
}
if(token[4]==NULL || atoi(token[4])==3) {
  sprintf(buf,"NOTICE %s :\002 Level 3 commands: (chan regular) \002 ",token[0]);
 writeln(sck,buf);
  sprintf(buf,"kb <channel> <nick>, kick <channel> <nick>, ban <channel> <n!u@h>, unban <channel> <n!u@h>, voice <channel> <nick>, unvoice <channel> <nick>, teaseop <channel> <nick>\n");
 writeln(sck,buf);
}
if(token[4]==NULL || atoi(token[4])==4) {
  sprintf(buf,"NOTICE %s :\002 Level 4 commands: (chan op) \002 ",token[0]);
 writeln(sck,buf);
  sprintf(buf,"op <channel> <nick>, deop <channel> <nick>, msg <channel> <msg>, status, updatehtml [color], addtimer <timer #> <time in secs> <raw command>, deltimer <timer #>, showtimers\n");
 writeln(sck,buf);
}
if(token[4]==NULL || atoi(token[4])==5) {
  sprintf(buf,"NOTICE %s :\002 Level 5 commands: (trusted op) \002 ",token[0]);
 writeln(sck,buf);
  sprintf(buf,"mode <channel> <modes>, xauth, wauth, xkick <hostname>, wkick <hostname>, system, netblock <block ip>\n");
 writeln(sck,buf);
}
if(token[4]==NULL || atoi(token[4])==6) {
  sprintf(buf,"NOTICE %s :\002 Level 6 commands: (chan admin) \002 ",token[0]);
 writeln(sck,buf);
  sprintf(buf, "join <channel>, part <channel>, userlist, addlocal <nick> <channel1> <channel2>, remlocal <nick>, findlocal <channel>, locallist, addscan <n!u@h>, scan <n!u@h>, clearscan\n");     
 writeln(sck,buf);  
}
if(token[4]==NULL || atoi(token[4])==7) {
  sprintf(buf,"NOTICE %s :\002 Level 7 commands: (bot friend) \002 ",token[0]);
 writeln(sck,buf);
  sprintf(buf,"nick <newnick>, play <file> <channel>, jumpserv <server> <port>, autoban <nick!user@host> <time in secs> <reason>, rautoban <nick!user@host>,"); 
 writeln(sck,buf);
  sprintf(buf," listautobans, clearbans <channel>, clearmodes <channel>, addsilence <u@h>, remsilence <u@h>, checkpopmail <mail server> <user> <password>, readmail <mail file>, cset <channel> [<modes> <topic>]\n");
 writeln(sck,buf);
}
if(token[4]==NULL || atoi(token[4])==8) {
  sprintf(buf,"NOTICE %s :\002 Level 8 commands: (bot admin) \002 ",token[0]);
 writeln(sck,buf);
  sprintf(buf,"adduser <nick> <u@h> <level> <pass> <autoop [1|0]> <email>,  close <channel>, rehash\n");
 writeln(sck,buf);                      
#ifdef OPER_CMDS
  sprintf(buf,"NOTICE %s :\002 Level 8 special commands: (oper) \002 ",token[0]);
 writeln(sck,buf); 
 sprintf(buf,"operup <user> <passwd>, operwall <wallops>, operrehash, operkill <nick>, masskill <hostname (NOT user@host)> [-nooper|-nochannel]\n");
 writeln(sck,buf);
#endif
#ifdef SERVICE
 sprintf(buf,"NOTICE %s :\002 Level 8 commands for service server:\002 operhelp, clearchan <chan>, opcom mode <cmd>, gline [time | -wildcard | -nick] <u@h> <reason>,\n",token[0]);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :remgline <user@host>, lock/unlock <chan>, jupe <server>, jupenick <nick> [host], operjoin <chan>, operpart <chan>, serverstats\n",token[0]);
 writeln(sck,buf);
#endif
}
if(token[4]==NULL || atoi(token[4])==9) {
  sprintf(buf,"NOTICE %s :\002 Level 9 commands: (bot super-admin) \002 ",token[0]);
 writeln(sck,buf);
  sprintf(buf,"addchan <channel> <description>, remchan <channel>, exec <shell command>, remuser <nick>, ftp <command>, spy <channel to spy on>, stopspy, countmail, showaliases\n");
 writeln(sck,buf);
}
if(token[4]==NULL || atoi(token[4])==10) {
  sprintf(buf,"NOTICE %s :\002 Level 10 commands: (bot owner) \002 ",token[0]);
 writeln(sck,buf);
  sprintf(buf,"exit, do <cmd>, readmsg, clearmsg, history, clearmess, notepad <whatever you want to remember (like TODO, grocery list, etc..)>, leaf <nick>, share <nick>, cryptpass <passwd>\n");
 writeln(sck,buf);
}
  sprintf(buf,"NOTICE %s :You are level %d - No <channel> required for commands topic, op, deop, mode, kick, kb if typed in channel.\n",token[0],ismaster);
 writeln(sck,buf);
 }
 else
 {
 if(!cas_cmp(token[4],"validate")) {
  sprintf(buf,"NOTICE %s :HELP - validate - level 0 command\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :SYNTAX: validate <your passwd>\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :Permits you to use other commands\n",token[0]);
  writeln(sck,buf);
 }
 else if(!cas_cmp(token[4],"up")) {
  sprintf(buf,"NOTICE %s :HELP - up - level 0 command\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :SYNTAX: up <channel> <your passwd>\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :Permits a user added with !addlocal to get op in a channel he has access to\n",token[0]);
  writeln(sck,buf);
 }  
 else if(!cas_cmp(token[4],"unvalidate")) {
  sprintf(buf,"NOTICE %s :HELP - unvalidate - level 1 command\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :SYNTAX: unvalidate <your passwd>\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :Reset the validation flag so no one can use the bot without your passwd",token[0]);
  writeln(sck,buf);
 }          
 else if(!cas_cmp(token[4],"xauth")) {
  sprintf(buf,"NOTICE %s :HELP - xauth - level 5 command\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :SYNTAX: xauth\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :Make the bot validate to X (Undernet's channel service) so you can use xkick following the info in undernet.file\n",token[0]);
  writeln(sck,buf);
 }
 else if(!cas_cmp(token[4],"wauth")) {
  sprintf(buf,"NOTICE %s :HELP - wauth - level 5 command\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :SYNTAX: wauth\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :Make the bot validate to W (Undernet's channel service) so you can use wkick following the info in undernet.file",token[0]);
  writeln(sck,buf); 
  }
 else if(!cas_cmp(token[4],"addlocal")) {
  sprintf(buf,"NOTICE %s :HELP - addlocal - level 6 command\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :SYNTAX: addlocal <nick> <channel1> ...\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :To allow a user to have op in one or more channels only, you can !adduser to level 1, then !addlocal with the channels where you want to allow the user access to\n",token[0]);
  writeln(sck,buf);
 }     
 else if(!cas_cmp(token[4],"jumpserv")) {
  sprintf(buf,"NOTICE %s :HELP - jumpserv - level 7 command\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :SYNTAX: jumpserv <server> <port>\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :Makes the bot jump to a server name and port. If the server is not available, it will try the default host, but will just exit if the server name doesnt exist\n",token[0]);
  writeln(sck,buf);
 }     
 else if(!cas_cmp(token[4],"play")) {
  sprintf(buf,"NOTICE %s :HELP - play - level 7 command\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :SYNTAX: play <file> <channel>\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :plays a test file into a channel at a 15 secs (or else) interval between lines\n",token[0]);
  writeln(sck,buf);
 }    
 else if(!cas_cmp(token[4],"adduser")) {
  sprintf(buf,"NOTICE %s :HELP - adduser - level 8 command\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :SYNTAX: adduser <nick> <user@host> <level> <passwd> <autoop> <email>\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :Example: adduser dummy *dummy@*.netcom.com 2 dummy_pass 0 dummy@mail.netcom.com. You need to !rehash after adding someone.\n",token[0]);
  writeln(sck,buf);
 }    
 else if(!cas_cmp(token[4],"addsilence")) {
  sprintf(buf,"NOTICE %s :HELP - addsilence - level 7 command\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :SYNTAX: addsilence <user@host>\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :Adds someone to the bot' silence list\n",token[0]);
  writeln(sck,buf);   
 }
 else if(!cas_cmp(token[4],"remsilence")) {
  sprintf(buf,"NOTICE %s :HELP - remsilence - level 7 command\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :SYNTAX: remsilence <user@host>\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :Removes someone to the bot' silence list\n",token[0]);
  writeln(sck,buf);
 }      
 else if(!cas_cmp(token[4],"register")) {
  sprintf(buf,"NOTICE %s :HELP - register - level 0 command\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :SYNTAX: register <channel> <nick> <user@host> <pass>\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :Requests that bot to be brought into your channel, and adds you automaticly if defined so. user@host should contain proper '*'\n",token[0]);
  writeln(sck,buf);
 }      
 else if(!cas_cmp(token[4],"botauth")) {
  sprintf(buf,"NOTICE %s :HELP - botauth - level 0 command\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :SYNTAX: botauth\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :Tells you basicly that this is the right bot and not a lamer taking it's nick.\n",token[0]);
  writeln(sck,buf);      
 }
 else {
  sprintf(buf,"NOTICE %s :No help on that topic\n",token[0]);
  writeln(sck,buf);
 }
} }

do_play(sck)
int sck;
{
FILE *ifp;
char temp[512];
strcpy(temp,"");
if (token[4] == NULL) {
 sprintf(buf,"NOTICE %s :Syntax: !play <file> <channel>\n",token[0]);
 writeln(sck,buf);
 return 0; }         
if (token[5] == NULL) {
 sprintf(buf,"NOTICE %s :Syntax: !play <file> <channel>\n",token[0]);
 writeln(sck,buf);
 return 0; }    
if (!match("*passwd",token[4])) {
 sprintf(buf,"NOTICE %s :Syntax: !play <file> <channel>\n",token[0]);
 writeln(sck,buf);
 return 0; }  
if(!match("*.file",token[4])) {
 sprintf(buf,"NOTICE %s :Syntax: !play <file> <channel>\n",token[0]);
 writeln(sck,buf);
 return 0; }
ifp = fopen(token[4],"r");
while (fgets(temp,sizeof(temp),ifp) != NULL)
{
 sprintf(buf,"PRIVMSG %s :%s\n",token[5],temp);
 writeln(sck,buf);
 sleep(PLAY_SLEEPTIME);
}
if(ifp!=NULL) fclose(ifp);
}

start_chan(sck)
int sck;
{
 int i,k=4,j;
 FILE *fpblah;
 FILE *ifpa;
 FILE *fpz;
 FILE *fp;
 char temp6[255];
 char chan[100];
 char temp[512];
 char temp2[512];
 char temp3[512];
 strcpy(temp,"");
 strcpy(temp2,"");
 strcpy(temp3,"");
 ifpa = fopen("channels.file","r");
 while(fgets(chan,100,ifpa) != NULL)
 {
  sprintf(buf,"JOIN %s\n",lindex(chan,0));
  writeln(sck,buf);
  strcpy(defchan,lindex(chan,0));
 }
 if(ifpa!=NULL) fclose(ifpa);
 ifpa = fopen(STARTSCRIPT,"r");
 strcpy(chan,"");
 while(fgets(chan,100,ifpa) != NULL)
 {
  sprintf(buf,"%s\n",chan);
  writeln(sck,buf);
 }
 if(ifpa!=NULL) fclose(ifpa);     
 ifpa = fopen(SILENCEFILE,"r");
 strcpy(chan,"");
 while(fgets(chan,100,ifpa) != NULL)
 {
  sprintf(buf,"SILENCE %s\n",chan);
  writeln(sck,buf);
 }
 if(ifpa!=NULL) fclose(ifpa);
#ifdef SERVICE
 if(service_off!=1) {
#ifdef IRCU_2_10
  sprintf(buff,"NICK OperServ 1 1 OperServ %s %s :Opers help bot\n",SERVICE_SERVER_NAME,SERVICE_SERVER_NAME);
#else
  sprintf(buff,"NICK OperServ 1 1 OperServ %s :Opers help bot\n",SERVICE_SERVER_NAME);
#endif
  writeln(servsck,buff);
  sprintf(buff,":OperServ MODE OperServ +ko :1000\n");
  writeln(servsck,buff);
  sprintf(buff,"WALLOPS :MudBot's services on [%s]\n",SERVICE_SERVER_NAME);
  writeln(servsck,buff);
  fp=fopen("locks.file","r");
  while(fgets(temp,255,fp)!=NULL) {
   sprintf(buff,":OperServ JOIN %s\n",lindex(temp,0));
   writeln(servsck,buff);
   sprintf(buff,"MODE %s +o OperServ\n",lindex(temp,0));
   writeln(servsck,buff);
   sprintf(buff,":OperServ MODE %s +mi\n",lindex(temp,0));
   writeln(servsck,buff); }
  if(fp!=NULL) fclose(fp);
  strcpy(temp,"");
#ifdef REPORTS
  sprintf(buff,":OperServ JOIN %s\n",REPORTS);
  writeln(servsck,buff);
  sprintf(buff,"MODE %s +o OperServ\n",REPORTS);
  writeln(servsck,buff);
#endif
}
#endif
#ifdef CHANSERV
#ifdef IRCU_2_10
 sprintf(bufc,"NICK ChanServ 1 1 ChanServ %s %s :Channel Service\n",CHANSERV_SERVER_NAME,CHANSERV_SERVER_NAME);
#else
 sprintf(bufc,"NICK ChanServ 1 1 ChanServ %s :Channel Service\n",CHANSERV_SERVER_NAME);
#endif
 writeln(chansck,bufc);
 sprintf(bufc,":ChanServ MODE ChanServ +k\n");
 writeln(chansck,bufc);
#ifdef REPORTS
 sprintf(bufc,":ChanServ JOIN %s\n",REPORTS);
 writeln(chansck,bufc);
#endif
 fpz=fopen("chanserv.file","r");
 while(fgets(temp,255,fpz)!=NULL) {
  if(temp[0]==NULL) break;
  sprintf(bufc,":ChanServ JOIN %s\n",lindex(temp,0));
  writeln(chansck,bufc);
  sprintf(bufc,"MODE %s +to ChanServ\n",lindex(temp,0));
  writeln(chansck,bufc); }
 if(fpz!=NULL) fclose(fpz);
#endif
#ifdef USE_ALIASES
 go_alias=1;
 fpz=fopen("alias.file","r");
 while(fgets(temp,255,fpz)!=NULL) {
 if(lindex(temp,1)==NULL) {
  printf("*** alias.file corrupted\n");
  exit(0); }
 if(*lindex(temp,1)=='s') printf("Loading MudScript %s\n",lindex(temp,0));
 else printf("Loading UNKNOWN script %s\n",lindex(temp,0));
 ifpa=fopen(lindex(temp,0),"r");
 strcpy(temp,"");
 while(fgets(temp,255,ifpa)!=NULL) 
 {
  if(!cas_cmp(lindex(temp,0),"on_connect")) 
  {
   strcpy(temp2,"");
   for(i=1;lindex(temp,i)!=NULL;i++) 
   {
       if (*lindex(temp,i)=='$' && *(lindex(temp,i)+2)=='a') { }             
#ifdef TCL_INT
       else if (*lindex(temp,i)=='$' && *(lindex(temp,i)+1)=='t' && *(lindex(temp,i)+2)=='c')
         { strcpy(temp3,TCL_INT);
           strcat(temp3," ");
           strcat(temp3,lindex(temp,i+1));
           strcat(temp3," ");
           strcat(temp3,"on_connect");
           strcat(temp3," ");
           k=4;
           fpblah=fopen(".tcl_info.file","w");      
           sprintf(temp6,"TCL_VER 1.0 TCL INFO VERSION\n");
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_NICK %s BOT NAME\n",BOTNAME);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_HOST %s USER HOST\n","on_connect");
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_CHAN %s CHANNEL\n","on_connect");
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_COMTYPE %s COM TYPE\n","on_connect");
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_TIME %ld UNIX TIME\n",time(NULL));    
           fputs(temp6,fpblah);
           if(fpblah!=NULL) fclose(fpblah);
           system(temp3); }
#endif 
       else if(*lindex(temp,i)=='$' && *(lindex(temp,i)+1)=='t' && *(lindex(temp,i)+2)=='i')
        { sprintf(timers[atoi(lindex(temp,i+1))],"%ld ",(atol(lindex(temp,i+2))+time(NULL)));
        for(j=i+3;lindex(temp,j)!=NULL;j++) {
         if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
          strcat(timers[atoi(lindex(temp,i+1))],token[2]);
         else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
          strcat(timers[atoi(lindex(temp,i+1))],token[0]);
         else
          strcat(timers[atoi(lindex(temp,i+1))],lindex(temp,j));
         strcat(timers[atoi(lindex(temp,i+1))]," "); } }
#ifdef REPORTS
       else if(*lindex(temp,i)=='$' && *(lindex(temp,i)+2)=='e')
          strcat(temp2,REPORTS);
#endif
       else strcat(temp2,lindex(temp,i));
       strcat(temp2," "); }
  sprintf(buf,"%s\n",temp2);
  writeln(sck,buf);
  }
 }
if(ifpa!=NULL) fclose(ifpa);
strcpy(temp,"");
strcpy(temp2,"");
}
if(fpz!=NULL) fclose(fpz);
#endif
fpz=fopen("cset.file","r");
while(fgets(temp,255,fpz)!=NULL) {
 sprintf(buf,"MODE %s %s \n",lindex(temp,0),lindex(temp,1));
 writeln(sck,buf);
 sprintf(buf,"TOPIC %s :%s\n",lindex(temp,0),lrange(temp,2));
 writeln(sck,buf); }
if(fpz!=NULL) fclose(fpz);
}

do_away(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if(token[4] == NULL) {
  sprintf(buf,"AWAY\n");
  writeln(sck,buf);
  return 0;}
 strcpy(temp,"AWAY :");
 if (j>3)
  for(i=4;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," ");
  }
  sprintf(buf,"%s\n",temp); 
  writeln(sck,buf);                
}

do_nick(sck)
int sck;
{
 sprintf(buf,"NICK %s\n",token[4]);
 writeln(sck,buf);
}

do_bitch(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if (j>3)
 for(i=4;i<j;i++) {
  strcat(temp,token[i]);
  strcat(temp," ");
 }                             
 if(*token[3] == 'o')
 {
  if (cas_cmp(token[4],BOTNAME) && cas_cmp(token[4],BOTSECNAME))
  {
  if (cas_cmp(token[0],BOTNAME) && cas_cmp(token[0],BOTSECNAME))  
  { 
  sprintf(buf,"NOTICE %s :This user is not allowed as chanop!\n",token[0]);
  writeln(sck,buf);       
  sprintf(buf,"MODE %s -oooooo %s\n",token[2],temp);
  writeln(sck,buf);
  }
  }
 }
return 0;
}

do_localuser(sck, fromhost)
int sck;
char *fromhost;
{
 FILE *fp;
 char temp[512];
 strcpy(temp,"");
 fp = fopen(LOCALFILE,"r");
 while (fgets(temp,sizeof(temp),fp) != NULL)  
 {
  if (!match(lindex(temp,1),fromhost))
  {
   sprintf(buf,"MODE %s +o %s\n",token[4],token[0]);
   writeln(sck,buf);
   sprintf(buf,"NOTICE %s :There ya go...\n",token[0]);
   writeln(sck,buf);
  }
 }
 if(fp!=NULL) fclose(fp);
}

do_takenick(sck)
int sck;
{
 char s[255];
 strcpy(s,token[0]);
 *(strchr(s, '!')) = '\0';
 memmove(s, s+1, strlen(s));
 if(!cas_cmp(s,BOTNAME)) {
  sprintf(buf,"NICK %s\n",BOTNAME);
  writeln(sck,buf); }
 if(!cas_cmp(s,BOTSECNAME)) {
  sprintf(buf,"NICK %s\n",BOTSECNAME);
  writeln(sck,buf);
  sprintf(buf,"NICK %s\n",BOTNAME);
  writeln(sck,buf); }
return 0;
}

do_joined(sck)
int sck;
{
 FILE *fp;
 FILE *fpa;
 char temp[255]="";
 char tempo[255];
 char *ptr;
 int h,l,i;
 char s[255];
 strcpy(s,token[0]);
 strcpy(temp,token[0]);
 fp=fopen("scan.file","r");
 while(fgets(tempo,255,fp)!=NULL) {
  if(!match(lindex(tempo,0),temp)) {
   fpa=fopen("scan.results","a");
   sprintf(tempo,"%s %d %s 0\n",temp,time(NULL),token[2]);
   fputs(tempo,fpa);
   if(fpa!=NULL) fclose(fpa); } }
 if(fp!=NULL) fclose(fp);
 strcpy(tempo,"");
 fp = fopen(AUTOBAN,"r");
 memmove(token[2], token[2]+1, strlen(token[2]));
 while(fgets(tempo,255,fp) != NULL)
 {
  if (!match(lindex(tempo,0),temp))
  {
   if(lindex(tempo,1)!=NULL)
   if(atol(lindex(tempo,1))>time(NULL))
   {
    sprintf(buf,"MODE %s +b %s\n",token[2],lindex(tempo,0));
    writeln(sck,buf);
    *(strchr(s, '!')) = '\0';
    memmove(s, s+1, strlen(s));
    sprintf(buf,"KICK %s %s :AUTOBAN [%ld secs left]: %s\n",token[2],s,(atol(lindex(tempo,1))-time(NULL)),lrange(tempo,4));
    writeln(sck,buf);
    return 0;
   }
  }
 }
 if(fp!=NULL) fclose(fp);
 for(i=0;temp[i]!='!';i++) { }
 i++;
 h = chkautoop(temp+i);
 if (h == 1)
 {
   *(strchr(s, '!')) = '\0';
   memmove(s, s+1, strlen(s));     
  sprintf(buf,"MODE %s +o %s\n",token[2],s);
  writeln(sck,buf);
 }
strcpy(temp,"");
return 0;
}

do_netjoin(sck)
int sck;
{
 sprintf(buf,"PRIVMSG %s :NET join: %s <-> %s\n",REPORTS,token[8],token[9]);
 writeln(sck,buf);
}

do_netbreak(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if (j>9)
  for(i=10;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," ");   
  }
 sprintf(buf,"PRIVMSG %s :NET break: %s <-> %s\n",REPORTS,token[8],token[9]);
 writeln(sck,buf);
#ifdef SERVICE
 if(!cas_cmp(token[9],SERVICE_SERVER_NAME)) {
#ifdef REPORTS
  sprintf(buf,"PRIVMSG %s :ACK!! %s split - restarting...\n",REPORTS,SERVICE_SERVER_NAME);
  writeln(sck,buf);
#endif
#ifdef CHANSERV
  close(chansck);
#endif
  sleep(1);
  do_jump(sck,NULL,0); }
#endif
}  

logerr(errormsg)
char errormsg[512];
{
#ifdef LOGERRORS
 FILE *fp;
 time_t lt;
 long uptime = time(NULL);
 fp = fopen(LOGERRORS,"a");
 fputs(errormsg,fp);
 fputs(" : ",fp);
 lt = time(NULL);
 fputs(ctime(&lt),fp);
 fputs("\n",fp);
 if(fp!=NULL) fclose(fp);
#endif
}

do_register(sck, fromhost)
int sck;
char *fromhost;
{
#ifdef ALLOW_REGISTER
 FILE *fpa;
 FILE *fpb;
 FILE *fpc;
 strcpy(temp1,"");
 char tempa[512] = "1:";
 char tempb[512];
 if (token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: register <channel> <nick> <user@host> <passwd>\n",token[0]);
  writeln(sck,buf); 
  return 0; }
 if (token[7] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: register <channel> <nick> <user@host> <passwd>\n",token[0]);
  writeln(sck,buf); 
  return 0; }        
 fpc = fopen("channels.file","r");
 while(fgets(temp1,255,fpc) != NULL) {
  if (!cas_cmp(token[4],lindex(temp1,0))) {
   sprintf(buf,"NOTICE %s :That channel is already registered.\n",token[0]);
   writeln(sck,buf);
   return 0; } }
 if(fpc!=NULL) fclose(fpc);
 fpc = fopen("channels.file","a");
 fpa = fopen(USERFILE,"a");
 fpb = fopen(LOCALFILE,"a");
 strcat(tempa,token[5]);
 strcat(tempa,":");
 strcat(tempa,token[6]);
 strcat(tempa,":");
 strcat(tempa,token[7]);
 strcat(tempa,":0:0:registred@");
 strcat(tempa,token[4]);
 strcat(tempa,"\n");
 fputs(tempa,fpa);
 strcpy(tempb,token[5]);
 strcat(tempb," ");
 strcat(tempb,token[4]);
 strcat(tempb," dummy\n");
 fputs(tempb,fpb);
 if(fpa!=NULL) fclose(fpa);
 if(fpb!=NULL) fclose(fpb);
 sprintf(buf,"NOTICE %s :Registering %s to %s.\n",token[0],token[4],token[6]);
 writeln(sck,buf);
 strcpy(temp1,token[4]);
 strcat(temp1," Registered by ");
 strcat(temp1,token[6]);
 strcat(temp1,"\n");
 fputs(temp1,fpc);
 if(fpc!=NULL) fclose(fpc);
 sprintf(buf,"JOIN %s\n",token[4]);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :Rehashing config...\n",token[0]);
 writeln(sck,buf);
 loadusr(USERFILE);    
#else
 do_tell(sck, fromhost);
 sprintf(buf,"NOTICE %s :Registration must be approved by the owner of this bot. The request has been transmitted.\n",token[0]);
 writeln(sck,buf);
#endif
}

do_addsilence(sck)
int sck;
{
 FILE *fp;
 if (token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: addsilence <user@host>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 fp = fopen(SILENCEFILE,"a");
 fputs(token[4],fp);
 fputs("\n",fp);
 if(fp!=NULL) fclose(fp);
 sprintf(buf,"NOTICE %s :Adding...\n",token[0]);
 writeln(sck,buf);
 sprintf(buf,"SILENCE +%s\n",token[4]);
 writeln(sck,buf);
}

do_remsilence(sck)
int sck;
{
 FILE *fpa;
 FILE *fpb;
 char temp[512];
 char temp3[512];
 strcpy(temp,"");
 strcpy(temp3,"");
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !addsilence <user@host>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 fpa = fopen("temp.temp","w");
 fpb = fopen(SILENCEFILE,"r");
 while(fgets(temp,255,fpb) != NULL)
 {
  temp[strlen(temp)-1]='\0'; 
  if (cas_cmp(temp,token[4]))
  {
   fputs(temp,fpa);         
  }
 }
 if(fpa!=NULL) fclose(fpa);
 if(fpb!=NULL) fclose(fpb);
 strcpy(temp3,"mv temp.temp ");
 strcat(temp3,SILENCEFILE);
 system(temp3);
 sprintf(buf,"NOTICE %s :Removing...\n",token[0]);
 writeln(sck,buf);
 sprintf(buf,"SILENCE -%s\n",token[4]);
 writeln(sck,buf);
}      

do_clearmodes(sck)
int sck;
{
 if (token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: clearmodes <channel>\n",token[0]);
  writeln(sck,buf);
 return 0; }
 sprintf(buf,"MODE %s -qwertyuioplkjhgfdsazxcvbnm *\n",token[4]);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :Clearing...\n",token[0]);
 writeln(sck,buf);
 sprintf(buf,"MODE %s\n",token[4]);
 writeln(sck,buf);
}

do_clearmodes2(sck)
int sck;
{
if (token[5] == NULL) return 0;
 sprintf(buf,"MODE %s -k %s\n",token[3],token[5]);
 writeln(sck,buf);
if (token[6] == NULL) return 0;
 sprintf(buf,"MODE %s -k %s\n",token[3],token[6]);
 writeln(sck,buf);
}

do_masskill(sck)
int sck;
{
#ifdef OPER_CMDS
 int i;
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: masskill <host> [-nooper | -nochannel]\n",token[0]);
  writeln(sck,buf);
  return 0; }
 if(!cas_cmp(token[4],"*")) {
  sprintf(buf,"NOTICE %s :Invalid entry.\n",token[0]);
  writeln(sck,buf);
  return 0; }
 if(!cas_cmp(token[4],"*.*")) {
  sprintf(buf,"NOTICE %s :Invalid entry.\n",token[0]);
  writeln(sck,buf);
  return 0; }
 if(!cas_cmp(token[4],"*.*.*")) {
  sprintf(buf,"NOTICE %s :Invalid entry.\n",token[0]);
  writeln(sck,buf);
  return 0; }      
 if(!cas_cmp(token[4],"*.*.*.*")) {
  sprintf(buf,"NOTICE %s :Invalid entry.\n",token[0]);
  writeln(sck,buf);
  return 0; }    
 if(!cas_cmp(token[4],"*.*.*.*.*")) {
  sprintf(buf,"NOTICE %s :Invalid entry.\n",token[0]);
  writeln(sck,buf);
  return 0; }    
 sprintf(buf,"WHO %s\n",token[4]);
 writeln(sck,buf);
 sprintf(buf,"WALLOPS :MASSKILL for %s requested by %s\n",token[4],token[0]);
 writeln(sck,buf);
 strcpy(masskill_msg,"MASSKILL");
 if(token[5]!=NULL) {
  for(i=5;token[i]!=NULL;i++) {
   strcat(masskill_msg," ");
   strcat(masskill_msg,token[i]); } }
 if(token[5]==NULL) { MASSKILL_FLAG=0; return 0; }
 if(!cas_cmp(token[5],"-nooper")) { MASSKILL_FLAG=1; return 0; }
 if(!cas_cmp(token[5],"-nochannel")) { MASSKILL_FLAG=2; return 0; }
#endif
}

do_masskill2(sck)
int sck;
{
#ifdef ALLOW_MASSKILL
 if(token[7] == NULL) { 
  printf("*** Masskill script error (server is not running ircd?)\n"); 
  return 0;
 }
 if(MASSKILL_FLAG==1) {
  if(*token[8]!=NULL && *token[8]=='*') return 0;
  if(*(token[8]+1)!=NULL && *(token[8]+1)=='*') return 0;
  if(*(token[8]+2)!=NULL && *(token[8]+2)=='*') return 0; }
 if(MASSKILL_FLAG==2) { if(!cas_cmp(token[3],"*")) return 0; }
 sprintf(buf,"KILL %s :%s\n",token[7],masskill_msg);
 writeln(sck,buf);
#endif
}

do_botauth(sck)
int sck;
{
 sprintf(buf,"NOTICE %s :MudBot %d.%d.\n",token[0],VERSION_MAJOR,VERSION_MINOR);
 writeln(sck,buf);
}

bar_tip(sck)
int sck;
{
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: tip <$$$>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 sprintf(buf,"PRIVMSG %s :Thanks for the tip %s!!!\n",token[2],token[0]);
 writeln(sck,buf);
}

bar_drink(sck)
int sck;
{
 if(token[5] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: drink <nick> <brand>\n",token[0]);
  writeln(sck,buf);
  return 0; }   
  if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: drink <nick> <brand>\n",token[0]);
  writeln(sck,buf);
  return 0; }
  sprintf(buf,"PRIVMSG %s :Here's a %s for %s... Now send the cash %s!\n",token[2],token[5],token[4],token[0]);
  writeln(sck,buf);
}

bar_beer(sck)
int sck;
{
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: beer <brand>\n",token[0]);
  writeln(sck,buf);
  return 0; }
  sprintf(buf,"PRIVMSG %s :Here's your %s beer... Now get drunk and give me money!\n",token[2],token[4]);
  writeln(sck,buf);
}

do_fortune(sck)
int sck;
{
 int i=1;
 int j=0;
 FILE *fp;
 char temp[512];
 strcpy(temp,"");
 srandom(time(NULL));
 srand(time(NULL));
 i = random() % 52;
 i=i+1;
 fp = fopen("fortune.file","r");
 while(fgets(temp,255,fp) != NULL) {
  if(i==j) {
   sprintf(buf,"PRIVMSG %s :Your fortune cookie: %s\n",token[2],temp);
   writeln(sck,buf);
   return 0; }
  j=j+1; }
 if(fp!=NULL) fclose(fp);
}

do_updatehtml(sck)
int sck;
{
 FILE *fp;
 FILE *fpb;
 FILE *fpa;
 char tempfile[255];
 char *tempp;
 char line[255];
 int i,j,z;
 int a=0;
 int b=0;
 int c=0;
 int d=0;
 int e=0;
 int f=0;
 int g=0;
 int h=0;
 int p=0;
 int n=0;
 char tempa[255];
 char tempb[255];
 time_t lt;
 long uptime = time(NULL);
 char temp[512];
 strcpy(temp,"");
 fp=fopen("vote.results","r");
 while(fgets(temp,255,fp)!=NULL) {
  if(temp[0]=='1') a++;
  if(temp[0]=='2') b++;
  if(temp[0]=='3') c++;
  if(temp[0]=='4') d++;
  if(temp[0]=='5') e++;
  if(temp[0]=='6') f++;
  if(temp[0]=='7') g++;
  if(temp[0]=='8') h++;
  if(temp[0]=='9') p++; }
 if(fp!=NULL) fclose(fp);  
 strcpy(tempfile,"mkdir ");
 strcat(tempfile,HTMLDIR);
 strcat(tempfile," > temp.temp 2> /dev/null \n");
 system(tempfile);
 strcpy(tempfile,HTMLDIR);
 strcat(tempfile,"/mudbot.html");
 fp = fopen(tempfile,"w");
 fputs("<html><head><title>Stats from ",fp);
 fputs(BOTNAME,fp);
 if(token[4]!=NULL) {
 fputs("</title></head><body bgcolor=\"",fp);
 fputs(token[4],fp);
 fputs("\" text=#ffffff>\n",fp); }
 else
 fputs("</title></head><body bgcolor=#000000 text=#ffffff>\n",fp);
 fputs("<center><h1>MudBot</h1></center><br><h2>Those are stats updated from IRC!</h2><hr>",fp);
 fputs("Bot name: ",fp);
 fputs(BOTNAME,fp);
 fputs("<br>My master: ",fp);
 fputs(MASTER,fp);
 fputs("<br>Servers I use: ",fp);
 fputs(SERVERA,fp);
 fputs(", ",fp);
 fputs(SERVERB,fp);
 fputs(", ",fp);
 fputs(SERVERC,fp);
 fputs(", ",fp);
 fputs(SERVERD,fp);
 fputs("<br>My description: ",fp);
 fputs(BOTDESC,fp);
 fputs("<br>My URL: <a href=\"",fp);
 fputs(URL,fp);
 fputs("\">",fp);
 fputs(URL,fp);
 fputs("</a><br><center><table border=1 witdh=50%><th>Channels I watch:</th><tr>",fp);
 fpb = fopen("channels.file","r");
 while(fgets(temp,255,fpb) != NULL) {
  fputs("<tr><td>",fp);
  fputs(temp,fp);
  fputs("</td></tr>",fp); }
 if(fpb!=NULL) fclose(fpb);
 fputs("</table></center><hr>Page automagicaly updated from IRC. Last updated:",fp);
 lt = time(NULL); 
 fputs(ctime(&lt),fp);
 fputs("<br>",fp);
 fputs("</body></html>",fp);
 if(fp!=NULL) fclose(fp);
 strcpy(tempfile,HTMLDIR);
 strcat(tempfile,"/index.html");
 fp=fopen(tempfile,"w");
 fputs("<html><head><title>",fp);
 fputs(BOTNAME,fp);
 fputs("'s main page</title></head><body bgcolor=#000000 text=#ffffff link=\"cyan\" vlink=\"cyan\"><center><h2>",fp);
 fputs(BOTNAME,fp);
 fputs("'s main page</h2><hr><br><li><a href=\"mudbot.html\">This bot's stats</a></p>",fp);
#ifdef LOGERRORS
 fputs("<li><a href=\"errors.log\">Errors log file</a></p>",fp);
#endif
 fputs("<li><a href=\"votes.html\">Votes from IRC</a></p>",fp);
 fputs("<li><a href=\"userlist.html\">Users list</a></p>",fp);
 fputs("<li><a href=\"http://www.mudbot.org\">MudBot main page</a></p>",fp);
 fputs("</center><hr>This page is updated from IRC!</p>",fp);
#ifdef INTER_WEB
 fputs("<br>Send a message to the bot: (You will be considered as a level 1 user)<br>",fp);
 fputs("<form ACTION=\"",fp);
 fputs(CGI_BIN,fp);
 fputs("/writetext.cgi\" METHOD=\"POST\"><input TYPE=\"Text\" NAME=\"command\" width=30 maxlenght=70><br><input type=\"submit\" value=\"Submit\">",fp);
 fputs("</p>Wait a few seconds (or minutes if the bot is in really idle chans) and go see what the bot had to say <a href=\"command.results\">here</a>. Note that you must reload that page.<br>",fp);
 fputs("<strong>Here are a few commands you have access to:</strong><br>",fp);
 fputs("botauth, vote, help, news, tell (nick) (msg), readmsg (nick) (pass), clearmsg (nick) (pass), description (channel), access (nick), seen(nick), ",fp);
 fputs("voteresults, drink (nick) (brand), beer (brand), fortune, ircaddict, dice (max dice number), dns (host), uwhois (host), uping (host), unixtime (unixtime), listnames (channel), country (country)",fp);
#endif
 fputs("</body></html>",fp);
 if(fp!=NULL) fclose(fp);
 strcpy(tempfile,HTMLDIR);
 strcat(tempfile,"/userlist.html");
 fp=fopen(tempfile,"w");
 fputs("<html><head><title>Users list</title></head><body bgcolor=#000000 text=#ffffff><h2>Users list</h2><br><hr><br>",fp);
 fpa=fopen(USERFILE,"r");
 for (z=0;fgets(line, 255, fpa);z++) {
 if(tempp = strtok(line,":")) {   /* level */
  fputs("Level: ",fp);
  fputs(tempp,fp); }
 if(tempp = strtok(NULL,":")) {   /* nick */
  fputs(" Nick: ",fp);
  fputs(tempp,fp); }
 if(tempp = strtok(NULL,":")) {   /* u@h */ } 
 if(tempp = strtok(NULL,":")) {   /* pass */ } 
 if(tempp = strtok(NULL,":")) {   /* validate */ } 
 if(tempp = strtok(NULL,":")) {   /* autoop */ } 
 if(tempp = strtok(NULL,":")) {   /* email */
  fputs(" Email: ",fp);
  fputs(tempp,fp); 
  fputs("<br>",fp); } }
 fputs("</p></body></html>",fp);
 if(fpa!=NULL) fclose(fpa);
 if(fp!=NULL) fclose(fp);
 strcpy(tempfile,HTMLDIR);
 strcat(tempfile,"/votes.html");
 fp=fopen(tempfile,"w");
 fpa=fopen("vote.file","r");
 fputs("<html><head><title>Votes results</title></head><body bgcolor=#000000 text=#ffffff><center><h2>Votes results</h2></center></p>",fp);
 fgets(temp,255,fpa);
 fputs(temp,fp);
 fputs("</p>",fp);
 while(fgets(temp,255,fpa)!=NULL) {
  n++;
 fputs("<li>",fp);
 fputs(temp,fp);
 if (n==1) {
  fputs(" choice 1 got ",fp);
  fprintf(fp,"%d",a);
  fputs(" votes<br>",fp); }
 if (n==2) {
  fputs(" choice 2 got ",fp);
  fprintf(fp,"%d",b);
  fputs(" votes<br>",fp); } 
 if (n==3) {
  fputs(" choice 3 got ",fp);
  fprintf(fp,"%d",c);
  fputs(" votes<br>",fp); } 
 if (n==4) {
  fputs(" choice 4 got ",fp);
  fprintf(fp,"%d",d);
  fputs(" votes<br>",fp); } 
 if (n==5) {
  fputs(" choice 5 got ",fp);
  fprintf(fp,"%d",e);
  fputs(" votes<br>",fp); } 
 if (n==6) {
  fputs(" choice 6 got ",fp);
  fprintf(fp,"%d",f);
  fputs(" votes<br>",fp); } 
 if (n==7) {
  fputs(" choice 7 got ",fp);
  fprintf(fp,"%d",g);
  fputs(" votes<br>",fp); } 
 if (n==8) {
  fputs(" choice 8 got ",fp);
  fprintf(fp,"%d",h);
  fputs(" votes<br>",fp); } 
 if (n==9) {
  fputs(" choice 9 got ",fp);
  fprintf(fp,"%d",p);
  fputs(" votes<br>",fp); }  }
 if(fpa!=NULL) fclose(fpa);
 fputs("</p></body></html>",fp);
 if(fp!=NULL) fclose(fp);
/* strcpy(temp,"chmod 755 ");
 strcpy(temp,HTMLDIR);
 system(temp);*/
 strcpy(temp,"chmod 644 ");
 strcat(temp,HTMLDIR);
 strcat(temp,"/*");
 system(temp);
#ifdef LOGERRORS
 strcpy(temp,"cp ");
 strcat(temp,LOGERRORS);
 strcat(temp," ");
 strcat(temp,HTMLDIR);
 strcat(temp,"/errors.log\n");
 system(temp);
#endif
 strcpy(temp,"chmod 644 ");
 strcat(temp,HTMLDIR);
 strcat(temp,"/*\n");
 system(temp);
 sprintf(buf,"NOTICE %s :Trying to update HTML file...\n",token[0]);
 writeln(sck,buf);
}

do_access(sck)
int sck;
{
 int i;
 char *tempx = "";
 char line[255];
 char dump[255];
 char list[255];
 char list0[255];
 char list1[255];
 char list2[255];
 char list3[255];
 FILE *fp;
 fp = fopen(USERFILE,"r");
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: access <nick>\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :If you want your access, use 'whoami'\n",token[0]);
  writeln(sck,buf);
  return 0; }
 for (i=0;fgets(line, 255, fp);i++) {
  if(tempx = strtok(line,":"))    /* level */
  strcpy(list2,tempx);
  if(tempx = strtok(NULL,":"))    /* nick */
  strcpy(list3,tempx);
  if(!cas_cmp(token[4],list3)) {
   if(tempx = strtok(NULL,":"))    /* u@h */
   strcpy(list1,tempx);  
   if(tempx = strtok(NULL,":"))    /* pass */
   strcpy(dump,tempx);  
   if(tempx = strtok(NULL,":"))    /* validate */
   strcpy(dump,tempx);  
   if(tempx = strtok(NULL,":"))    /* autoop */
   strcpy(list0,tempx);  
   if(tempx = strtok(NULL,":"))    /* email */
   strcpy(list,tempx);  
   sprintf(buf,"NOTICE %s :Name: %s Level: %s user@host: %s Email: %s\n",token[0],list3,list2,list1,list);
   writeln(sck,buf); } }
 if(fp!=NULL) fclose(fp);
}

do_system(sck)
int sck;
{
 FILE *fp; 
 char temp[512];
#ifdef POSIX
 struct utsname ohwell;
#endif
#ifndef POSIX
 strcpy(temp,"");
 system("uname -a > temp.temp");
 sleep(1);
 fp = fopen("temp.temp","r");
 fgets(temp,255,fp);
 sprintf(buf,"NOTICE %s :This bot is running on: %s\n",token[0],temp);
 writeln(sck,buf);
 if(fp!=NULL) fclose(fp);
#endif
#ifdef POSIX
 uname(&ohwell);
 sprintf(buf,"NOTICE %s :This bot is running on %s %s release %s version %s %s.%s\n",token[0],ohwell.sysname,ohwell.machine,ohwell.release,ohwell.version,ohwell.nodename,ohwell.domainname);
 writeln(sck,buf);
#endif
#ifdef CHECK_SYSTEM_MAX
 do_sysmax(sck);
#endif
}

do_regnick(sck)
int sck;
{
 FILE *fp;
 char temp[512];
 strcpy(temp,"");
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: regnick <nick you want to register> <passwd> <masked user@host>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 if(token[5] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: regnick <nick you want to register> <passwd> <masked user@host>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 if(token[6] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: regnick <nick you want to register> <passwd> <masked user@host>\n",token[0]);
  writeln(sck,buf);
  return 0; } 
 if(cas_cmp(token[4],token[0])) {
  sprintf(buf,"NOTICE %s :Please register your nick only.\n",token[0]);
  writeln(sck,buf);
  return 0; }
 fp = fopen("nickserv.file","r");
 while(fgets(temp,255,fp) != NULL) {
  if(!cas_cmp(lindex(temp,0),token[4])) {
   sprintf(buf,"NOTICE %s :Nick already registered!\n",token[0]);
   writeln(sck,buf);
   if(fp!=NULL) fclose(fp);
   return 0; } }
 if(fp!=NULL) fclose(fp);
 fp = fopen("nickserv.file","a");
 fputs(token[4],fp);
 fputs(" ",fp);
 fputs(token[5],fp);
 fputs(" ",fp);
 fputs(token[6],fp);
 fputs(" dummy\n",fp);
 if(fp!=NULL) fclose(fp);
 sprintf(buf,"NOTICE %s :Registering.. Plz remember your passwd, and use the enforce command to kill unwanted users that use your nick.\n",token[0]);
 writeln(sck,buf);
}

do_enfnick(sck, fromhost)
int sck;
char *fromhost;
{
 FILE *fp;
 char temp[512];
 strcpy(temp,"");
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: regnick <nick you want to kill> <passwd>\n",token[0]);
  writeln(sck,buf);
  return 0; }   
 if(token[5] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: regnick <nick you want to kill> <passwd>\n",token[0]);
  writeln(sck,buf); 
  return 0; } 
 fp = fopen("nickserv.file","r");
 while(fgets(temp,255,fp) != NULL) {
  if(!cas_cmp(lindex(temp,0),token[4])) {
   if(!cas_cmp(lindex(temp,1),token[5])) {
    if(!match(lindex(temp,2),fromhost)) {
     sprintf(buf,"KILL %s :Enforced nick kill by %s\n",token[4],token[0]);
     writeln(sck,buf); }
    if(match(lindex(temp,2),fromhost)) {
     sprintf(buf,"NOTICE %s :Bad user@host\n",token[0]);
     writeln(sck,buf); } }
   if(cas_cmp(lindex(temp,1),token[5])) {
    sprintf(buf,"NOTICE %s :Bad password\n",token[0]);
    writeln(sck,buf); }  } }
 if(fp!=NULL) fclose(fp);
}

do_clearmsg(sck)
int sck;
{
 FILE *fp;
 fp = fopen("tell.file","w");
 if(fp!=NULL) fclose(fp);
 sprintf(buf,"notice %s :Clearing...\n",token[0]);
 writeln(sck,buf);
}

#ifdef OPERVIEW

view_squit(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if(j>7)
 for(i=8;i<j;i++) {
  strcat(temp,token[i]);
  strcat(temp," "); }
 sprintf(buf,"privmsg %s :Operview: [SQUIT] %s\n",OPERVIEW,temp);
 writeln(sck,buf);
}

#endif
#ifdef VIEWKILLS

view_kill(sck)
int sck;
{
 int i;
 char temp[255];
 strcpy(temp,"");
#ifdef KILLS_REASONS
 for(i=13;token[i]!=NULL;i++) { strcat(temp,token[i]); strcat(temp," "); }
 sprintf(buf,"PRIVMSG %s :Operview: [KILL] from %s for %s [%s]\n",OPERVIEW,token[12],token[10],temp);
#else
 sprintf(buf,"PRIVMSG %s :Operview: [KILL] from %s for %s\n",OPERVIEW,token[12],token[10]);
#endif
 writeln(sck,buf);
}

#endif
#ifdef OPERVIEW

view_addgline(sck)
int sck;
{
 char tempo[512]="";
 int i,j,z;
 time_t lt;
 char temp[512];
 strcpy(temp," (no reason)");
 j = chk_num(0);
 lt=atoi(token[13]);
 if (j>13) {
  strcpy(temp," ");
  for(i=14;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
#ifndef OPERVIEW_G_REASON
 sprintf(buf,"privmsg %s :Operview: [GLINE] added for %s until %s\n",OPERVIEW,token[10],ctime(&lt));
#else
 for(z=14;token[z]!=NULL;z++) {
  strcat(tempo,token[z]);
  strcat(tempo," "); }
 sprintf(buf,"privmsg %s :Operview: [GLINE] added for %s [%s] until %s\n",OPERVIEW,token[10],tempo,ctime(&lt));
#endif
 writeln(sck,buf); 
}

view_remgline(sck)
int sck;
{
 sprintf(buf,"privmsg %s :Operview: [GLINE] removed for %s\n",OPERVIEW,token[10]);
 writeln(sck,buf);
}
#endif

client_msg(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j = chk_num(0);
 if (j>2) {
  for(i=3;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }         
 if(temp[0]==':') temp[0]=' ';
 if(*token[2] == '#') printf("<%s:%s>%s\n",token[0],token[2],temp);
 else printf("[1;33m*%s*[0;37m%s\n",token[0],temp);
return 0;
}

client_notice(sck)
int sck;
{
 int i,j;
 char temp[512];
 if(cas_cmp(token[3],":***")) {
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>2) {
  strcpy(temp," ");
  for(i=3;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("-%s:%s- %s\n",token[2],token[0],temp);
} 
return 0;
}

client_quit(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>1) {
  strcpy(temp," ");
  for(i=2;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("[1;34m[SIGNOFF][0;34m %s %s[0;37m\n",token[0],temp);
return 0;
}     

client_join(sck)
int sck;
{
 printf("[1;32m[JOIN][0;32m %s joined %s[0;37m\n",token[0],token[2]);
return 0;
}

client_part(sck)
int sck;
{
 printf("[1;32m[PART][0;32m %s left %s[0;37m\n",token[0],token[2]);
return 0;
} 

client_mode(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>1) {
  strcpy(temp," ");
  for(i=2;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("[1;31m[MODE][0;31m %s by %s[0;37m\n",temp,token[0]);
return 0;
}     

client_names(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>3) {
  strcpy(temp," ");
  for(i=4;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }  
 printf("[1;35m[NAMES][0;35m %s[0;37m\n",temp);
}

client_motd(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if(j>3) {
  strcpy(temp," ");
  for(i=4;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("[IRC] %s\n",temp);
}

client_cmds(line,sck)
char line[512];
int sck;
{
 int i;
 char lala[515];
 printf("%s [1;34m->[0;37m %s\n",defchan,line);
 if(line[0] == '/') {
  if(!cas_cmp(lindex(line,0),"/msg")) {
   strcpy(lala,line);
   sprintf(buf,"PRIVMSG %s :%s\n",lindex(lala,1),lrange(lala,2));
   writeln(sck,buf); }
  else if(!cas_cmp(lindex(line,0),"/wallops")) {
   strcpy(lala,line);
   sprintf(buf,"WALLOPS :%s\n",lrange(lala,1));
   writeln(sck,buf); }
  else if(!cas_cmp(lindex(line,0),"/topic")) {
   strcpy(lala,line);
   sprintf(buf,"TOPIC %s :%s\n",lindex(line,1),lrange(line,2));
   writeln(sck,buf); }
  else if(line[0]=='/' && line[1]=='q' && line[2]=='u' && line[3]=='i') {
   printf("\n\n---------------------------------------------------------\n");
   sprintf(buf,"QUIT :Shut down from console\n");
   writeln(sck,buf);
   close(sck);
   exit(0);
  }
  else if(!cas_cmp(lindex(line,0),"/join")) {
   line[strlen(line)-1]='\0';
   sprintf(buf,"JOIN %s\n",lindex(line,1));
   writeln(sck,buf);
   strcpy(defchan,lindex(line,1)); }
  else if(!cas_cmp(lindex(line,0),"/part")) 
  {
   line[strlen(line)-1]='\0';
   strcpy(defchan,REPORTS);
   sprintf(buf,"PART %s\n",lindex(line,1));
   writeln(sck,buf); 
  }
  else if(!cas_cmp(lindex(line,0),"/quote")) {
   sprintf(buf,":%s\n",line);
   writeln(sck,buf); }
  else if(line[0]=='/' && line[1]=='l' && line[2]=='u' && line[3]=='s') {
   sprintf(buf,"LUSERS\n");
   writeln(sck,buf); }
  else if(!cas_cmp(lindex(line,0),"/op")) {
   line[strlen(line)-1]='\0';
   sprintf(buf,"MODE %s +oooooo %s\n",defchan,lrange(line,1));
   writeln(sck,buf); }
  else if(!cas_cmp(lindex(line,0),"/who")) printf("Unknown command\n");
  else if(!cas_cmp(line,"/who")) printf("Unknown command\n");
  else if(!cas_cmp(lindex(line,0),"/deop")) {
   line[strlen(line)-1]='\0';
   sprintf(buf,"MODE %s -oooooo %s\n",defchan,lrange(line,1));
   writeln(sck,buf); }
  else if(line[0]=='/' && line[1]=='h' && line[2]=='e' && line[3]=='l') {
   printf("----------------------------------------------------\n");
   printf("Online HELP about MudBot IRC client interface\n");
   printf("Available commands: LUSERS WHOIS QUOTE QUIT HELP\n");
   printf("NICK JOIN PART MSG AWAY MODE OP DEOP TOPIC MAP\n");
   printf("VERSION INFO\n");
   printf("For more help read the README file.\n");
   printf("----------------------------------------------------\n"); }
   else {
   line++;
   sprintf(buf,"%s\n",line);
   writeln(sck,buf);
 } }
 else 
 {
  sprintf(buf,"PRIVMSG %s :%s\n",defchan,line);
  writeln(sck,buf); 
 }
}

client_lusers(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>2) {
  strcpy(temp," ");
  for(i=3;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("[1;35m[LUSERS][0;35m %s[0;37m\n",temp);
}

client_no_whois(sck)
int sck;
{
 printf("[1;35m[WHOIS][0;35m %s No such nick/channel[0;37m\n",token[3]);
}

client_whois_who(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>5) {
  strcpy(temp," ");
  for(i=6;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("[1;35m[WHOIS][0;35m %s!%s@%s %s[0;37m\n",token[3],token[4],token[5],temp);
}

client_whois_channels(sck)
int sck;
{ 
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>3) {
  strcpy(temp," ");
  for(i=4;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 if(temp[1]==':') temp[1]=' ';
 printf("[1;35m[WHOIS][0;35m On channels%s[0;37m\n",temp);
}

client_whois_server(sck)
int sck;
{ 
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>3) {
  strcpy(temp," ");
  for(i=4;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("[1;35m[WHOIS][0;35m Using %s[0;37m\n",temp);
}

client_whois_away(sck)
int sck;
{ 
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>2) {
  strcpy(temp," ");
  for(i=3;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("[1;37m[AWAY][1;37m %s[0;37m\n",temp);
}

client_whois_oper(sck)
int sck;
{ 
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>2) {
  strcpy(temp," ");
  for(i=3;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("[1;35m[IRCOP][0;35m %s[0;37m\n",temp);
}

client_topic(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>2) {
  strcpy(temp," ");
  for(i=3;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }     
 printf("[1;31m[TOPIC][0;31m for %s changed to %s[0;37m\n",token[2],temp);
}

client_wallops(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>1) {
  strcpy(temp," ");
  for(i=2;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 if(temp[1]==':') temp[1]=' ';
 printf("[1;35m[WALLOPS][0;35m from %s%s[0;37m\n",token[0],temp);
}

client_kick(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>3) {
  strcpy(temp," ");
  for(i=4;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("[1;36m[KICK][0;36m %s kicked %s from %s %s[0;37m\n",token[0],token[3],token[2],temp);
}

client_info(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>3) {
  strcpy(temp," ");
  for(i=4;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("[1;35m[INFO][0;35m %s[0;37m\n",temp);
}

client_links(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>2) {
  strcpy(temp," ");
  for(i=3;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("[1;35m[LINKS][0;35m %s[0;37m\n",temp);
}

client_nick(sck)
int sck;
{
 printf("[1;35m[NICK][0;35m %s is now known as %s[0;37m\n",token[0],token[2]);
}

client_version(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>2) {
  strcpy(temp," ");
  for(i=3;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("[1;35m[VERSION][0;35m This is MudBot version 1.7[0;37m\n");
 printf("[1;35m[VERSION][0;35m SERVER: %s[0;37m\n",temp);
}

client_whowas(sck)
int sck;
{
 printf("[1;35m[WHOWAS][0;35m %s!%s@%s[0;37m\n",token[3],token[4],token[5]);
}                        

client_stats(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>3) {
  strcpy(temp," ");
  for(i=4;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("[1;35m[STATS][0;35m %s[0;37m\n",temp);
}

client_uptime(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>3) {
  strcpy(temp," ");
  for(i=4;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("[1;35m[UPTIME][0;35m %s[0;37m\n",temp);
} 

client_welcome_to_irc(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"(no message)");
 j = chk_num(0);
 if (j>2) {
  strcpy(temp," ");
  for(i=3;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); } }
 printf("[IRC] %s\n",temp);
}

do_country(sck)
int sck;
{
 int i;
 char *temp22;
 FILE *fp;
 char temp[512];
 strcpy(temp,"");
 if(token[4] == NULL) {
  sprintf(buf,"PRIVMSG %s :Syntax: !country <abr|name>\n",token[2]);
  writeln(sck,buf);
  return 0; }
 temp22 = malloc(255);
 strcpy(temp22,token[4]);    
 fp = fopen("countries.file","r");
 for(i=strlen(temp22); --i>=0;) temp22[i]= toupper(temp22[i]); 
 while(fgets(temp,255,fp) != NULL) {
  if(!cas_cmp(lindex(temp,0),"END")) {
   sprintf(buf,"PRIVMSG %s :No country found.\n",token[2]);
   writeln(sck,buf);
   if(fp!=NULL) fclose(fp);
   return 0; }
  if (!cas_cmp(lindex(temp,0),temp22)) {
   sprintf(buf,"PRIVMSG %s :Country for %s is %s\n",token[2],token[4],lrange(temp,2));
   writeln(sck,buf);
   if(fp!=NULL) fclose(fp);
   return 0; }
  if (!cas_cmp(lindex(temp,1),temp22)) {
   sprintf(buf,"PRIVMSG %s :Country for %s is %s\n",token[2],token[4],lrange(temp,2));
   writeln(sck,buf);
   if(fp!=NULL) fclose(fp);
   return 0; }   
  if (!cas_cmp(lindex(temp,2),temp22)) {
   sprintf(buf,"PRIVMSG %s :Country for %s is %s\n",token[2],token[4],lindex(temp,0));
   writeln(sck,buf);
   if(fp!=NULL) fclose(fp);
   return 0; }  
 }
 if(fp!=NULL) fclose(fp);
 strcpy(temp22,"");
}

#ifdef USE_BINDS
bind_join(sck)
int sck;
{
#ifdef BIND_JOIN
 int j=0;
 char temp[512];
 strcpy(temp,"");
 while(lindex(BIND_JOIN,j)!=NULL){
 if(!cas_cmp(lindex(BIND_JOIN,j),"$channel"))
  strcat(temp,token[2]);
#ifdef REPORTS
 else if(!cas_cmp(lindex(BIND_JOIN,j),"$reports"))
  strcat(temp,REPORTS);
#endif
 else if(!cas_cmp(lindex(BIND_JOIN,j),"$nick"))
  strcat(temp,token[0]);
 else if(lindex(BIND_JOIN,j)[0]=='%') {
  if(lindex(BIND_JOIN,j)[1]=='0' && token[3]!=NULL)
   strcat(temp,token[3]);
  else if(lindex(BIND_JOIN,j)[1]=='1' && token[4]!=NULL)
   strcat(temp,token[4]);
  else if(lindex(BIND_JOIN,j)[1]=='2' && token[5]!=NULL)
   strcat(temp,token[5]);
  else if(lindex(BIND_JOIN,j)[1]=='3' && token[6]!=NULL)
   strcat(temp,token[6]);
  else if(lindex(BIND_JOIN,j)[1]=='4' && token[7]!=NULL)
   strcat(temp,token[7]);
  else if(lindex(BIND_JOIN,j)[1]=='5' && token[8]!=NULL)
   strcat(temp,token[8]);
  else if(lindex(BIND_JOIN,j)[1]=='6' && token[9]!=NULL)
   strcat(temp,token[9]);
  else break; }
 else 
  strcat(temp,lindex(BIND_JOIN,j));
 strcat(temp," ");
 j++;
 }
 sprintf(buf,"%s\n",temp);
 writeln(sck,buf);
#endif
}

bind_part(sck)
int sck;
{
#ifdef BIND_PART
 int j=0;
 char temp[512];
 strcpy(temp,"");
 while(lindex(BIND_PART,j)!=NULL){
 if(!cas_cmp(lindex(BIND_PART,j),"$channel"))
  strcat(temp,token[2]);
#ifdef REPORTS    
 else if(!cas_cmp(lindex(BIND_PART,j),"$reports"))
  strcat(temp,REPORTS);
#endif
 else if(!cas_cmp(lindex(BIND_PART,j),"$nick"))
  strcat(temp,token[0]);
 else if(lindex(BIND_PART,j)[0]=='%') {
  if(lindex(BIND_PART,j)[1]=='0' && token[3]!=NULL)
   strcat(temp,token[3]);
  else if(lindex(BIND_PART,j)[1]=='1' && token[4]!=NULL)
   strcat(temp,token[4]);
  else if(lindex(BIND_PART,j)[1]=='2' && token[5]!=NULL)
   strcat(temp,token[5]);
  else if(lindex(BIND_PART,j)[1]=='3' && token[6]!=NULL)
   strcat(temp,token[6]);
  else if(lindex(BIND_PART,j)[1]=='4' && token[7]!=NULL)
   strcat(temp,token[7]);
  else if(lindex(BIND_PART,j)[1]=='5' && token[8]!=NULL)
   strcat(temp,token[8]);
  else if(lindex(BIND_PART,j)[1]=='6' && token[9]!=NULL)
   strcat(temp,token[9]);
  else break; }
 else   
  strcat(temp,lindex(BIND_PART,j));
 strcat(temp," ");
 j++;
 }
 sprintf(buf,"%s\n",temp);
 writeln(sck,buf);
#endif
}

bind_mode(sck)
int sck;
{
#ifdef BIND_MODE
 int j=0;
 char temp[512];
 strcpy(temp,"");
 while(lindex(BIND_MODE,j)!=NULL){
 if(!cas_cmp(lindex(BIND_MODE,j),"$channel"))
  strcat(temp,token[2]);
#ifdef REPORTS    
 else if(!cas_cmp(lindex(BIND_MODE,j),"$reports"))
  strcat(temp,REPORTS);
#endif
 else if(!cas_cmp(lindex(BIND_MODE,j),"$nick"))
  strcat(temp,token[0]);
 else if(lindex(BIND_MODE,j)[0]=='%') {
  if(lindex(BIND_MODE,j)[1]=='0' && token[3]!=NULL) 
   strcat(temp,token[3]);
  else if(lindex(BIND_MODE,j)[1]=='1' && token[4]!=NULL)
   strcat(temp,token[4]);
  else if(lindex(BIND_MODE,j)[1]=='2' && token[5]!=NULL)
   strcat(temp,token[5]);
  else if(lindex(BIND_MODE,j)[1]=='3' && token[6]!=NULL)
   strcat(temp,token[6]);
  else if(lindex(BIND_MODE,j)[1]=='4' && token[7]!=NULL)
   strcat(temp,token[7]);
  else if(lindex(BIND_MODE,j)[1]=='5' && token[8]!=NULL)
   strcat(temp,token[8]);
  else if(lindex(BIND_MODE,j)[1]=='6' && token[9]!=NULL)
   strcat(temp,token[9]);
  else break; }
 else   
  strcat(temp,lindex(BIND_MODE,j));
 strcat(temp," ");
 j++;
 }
 sprintf(buf,"%s\n",temp);
 writeln(sck,buf);
#endif
}

bind_msg(sck)
int sck;
{
#ifdef BIND_PRIVMSG
 int j=0;
 char temp[512];
 strcpy(temp,"");
 while(lindex(BIND_PRIVMSG,j)!=NULL){
 if(!cas_cmp(lindex(BIND_PRIVMSG,j),"$channel"))
  strcat(temp,token[2]);
#ifdef REPORTS    
 else if(!cas_cmp(lindex(BIND_PRIVMSG,j),"$reports"))
  strcat(temp,REPORTS);
#endif
 else if(!cas_cmp(lindex(BIND_PRIVMSG,j),"$nick"))
  strcat(temp,token[0]);
 else if(lindex(BIND_PRIVMSG,j)[0]=='%') {
  if(lindex(BIND_PRIVMSG,j)[1]=='0' && token[3]!=NULL)
   strcat(temp,token[3]);
  else if(lindex(BIND_PRIVMSG,j)[1]=='1' && token[4]!=NULL)
   strcat(temp,token[4]);
  else if(lindex(BIND_PRIVMSG,j)[1]=='2' && token[5]!=NULL)
   strcat(temp,token[5]);
  else if(lindex(BIND_PRIVMSG,j)[1]=='3' && token[6]!=NULL)
   strcat(temp,token[6]);
  else if(lindex(BIND_PRIVMSG,j)[1]=='4' && token[7]!=NULL)
   strcat(temp,token[7]);
  else if(lindex(BIND_PRIVMSG,j)[1]=='5' && token[8]!=NULL)
   strcat(temp,token[8]);
  else if(lindex(BIND_PRIVMSG,j)[1]=='6' && token[9]!=NULL)
   strcat(temp,token[9]);
  else break; }
 else   
  strcat(temp,lindex(BIND_PRIVMSG,j));
 strcat(temp," ");
 j++;
 }
 sprintf(buf,"%s\n",temp);
 writeln(sck,buf);
#endif
}

bind_notice(sck)
int sck;
{
#ifdef BIND_NOTICE
 int j=0;
 char temp[512];
 strcpy(temp,"");
 while(lindex(BIND_NOTICE,j)!=NULL){
 if(!cas_cmp(lindex(BIND_NOTICE,j),"$channel"))
  strcat(temp,token[2]);
#ifdef REPORTS    
 else if(!cas_cmp(lindex(BIND_NOTICE,j),"$reports"))
  strcat(temp,REPORTS);
#endif
 else if(!cas_cmp(lindex(BIND_NOTICE,j),"$nick"))
  strcat(temp,token[0]);
 else if(lindex(BIND_NOTICE,j)[0]=='%') {
  if(lindex(BIND_NOTICE,j)[1]=='0' && token[3]!=NULL)
   strcat(temp,token[3]);
  else if(lindex(BIND_NOTICE,j)[1]=='1' && token[4]!=NULL)
   strcat(temp,token[4]);
  else if(lindex(BIND_NOTICE,j)[1]=='2' && token[5]!=NULL)
   strcat(temp,token[5]);
  else if(lindex(BIND_NOTICE,j)[1]=='3' && token[6]!=NULL)
   strcat(temp,token[6]);
  else if(lindex(BIND_NOTICE,j)[1]=='4' && token[7]!=NULL)
   strcat(temp,token[7]);
  else if(lindex(BIND_NOTICE,j)[1]=='5' && token[8]!=NULL)
   strcat(temp,token[8]);
  else if(lindex(BIND_NOTICE,j)[1]=='6' && token[9]!=NULL)
   strcat(temp,token[9]);
  else break; }
 else   
  strcat(temp,lindex(BIND_NOTICE,j));
 strcat(temp," ");
 j++;
 }
 sprintf(buf,"%s\n",temp);
 writeln(sck,buf);
#endif
}
#endif

do_exec(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if(token[4] == NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !exec <shell command>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 if (j>3)
 for(i=4;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); }
 system(temp);
}

do_ircaddict(sck)
int sck;
{
 int i=1;
 int j=0;
 FILE *fp;
 char temp[512];
 strcpy(temp,"");   
 srandom(time(NULL));
 srand(time(NULL));
 i = random() % 33;
 i=i+1;
 fp = fopen("addict.file","r");
 while(fgets(temp,255,fp) != NULL) {
  if(i==j) {
   sprintf(buf,"PRIVMSG %s :You know you're an IRC addict when %s\n",token[2],temp);
   writeln(sck,buf);
   if(fp!=NULL) fclose(fp);
   return 0; }
  j=j+1; }
 if(fp!=NULL) fclose(fp);
}

do_dice(sck)
int sck;
{
 int i,j;
 if(token[4]==NULL) {
  sprintf(buf,"PRIVMSG %s :Syntax: !dice <max number>\n",token[2]);
  writeln(sck,buf);
  return 0; }
 srandom(time(NULL));
 j = atoi(token[4]);
 if(j<1) {
  sprintf(buf,"PRIVMSG %s :Syntax: !dice <max number>\n",token[2]);
  writeln(sck,buf);
  return 0; }
 i = random() % j;
 i++;
 sprintf(buf,"PRIVMSG %s :After rolling the dice, it came on %d!\n",token[2],i);
 writeln(sck,buf);
}

show_aliases(sck,fromhost,type)
int sck;
int type;
char *fromhost;
{
 FILE *fp,*fpblah,*morefp;
 int i=0,j=0,z=0,f=0,k=4;
 int blah,zz;
 int level=0;
 int lala=0;
 char temp[255]="";
 char temp2[512]="";
 char temp3[512]="";
 char temp4[512]="";
 char temp5[512]="";
 char temp6[512]="";
 j=chk_num(0);
 level = chklevel(fromhost);
 if(token[2]==NULL) return 0;
 if(token[1]==NULL) return 0;
 if(j>2)
 for(i=3;i<j;i++) strcat(temp2,token[i]);
 if((fp=fopen("alias.file","r"))==NULL) { return 0; }
 while(fgets(temp,255,fp)!=NULL) {
 fpalias=fopen(lindex(temp,0),"r");
 strcpy(temp,"");
 strcpy(temp4,"");
 strcpy(temp5,"");
 while(fgets(temp,255,fpalias)!=NULL) 
 {
 if(temp==NULL) break;
 if(!cas_cmp(temp,"")) break;
 strcpy(temp4,"");
 if(type==0)
 {
  if(!cas_cmp(lindex(temp,0),"on_word")) 
  {
   if(token[1]!=NULL && token[2]!=NULL && token[3]!=NULL)
    if(!match(lindex(temp,1),temp2))
    {
     if(!(cas_cmp(token[1],"PRIVMSG")) || !(cas_cmp(token[1],"NOTICE")))
     if(level >= atoi(lindex(temp,2)))
     { 
      for(f=3;lindex(temp,f)!=NULL;f++)
      {
       if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='h') 
          strcat(temp4,token[2]);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='m')
          sprintf(temp4,"%s%c",temp4,CMDCHAR);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='b' && *(lindex(temp,f)+2)=='o')
          strcat(temp4,BOTNAME);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n') 
          strcat(temp4,token[0]);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='e' && *(lindex(temp,f)+2)=='x')
          system(lindex(temp,f+1));
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
       { sprintf(timers[atoi(lindex(temp,f+1))],"%ld ",(atol(lindex(temp,f+2))+time(NULL)));
        for(j=f+3;lindex(temp,j)!=NULL;j++) {
         if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
          strcat(timers[atoi(lindex(temp,f+1))],token[2]);
         else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
          strcat(timers[atoi(lindex(temp,f+1))],token[0]);
         else
          strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
         strcat(timers[atoi(lindex(temp,f+1))]," "); } }
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
        { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }   
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='m' && *(lindex(temp,f)+2)=='1')
         { strcat(temp4,":\001ACTION"); 
          lala=1; }
#ifdef TCL_INT
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='c')
         { strcpy(temp3,TCL_INT);
           strcat(temp3," ");
           strcat(temp3,lindex(temp,f+1));
           strcat(temp3," ");
           strcat(temp3,token[0]);
           while(token[k]!=NULL) { 
            for(i=0;*(token[k]+i)!=NULL;i++)
             if(*(token[k]+i)==';' || *(token[k]+i)=='|' || *(token[k]+i)=='&') return 0;
            i=0;
            strcat(temp3," ");
            strcat(temp3,token[k]);
            k++; }
           k=4;
           fpblah=fopen(".tcl_info.file","w");
           sprintf(temp6,"TCL_VER 1.0 TCL INFO VERSION\n");
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_NICK %s BOT NAME\n",BOTNAME);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_HOST %s USER HOST\n",fromhost);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_CHAN %s CHANNEL\n",token[2]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_COMTYPE %s COM TYPE\n",token[1]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_TIME %ld UNIX TIME\n",time(NULL));
           fputs(temp6,fpblah);
           if(fpblah!=NULL) fclose(fpblah); 
           system(temp3); }
#endif
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='m' && *(lindex(temp,f)+2)=='2')
         { strcat(temp4,"\001"); 
           lala=1; }
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
#ifdef REPORTS
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e') 
          strcat(temp4,REPORTS);
#endif
       else strcat(temp4,lindex(temp,f));
       /* CRAP AHEAD */
       if(lala==1 && lindex(temp,f+1)==NULL) { }
       else strcat(temp4," ");
      }
      if(lala==1) {
       lala=0; }
      sprintf(buf,"%s\n",temp4); 
      writeln(sck,buf);
#ifndef MULT_ALIASES
      if(fpalias!=NULL) fclose(fpalias);
      return 0;
#endif
     }
    }
  }

  else if(!cas_cmp(lindex(temp,0),"#")) { }
  else if(!cas_cmp(lindex(temp,0),"on_connect")) { }
  else if(!cas_cmp(lindex(temp,0),"on_numeric")) { }

  else if(!cas_cmp(lindex(temp,0),"on_mode"))
  {
   if(!cas_cmp(token[1],"MODE"))
   {
    if(!match(lindex(temp,2),token[3]))
    if(!match(lindex(temp,1),token[2]))
    {
     if(!cas_cmp(lindex(temp,3),"1"))
     {
      if(cas_cmp(token[0],BOTNAME) && cas_cmp(token[0],BOTSECNAME))
      {
       for(f=4;lindex(temp,f)!=NULL;f++)  
       {
        if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='h')
           strcat(temp4,token[2]); 
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='m')
          sprintf(temp4,"%s%c",temp4,CMDCHAR);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='b' && *(lindex(temp,f)+2)=='o')
          strcat(temp4,BOTNAME);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='e' && *(lindex(temp,f)+2)=='x')
          system(lindex(temp,f+1));  
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n')
           strcat(temp4,token[0]);
        else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
       { sprintf(timers[atoi(lindex(temp,f+1))],"%ld ",(atol(lindex(temp,f+2))+time(NULL)));
        for(j=f+3;lindex(temp,j)!=NULL;j++) {
         if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
          strcat(timers[atoi(lindex(temp,f+1))],token[2]);
         else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
          strcat(timers[atoi(lindex(temp,f+1))],token[0]);
         else
          strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
         strcat(timers[atoi(lindex(temp,f+1))]," "); } }
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='m')
           strcat(temp4,token[3]);
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
        { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }   
#ifdef REPORTS
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e')
          strcat(temp4,REPORTS);
#endif
        else strcat(temp4,lindex(temp,f));
        strcat(temp4," "); 
       }
      } 
     }
     else
     {
      for(f=4;lindex(temp,f)!=NULL;f++)
      {
       if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='h')
          strcat(temp4,token[2]);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='m')
          sprintf(temp4,"%s%c",temp4,CMDCHAR);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='b' && *(lindex(temp,f)+2)=='o')
          strcat(temp4,BOTNAME);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n')
          strcat(temp4,token[0]);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='e' && *(lindex(temp,f)+2)=='x')
          system(lindex(temp,f+1));  
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='m')
          strcat(temp4,token[3]);
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
        { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
       { sprintf(timers[atoi(lindex(temp,f+1))],"%ld ",(atol(lindex(temp,f+2))+time(NULL)));
        for(j=f+3;lindex(temp,j)!=NULL;j++) {
         if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
          strcat(timers[atoi(lindex(temp,f+1))],token[2]);
         else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
          strcat(timers[atoi(lindex(temp,f+1))],token[0]);
         else
          strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
         strcat(timers[atoi(lindex(temp,f+1))]," "); } }
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }   
#ifdef REPORTS
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e')
         strcat(temp4,REPORTS);
#endif
       else strcat(temp4,lindex(temp,f));
       strcat(temp4," ");
      }
     }
     sprintf(buf,"%s\n",temp4);  
     writeln(sck,buf);
#ifndef MULT_ALIASES
if(fpalias!=NULL) fclose(fpalias);
     return 0;
#endif
    } 
   }
  }

  else if(!cas_cmp(lindex(temp,0),"on_topic"))
  {
   if(!cas_cmp(token[1],"TOPIC")) 
   {
    if(cas_cmp(token[0],BOTNAME))
    for(f=1;lindex(temp,f)!=NULL;f++)  
    {
     if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='h')
          strcat(temp4,token[2]);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='m')
          sprintf(temp4,"%s%c",temp4,CMDCHAR);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='b' && *(lindex(temp,f)+2)=='o')
          strcat(temp4,BOTNAME);
     else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
        { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
       { sprintf(timers[atoi(lindex(temp,f+1))],"%ld ",(atol(lindex(temp,f+2))+time(NULL)));
        for(j=f+3;lindex(temp,j)!=NULL;j++) {
         if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
          strcat(timers[atoi(lindex(temp,f+1))],token[2]);
         else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
          strcat(timers[atoi(lindex(temp,f+1))],token[0]);
         else
          strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
         strcat(timers[atoi(lindex(temp,f+1))]," "); } }
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='e' && *(lindex(temp,f)+2)=='x')
          system(lindex(temp,f+1));  
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }   
     else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n')
          strcat(temp4,token[0]);
#ifdef REPORTS  
     else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e')
          strcat(temp4,REPORTS);
#endif
     else strcat(temp4,lindex(temp,f));
     strcat(temp4," ");
    }
    sprintf(buf,"%s\n",temp4);
    writeln(sck,buf);
#ifndef MULT_ALIASES
if(fpalias!=NULL) fclose(fpalias);
    return 0;
#endif 
   }
  }   

  else if(!cas_cmp(lindex(temp,0),"on_kick"))
  {
   if(!cas_cmp(token[1],"KICK"))
   {
    if(!match(lindex(temp,1),token[2]))
    {
     for(f=2;lindex(temp,f)!=NULL;f++)
     {
      if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='h')
          strcat(temp4,token[2]);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='m')
          sprintf(temp4,"%s%c",temp4,CMDCHAR);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='b' && *(lindex(temp,f)+2)=='o')
          strcat(temp4,BOTNAME);
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
        { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='e' && *(lindex(temp,f)+2)=='x')
          system(lindex(temp,f+1));  
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
       { sprintf(timers[atoi(lindex(temp,f+1))],"%ld ",(atol(lindex(temp,f+2))+time(NULL)));
        for(j=f+3;lindex(temp,j)!=NULL;j++) {
         if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
          strcat(timers[atoi(lindex(temp,f+1))],token[2]);
         else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
          strcat(timers[atoi(lindex(temp,f+1))],token[0]);
         else
          strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
         strcat(timers[atoi(lindex(temp,f+1))]," "); } }
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }   
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n')
          strcat(temp4,token[0]);
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='k')
          strcat(temp4,token[3]);
#ifdef REPORTS
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e')
          strcat(temp4,REPORTS);
#endif
      else strcat(temp4,lindex(temp,f));
      strcat(temp4," ");
     }
     sprintf(buf,"%s\n",temp4);  
     writeln(sck,buf);
#ifndef MULT_ALIASES
if(fpalias!=NULL) fclose(fpalias);
     return 0;
#endif
    } 
   }
  }

 else if(!cas_cmp(lindex(temp,0),"ifnot"))
  {
   if(!cas_cmp(lindex(temp,2),token[1]))
   {
    if(!cas_cmp(lindex(temp,1),"mask"))
    {
     if(match(lindex(temp,3),fromhost))
     {
      strcpy(temp4,"");
      for(f=4;lindex(temp,f)!=NULL;f++)
      {
       if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='h')
          strcat(temp4,token[2]);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='m')
          sprintf(temp4,"%s%c",temp4,CMDCHAR);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='b' && *(lindex(temp,f)+2)=='o')
          strcat(temp4,BOTNAME);
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
        { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='e' && *(lindex(temp,f)+2)=='x')
          system(lindex(temp,f+1));
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
        { sprintf(timers[atoi(lindex(temp,f+1))],"%ld",(atol(lindex(temp,f+2))+time(NULL)));
         for(j=f+3;lindex(temp,j)!=NULL;j++) {
          if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
           strcat(timers[atoi(lindex(temp,f+1))],token[2]);
          else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
           strcat(timers[atoi(lindex(temp,f+1))],token[0]);
          else
           strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
           strcat(timers[atoi(lindex(temp,f+1))]," "); } }
#ifdef TCL_INT
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='c')
         { strcpy(temp3,TCL_INT);
           strcat(temp3," ");
           strcat(temp3,lindex(temp,f+1));
           strcat(temp3," ");
           strcat(temp3,token[0]);
           strcat(temp3," ");
           k=4;
           fpblah=fopen(".tcl_info.file","w");
           sprintf(temp6,"TCL_VER 1.0 TCL INFO VERSION\n");
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_NICK %s BOT NAME\n",BOTNAME);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_HOST %s USER HOST\n",fromhost);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_CHAN %s CHANNEL\n",token[2]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_COMTYPE %s COM TYPE\n",token[1]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_TIME %ld UNIX TIME\n",time(NULL));
           fputs(temp6,fpblah);
           if(fpblah!=NULL) fclose(fpblah);
           system(temp3); }
#endif
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n')
          strcat(temp4,token[0]);
#ifdef REPORTS
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e')
          strcat(temp4,REPORTS);
#endif
       else strcat(temp4,lindex(temp,f));
       strcat(temp4," ");
      }
      sprintf(buf,"%s\n",temp4);
      writeln(sck,buf);
#ifndef MULT_ALIASES
      if(fpalias!=NULL) fclose(fpalias);
       return 0;
#endif
     }
    }
    if(!cas_cmp(lindex(temp,1),"mask_from_file"))
    {
     morefp=fopen(lindex(temp,3),"r");
     zz=0;
     while(fgets(temp3,255,morefp)!=NULL)
     {
      if(!match(lindex(temp3,0),fromhost)) zz=1;
     }
     if(zz==0)
     {
       strcpy(temp4,"");
       for(f=4;lindex(temp,f)!=NULL;f++)
       {
        if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='h')
          strcat(temp4,token[2]);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='m')
          sprintf(temp4,"%s%c",temp4,CMDCHAR);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='b' && *(lindex(temp,f)+2)=='o')
          strcat(temp4,BOTNAME);
        else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
         { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='e' && *(lindex(temp,f)+2)=='x')
          system(lindex(temp,f+1));
        else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
         { sprintf(timers[atoi(lindex(temp,f+1))],"%ld",(atol(lindex(temp,f+2))+time(NULL)));
          for(j=f+3;lindex(temp,j)!=NULL;j++) {
           if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
            strcat(timers[atoi(lindex(temp,f+1))],token[2]);
           else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
            strcat(timers[atoi(lindex(temp,f+1))],token[0]);
           else
            strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
           strcat(timers[atoi(lindex(temp,f+1))]," "); } }
#ifdef TCL_INT
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='c')
         { strcpy(temp3,TCL_INT);
           strcat(temp3," ");
           strcat(temp3,lindex(temp,f+1));
           strcat(temp3," ");
           strcat(temp3,token[0]);
           strcat(temp3," ");
           k=4;
           fpblah=fopen(".tcl_info.file","w");
           sprintf(temp6,"TCL_VER 1.0 TCL INFO VERSION\n");
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_NICK %s BOT NAME\n",BOTNAME);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_HOST %s USER HOST\n",fromhost);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_CHAN %s CHANNEL\n",token[2]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_COMTYPE %s COM TYPE\n",token[1]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_TIME %ld UNIX TIME\n",time(NULL));
           fputs(temp6,fpblah);
           if(fpblah!=NULL) fclose(fpblah);
           system(temp3); }
#endif
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n')
          strcat(temp4,token[0]);
#ifdef REPORTS
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e')
          strcat(temp4,REPORTS);
#endif
        else strcat(temp4,lindex(temp,f));
        strcat(temp4," ");
       }
       sprintf(buf,"%s\n",temp4);
       writeln(sck,buf);
#ifndef MULT_ALIASES
       if(fpalias!=NULL) fclose(fpalias);
       return 0;
#endif
     } 
     if(morefp!=NULL) fclose(morefp);
    }
   }
  }

  else if(!cas_cmp(lindex(temp,0),"if"))
  {
   if(!cas_cmp(lindex(temp,2),token[1]))
   {
    if(!cas_cmp(lindex(temp,1),"mask"))
    {
     if(!match(lindex(temp,3),fromhost))
     {
      strcpy(temp4,"");
      for(f=4;lindex(temp,f)!=NULL;f++)
      {
       if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='h')
          strcat(temp4,token[2]);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='m')
          sprintf(temp4,"%s%c",temp4,CMDCHAR);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='b' && *(lindex(temp,f)+2)=='o')
          strcat(temp4,BOTNAME);
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
        { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='e' && *(lindex(temp,f)+2)=='x')
          system(lindex(temp,f+1));
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
        { sprintf(timers[atoi(lindex(temp,f+1))],"%ld ",(atol(lindex(temp,f+2))+time(NULL)));
         for(j=f+3;lindex(temp,j)!=NULL;j++) {
          if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
           strcat(timers[atoi(lindex(temp,f+1))],token[2]);
          else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
           strcat(timers[atoi(lindex(temp,f+1))],token[0]);
          else
           strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
           strcat(timers[atoi(lindex(temp,f+1))]," "); } }
#ifdef TCL_INT
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='c')
         { strcpy(temp3,TCL_INT);
           strcat(temp3," ");
           strcat(temp3,lindex(temp,f+1));
           strcat(temp3," ");
           strcat(temp3,token[0]);
           strcat(temp3," ");
           k=4;
           fpblah=fopen(".tcl_info.file","w");
           sprintf(temp6,"TCL_VER 1.0 TCL INFO VERSION\n");
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_NICK %s BOT NAME\n",BOTNAME);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_HOST %s USER HOST\n",fromhost);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_CHAN %s CHANNEL\n",token[2]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_COMTYPE %s COM TYPE\n",token[1]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_TIME %ld UNIX TIME\n",time(NULL));
           fputs(temp6,fpblah);
           if(fpblah!=NULL) fclose(fpblah);
           system(temp3); }
#endif
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n')
          strcat(temp4,token[0]);
#ifdef REPORTS
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e')
          strcat(temp4,REPORTS);
#endif
       else strcat(temp4,lindex(temp,f));
       strcat(temp4," ");
      }
      sprintf(buf,"%s\n",temp4);
      writeln(sck,buf);
#ifndef MULT_ALIASES
      if(fpalias!=NULL) fclose(fpalias);
       return 0;
#endif
     }
    }
    if(!cas_cmp(lindex(temp,1),"mask_from_file"))
    {
     morefp=fopen(lindex(temp,3),"r");
     while(fgets(temp3,255,morefp)!=NULL)
     {
      if(!match(lindex(temp3,0),fromhost))
      {
       strcpy(temp4,"");
       for(f=4;lindex(temp,f)!=NULL;f++)
       {
        if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='h')
          strcat(temp4,token[2]);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='m')
          sprintf(temp4,"%s%c",temp4,CMDCHAR);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='b' && *(lindex(temp,f)+2)=='o')
          strcat(temp4,BOTNAME);
        else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
         { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='e' && *(lindex(temp,f)+2)=='x')
          system(lindex(temp,f+1));
        else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
         { sprintf(timers[atoi(lindex(temp,f+1))],"%ld ",(atol(lindex(temp,f+2))+time(NULL)));
          for(j=f+3;lindex(temp,j)!=NULL;j++) {
           if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
            strcat(timers[atoi(lindex(temp,f+1))],token[2]);
           else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
            strcat(timers[atoi(lindex(temp,f+1))],token[0]);
           else
            strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
           strcat(timers[atoi(lindex(temp,f+1))]," "); } }
#ifdef TCL_INT
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='c')
         { strcpy(temp3,TCL_INT);
           strcat(temp3," ");
           strcat(temp3,lindex(temp,f+1));
           strcat(temp3," ");
           strcat(temp3,token[0]);
           strcat(temp3," ");
           k=4;
           fpblah=fopen(".tcl_info.file","w");
           sprintf(temp6,"TCL_VER 1.0 TCL INFO VERSION\n");
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_NICK %s BOT NAME\n",BOTNAME);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_HOST %s USER HOST\n",fromhost);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_CHAN %s CHANNEL\n",token[2]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_COMTYPE %s COM TYPE\n",token[1]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_TIME %ld UNIX TIME\n",time(NULL));
           fputs(temp6,fpblah);
           if(fpblah!=NULL) fclose(fpblah);
           system(temp3); }
#endif
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n')
          strcat(temp4,token[0]);
#ifdef REPORTS
        else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e')
          strcat(temp4,REPORTS);
#endif
        else strcat(temp4,lindex(temp,f));
        strcat(temp4," ");
       }
       sprintf(buf,"%s\n",temp4);
       writeln(sck,buf);
#ifndef MULT_ALIASES
       if(fpalias!=NULL) fclose(fpalias);
       return 0;
#endif
      }
     } 
     if(morefp!=NULL) fclose(morefp);
    }
   }
  }

  else if(!cas_cmp(lindex(temp,0),"on_join")) 
  { 
   if(!cas_cmp(token[1],"JOIN")) 
   {
    if(!match(lindex(temp,2),token[0]))
    if(!match(lindex(temp,1),token[2]))
    {
     for(f=3;lindex(temp,f)!=NULL;f++)  
     {
      if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='h')
          strcat(temp4,token[2]);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='m')
          sprintf(temp4,"%s%c",temp4,CMDCHAR);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='b' && *(lindex(temp,f)+2)=='o')
          strcat(temp4,BOTNAME);
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
        { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='e' && *(lindex(temp,f)+2)=='x')
          system(lindex(temp,f+1));  
      else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
       { sprintf(timers[atoi(lindex(temp,f+1))],"%ld ",(atol(lindex(temp,f+2))+time(NULL)));
        for(j=f+3;lindex(temp,j)!=NULL;j++) {
         if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
          strcat(timers[atoi(lindex(temp,f+1))],token[2]);
         else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
          strcat(timers[atoi(lindex(temp,f+1))],token[0]);
         else
          strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
         strcat(timers[atoi(lindex(temp,f+1))]," "); } }
#ifdef TCL_INT
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='c')
         { strcpy(temp3,TCL_INT);
           strcat(temp3," ");
           strcat(temp3,lindex(temp,f+1));
           strcat(temp3," ");
           strcat(temp3,token[0]);
           strcat(temp3," ");
           k=4;
           fpblah=fopen(".tcl_info.file","w");
           sprintf(temp6,"TCL_VER 1.0 TCL INFO VERSION\n");
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_NICK %s BOT NAME\n",BOTNAME);          
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_HOST %s USER HOST\n",fromhost);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_CHAN %s CHANNEL\n",token[2]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_COMTYPE %s COM TYPE\n",token[1]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_TIME %ld UNIX TIME\n",time(NULL));
           fputs(temp6,fpblah);
           if(fpblah!=NULL) fclose(fpblah);
           system(temp3); }              
#endif
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }   
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n')
          strcat(temp4,token[0]);
#ifdef REPORTS   
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e')
          strcat(temp4,REPORTS);
#endif
      else strcat(temp4,lindex(temp,f));
      strcat(temp4," ");
     }
     sprintf(buf,"%s\n",temp4);
     writeln(sck,buf);
#ifndef MULT_ALIASES
if(fpalias!=NULL) fclose(fpalias);
     return 0;
#endif
    }
   }
  }

  else if(!cas_cmp(lindex(temp,0),"on_botnick"))
  {
   if(!cas_cmp(token[1],"PRIVMSG"))
   {
    strcpy(temp5,"*:");
    strcat(temp5,BOTNAME);
    strcat(temp5,"*");
    if(!match(lindex(temp,2),temp2))
    if(!match(temp5,token[3]))
    if(level >= atoi(lindex(temp,1)))
    {
     for(f=3;lindex(temp,f)!=NULL;f++)
     {
      if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='h')
          strcat(temp4,token[2]);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='m')
          sprintf(temp4,"%s%c",temp4,CMDCHAR);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='b' && *(lindex(temp,f)+2)=='o')
          strcat(temp4,BOTNAME);
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
        { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
      else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
       { sprintf(timers[atoi(lindex(temp,f+1))],"%ld ",(atol(lindex(temp,f+2))+time(NULL)));
        for(j=f+3;lindex(temp,j)!=NULL;j++) {
         if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
          strcat(timers[atoi(lindex(temp,f+1))],token[2]);
         else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
          strcat(timers[atoi(lindex(temp,f+1))],token[0]);
         else
          strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
         strcat(timers[atoi(lindex(temp,f+1))]," "); } }
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='e' && *(lindex(temp,f)+2)=='x')
          system(lindex(temp,f+1));  
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }   
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n')
          strcat(temp4,token[0]);
#ifdef REPORTS
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e')
          strcat(temp4,REPORTS);
#endif
      else strcat(temp4,lindex(temp,f));   
      strcat(temp4," ");
     }
     sprintf(buf,"%s\n",temp4);  
     writeln(sck,buf);
#ifndef MULT_ALIASES
if(fpalias!=NULL) fclose(fpalias);
     return 0;
#endif
    } 
   }
  }
  
  else if(!cas_cmp(lindex(temp,0),"on_part"))
  {
   if(!cas_cmp(token[1],"PART"))
   {
    if(!match(lindex(temp,1),token[2]))
    {
     for(f=2;lindex(temp,f)!=NULL;f++)
     {
      if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='h')
          strcat(temp4,token[2]);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='m')
          sprintf(temp4,"%s%c",temp4,CMDCHAR);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='b' && *(lindex(temp,f)+2)=='o')
          strcat(temp4,BOTNAME);
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
        { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
#ifdef TCL_INT
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='c')
         { strcpy(temp3,TCL_INT);
           strcat(temp3," ");
           strcat(temp3,lindex(temp,f+1));
           strcat(temp3," ");
           strcat(temp3,token[0]);
           strcat(temp3," ");
           k=4;
           fpblah=fopen(".tcl_info.file","w");      
           sprintf(temp6,"TCL_VER 1.0 TCL INFO VERSION\n");
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_NICK %s BOT NAME\n",BOTNAME);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_HOST %s USER HOST\n",fromhost);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_CHAN %s CHANNEL\n",token[2]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_COMTYPE %s COM TYPE\n",token[1]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_TIME %ld UNIX TIME\n",time(NULL));    
           fputs(temp6,fpblah);
           if(fpblah!=NULL) fclose(fpblah);
           system(temp3); }
#endif 
      else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
       { sprintf(timers[atoi(lindex(temp,f+1))],"%ld ",(atol(lindex(temp,f+2))+time(NULL)));
        for(j=f+3;lindex(temp,j)!=NULL;j++) {
         if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
          strcat(timers[atoi(lindex(temp,f+1))],token[2]);
         else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
          strcat(timers[atoi(lindex(temp,f+1))],token[0]);
         else
          strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
         strcat(timers[atoi(lindex(temp,f+1))]," "); } }
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }   
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='e' && *(lindex(temp,f)+2)=='x')
          system(lindex(temp,f+1));  
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n')
          strcat(temp4,token[0]);
#ifdef REPORTS
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e')
          strcat(temp4,REPORTS);
#endif
      else strcat(temp4,lindex(temp,f));
      strcat(temp4," ");
     }
     sprintf(buf,"%s\n",temp4);  
     writeln(sck,buf);
#ifndef MULT_ALIASES
if(fpalias!=NULL) fclose(fpalias);
     return 0;
#endif
    }
   }  
  }

  else if(!cas_cmp(lindex(temp,0),"on_wallops"))
  {
   if(!cas_cmp(token[1],"WALLOPS"))
   {
    if(!match(lindex(temp,1),token[0]))
    {
     for(f=2;lindex(temp,f)!=NULL;f++)
     {
      if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='e' && *(lindex(temp,f)+2)=='x')
          system(lindex(temp,f+1));  
      else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
       { sprintf(timers[atoi(lindex(temp,f+1))],"%ld ",(atol(lindex(temp,f+2))+time(NULL)));
        for(j=f+3;lindex(temp,j)!=NULL;j++) {
         if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
          strcat(timers[atoi(lindex(temp,f+1))],token[2]);
         else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
          strcat(timers[atoi(lindex(temp,f+1))],token[0]);
         else
          strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
         strcat(timers[atoi(lindex(temp,f+1))]," "); } }
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
        { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }   
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n')
          strcat(temp4,token[0]);
#ifdef REPORTS
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e')
          strcat(temp4,REPORTS); 
#endif
      else strcat(temp4,lindex(temp,f));
      strcat(temp4," "); }
     sprintf(buf,"%s\n",temp4);
     writeln(sck,buf);
#ifndef MULT_ALIASES
if(fpalias!=NULL) fclose(fpalias);
     return 0;
#endif
    } 
   }
  }

  else if(!cas_cmp(lindex(temp,0),"on_nick"))
  {
   if(!cas_cmp(token[1],"NICK"))
   {
    if(!match(lindex(temp,1),token[2]))
    {
     for(f=2;lindex(temp,f)!=NULL;f++)
     {
      if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='e' && *(lindex(temp,f)+2)=='x')
          system(lindex(temp,f+1));  
      else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
       { sprintf(timers[atoi(lindex(temp,f+1))],"%ld ",(atol(lindex(temp,f+2))+time(NULL)));
        for(j=f+3;lindex(temp,j)!=NULL;j++) {
         if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
          strcat(timers[atoi(lindex(temp,f+1))],token[2]);
         else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
          strcat(timers[atoi(lindex(temp,f+1))],token[0]);
         else
          strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
         strcat(timers[atoi(lindex(temp,f+1))]," "); } }
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
        { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n')
          strcat(temp4,token[0]);
#ifdef REPORTS
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e')
          strcat(temp4,REPORTS); 
#endif
      else strcat(temp4,lindex(temp,f));
      strcat(temp4," "); }
     sprintf(buf,"%s\n",temp4);
     writeln(sck,buf);
#ifndef MULT_ALIASES
if(fpalias!=NULL) fclose(fpalias);
     return 0;
#endif
    }
   }  
  }

  else if(!cas_cmp(lindex(temp,0),"on_quit"))
  {
   if(!cas_cmp(token[1],"QUIT"))
   {
    if(!match(lindex(temp,1),token[0]))
    { 
     for(f=2;lindex(temp,f)!=NULL;f++)  
     {
      if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='h')
          strcat(temp4,token[2]);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='m')
          sprintf(temp4,"%s%c",temp4,CMDCHAR);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='b' && *(lindex(temp,f)+2)=='o')
          strcat(temp4,BOTNAME);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='e' && *(lindex(temp,f)+2)=='x')
          system(lindex(temp,f+1));  
      else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
       { sprintf(timers[atoi(lindex(temp,f+1))],"%ld ",(atol(lindex(temp,f+2))+time(NULL)));
        for(j=f+3;lindex(temp,j)!=NULL;j++) {
         if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
          strcat(timers[atoi(lindex(temp,f+1))],token[2]);
         else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
          strcat(timers[atoi(lindex(temp,f+1))],token[0]);
         else
          strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
         strcat(timers[atoi(lindex(temp,f+1))]," "); } }
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
        { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
#ifdef TCL_INT
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='c')
         { strcpy(temp3,TCL_INT);
           strcat(temp3," ");
           strcat(temp3,lindex(temp,f+1));
           strcat(temp3," ");
           strcat(temp3,token[0]);
           strcat(temp3," ");
           k=4;
           fpblah=fopen(".tcl_info.file","w");      
           sprintf(temp6,"TCL_VER 1.0 TCL INFO VERSION\n");
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_NICK %s BOT NAME\n",BOTNAME);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_HOST %s USER HOST\n",fromhost);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_CHAN %s CHANNEL\n",token[2]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_COMTYPE %s COM TYPE\n",token[1]);
           fputs(temp6,fpblah);
           sprintf(temp6,"TCL_TIME %ld UNIX TIME\n",time(NULL));    
           fputs(temp6,fpblah);
           if(fpblah!=NULL) fclose(fpblah);
           system(temp3); }
#endif 
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }   
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n')
          strcat(temp4,token[0]);
#ifdef REPORTS  
      else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e')
          strcat(temp4,REPORTS);
#endif
      else strcat(temp4,lindex(temp,f));
      strcat(temp4," ");
     }
     sprintf(buf,"%s\n",temp4);
     writeln(sck,buf);
#ifndef MULT_ALIASES
if(fpalias!=NULL) fclose(fpalias);
     return 0;
#endif
    }
   }  
  }

  else
  {
   if(token[3]!=NULL)
   if(!match(lindex(temp,0),temp2)) 
   {
    if(level >= atoi(lindex(temp,1))) 
    {
     sprintf(buf,"PRIVMSG %s :%s\n",token[2],lrange(temp,2));
     writeln(sck,buf);
#ifndef MULT_ALIASES
if(fpalias!=NULL) fclose(fpalias); 
    return 0; 
#endif
    } 
   }
   else if(!cas_cmp(token[3],lindex(temp,0))) 
   {
    if(level >= atoi(lindex(temp,1))) 
    {
     sprintf(buf,"PRIVMSG %s :%s\n",token[2],lrange(temp,2));
     writeln(sck,buf);
#ifndef MULT_ALIASES
if (fpalias!=NULL) fclose(fpalias);
     return 0; 
#endif
    } 
   }
   else if(*temp=='%') 
   {
    for(z=0;token[z]!=NULL;z++) 
    {
     if(!cas_cmp(token[z],lindex(temp,0))) 
     {
      if(level >= atoi(lindex(temp,1))) 
      {
       sprintf(buf,"PRIVMSG %s :%s\n",token[2],lrange(temp,2));
       writeln(sck,buf);
#ifndef MULT_ALIASES 
if(fpalias!=NULL) fclose(fpalias);
      return 0; 
#endif
      }
     }
    }
   }
  }
 }
 else
 {
  if(!cas_cmp(lindex(temp,0),"on_numeric"))
  {
   if(token[1]!=NULL && token[2]!=NULL && token[3]!=NULL)
    if(!match(lindex(temp,1),token[1]))
    {
      for(f=2;lindex(temp,f)!=NULL;f++)
      {
       if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='h')
          strcat(temp4,token[2]);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='c' && *(lindex(temp,f)+2)=='m')
          sprintf(temp4,"%s%c",temp4,CMDCHAR);
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='b' && *(lindex(temp,f)+2)=='o')
          strcat(temp4,BOTNAME);
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='t' && *(lindex(temp,f)+2)=='i')
       { sprintf(timers[atoi(lindex(temp,f+1))],"%ld ",(atol(lindex(temp,f+2))+time(NULL)));
        for(j=f+3;lindex(temp,j)!=NULL;j++) {
         if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='c')
          strcat(timers[atoi(lindex(temp,f+1))],token[3]);
         else if(*lindex(temp,j)=='$' && *(lindex(temp,j)+1)=='n')
          strcat(timers[atoi(lindex(temp,f+1))],token[2]);
         else
          strcat(timers[atoi(lindex(temp,f+1))],lindex(temp,j));
         strcat(timers[atoi(lindex(temp,f+1))]," "); } }
       else if(*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='s' && *(lindex(temp,f)+2)=='t')
        { f++; for(blah=atoi(lindex(temp,f));token[blah]!=NULL;blah++) {
           strcat(temp4,token[blah]);
           strcat(temp4," "); } }
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='n') {
          strcpy(temp2,token[0]);
          if(temp2[0]==':') temp2[0]=' ';
          strcat(temp4,temp2); }
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='w')
          { f++; if(token[atoi(lindex(temp,f))+2]!=NULL) {
            strcpy(temp5,token[atoi(lindex(temp,f))+2]);
            if(temp5[0]==':') temp5[0]=' ';
            strcat(temp4,temp5); } }   
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+1)=='u')
          strcat(temp4,fromhost);
#ifdef REPORTS
       else if (*lindex(temp,f)=='$' && *(lindex(temp,f)+2)=='e')
          strcat(temp4,REPORTS);
#endif
       else strcat(temp4,lindex(temp,f));
       strcat(temp4," ");
      }
      sprintf(buf,"%s\n",temp4);
      writeln(sck,buf);
#ifndef MULT_ALIASES
      if(fpalias!=NULL) fclose(fpalias);
      return 0;
#endif
     }
   }
  }
 }
if(fpalias!=NULL) fclose(fpalias);
strcpy(temp,"");
}
if(fp!=NULL) fclose(fp);
#ifdef TCL_INT
fp=fopen(".tcl_tmp.file","r");
while(fgets(temp,255,fp)!=NULL) {
 sprintf(buf,"%s\n",temp);
 writeln(sck,buf); }
if(fp!=NULL) fclose(fp);
fp=fopen(".tcl_tmp.file","w");
fputs("",fp);
if(fp!=NULL) fclose(fp);
#endif
}

do_listautobans(sck)
int sck;
{
 FILE *fp;
 char temp[512];
 strcpy(temp,"");
 fp = fopen(AUTOBAN,"r");
 sprintf(buf,"NOTICE %s :Autobans list\n",token[0]);
 writeln(sck,buf);
 while(fgets(temp,255,fp)!=NULL) {
  if(temp!=NULL && lindex(temp,1)!=NULL) {
   sprintf(buf,"NOTICE %s :[%ld secs left] %s\n",token[0],(atol(lindex(temp,1))-time(NULL)),temp);
   writeln(sck,buf); } }
 if(fp!=NULL) fclose(fp);
}

#ifdef FTPMGR

ftpmgr(sck)
int sck;
{
if(token[4]!=NULL) {
 if(!cas_cmp(token[4],"makesvr")) ftp_makesvr(sck);
 else if(!cas_cmp(token[4],"intro")) ftp_intro(sck);
 else if(!cas_cmp(token[4],"welcome")) ftp_welcome(sck);
return 0; }
sprintf(buf,"NOTICE %s :Welcome to MudBot's FTP server manager.\n",token[0]);
writeln(sck,buf);
sprintf(buf,"NOTICE %s :It is important you read the introduction text before you attempt anything by typing the 'intro' command: !ftp intro\n",token[0]);
writeln(sck,buf);
sprintf(buf,"NOTICE %s :- ftp makesvr - Makes the server from scratch.\n",token[0]);
writeln(sck,buf);
sprintf(buf,"NOTICE %s :- ftp intro - Read the instructions.\n",token[0]);
writeln(sck,buf);
sprintf(buf,"NOTICE %s :- ftp welcome <welcome msg> - Change the default welcome msg.\n",token[0]);
writeln(sck,buf);
sprintf(buf,"NOTICE %s :- exec <shell command> - Use shell commands to move files and such (requires ALLOW_EXEC)\n",token[0]);
writeln(sck,buf);
sprintf(buf,"NOTICE %s :- End of commands -\n",token[0]);
writeln(sck,buf);
}

ftp_intro(sck)
int sck;
{
sprintf(buf,"NOTICE %s :FTP server manager\n",token[0]);
writeln(sck,buf);
sprintf(buf,"NOTICE %s :The idea of this manager is to be able to handle an anonymous FTP server from IRC. It requires root to hands you the management of the server's anonymous FTP.\n",token[0]); 
writeln(sck,buf);
sprintf(buf,"NOTICE %s :You could use this to handle a small, private server tho, if you don't mind giving your login/pass to the users using that FTP.\n",token[0]);
writeln(sck,buf);
sprintf(buf,"NOTICE %s :For it to work correctly, you need to do a few basic steps: as root, create a directory for the FTP server, FTPROOT. Usualy, /home/ftp. Then, type 'chown loginname /home/ftp' where loginname is your login name\n",token[0]);
writeln(sck,buf);
sprintf(buf,"NOTICE %s :Last thing to do is check the anonymous FTP' files (/etc/ftpaccess) and passwd (/etc/passwd) make them point to that dir. And it's done!\n",token[0]);
writeln(sck,buf); 
sprintf(buf,"NOTICE %s :When you first start to manage the server, you need to use the 'makesvr' command *only if the FTPROOT dir is empty*. Use this only once to make the basic dirs there. Now you can test the server\n",token[0]);
writeln(sck,buf); 
}

ftp_makesvr(sck)
int sck;
{
 char temp[512];
 strcpy(temp,"");
 sprintf(buf,"NOTICE %s :Making basic directories...\n",token[0]);
 writeln(sck,buf);
 strcpy(temp,"mkdir ");
 strcat(temp,FTPROOT);
 strcat(temp,"/pub");
 system(temp);
 strcpy(temp,"mkdir ");
 strcat(temp,FTPROOT);
 strcat(temp,"/etc");
 system(temp);
 strcpy(temp,"mkdir ");
 strcat(temp,FTPROOT);
 strcat(temp,"/lib");
 system(temp);
 strcpy(temp,"mkdir ");
 strcat(temp,FTPROOT);
 strcat(temp,"/bin");
 system(temp);
 strcpy(temp,"cp /bin/ls ");
 strcat(temp,FTPROOT);
 strcat(temp,"/bin/ls");
 system(temp);
 sprintf(buf,"NOTICE %s :Setting right permissions...\n",token[0]);
 writeln(sck,buf);
 strcpy(temp,"chmod -R 755 ");
 strcat(temp,FTPROOT);
 system(temp);
 sprintf(buf,"NOTICE %s :Everything *should* be set up right.\n",token[0]);
 writeln(sck,buf);
}

ftp_welcome(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if(token[5]==NULL) {
  sprintf(buf,"NOTICE %s :!ftp welcome <welcome line>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 sprintf(buf,"NOTICE %s :Setting up default welcome.msg file...\n",token[0]);
 writeln(sck,buf);
 strcpy(temp,"echo ");
 if (j>5)
 for(i=5;i<j;i++) {
  strcat(temp,token[i]);
  strcat(temp," "); }
 strcat(temp," > ");
 strcat(temp,FTPROOT);
 strcat(temp,"/welcome.msg");
 system(temp);
 sprintf(buf,"NOTICE %s :Sent '%s'\n",token[0],temp);
 writeln(sck,buf);
}
#endif /* ftp */

do_history(sck)
int sck;
{
 FILE *fp;
 int i=0;
 int j=0;
 char temp[512];
 strcpy(temp,"");
#ifndef LOGFILE_CMD
 sprintf(buf,"NOTICE %s :Log is not activated. You need to define a log file in the config.\n",token[0]);
 writeln(sck,buf);
#endif
#ifdef LOGFILE_CMD
 sprintf(buf,"NOTICE %s :Last 5 lines of log file:\n",token[0]);
 writeln(sck,buf);
 fp = fopen(LOGFILE_CMD,"r");
 while(fgets(temp,255,fp)!=NULL) {i++;}
 if(fp!=NULL) fclose(fp);
 i=i-5;
 if(i<5) {
  sprintf(buf,"NOTICE %s :Log is not big enough! Try again when a few more entries are in.\n",token[0]);
  writeln(sck,buf);
  return 0; }
 fp=fopen(LOGFILE_CMD,"r");
 while(j!=i) {
  fgets(temp,255,fp);
  j++; }
 while(fgets(temp,255,fp)!=NULL) {
  sprintf(buf,"NOTICE %s :- %s\n",token[0],temp);
  writeln(sck,buf); }
 if(fp!=NULL) fclose(fp);
#endif
}

do_dns(sck)
int sck;
{
 int i=0;
 FILE *fp;
 char temp[512]="";
 if(token[4]==NULL) {
  sprintf(buf,"PRIVMSG %s :Syntax: !dns <host>\n",token[2]);
  writeln(sck,buf);
  return 0; }
 sprintf(buf,"PRIVMSG %s :Sending NS call and waiting 5secs for a reply...\n",token[2]);
 writeln(sck,buf);
 strcpy(temp,"nslookup ");
 strcat(temp,token[4]);
 strcat(temp," > temp.ns 2> /dev/null \n");
 system(temp);
 sleep(5);
 fp = fopen("temp.ns","r");
 while(fgets(temp,255,fp)!=NULL) {
  if(!cas_cmp(lindex(temp,0),"Non-authoritative")) {
   sprintf(buf,"PRIVMSG %s :*** Answer already cached\n",token[2]);
   writeln(sck,buf); }
  if(!cas_cmp(lindex(temp,0),"Name:")) {
   sprintf(buf,"PRIVMSG %s :Hostname: %s\n",token[2],lindex(temp,1));
   writeln(sck,buf); 
   i=1; }
  if(!cas_cmp(lindex(temp,0),"Aliases:") && i==1) {
   sprintf(buf,"PRIVMSG %s :Aliases: %s\n",token[2],lrange(temp,1));
   writeln(sck,buf); }
  if(!cas_cmp(lindex(temp,0),"Addresses:") && i==1) {
   sprintf(buf,"PRIVMSG %s :*** RR (host has multiple IPs)\n",token[2]);
   writeln(sck,buf); 
   sprintf(buf,"PRIVMSG %s :IP: %s\n",token[2],lrange(temp,1));
   writeln(sck,buf); }
  if(!cas_cmp(lindex(temp,0),"Address:") && i==1) {
   sprintf(buf,"PRIVMSG %s :IP: %s\n",token[2],lrange(temp,1));
   writeln(sck,buf); }
  if(temp[3]=='1' || temp[3]=='2' || temp[3]=='3' || temp[3]=='4' || temp[3]=='5' || temp[3]=='6' || temp[3]=='7' || temp[3]=='8' || temp[3]=='9') {
   sprintf(buf,"PRIVMSG %s :-> %s\n",token[2],lrange(temp,0));
   writeln(sck,buf); }
  if(!cas_cmp(lindex(temp,0),"***")) {
   sprintf(buf,"PRIVMSG %s :%s\n",token[2],temp);
   writeln(sck,buf); }
 }
 if(i==0) {
 sprintf(buf,"PRIVMSG %s :*** Host not found or nslookup timeout. This function has been made to work with Linux's GNU nslookup program and may not work properly with other OS\n",token[2]);
 writeln(sck,buf); }
 if(fp!=NULL) fclose(fp);
}

do_uwhois(sck)
int sck;
{
 int i=0;
 FILE *fp;
 char temp[512];
 strcpy(temp,"");
 if(token[4]==NULL) {
  sprintf(buf,"PRIVMSG %s :Syntax: !uwhois <domain.name>\n",token[2]);
  writeln(sck,buf);
  return 0; }
 sprintf(buf,"PRIVMSG %s :Sending request to WHOIS server and waiting 5secs for a reply...\n",token[2]);
 writeln(sck,buf);
 strcpy(temp,"whois ");
 strcat(temp,token[4]);
 strcat(temp," > temp.whois 2> /dev/null \n");
 system(temp);
 sleep(5);
 fp = fopen("temp.whois","r");
 while(fgets(temp,255,fp)!=NULL) {
  if(i>0) {
   sprintf(buf,"PRIVMSG %s :%s\n",token[2],temp);
   writeln(sck,buf); 
   i--; }
  if(temp[0]=='[') i=1;
  if(!cas_cmp(lindex(temp,0),"Domain")) {
   if(!cas_cmp(lindex(temp,1),"servers")) i=4;
   sprintf(buf,"PRIVMSG %s :-> %s\n",token[2],temp);
   writeln(sck,buf); }
  if(!cas_cmp(temp,"")) {
   i--;
   sleep(1); }
  if(!cas_cmp(lindex(temp,0),"Administrative")) {
   i=1;
   sprintf(buf,"PRIVMSG %s :-> Administrative contact:\n",token[2]);
   writeln(sck,buf); }
  if(!cas_cmp(lindex(temp,0),"Technical")) {
   i=1;
   sprintf(buf,"PRIVMSG %s :-> Technical contact:\n",token[2]);
   writeln(sck,buf); }
  if(!cas_cmp(lindex(temp,0),"Billing")) {
   i=1;
   sprintf(buf,"PRIVMSG %s :-> Billing contact:\n",token[2]);
   writeln(sck,buf); }
 }
 if(fp!=NULL) fclose(fp);
}

do_uping(sck)
int sck;
{
 FILE *fp;
 int i=0;
 char temp[512];
 strcpy(temp,"");
 if(token[4]==NULL) {
  sprintf(buf,"PRIVMSG %s :Syntax: !uping <host>\n",token[2]);
  writeln(sck,buf);
  return 0; }
 sprintf(buf,"PRIVMSG %s :Sending 5 packets of 64 bytes to %s...\n",token[2],token[4]);
 writeln(sck,buf);
 strcpy(temp,"ping -s 64 -c 5 ");
 strcat(temp,token[4]);
 strcat(temp," > temp.ping 2> /dev/null \n");
 system(temp);
 sleep(5);
 fp = fopen("temp.ping","r");
 while(fgets(temp,255,fp)!=NULL) {
  if(i==1) {
   sprintf(buf,"PRIVMSG %s :-> %s\n",token[2],temp);
   writeln(sck,buf); } 
  if(!cas_cmp(lindex(temp,0),"---")) {
   sprintf(buf,"PRIVMSG %s :PING reply from %s\n",token[2],token[4]);
   writeln(sck,buf);
   i=1; }
 }
 if(i==0) {
  sprintf(buf,"PRIVMSG %s :*** No reply from host or PING timeout. This function has been made for Linux's GNU PING command. Some other versions might not work properly.\n",token[2]);
  writeln(sck,buf); }
 if (fp!=NULL) fclose(fp);
}

do_spyo(sck)
int sck;
{
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !spy <channel to spy> (use this command from a channel, not from msg)\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :Syntax: !spy <channel>\n",token[2]);
  writeln(sck,buf);
  return 0; }
 strcpy(spying,token[4]);
 strcpy(spyto,token[2]);
 sprintf(buf,"PRIVMSG %s :*** Starting spy on %s\n",token[2],token[4]);
 writeln(sck,buf);
 sprintf(buf,"JOIN %s\n",token[4]);
 writeln(sck,buf);
}

do_stopspy(sck)
int sck;
{
 sprintf(buf,"PART %s\n",spying);
 writeln(sck,buf);
 strcpy(spying,"dummy");
 sprintf(buf,"PRIVMSG %s :*** Left channel\n",token[2]);
 writeln(sck,buf);
}

spy_report(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if(j>2)
 for(i=3;i<j;i++) {
  strcat(temp,token[i]);
  strcat(temp," "); }
 if(!cas_cmp(temp,"")) strcpy(temp," >>>");
 if(temp[0]==':') temp[0]=' ';
 if(temp[2]=='A' && temp[3]=='C' && temp[4]=='T' && temp[5]=='I') {
  temp[strlen(temp)-2]='\0';
  sprintf(buf,"PRIVMSG %s :(spy[%s:%s]) *** %s\n",spyto,token[0],token[1],lrange(temp,1));
 }
 else {
  sprintf(buf,"PRIVMSG %s :(spy[%s:%s]) %s\n",spyto,token[0],token[1],temp); 
 }
 writeln(sck,buf);
}

do_seen(sck)
int sck;
{
 FILE *fpz;
 char boo[255];
 char temp[255];
 strcpy(temp,"");
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !seen <nick>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 fpz = fopen("seen.file","r");
 strcpy(boo,"Don't know that user");
 while(fgets(temp,255,fpz)!=NULL) 
 {
  if(!cas_cmp(lindex(temp,0),token[4])) strcpy(boo,lrange(temp,1));
 }
 sprintf(buf,"NOTICE %s :Last seen: %s\n",token[0],boo);
 writeln(sck,buf);
 if(fpz!=NULL) fclose(fpz);
}

do_countmail(sck,mailacc)
int sck;
char mailacc[255];
{
 int i=0;
 FILE *fp;
 char temp[512];
 strcpy(temp,"");
 if(mailacc==NULL) {
 sprintf(buf,"NOTICE %s :Fetching mail from %s mail folder...\n",token[0],ACCOUNTNAME);
 writeln(sck,buf);
 strcpy(temp,"/var/spool/mail/");
 strcat(temp,ACCOUNTNAME); }
 else {
 sprintf(buf,"NOTICE %s :Fetching mail from %s mail folder...\n",token[0],mailacc);
 writeln(sck,buf);
 strcpy(temp,mailacc); }
 fp=fopen(temp,"r");
 while(fgets(temp,255,fp)!=NULL) {
  if(!cas_cmp(lindex(temp,0),"From")) i++; }
 if(fp!=NULL) fclose(fp);
 if(i==0) {
  sprintf(buf,"NOTICE %s :Failed to retrieve mail count. This may be for many reasons: Your account name is wrong, the file doesn't have the right permissions, or you simply have no mail at all!\n",token[0]); 
  writeln(sck,buf);
  return 0; }
 sprintf(buf,"NOTICE %s :You currently have %d email(s)\n",token[0],i);
 writeln(sck,buf);
}

do_stats(sck)
int sck;
{
 FILE *fp;
 int c=0;
 int l=0;
 int e=0;
 int u=0;
 int a=0;
#ifdef POSIX
 struct rusage r_usage;
#endif
 char temp[512];
 strcpy(temp,"");
 fp=fopen("stats.file","r");
 while(fgets(temp,255,fp)!=NULL) {
  if(temp[0]=='C') c++;
  if(temp[0]=='A') a++;
  if(temp[0]=='U') u++;
  if(temp[0]=='L') l++;
  if(temp[0]=='E') e++; }
 if(fp!=NULL) fclose(fp);
 sprintf(buf,"NOTICE %s :LOGINS COMMANDS AUTH DEAUTH EXIT\n",token[0]);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :%d      %d        %d    %d    %d\n",token[0],l,c,a,u,e);
 writeln(sck,buf);
 do_uptime(sck);
 do_system(sck);
#ifdef POSIX
 getrusage(RUSAGE_SELF,&r_usage);
 sprintf(buf,"NOTICE %s :CPU usage: user: %ld.%06ld ms system: %ld.%06ld ms\n",token[0],r_usage.ru_utime.tv_sec,r_usage.ru_utime.tv_usec,r_usage.ru_stime.tv_sec,r_usage.ru_stime.tv_usec);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :Max resident set size: %ld Shared memory size: %ld Unshared data size: %ld Unshared stack size: %ld\n",token[0],r_usage.ru_maxrss,r_usage.ru_ixrss,r_usage.ru_idrss,r_usage.ru_isrss);
 writeln(sck,buf);
 sprintf(buf,"NOTICE %s :Page faults: %ld Swap: %ld Messages sent: %ld Messages received: %ld Signals received: %ld\n",token[0],r_usage.ru_majflt,r_usage.ru_nswap,r_usage.ru_msgsnd,r_usage.ru_msgrcv,r_usage.ru_nsignals);
 writeln(sck,buf);
#endif
}

do_clearmess(sck)
int sck;
{
 FILE *fp;
 char temp[512];
 strcpy(temp,"");
 sprintf(buf,"NOTICE %s :Deleting *.log, *.old, seen.file and stats.file to clear up space...\n",token[0]);
 writeln(sck,buf);
 fp=fopen("seen.file","w");
 fputs("",fp);
 if(fp!=NULL) fclose(fp);
 system("rm *.old \n");
 system("rm *.log \n");
 fp=fopen("stats.file","w");
 fputs("",fp);
 if(fp!=NULL) fclose(fp);
}

do_unixtime(sck)
int sck;
{
 time_t lt;
 if(token[4]==NULL) {
 sprintf(buf,"PRIVMSG %s :Syntax: !unixtime <unix time>\n",token[2]);
 writeln(sck,buf);
 return 0; }
 lt=atol(token[4]);
 sprintf(buf,"PRIVMSG %s :%ld == %s \n",token[2],atol(token[4]),ctime(&lt));
 writeln(sck,buf);
}

do_newpass(sck, level)   
int sck;
int level;
{
 FILE *fp;
 FILE *fpb;
 char line[255];   
 char line2[255];
 int i,j;
 char tempa[100] = "";
 char tempb[100] = "";
 char tempc[100] = "";
 char tempd[100] = "";
 char tempe[100] = "";
 char tempf[100] = "";
 char tempg[100] = "";
 char *tempp = "";
 char another[100] = "cp user.new ";
 char temp[512];
 strcpy(temp,"");
 if(token[4]==NULL || token[6]==NULL || token[5]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !newpass <nick> <old pass> <new pass>\n",token[0]);
  writeln(sck,buf);
  return 0; }
  if(!cas_cmp(token[4],MASTER)) {
  sprintf(buf,"NOTICE %s :Error: You cannot change the pass for the master entry.\n",token[0]);
  writeln(sck,buf);
  return 0; }
 fp = fopen(USERFILE,"r");   
 fpb = fopen("user.new","w");
 for (i=0;fgets(line, 255, fp);i++)
 {
  strcpy(line2,line);
  if(tempp = strtok(line,":"))    /* level */
   strcpy(tempa,tempp);

  if(tempp = strtok(NULL,":"))    /* nick */
   strcpy(tempb,tempp);

  if(tempp = strtok(NULL,":"))    /* u@h */
   strcpy(tempc,tempp);

  if(tempp = strtok(NULL,":"))    /* pass */
   strcpy(tempd,tempp);

  if(tempp = strtok(NULL,":"))    /* validate */
   strcpy(tempe,tempp);

  if(tempp = strtok(NULL,":"))    /* autoop */
   strcpy(tempf,tempp);

  if(tempp = strtok(NULL,":"))    /* email */
   strcpy(tempg,tempp);

 if (cas_cmp(tempb,token[4]))
 {
   fputs(line2,fpb);
 }
 else if(!cas_cmp(tempb,token[4])) {
  if(cas_cmp(tempd,do_cryptpass(token[5]))) {
   sprintf(buf,"NOTICE %s :Error: Wrong password!\n",token[0]);
   writeln(sck,buf);
   if(fpb!=NULL) fclose(fpb);
   if(fp!=NULL) fclose(fp);
   return 0; } 
  if(atoi(tempa)!=level) {
   sprintf(buf,"NOTICE %s :Error: You can only change your own password!\n",token[0]);
   writeln(sck,buf);
   if(fp!=NULL) fclose(fp);
   if(fpb!=NULL) fclose(fpb);
   return 0; }
   strcpy(temp,tempa);
   strcat(temp,":");
   strcat(temp,tempb);
   strcat(temp,":");
   strcat(temp,tempc);
   strcat(temp,":");
   strcat(temp,do_cryptpass(token[6]));
   strcat(temp,":");
   strcat(temp,tempe);
   strcat(temp,":");
   strcat(temp,tempf);
   strcat(temp,":");
   strcat(temp,tempg);
   strcat(temp,":\n");
   fputs(temp,fpb);
   sprintf(buf,"NOTICE %s :Entry found and modified: [%s] %s -> %s \n",token[0],tempb,tempd,token[6]);
   writeln(sck,buf); } }
 if(fp!=NULL) fclose(fp);
 if(fpb!=NULL) fclose(fpb);
 strcat(another,USERFILE);
 system(another);
} 

do_getpopmail(sck)
int sck;
{
 FILE *fp;
 FILE *tempfd=0;
 int i,length,msgno;
 char tempbuf[512];
 char somebuf[512];
 char temp[255];
 strcpy(tempbuf,"");
 strcpy(somebuf,"");
 if(token[4]==NULL || token[5]==NULL || token[6]==NULL) {
 sprintf(buf,"NOTICE %s :Syntax: !checkpopmail <POP3 mail server> <user id> <password>\n",token[0]);
 writeln(sck,buf);
 return 0; }
 sprintf(buf,"NOTICE %s :Contacting %s...\n",token[0],token[4]);
 writeln(sck,buf);
 for(i=1;i < 50;i++)
 {
  tempfd=mail_socket(token[4],110,sck);
  if(tempfd==-1) continue;
  else if(tempfd==-2) return 0;
  else break;
 }
 if(i>48) return 0;
 if((length=read(tempfd,tempbuf,512))<1)
 {
  sprintf(buf,"NOTICE %s :Error connecting to mail server.\n",token[0]);
  writeln(sck,buf);
  if(tempfd!=0) close(tempfd);
  return 0;
 }
 tempbuf[length]='\0';
 sprintf(somebuf,"USER %s\n",token[5]);
 writeln(tempfd,somebuf);
 if((length=read(tempfd,tempbuf,512))<1)
 {
  sprintf(buf,"NOTICE %s :Error login in mail server.\n",token[0]);
  writeln(sck,buf);
  if(tempfd!=0) close(tempfd);
  return 0;
 }
 sprintf(somebuf,"PASS %s\n",token[6]);
 writeln(tempfd,somebuf);
 if((length=read(tempfd,tempbuf,512))<1)
 {
  sprintf(buf,"NOTICE %s :Login incorrect to mail server.\n",token[0]);
  writeln(sck,buf);
  if(tempfd!=0) close(tempfd);
  return 0;
 }
 if(!cas_cmp(lindex(tempbuf,0),"-ERR"))
 {
  sprintf(buf,"NOTICE %s :Login incorrect to mail server.\n",token[0]);
  writeln(sck,buf);
  if(tempfd!=0) close(tempfd);
  return 0;
 }
 sprintf(somebuf,"STAT\n");
 writeln(tempfd,somebuf);
 if((length=read(tempfd,tempbuf,512))<1)
 {
  sprintf(buf,"NOTICE %s :Error getting stats from mail server.\n",token[0]);
  writeln(sck,buf);
  if(tempfd!=0) close(tempfd);
  return 0;
 }
 msgno=atoi(lindex(tempbuf,1));
 sprintf(buf,"NOTICE %s :You have %s new mail(s). Closing connection.\n",token[0],lindex(tempbuf,1));
 writeln(sck,buf);
/*
* sprintf(temp,"popmail.%s.%ld.file",token[0],time(NULL));
* fp=fopen(temp,"a");
* for(i=1;i<(msgno+1);i++) {
* sprintf(somebuf,"DELE %d\n",(i-1));
* writeln(tempfd,somebuf);
* sprintf(somebuf,"RETR %d\n",i);
* writeln(tempfd,somebuf);
* strcpy(tempbuf,"");
* while(cas_cmp(tempbuf,"."))
* {
*  strcpy(tempbuf,"");
*  length=read(tempfd,tempbuf,512);
*  printf("%s\n--------------------\n",tempbuf);
*  sleep(1);
*  fputs(tempbuf,temp);
*  if(!cas_cmp(lindex(tempbuf,0),"From:"))
*  {
*   sprintf(buf,"NOTICE %s :%s\n",token[0],tempbuf);
*   writeln(sck,buf);
*  }
*  if(!cas_cmp(lindex(tempbuf,0),"Subject:"))
*  {
*   sprintf(buf,"NOTICE %s :%s\n",token[0],tempbuf);
*   writeln(sck,buf);
*  }
* } }
*/
 close(tempfd);
}

do_readmail(sck)
int sck;
{
 FILE *fp;
 char temp[512];
 strcpy(temp,"");
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !readmail <mail file>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 fp=fopen(token[4],"r");
 while(fgets(temp,500,fp)!=NULL) {
  if(!cas_cmp(lindex(temp,0),"From:") || !cas_cmp(lindex(temp,0),"Subject:")) {
   sprintf(buf,"NOTICE %s :- %s\n",token[0],temp);
   writeln(sck,buf); } }
 sprintf(buf,"NOTICE %s :End of mail file. To read the whole file, use the !play command.\n",token[0]);
 writeln(sck,buf);
 if(fp!=NULL) fclose(fp);
}

do_sysmax(sck)
int sck;
{
#ifdef POSIX
 int a=sysconf(_SC_ARG_MAX);
 int b=sysconf(_SC_CHILD_MAX);
 int c=sysconf(_SC_CLK_TCK);
 int d=sysconf(_SC_STREAM_MAX);
 int e=sysconf(_SC_TZNAME_MAX);
 int f=sysconf(_SC_OPEN_MAX);
 int g=sysconf(_SC_VERSION);
 int h=sysconf(_SC_BC_STRING_MAX);
 int i=sysconf(_SC_2_VERSION);
 sprintf(buf,"NOTICE %s :SYSTEM: ARG_MAX=%d CHILD_MAX=%d CLK_TCK=%d STREAM_MAX=%d TZ_MAX=%d OPEN_MAX=%d POSIX_VER=%d STR_MAX=%d POSIX2_VER=%d\n",token[0],a,b,c,d,e,f,g,h,i);
 writeln(sck,buf);
#endif
}

do_vote(sck, fromhost)
int sck;
char *fromhost;
{
 FILE *fp;
 int i=0;
 char temp[512];
 strcpy(temp,"");
 if(*token[2]!='#') {
  sprintf(buf,"NOTICE %s :You must use this command in a channel\n",token[0]);
  writeln(sck,buf);
  return 0; }
 if(token[4]==NULL) {
  fp=fopen("vote.file","r");
  sprintf(buf,"PRIVMSG %s :Use the vote command to vote on the current topic:\n",token[2]);
  writeln(sck,buf);
  fgets(temp,255,fp);
  sprintf(buf,"PRIVMSG %s :- %s\n",token[2],temp);
  writeln(sck,buf);
  while(fgets(temp,255,fp)!=NULL) {
   i++;
   sprintf(buf,"PRIVMSG %s :Choice %d -> %s\n",token[2],i,temp);
   writeln(sck,buf); }
  sprintf(buf,"PRIVMSG %s :Syntax: !vote <choice number>\n",token[2]);
  writeln(sck,buf);
  if(fp!=NULL) fclose(fp);
  return 0; }
 fp=fopen("vote.results","a");
 fputs(token[4],fp);
 fputs(" ",fp);
 fputs(fromhost,fp);
 fputs("\n",fp);
 if(fp!=NULL) fclose(fp);
 sprintf(buf,"PRIVMSG %s :Thanks for voting\n",token[2]);
 writeln(sck,buf);
}

do_voteresults(sck)
int sck;
{
 FILE *fp;
 int a=0;
 int b=0;
 int c=0;
 int d=0;
 int e=0;
 int f=0;
 int g=0;
 int h=0;
 int i=0;
 int n=0;
 char temp[512];
 strcpy(temp,"");
 fp=fopen("vote.results","r");
 while(fgets(temp,255,fp)!=NULL) {
  if(temp[0]=='1') a++;
  if(temp[0]=='2') b++;
  if(temp[0]=='3') c++;
  if(temp[0]=='4') d++;
  if(temp[0]=='5') e++;
  if(temp[0]=='6') f++;
  if(temp[0]=='7') g++;
  if(temp[0]=='8') h++;
  if(temp[0]=='9') i++; }
 if(fp!=NULL) fclose(fp);
 fp=fopen("vote.file","r");
 fgets(temp,255,fp);
 sprintf(buf,"NOTICE %s :Vote subject %s\n",token[0],temp);
 writeln(sck,buf);
 while(fgets(temp,255,fp)!=NULL) {
  n++;
  if (n==1) sprintf(buf,"NOTICE %s :Choice %d got %d votes\n",token[0],n,a);
  if (n==2) sprintf(buf,"NOTICE %s :Choice %d got %d votes\n",token[0],n,b);
  if (n==3) sprintf(buf,"NOTICE %s :Choice %d got %d votes\n",token[0],n,c);
  if (n==4) sprintf(buf,"NOTICE %s :Choice %d got %d votes\n",token[0],n,d);
  if (n==5) sprintf(buf,"NOTICE %s :Choice %d got %d votes\n",token[0],n,e);
  if (n==6) sprintf(buf,"NOTICE %s :Choice %d got %d votes\n",token[0],n,f);
  if (n==7) sprintf(buf,"NOTICE %s :Choice %d got %d votes\n",token[0],n,g);
  if (n==8) sprintf(buf,"NOTICE %s :Choice %d got %d votes\n",token[0],n,h);
  if (n==9) sprintf(buf,"NOTICE %s :Choice %d got %d votes\n",token[0],n,i);
  writeln(sck,buf); }
 if(fp!=NULL) fclose(fp);
}

do_notepad(sck)
int sck;
{
 FILE *fp;
 int i,j;
 char temp[512];
 strcpy(temp,""); 
 if(token[4]==NULL) {
  fp=fopen("notes.file","r");
  while(fgets(temp,255,fp)!=NULL) {
   sprintf(buf,"NOTICE %s :%s\n",token[0],temp);
   writeln(sck,buf); }
  if(fp!=NULL) fclose(fp); }
 else {
  j=chk_num(0);
  if(j>3)
  for (i=4;i<j;i++) {
   strcat(temp,token[i]);
   strcat(temp," "); }
  fp=fopen("notes.file","a");
  fputs(temp,fp);
  fputs("\n",fp);
  sprintf(buf,"NOTICE %s :Saved.... Use !notepad to see your notes list\n",token[0]); 
  writeln(sck,buf);
  if(fp!=NULL) fclose(fp); }
}

do_opcom(sck)
int sck;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !opcom mode <command>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 if(!cas_cmp(token[4],"mode") || !cas_cmp(token[4],"kick")) {
 j=chk_num(0);
 if(j>3)
 for(i=4;i<j;i++) {
  strcat(temp,token[i]);
  strcat(temp," "); }
 sprintf(buff,"%s\n",temp);
 writeln(servsck,buff);
 sprintf(buff,"WALLOPS :OPCOM %s\n",temp);
 writeln(servsck,buff); 
#ifdef REPORTS
 sprintf(buff,":OperServ PRIVMSG %s :%s is using me to %s\n",REPORTS,token[0],temp);
 writeln(servsck,buff);
#endif
}
 else {
 sprintf(buf,"NOTICE %s :Invalid command\n",token[0]);
 writeln(sck,buf); }
}

do_clearchan(sck)
int sck;
{
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !clearchan <channel>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 sprintf(buff,"MODE %s -tniplkms *\n",token[4]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ JOIN %s\n",token[4]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ NAMES %s\n",token[4]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ MODE %s b\n",token[4]);
 writeln(servsck,buff);
 sprintf(buff,"WALLOPS :CLEARCHAN for %s\n",token[4]);
 writeln(servsck,buff);
#ifdef REPORTS
 sprintf(buff,":OperServ PRIVMSG %s :%s is using me to CLEARCHAN %s\n",REPORTS,token[0],token[4]);
 writeln(servsck,buff);
#endif
 sprintf(buff,":OperServ PART %s\n",token[4]);
 writeln(servsck,buff);
 strcpy(clearchan,token[4]);
}

do_gline(sck,a)
int sck;
int a;
{
 int i,j,k;
 char temp[512];
 char temp2[512];
 strcpy(temp,"BANNED: ");
 if (a)
 if(token[4]==NULL || token[5]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !gline [time in secs | -wildcard | -nick] <user@host> <reason>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 if (!a) { 
  if(token[4]==NULL) {
   sprintf(buf,"NOTICE %s :Syntax: !remgline [-wildcard] <user@host>\n",token[0]);
   writeln(sck,buf); 
   return 0; }
 if(!cas_cmp(token[4],"-wildcard") || atoi(token[4])>0) {
  if(token[5]==NULL) {
   sprintf(buf,"NOTICE %s :Syntax: !remgline [-wildcard] <user@host>\n",token[0]);
   writeln(sck,buf);
   return 0; } } }
 if (a)
 if(!cas_cmp(token[4],"-nick")) {
  sprintf(buff,":OperServ WHOIS %s\n",token[5]);
  writeln(servsck,buff);
#ifdef REPORTS
  sprintf(buff,":OperServ PRIVMSG %s :%s adding GLINE by NICK for %s\n",REPORTS,token[0],token[5]);
  writeln(servsck,buff);
#endif
 by_nick = 1;
 return 0; }
 if(atoi(token[4])<1 && cas_cmp(token[4],"-wildcard")) {
  strcpy(temp2,token[4]);
  strcat(temp2,"\0");
  for(k=0;temp2[k]!='@';k++) { if(temp2[k]=='\0') return 0; }
  for(k=k;temp2[k]!='\0';k++) {
   if(temp2[k]=='*') {
#ifndef MASKED_GLINES
   sprintf(buff,":OperServ NOTICE %s :NO MASKED HOST\n",token[0]);
   writeln(servsck,buff);
   return 0;
#endif
 } } }
 else {
  strcpy(temp2,token[5]);
  strcat(temp2,"\0");
  for(k=0;temp2[k]!='@';k++) { if(temp2[k]=='\0') return 0; }
  for(k=k;temp2[k]!='\0';k++) {
   if(temp2[k]=='*') {
#ifndef MASKED_GLINES
    sprintf(buff,":OperServ NOTICE %s :NO MASKED HOST\n",token[0]);
    writeln(servsck,buff);
    return 0;
#endif
 } } }
 if(cas_cmp(token[4],"-wildcard")) {
 if(temp2[strlen(temp2)-1]=='*' || temp2[strlen(temp2)-1]=='?' || temp2[strlen(temp2)-2]=='*' || temp2[strlen(temp2)-2]=='?') {
  sprintf(buff,":OperServ NOTICE %s :CANNOT TERMINATE STRING BY WILDCARD\n",token[0]);
  writeln(servsck,buff);
  return 0; } }
 j=chk_num(0);
 if(j>4)
 for(i=5;i<j;i++) {
  strcat(temp,token[i]);
  strcat(temp," "); }
 if(atoi(token[4])<1 && cas_cmp(token[4],"-wildcard")) {
  if (a) sprintf(buff,"GLINE %s +%s %d :%s\n",SERVICE_SERVER_NAME,token[4],GLINE_TIME,temp); 
  if (!a) sprintf(buff,"GLINE %s -%s\n",SERVICE_SERVER_NAME,token[4]); }
 else if (!cas_cmp(token[4],"-wildcard")) {
  if (a) sprintf(buff,"GLINE %s +%s %d :%s\n",SERVICE_SERVER_NAME,token[5],GLINE_TIME,temp); 
  if (!a) sprintf(buff,"GLINE %s -%s\n",SERVICE_SERVER_NAME,token[5]); }
 else {
  if (a) sprintf(buff,"GLINE %s +%s %d :%s\n",SERVICE_SERVER_NAME,token[5],atoi(token[4]),temp); 
  if (!a) sprintf(buff,"GLINE %s -%s\n",SERVICE_SERVER_NAME,token[5]); }
 writeln(servsck,buff);
 if(atoi(token[4])<1 && cas_cmp(token[4],"-wildcard")) {
  if (a) sprintf(buff,"WALLOPS :adding GLINE for %s (%s)\n",token[4],temp); 
  if (!a) sprintf(buff,"WALLOPS :removing GLINE for %s\n",token[4]); }
 else if (!cas_cmp(token[4],"-wildcard")) {
  if (a) sprintf(buff,"WALLOPS :adding GLINE for %s (%s)\n",token[5],temp); 
  if (!a) sprintf(buff,"WALLOPS :removing GLINE for %s\n",token[5]); }
 else {
  if (a) sprintf(buff,"WALLOPS :adding GLINE for %s [%d secs] (%s)\n",token[5],atoi(token[4]),temp); 
  if (!a) sprintf(buff,"WALLOPS :removing GLINE for %s\n",token[5]); }
 writeln(servsck,buff);
#ifdef REPORTS
 if(atoi(token[4])<1 && cas_cmp(token[4],"-wildcard")) {
  if (a) sprintf(buff,":OperServ PRIVMSG %s :%s is adding GLINE for %s\n",REPORTS,token[0],token[4]); 
 if (!a) sprintf(buff,":OperServ PRIVMSG %s :%s is removing GLINE for %s\n", REPORTS, token[0], token[4]); }
 else if (!cas_cmp(token[4],"-wildcard")) {
  if (a) sprintf(buff,":OperServ PRIVMSG %s :%s is adding GLINE for %s using WILDCARD flag\n",REPORTS,token[0],token[5]); 
 if (!a) sprintf(buff,":OperServ PRIVMSG %s :%s is removing GLINE for %s\n",REPORTS, token[0], token[5]); }
 else {
  if (a) sprintf(buff,":OperServ PRIVMSG %s :%s is adding GLINE for %s\n",REPORTS,token[0],token[5]); 
 if (!a) sprintf(buff,":OperServ PRIVMSG %s :%s is removing GLINE for %s\n",REPORTS, token[0], token[5]); }
 writeln(servsck,buff);
#endif
}

do_operin(sck)
int sck;
{
 sprintf(buff,":OperServ INVITE %s %s\n",token[0],token[4]);
 writeln(servsck,buff);
}

do_lock(sck)
int sck;
{
 FILE *fp;
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Invalid channel\n",token[0]);
  writeln(sck,buf);
  return 0; }
 sprintf(buff,":OperServ JOIN %s\n",token[4]);
 writeln(servsck,buff);
 sprintf(buff,"MODE %s +mtpni-kl *\n",token[4]);
 writeln(servsck,buff);
 sprintf(buff,"MODE %s +o OperServ\n",token[4]);
 writeln(servsck,buff);
 sprintf(buff,"WALLOPS :%s is LOCKING %s\n",token[0],token[4]);
 writeln(servsck,buff);
 fp=fopen("locks.file","a");
 fputs(token[4],fp);
 fputs(" dummy\n",fp);
 if(fp!=NULL) fclose(fp);
}

do_unlock(sck)
int sck;
{
 FILE *fp;
 FILE *fpa;
 char temp[255];
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Invalid channel\n",token[0]);
  writeln(sck,buf);
  return 0; }
 sprintf(buff,":OperServ MODE %s -i\n",token[4]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ PART %s\n",token[4]);
 writeln(servsck,buff);
 fp=fopen("locks.file","r");
 fpa=fopen("locks.new","w");
 while(fgets(temp,255,fp)!=NULL) { 
  if(cas_cmp(lindex(temp,0),token[4])) fputs(temp,fpa); }
 if(fpa!=NULL) fclose(fpa);
 if(fp!=NULL) fclose(fp);
 system("mv locks.new locks.file \n");
}

serv_in(sck)
int sck;
{
int i,j,k,l;
FILE *fpo;
char servbuf2[20000];
char temp[255];
if(servbuf!=NULL) {
 strcpy(servbuf2,servbuf);
 for(i=0;i<200;i++) servtok[i]=NULL;
 servtok[i=0]=strtok(servbuf2," ");
 while(servtok[++i]=strtok(NULL," ")); servtok[i]=NULL;
 sprintf(buff,"PONG :%s\n",SERVICE_UPLINK);
 writeln(servsck,buff);
 sprintf(buff,"PONG :9999999999999\n");
 writeln(servsck,buff);
#ifdef REPORTS
 if(i>2) {
  if(!cas_cmp(servtok[1],"MODE")) {
   if(servtok[2][0]!='#') {
    if(*servtok[3]==':' && *(servtok[3]+1)=='+' && *(servtok[3]+2)=='o') {
     sprintf(buff,":OperServ NOTICE %s :OPER by %s\n",REPORTS,servtok[2]);
     writeln(servsck,buff); } } } }
#endif
 for(l=1;lindex(servbuf,l)!=NULL;l++) {
  if(!cas_cmp(lindex(servbuf,l),"251")) {
   if(lindex(servbuf,l+2)!=NULL && lindex(servbuf,l+4)!=NULL && lindex(servbuf,l+7)!=NULL && lindex(servbuf,l+10)!=NULL) {
    if(!cas_cmp(lindex(servbuf,l+2),":There")) {
     fpo=fopen(".operserv.stats","a");
     sprintf(temp,"%d dummy\n",(atoi(lindex(servbuf,l+4))+atoi(lindex(servbuf,l+7))));
     fputs(temp,fpo);
     if(fpo!=NULL) fclose(fpo); } } } }
 for(l=1;lindex(servbuf,l)!=NULL;l++) {
 if(!cas_cmp(lindex(servbuf,l),"311")) {
  if(by_nick==1) {
   if(!cas_cmp(lindex(servbuf,l+1),"OperServ")) {
    sprintf(buff,"WALLOPS :adding GLINE for *@%s (Banned from this server)\n",lindex(servbuf,l+4));
    writeln(servsck,buff);
    sprintf(buff,"GLINE %s +*@%s %d :Banned from this server\n",SERVICE_SERVER_NAME,lindex(servbuf,l+4),GLINE_TIME);
    writeln(servsck,buff); 
    by_nick = 0; } } } }
 if(i>1)
 if(!cas_cmp(servtok[1],"KILL")) {
  if(!cas_cmp(servtok[2],"OperServ")) {
#ifdef IRCU_2_10
   sprintf(buff,"NICK OperServ 1 1 OperServ %s %s :Opers help bot\n",SERVICE_SERVER_NAME,SERVICE_SERVER_NAME);
#else
   sprintf(buff,"NICK OperServ 1 1 OperServ %s :Opers help bot\n",SERVICE_SERVER_NAME);
#endif
   writeln(servsck,buff);
   sprintf(buff,":OperServ MODE OperServ +ok :234342\n");
   writeln(servsck,buff);
   sprintf(buff,"WALLOPS :UnAuthorized KILL on OperServ by %s\n",servtok[0]);
   writeln(servsck,buff); } }
 for(j=5;servtok[j]!=NULL;j++) {
  if(*servtok[j]=='@') { 
   servtok[j]++;
   sprintf(buff,"MODE %s -o %s\n",clearchan,servtok[j]);
   writeln(servsck,buff);
  }
 }
 for(j=0;servtok[j]!=NULL;j++) {
  if(!cas_cmp(servtok[j],"367")) {
   j=j+3;
   sprintf(buff,"MODE %s -b %s\n",clearchan,servtok[j]);
   writeln(servsck,buff);
  }
 } 
 if(!cas_cmp(lindex(servbuf,0),"ERROR")) {
  printf("*** Uplink closed the connection\n");
  service_off = 1; }
 sprintf(buff,":OperServ LUSERS\n");
 writeln(servsck,buff);
 global_stats_lines++;
 if(global_stats_lines>1000)
  { system("echo > .operserv.stats");
    global_stats_lines=0; }
#ifdef SERVICE_TERMINAL
 printf("[SERVICE] %s",servbuf);
#endif
} }

do_jupe(sck)
int sck;
{
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !jupe <server>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 sprintf(buff,":OperServ SQUIT %s :Juping\n",token[4]);
 writeln(servsck,buff);
#ifndef IRCU_2_10
 sprintf(buff,"SERVER %s 1 :Jupe\n",token[4]);
#else
 sprintf(buff,"SERVER %s 1 %ld %ld P09 :Jupe\n",token[4],time(NULL),time(NULL));
#endif
 writeln(servsck,buff);
 sprintf(buff,"WALLOPS :%s is trying to JUPE %s\n",token[0],token[4]);
 writeln(servsck,buff);
}

do_operhelp(sck,level)
int sck;
int level;
{
 if(level<8) {
  sprintf(buff,":OperServ NOTICE %s :ACCESS DENIED - Did you validate?\n",token[0]);
  writeln(servsck,buff);
  return 0; }
 sprintf(buff,":OperServ NOTICE %s :Help on Opers and Services commands (level 8 MudBot's commands)\n",token[0]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ NOTICE %s :- gline [time in secs | -wildcard | -nick] <user@host> <reason>\n",token[0]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ NOTICE %s :- remgline <user@host>\n",token[0]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ NOTICE %s :- serverstats\n",token[0]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ NOTICE %s :- opcom <mode|kick> <command>\n",token[0]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ NOTICE %s :- lock/unlock <channel>\n",token[0]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ NOTICE %s :- operin <channel>\n",token[0]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ NOTICE %s :- clearchan <channel>\n",token[0]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ NOTICE %s :- jupe <server>\n",token[0]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ NOTICE %s :- jupenick <nick> [hostname]\n",token[0]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ NOTICE %s :- operjoin <channel>\n",token[0]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ NOTICE %s :- operpart <channel>\n",token[0]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ NOTICE %s :- wibble\n",token[0]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ NOTICE %s :- killservice\n",token[0]);
 writeln(servsck,buff);
 sprintf(buff,":OperServ NOTICE %s :- makeoperserv\n",token[0]);
 writeln(servsck,buff);
}

showver()
{
 printf("%d.%d\n",VERSION_MAJOR,VERSION_MINOR);
}

#ifdef SHARE_USERFILE

do_leaf(sck)
int sck;
{
 FILE *fp;
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !leaf <nick>\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :ATTENTION: This will erase the current user.file\n",token[0]);
  writeln(sck,buf);
  return 0; }
 sprintf(buf,"NOTICE %s :Deleting current user.file and awaiting for a share...\n",token[0]);
 writeln(sck,buf);
 fp=fopen(USERFILE,"w");
 fputs("",fp);
 if(fp!=NULL) fclose(fp);
 fp=fopen("temp.share","w");
 fputs(token[4],fp);
 if(fp!=NULL) fclose(fp);
}

do_share(sck)
int sck;
{
 FILE *fp;
 char temp[512];
 strcpy(temp,"");
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !share <nick>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 fp=fopen(USERFILE,"r");
 while(fgets(temp,255,fp)!=NULL) {
  sprintf(buf,"PRIVMSG %s :share-add %s dummy\n",token[4],temp);
  writeln(sck,buf); }
 if(fp!=NULL) fclose(fp);
 sprintf(buf,"NOTICE %s :Sent to %s\n",token[0],token[4]);
 writeln(sck,buf);
}

do_shared(sck)
int sck;
{
 FILE *fp;
 int z;
 char temp[512];
 strcpy(temp,"");
 fp=fopen("temp.share","r");
 fgets(temp,255,fp);
 if(cas_cmp(temp,token[0])) {
  sprintf(buf,"NOTICE %s :Wrong SHARE-ID (Type !leaf on the leaf bot)\n",token[0]);
  writeln(sck,buf);
  printf("*** Warning! Illegal share from %s\n",token[0]);
#ifdef REPORTS
  sprintf(buf,"PRIVMSG %s :Warning! Illegal share attempt from %s\n",REPORTS,token[0]);
  writeln(sck,buf);
#endif
  return 0; }
 if(fp!=NULL) fclose(fp);
 fp=fopen(USERFILE,"a");
 strcpy(temp,"");
 if(token[4]!=NULL) fputs(token[4],fp);
 fputs("\n",fp);
 if(fp!=NULL) fclose(fp);
}
#endif

#ifdef INTER_WEB
/* This was a real pain in the ass to do */
check_cgi(sck)
int sck;
{
 FILE *fp;
 int i,length,k,j=3;
 char file[255];
 char fromwhere[255];
 char temp[512];
 strcpy(temp,"");
 strcpy(file,PATH);
 strcat(file,"/writetext/temp.writetext");
 if((fp=fopen(file,"r"))==NULL) return 0;
 if(fgets(temp,255,fp)==NULL) { fclose(fp); return 0; }
 if(!cas_cmp(temp,"")) { fclose(fp); return 0; }
 length=strlen(temp);
 token[0]="inter_web";
 token[1]="PRIVMSG";
 temp[7]=' ';
 for(i=8;i<length;i++) if(temp[i]=='+') temp[i]=' ';
 token[i=2]=strtok(temp," ");
 while(token[++i]=strtok(NULL," ")); token[i]=NULL;
 *(token[i-1]+(strlen(token[i-1])-1))='\0';
 token[2]=BOTNAME;
 fgets(fromwhere,255,fp);
 if(fp!=NULL) fclose(fp);
 if((fp=fopen(file,"w"))!=NULL) fputs("",fp);
 if(fp!=NULL) fclose(fp);
 global_write_html=1;
 do_check_command(sck,lindex(fromwhere,0),-775); 
}
#endif

do_cryptpass(temp)
char temp[20];
{
 char salt[3];
 salt[0]=CRYPTA;
 salt[1]=CRYPTB;
 salt[2]='\0';
 return crypt(temp,salt);
}

report_clients(sck,stat)
int sck;
int stat;
{
 int i,j;
 char temp[512];
 strcpy(temp,"");
 j=chk_num(0);
 if(j>4)
 for(i=4;i<j;i++) {
  strcat(temp,token[i]);
  strcat(temp," "); }
 if(stat==0) {
  sprintf(buf,"PRIVMSG %s :[NAMES %s] %s\n",reports_names,token[2],temp);
  writeln(sck,buf); }
 if(stat==1) {
  sprintf(buf,"PRIVMSG %s :[NAMES %s] END OF LIST\n",reports_names,token[2]);
  writeln(sck,buf);
  sprintf(buf,"PART %s\n",reports_chan);
  writeln(sck,buf);
  strcpy(reports_names,"."); }
}

do_rep(sck)
int sck;
{
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !listnames <channel>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 strcpy(reports_names,token[2]);
 strcpy(reports_chan,token[4]);
 sprintf(buf,"JOIN %s\n",token[4]);
 writeln(sck,buf);
}

do_sa(sck)
int sck;
{
 FILE *fp;
 FILE *fpa;
 char temp[512];
 strcpy(temp,"");
 fpa=fopen("alias.file","r");
 while(fgets(temp,255,fpa)!=NULL) {
 fp=fopen(lindex(temp,0),"r");
 while(fgets(temp,255,fp)!=NULL) {
  if(!cas_cmp(lindex(temp,0),"on_connect")) {
   sprintf(buf,"NOTICE %s :ON: connect RAW: %s\n",token[0],lrange(temp,1));
   writeln(sck,buf); }
  if(!cas_cmp(lindex(temp,0),"on_word")) {
   sprintf(buf,"NOTICE %s :ON: word WORD: %s LEVEL: %s RAW: %s\n",token[0],lindex(temp,1),lindex(temp,2),lrange(temp,3));
   writeln(sck,buf); }
  if(!cas_cmp(lindex(temp,0),"on_join")) {
   sprintf(buf,"NOTICE %s :ON: join CHANNEL: %s RAW: %s\n",token[0],lindex(temp,1),lrange(temp,2));
   writeln(sck,buf); }
  if(!cas_cmp(lindex(temp,0),"on_part")) {
   sprintf(buf,"NOTICE %s :ON: part CHANNEL: %s RAW: %s\n",token[0],lindex(temp,1),lrange(temp,2));
   writeln(sck,buf); }
  if(!cas_cmp(lindex(temp,0),"on_quit")) {
   sprintf(buf,"NOTICE %s :ON: quit NICK: %s RAW: %s\n",token[0],lindex(temp,1),lrange(temp,2));
   writeln(sck,buf); }
  if(!cas_cmp(lindex(temp,0),"on_topic")) {
   sprintf(buf,"NOTICE %s :ON: topic RAW: %s\n",token[0],lrange(temp,1));
   writeln(sck,buf); }
  if(!cas_cmp(lindex(temp,0),"on_mode")) {
   sprintf(buf,"NOTICE %s :ON: mode CHANNEL: %s MODE: %s RAW: %s\n",token[0],lindex(temp,1),lindex(temp,2),lrange(temp,4));
   writeln(sck,buf); }
  if(!cas_cmp(lindex(temp,0),"on_botnick")) {
   sprintf(buf,"NOTICE %s :ON: botnick LEVEL: %s WORD: %s RAW: %s\n",token[0],lindex(temp,1),lindex(temp,2),lrange(temp,3));
   writeln(sck,buf); }
  if(!cas_cmp(lindex(temp,0),"on_numeric")) {
   sprintf(buf,"NOTICE %s :ON: numeric NUMERIC: %s RAW: %s\n",token[0],lindex(temp,1),lrange(temp,2)); 
   writeln(sck,buf); }
  if(!cas_cmp(lindex(temp,0),"on_kick")) {
   sprintf(buf,"NOTICE %s :ON: kick CHANNEL: %s RAW: %s\n",token[0],lindex(temp,1),lrange(temp,2));
   writeln(sck,buf); }
 }
if(fp!=NULL) fclose(fp);
}
if(fpa!=NULL) fclose(fpa);
}

do_operjoin(sck)
int sck;
{
 if(token[4]==NULL) return 0;
 sprintf(buff,":OperServ JOIN %s\n",token[4]);
 writeln(servsck,buff);
}

do_operpart(sck)
int sck;
{
 if(token[4]==NULL) return 0;
 sprintf(buff,":OperServ PART %s\n",token[4]);
 writeln(servsck,buff);
}

do_wibble(sck)
int sck;
{
 sprintf(buff,"WALLOPS :*wibble*\n");
 writeln(servsck,buff);
}

do_insult(sck)
int sck;
{
 int i;
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !insult <nick>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 srandom(time(NULL));
 i=(random() % 9);
 if(i<1) {
  sprintf(buf,"PRIVMSG %s :Why don't you go see your momma and come back right after? I'll still be here!\n",token[4]);
  writeln(sck,buf); }
 else if(i==1) {
  sprintf(buf,"PRIVMSG %s :Go ahead! Call me names! But I warn you I'm the best at these games\n",token[4]);
  writeln(sck,buf); }
 else if(i==2) {
  sprintf(buf,"PRIVMSG %s :Your momma's so ugly that.... uh.. that... Come back in an hour and I'll tell you\n",token[4]);
  writeln(sck,buf); }
 else if(i==3) {
  sprintf(buf,"PRIVMSG %s :BOO! Did I scare you ?? uh? Did I ??\n",token[4]);
  writeln(sck,buf); }
 else if(i==4) {
  sprintf(buf,"PRIVMSG %s :Go in the toilet and see if I'm there\n",token[4]);
  writeln(sck,buf); }
 else if(i==5) {
  sprintf(buf,"PRIVMSG %s :Hey you! You think I'm a bot uh?? uhm... Well you're right\n",token[4]);
  writeln(sck,buf); }
 else if(i==6) {
  sprintf(buf,"PRIVMSG %s :You suck! ahhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh... That felt good...\n",token[4]);
  writeln(sck,buf); }
 else if(i==7) {
  sprintf(buf,"PRIVMSG %s :Go see in #!!!!!!!!pickup_bots_and_bots_sex if I'm there...\n",token[4]);
  writeln(sck,buf); }
 else {
  sprintf(buf,"PRIVMSG %s :Hey you! I got something for you! Did you eat yet?? oh.. you did... nevermind then......\n",token[4]);
  writeln(sck,buf); }
}

chk_config(type)
int type;
{
FILE *fpa;
char temp[255];
 if(chdir(PATH)) printf("ERROR path is not valid!\n");
 printf("\nChecking config options...\n");
#ifdef TERMINAL
 printf("terminal... on\n");
#else
 printf("terminal... off\n");
#endif
#ifdef BACKGROUND
 printf("background... on\n");
#else
 printf("background... off\n");
#endif
#ifdef UMODES
 if(cas_cmp(UMODES,"")) printf("umodes... %s\n",UMODES);
 else printf("umodes... ERROR no umodes defined!\n");
#else
 printf("umodes... ERROR no umodes defined!\n");
#endif
#ifdef ACCOUNTNAME
 if(cas_cmp(ACCOUNTNAME,"")) printf("account name... %s\n",ACCOUNTNAME);
 else printf("account name... ERROR no accountname defined!\n");
#else
 printf("account name... WARNING no accountname defined!\n");
#endif
#ifdef REPORTS
 if(cas_cmp(REPORTS,"")) printf("main channel... %s\n",REPORTS);
 else printf("main channel... ERROR no main channel defined!\n");
#else
 printf("main channel... WARNING no main channel defined!\n");
#endif
#ifdef PATH
 if(cas_cmp(PATH,"")) printf("path... %s\n",PATH);
 else printf("path... ERROR no path defined!\n");
 if(*PATH=='~') printf("WARNING path is not in full-path format!\n");
#else
 printf("path... ERROR no path defined!\n");
#endif
#ifdef DEFAULTPORT
 printf("port... %d\n",DEFAULTPORT);
 if(DEFAULTPORT < 0) printf("WARNING port is not valid!\n");
 if(DEFAULTPORT > 12000) printf("WARNING port is not valid!\n");
#else
 printf("port... ERROR no port defined!\n");
#endif
#ifdef BOTNAME
 if(cas_cmp(BOTNAME,"")) printf("bot nick... %s\n",BOTNAME);
 else printf("bot nick... ERROR no bot nick defined!\n");
#else
 printf("bot nick... ERROR no bot nick defined!\n");
#endif
#ifndef USERFILE
 printf("ERROR no user file defined!\n");
#endif
 fpa=fopen(USERFILE,"r");
 fgets(temp,255,fpa);
 if(!cas_cmp(temp,"")) printf("ERROR user file is empty!\n");
 fclose(fpa);
 fpa=fopen("channels.file","r");
 fgets(temp,255,fpa);
 if(!cas_cmp(temp,"")) printf("ERROR channels file empty!\n");
 fclose (fpa);
 printf("Check completed.\n"); 
}

chanserv_read(sck)
int sck;
{
 int i;
 if(!cas_cmp(lindex(chanbuf,0),"ERROR")) {
 if(!cas_cmp(lindex(chanbuf,1),":Closing")) {
  printf("Error linking Channel Service: %s\n",chanbuf); } }
 sprintf(bufc,"PONG :%s\n",CHANSERV_UPLINK);
 writeln(chansck,bufc);
#ifdef CHANSERV_TERMINAL
 printf("[CHANSERV] %s\n",chanbuf);
#endif
 for(i=0;lindex(chanbuf,i)!=NULL;i++) {
  if(!cas_cmp(lindex(chanbuf,i),"367")) {
   i=i+3;
   sprintf(bufc,":ChanServ NOTICE %s :- %s\n",banlist_nick,lindex(chanbuf,i));
   writeln(chansck,bufc); } }
}

#ifdef CHANSERV
chanserv(sck,level,fromhost)
int sck;
int level;
char *fromhost;
{
 FILE *fp;
 FILE *fpa;
 int l;
 char temp[255];
 char temp2[255];
 char temp_nick[100];
 char temp_pass[100]="dummy";
 char temp_mail[100];
 if(token[4]==NULL) {
  sprintf(bufc,":ChanServ NOTICE %s :Unknown command. Try %cchanserv help\n",token[0],CMDCHAR);
  writeln(chansck,bufc);
  return 0; }

 if(!cas_cmp(token[4],"help")) {
  sprintf(bufc,":ChanServ NOTICE %s :Help for ChanServ.\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv chaninfo <channel>\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv info\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :Commands available to you as a channel founder:\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv op <password> <channel> <nick>\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv deop <password> <channel> <nick>\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv mode <password> <channel> <mode> [arg]\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv banlist <password> <channel>\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv clearmodes <password> <channel>\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv adduser <your password> <channel> <nick> <user@host> <password> <email>\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv deluser <password> <channel> <nick>\n",token[0]);
  writeln(chansck,bufc);
 if(level>6) {
  sprintf(bufc,":ChanServ NOTICE %s :ChanServ Admins commands:\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv makechanserv\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv register <channel> <nick> <user@host> <password> <email>\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv purge <channel>\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv addhost <channel> <user@host>\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv reop <channel>\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv join <channel>\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv part <channel>\n",token[0]);
  writeln(chansck,bufc);
  sprintf(bufc,":ChanServ NOTICE %s :chanserv lock <channel>\n",token[0]);
  writeln(chansck,bufc); } }

 if(!cas_cmp(token[4],"info")) {
  sprintf(bufc,":ChanServ NOTICE %s :MudBot's ChanServ - made by Drow (drow@wildstar.net)\n",token[0]);
  writeln(chansck,bufc);
  fpa=fopen("chanserv.file","r");
  l=0;
  while(fgets(temp,255,fpa)!=NULL) l++;
  if(fpa!=NULL) fclose(fpa);
  sprintf(bufc,":ChanServ NOTICE %s :Total users in database: %d\n",token[0],l);
  writeln(chansck,bufc); }

 if(!cas_cmp(token[4],"join")) {
  if(level>6) {
   sprintf(bufc,":ChanServ JOIN %s\n",token[5]);
   writeln(chansck,bufc); } }

 if(!cas_cmp(token[4],"part")) {
  if(level>6) {
   sprintf(bufc,":ChanServ PART %s\n",token[5]);
   writeln(chansck,bufc); } }

 if(!cas_cmp(token[4],"deluser")) {
  if(token[5]==NULL || token[6]==NULL || token[7]==NULL) {
   sprintf(bufc,":ChanServ NOTICE %s :Syntax: deluser <password> <channel> <nick>\n",token[0]);
   writeln(chansck,bufc);
   return 0; }
  fp=fopen("chanserv.file","r");
  while(fgets(temp,255,fp)!=NULL) {
   if(!cas_cmp(lindex(temp,0),token[6])) {
    if(!match(lindex(temp,2),fromhost)) {
     if(!cas_cmp(lindex(temp,5),"1"))
     if(!cas_cmp(lindex(temp,3),do_cryptpass(token[5]))) {
      if(fp!=NULL) fclose(fp);
      fp=fopen("chanserv.file","r");
      fpa=fopen("chanserv.new","w");
      while(fgets(temp,255,fp)!=NULL) {
       if(!cas_cmp(lindex(temp,0),token[6])) {
        if(cas_cmp(lindex(temp,1),token[7])) { fputs(temp,fpa); } }
       if(cas_cmp(lindex(temp,0),token[6])) fputs(temp,fpa); }
      if(fpa!=NULL) fclose(fpa); 
      if(fp!=NULL) fclose(fp);
      system("mv chanserv.new chanserv.file");
      return 0; } } } }
  if(fp!=NULL) fclose(fp); }

 if(!cas_cmp(token[4],"addhost")) {
  if(level>6) {
   if(token[5]==NULL || token[6]==NULL) {
    sprintf(bufc,":ChanServ NOTICE %s :Syntax: addhost <channel> <user@host>\n",token[0]);
    writeln(chansck,bufc);
    return 0; }
   fp=fopen("chanserv.file","r");
   while(fgets(temp,255,fp)!=NULL) {
    if(!cas_cmp(lindex(temp,0),token[5])) {
     strcpy(temp_nick,lindex(temp,1));
     strcpy(temp_pass,lindex(temp,3));
     strcpy(temp_mail,lindex(temp,4)); } }
   if(fp!=NULL) fclose(fp);
   if(cas_cmp(temp_pass,"dummy")) {
    fp=fopen("chanserv.file","a");
    strcpy(temp,"");
    sprintf(temp,"%s %s %s %s %s dummy\n",token[5],temp_nick,token[6],temp_pass,temp_mail);
    fputs(temp,fp);
    if(fp!=NULL) fclose(fp);
    sprintf(bufc,":ChanServ NOTICE %s :Adding...\n",token[0]);
    writeln(chansck,bufc); }
   else {
    sprintf(bufc,":ChanServ NOTICE %s :No match found.\n",token[0]);
    writeln(chansck,bufc); } } }

 if(!cas_cmp(token[4],"register")) {
  if(level>6) {
   if(token[5]==NULL || token[6]==NULL || token[7]==NULL || token[8]==NULL || token[9]==NULL) {
    sprintf(bufc,":ChanServ NOTICE %s :Syntax: register <channel> <nick> <user@host> <password> <email>\n",token[0]);
    writeln(chansck,bufc);
    return 0; }
   fp=fopen("chanserv.file","r");
   while(fgets(temp,255,fp)!=NULL) {
    if(!cas_cmp(lindex(temp,0),token[5])) {
     sprintf(bufc,":ChanServ NOTICE %s :Channel already in the list!\n",token[0]);
     writeln(chansck,bufc);
     if(fp!=NULL) fclose(fp);
     return 0; } }
   if(fp!=NULL) fclose(fp);
   sprintf(bufc,":ChanServ NOTICE %s :Adding...\n",token[0]);
   writeln(chansck,bufc);
#ifdef REPORTS
   sprintf(bufc,"999 %s :[ChanServ] %s adding %s\n",REPORTS,token[0],token[5]);
   writeln(chansck,bufc);
#endif
   fp=fopen("chanserv.file","a");
   fputs(token[5],fp);
   fputs(" ",fp);
   fputs(token[6],fp);
   fputs(" ",fp);
   fputs(token[7],fp);
   fputs(" ",fp);
   fputs(do_cryptpass(token[8]),fp);
   fputs(" ",fp);
   fputs(token[9],fp);
   fputs(" 1 dummy\n",fp);
   sprintf(bufc,":ChanServ JOIN %s\n",token[5]);
   writeln(chansck,bufc);
   sprintf(bufc,"MODE %s +to ChanServ\n",token[5]);
   writeln(chansck,bufc);
   if(fp!=NULL) fclose(fp); } }

 if(!cas_cmp(token[4],"reop")) {
  if(level>6) {
   if(token[5]==NULL) {
    sprintf(bufc,":ChanServ NOTICE %s :Syntax: reop <channel>\n",token[0]);
    writeln(chansck,bufc);
    return 0; }
#ifdef REPORTS
   sprintf(bufc,"999 %s :[ChanServ] %s op %s\n",REPORTS,token[0],token[5]);
   writeln(chansck,bufc);
#endif
   sprintf(bufc,"MODE %s +o %s\n",token[5],token[0]);
   writeln(chansck,bufc); } }

 if(!cas_cmp(token[4],"lock")) {
  if(level>6) {
   if(token[5]==NULL) {
    sprintf(bufc,":ChanServ NOTICE %s :Syntax: lock <channel>\n",token[0]);
    writeln(chansck,bufc);
    return 0; }
   sprintf(bufc,":ChanServ JOIN %s\n",token[5]);
   writeln(chansck,bufc);
   sprintf(bufc,"MODE %s +mntio ChanServ\n",token[5]);
   writeln(chansck,bufc);
#ifdef REPORTS
   sprintf(bufc,"999 %s :[ChanServ] %s locking %s\n",REPORTS,token[0],token[5]);
   writeln(chansck,bufc);
#endif
 } }

 if(!cas_cmp(token[4],"mode")) {
  fp=fopen("chanserv.file","r"); 
  if(token[5]==NULL || token[6]==NULL || token[7]==NULL) {
   sprintf(bufc,":ChanServ NOTICE %s :Syntax: mode <password> <channel> <mode> [arg]\n",token[0]);
   writeln(chansck,bufc);
   if(fp!=NULL) fclose(fp);
   return 0; }
  while(fgets(temp,255,fp)!=NULL) {
   if(!match(lindex(temp,2),fromhost))
   if(!cas_cmp(lindex(temp,3),do_cryptpass(token[5]))) {
    if(!cas_cmp(lindex(temp,0),token[6])) {
     if(token[8]!=NULL) sprintf(bufc,":ChanServ MODE %s %s %s\n",token[6],token[7],token[8]);
     if(token[8]==NULL) sprintf(bufc,":ChanServ MODE %s %s\n",token[6],token[7]);
     writeln(chansck,bufc); } } }
  if(fp!=NULL) fclose(fp); }

 if(!cas_cmp(token[4],"banlist")) {
  fp=fopen("chanserv.file","r"); 
  if(token[5]==NULL || token[6]==NULL) {
   sprintf(bufc,":ChanServ NOTICE %s :Syntax: banlist <password> <channel>\n",token[0]);
   writeln(chansck,bufc);
   if(fp!=NULL) fclose(fp);
   return 0; }
  while(fgets(temp,255,fp)!=NULL) {
   if(!match(lindex(temp,2),fromhost))
   if(!cas_cmp(lindex(temp,3),do_cryptpass(token[5]))) {
    if(!cas_cmp(lindex(temp,0),token[6])) {
     strcpy(banlist_nick,token[0]);
     sprintf(bufc,":ChanServ MODE %s b\n",token[6]);
     writeln(chansck,bufc); } } }  
  if(fp!=NULL) fclose(fp); }


 if(!cas_cmp(token[4],"op")) {
  fp=fopen("chanserv.file","r");
  if(token[5]==NULL || token[6]==NULL || token[7]==NULL) {
   sprintf(bufc,":ChanServ NOTICE %s :Syntax: op <password> <channel> <nick>\n",token[0]);
   writeln(chansck,bufc);
   if(fp!=NULL) fclose(fp);
   return 0; }
  while(fgets(temp,255,fp)!=NULL) {
   if(!match(lindex(temp,2),fromhost))
   if(!cas_cmp(lindex(temp,3),do_cryptpass(token[5]))) {
    if(!cas_cmp(lindex(temp,0),token[6])) {
     sprintf(bufc,":ChanServ MODE %s +o %s\n",token[6],token[7]);
     writeln(chansck,bufc); } } }
  if(fp!=NULL) fclose(fp); }

 if(!cas_cmp(token[4],"deop")) {
  fp=fopen("chanserv.file","r"); 
  if(token[5]==NULL || token[6]==NULL || token[7]==NULL) {
   sprintf(bufc,":ChanServ NOTICE %s :Syntax: op <password> <channel> <nick>\n",token[0]);
   writeln(chansck,bufc);
   if(fp!=NULL) fclose(fp);
   return 0; }
  while(fgets(temp,255,fp)!=NULL) {
   if(!match(lindex(temp,2),fromhost))
   if(!cas_cmp(lindex(temp,3),do_cryptpass(token[5]))) {
    if(!cas_cmp(lindex(temp,0),token[6])) {
     sprintf(bufc,":ChanServ MODE %s -o %s\n",token[6],token[7]);
     writeln(chansck,bufc); } } }  
  if(fp!=NULL) fclose(fp); }

 if(!cas_cmp(token[4],"clearmodes")) {
  fp=fopen("chanserv.file","r");
  if(token[5]==NULL || token[6]==NULL) {
   sprintf(bufc,":ChanServ NOTICE %s :Syntax: clearmodes <password> <channel>\n",token[0]);
   writeln(chansck,bufc);
   if(fp!=NULL) fclose(fp);
   return 0; }
  while(fgets(temp,255,fp)!=NULL) {
   if(!match(lindex(temp,2),fromhost))
   if(!cas_cmp(lindex(temp,3),do_cryptpass(token[5]))) {
    if(!cas_cmp(lindex(temp,0),token[6])) {
     if(!cas_cmp(lindex(temp,5),"1")) {
      sprintf(bufc,"MODE %s -ntmipslk *\n",token[6]);
      writeln(chansck,bufc); } } } }
  if(fp!=NULL) fclose(fp); }

 if(!cas_cmp(token[4],"adduser")) {
  if(token[5]==NULL || token[6]==NULL || token[7]==NULL || token[8]==NULL || token[9]==NULL || token[10]==NULL) {
   sprintf(bufc,":ChanServ NOTICE %s :Syntax: adduser <your pass> <channel> <nick> <user@host> <password> <email>\n",token[0]);
   writeln(chansck,bufc);
   return 0; }
  fp=fopen("chanserv.file","r");
  while(fgets(temp,255,fp)!=NULL) {
   if(!match(lindex(temp,2),fromhost)) {
    if(!cas_cmp(lindex(temp,3),do_cryptpass(token[5]))) {
     if(!cas_cmp(lindex(temp,0),token[6])) {
      if(!cas_cmp(lindex(temp,5),"1")) {
       if(fp!=NULL) fclose(fp);
       fp=fopen("chanserv.file","a");
       sprintf(temp,"%s %s %s %s %s 0 dummy\n",token[6],token[7],token[8],do_cryptpass(token[9]),token[10]);
       fputs(temp,fp);
       sprintf(bufc,":ChanServ NOTICE %s :Adding %s to %s\n",token[0],token[7],token[6]);
       writeln(chansck,bufc); } } } } }
  if(fp!=NULL) fclose(fp); }

 if(!cas_cmp(token[4],"chaninfo")) {
  if(token[5]==NULL) {
   sprintf(bufc,":ChanServ NOTICE %s :Syntax: chaninfo <channel>\n",token[0]);
   writeln(chansck,bufc);
   return 0; }
  fp=fopen("chanserv.file","r");
  sprintf(bufc,":ChanServ NOTICE %s :Searching match for %s\n",token[0],token[5]);
  writeln(chansck,bufc);
  while(fgets(temp,255,fp)!=NULL) {
   if(token[5]!=NULL) {
    if(!cas_cmp(lindex(temp,0),token[5])) {
     if(!cas_cmp(lindex(temp,5),"1"))
      sprintf(bufc,":ChanServ NOTICE %s :%s is registered by %s!%s [%s] [FOUNDER]\n",token[0],lindex(temp,0),lindex(temp,1),lindex(temp,2),lindex(temp,4));
     else
      sprintf(bufc,":ChanServ NOTICE %s :%s is registered by %s!%s [%s] [USER]\n",token[0],lindex(temp,0),lindex(temp,1),lindex(temp,2),lindex(temp,4));
      writeln(chansck,bufc); } } }
  if(fp!=NULL) fclose(fp); }

 if(!cas_cmp(token[4],"makechanserv")) {
  if(level>6) {
#ifdef IRCU_2_10
   sprintf(bufc,"NICK ChanServ 1 1 ChanServ %s %s :Channel Service\n",CHANSERV_SERVER_NAME,CHANSERV_SERVER_NAME);
#else
   sprintf(bufc,"NICK ChanServ 1 1 ChanServ %s :Channel Service\n",CHANSERV_SERVER_NAME);
#endif
   writeln(chansck,bufc);
   sprintf(bufc,":ChanServ MODE ChanServ +k\n");
   writeln(chansck,bufc); } }

 if(!cas_cmp(token[4],"purge")) {
  if(level>6) {
   fp=fopen("chanserv.file","r");
   fpa=fopen("chanserv.new","w");
   while(fgets(temp,255,fp)!=NULL) {
    if(cas_cmp(lindex(temp,0),token[5])) {
     fputs(temp,fpa);
     fputs("\n",fpa); } }
  if(fp!=NULL) fclose(fp);
  if(fpa!=NULL) fclose(fpa);
#ifdef REPORTS
  sprintf(bufc,"999 %s :[ChanServ] %s purging %s\n",REPORTS,token[0],token[5]);
  writeln(chansck,bufc);
#endif
  sprintf(bufc,":ChanServ PART %s\n",token[5]);
  writeln(chansck,bufc);
  system("mv chanserv.new chanserv.file \n"); } }
}
#endif

do_sv(sck)
int sck;
{
 sprintf(buf,"PRIVMSG %s :MudBot v%d.%d by Drow <drow@wildstar.net>\n",token[2],VERSION_MAJOR,VERSION_MINOR);
 writeln(sck,buf);
}

chk_uptime()
{
 FILE *fpp;
 char temp[256];
 fpp=fopen("uptime.file","r");
 if(fgets(temp,255,fpp)!=NULL) {
  if(temp[0]=='0') {
   printf("\n\nMudBot has detected this is the first time you run this bot. When the bot is connected, you can go on IRC and /msg %s %cvalidate <your password>\n",BOTNAME,CMDCHAR);
   printf("You might also want to subscribe to the MudBot mailing list... See the README for how to subscribe\n\n"); }
 }
 if(fpp!=NULL) fclose(fpp);
}

do_addtimer(sck)
int sck;
{
 int i;
 unsigned long blah;
 if(token[4]==NULL || token[5]==NULL || token[6]==NULL || atoi(token[4])==0) {
  sprintf(buf,"NOTICE %s :Syntax: !addtimer <timer number (1 to 199)> <in how many secs> <raw command>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 blah=(time(NULL)+atol(token[5]));
 sprintf(timers[atoi(token[4])],"%ld",blah);
 for(i=6;token[i]!=NULL;i++) {
  strcat(timers[atoi(token[4])]," ");
  strcat(timers[atoi(token[4])],token[i]); }
 sprintf(buf,"NOTICE %s :Adding timer %d\n",token[0],atoi(token[4]));
 writeln(sck,buf); 
}

do_showtimers(sck)
int sck;
{
 int i;
 for(i=0;i<200;i++) {
  if(cas_cmp(timers[i],"")) {
   sprintf(buf,"NOTICE %s :Timer %d should run '%s' at %s (in %ld secs)\n",token[0],i,lrange(timers[i],1),lindex(timers[i],0),(atol(lindex(timers[i],0))-time(NULL)));
   writeln(sck,buf); } }
}

do_deltimer(sck)
int sck;
{
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !deltimer <timer number>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 strcpy(timers[atoi(token[4])],"");
}

check_timers(sck)
int sck;
{
 int i;
 for(i=0;i<200;i++) {
  if(cas_cmp(timers[i],"")) {
   if(atol(lindex(timers[i],0))<time(NULL)) {
    sprintf(buf,"%s\n",lrange(timers[i],1));
    writeln(sck,buf);
    strcpy(timers[i],""); } } }
}

do_netblock(sck)
int sck;
{
 int i;
 FILE *fp;
 char temp[255];
 char temp2[255];
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !netblock <ip.ip.ip>\n",token[0]);
  writeln(sck,buf); 
  return 0; }
 for(i=0;*(token[4]+i)!=NULL;i++) { }
 if(*(token[4]+(i-1))=='*' || *(token[4]+(i-1))=='.') {
  sprintf(buf,"NOTICE %s :Netblock must be ip.ip.ip with no trailing '.' or '.*'\n",token[0]);
  writeln(sck,buf);
  return 0; }
 sprintf(buf,"NOTICE %s :Listing hosts for netblock %s.0. It may take a while.\n",token[0],token[4]);
 writeln(sck,buf);
 system("echo Listing Hosts > netblock.temp");
 for(i=1;i<256;i++) {
  sprintf(temp,"host %s.%d >> netblock.temp 2> /dev/null",token[4],i);
  system(temp); }
 sleep(1);
 fp=fopen("netblock.temp","r");
 while(fgets(temp,255,fp)!=NULL) {
  if(*temp==NULL) break;
  if(!cas_cmp(lindex(temp,0),"Name:")) {
   sprintf(temp2,"NOTICE %s :%s",token[0],lindex(temp,1));
   sprintf(buf,"%s\n",temp2);
   sleep(1);
   writeln(sck,buf); } 
  if(!cas_cmp(lindex(temp,0),"Aliases:")) {
   sprintf(temp2,"NOTICE %s :%s",token[0],lindex(temp,1));
   sprintf(buf,"%s\n",temp2);
   writeln(sck,buf); } }
 if(fp!=NULL) fclose(fp);
}

do_operstats(sck)
int sck;
{
#ifdef SERVICE
 FILE *fp;
 int i=0,min=9999999,max=0,count=0,total,total_r;
 char temp[255];
 fp=fopen(".operserv.stats","r");
 while(fgets(temp,255,fp)!=NULL) {
  if(atoi(lindex(temp,0))<min) min=atoi(lindex(temp,0));
  if(atoi(lindex(temp,0))>max) max=atoi(lindex(temp,0));
  i=i+atoi(lindex(temp,0)); 
  count++; }
 total=i/count;
 total_r=i%count;
 sprintf(buff,":OperServ NOTICE %s :Server stats: On %d requests (%d in this session), min user count: %d max user count: %d avg: %d.%d\n",token[0],count,global_stats_lines,min,max,total,total_r); 
 writeln(servsck,buff);
 if(fp!=NULL) fclose(fp);
#endif 
}

do_scan(sck)
int sck;
{
 FILE *fp;
 char temp[255];
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !scan <masked nick!user@host>   See the README for more\n",token[0]);
  writeln(sck,buf);
  return 0; }
 fp=fopen("scan.results","r");
 while(fgets(temp,255,fp)!=NULL) {
  if(!match(token[4],lindex(temp,0))) {
   sprintf(buf,"NOTICE %s %s was seen at %d in %s\n",token[0],lindex(temp,0),atol(lindex(temp,1)),lindex(temp,2));
   writeln(sck,buf); } }
 if(fp!=NULL) fclose(fp);
}

do_addscan(sck)
int sck;
{
 FILE *fp;
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !addscan <masked nick!user@host>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 fp=fopen("scan.file","a");
 fputs(token[4],fp);
 fputs(" 0\n",fp);
 if(fp!=NULL) fclose(fp);
 sprintf(buf,"NOTICE %s :Adding...\n",token[0]);
 writeln(sck,buf);
}

do_clearscan(sck)
int sck;
{
 FILE *fp;
 fp=fopen("scan.file","w");
 fclose(fp);
 sprintf(buf,"NOTICE %s :Clearing scan.file\n",token[0]);
 writeln(sck,buf);
}

do_jupenick(sck)
int sck;
{
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !jupenick <nick> [hostname]\n",token[0]);
  writeln(sck,buf);
  return 0; }
 sprintf(buff,":OperServ KILL %s :Juping nick requested by %s\n",token[4],token[0]);
 writeln(servsck,buff);
 if(token[5]==NULL) {
#ifndef IRCU_2_10
  sprintf(buff,"NICK %s 1 1 Jupe %s :Jupe\n",token[4],SERVICE_SERVER_NAME);
#else
  sprintf(buff,"NICK %s 1 1 Jupe %s %s :Jupe\n",token[4],SERVICE_SERVER_NAME,SERVICE_SERVER_NAME);
#endif
 }
 else {
#ifndef IRCU_2_10
  sprintf(buff,"NICK %s 1 1 Jupe %s :Jupe\n",token[4],token[5]);
#else
  sprintf(buff,"NICK %s 1 1 Jupe %s :Jupe\n",token[4],token[5]);
#endif
 } 
 writeln(servsck,buff);
}

do_update(sck)
int sck;
{
 int tempfd,i,length;
 char tempbuf[516];
 sprintf(buf,"NOTICE %s :Fetching update information from mudbot.darkelf.net\n",token[0]);
 writeln(sck,buf);
 for(i=1;i < 10;i++)
 {
  tempfd=update_socket("205.237.65.199",1044,sck);
  if(tempfd==-1) continue;
  else break;
 }
 strcpy(tempbuf,"dummy");
 if((length=read(tempfd,tempbuf,512))<1)
 {
  if(errno==EWOULDBLOCK || errno==EAGAIN) {
   sprintf(buf,"NOTICE %s :ERROR in getting update info from server: Please try again.\n",token[0]);
   writeln(sck,buf);
   return 0; }
  else {
   sprintf(buf,"NOTICE %s :ERROR in getting update info from server: Server is not responding. Try again later.\n",token[0]);
   writeln(sck,buf);
   return 0; }
  }
 tempbuf[length]='\0';
 sprintf(buf,"NOTICE %s :This bot is a MudBot version %d.%d. Current MudBot version from http://mudbot.darkelf.net is %s.%s.\n",token[0],VERSION_MAJOR,VERSION_MINOR,lindex(tempbuf,0),lindex(tempbuf,1));
 writeln(sck,buf);
 close(tempfd);
}

do_cset(sck)
int sck;
{
 FILE *fpa;
 FILE *fpb;
 int i;
 char temp[255];
 if(token[4]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !cset <channel> [<modes> <topic>]\n",token[0]);
  writeln(sck,buf);
  sprintf(buf,"NOTICE %s :Use !cset <channel> to remove a channel from cset list\n",token[0]);
  writeln(sck,buf);
  return 0; }
 fpa=fopen("cset.file","r");
 fpb=fopen("cset.new","w");
 while(fgets(temp,255,fpa)!=NULL)
  if(cas_cmp(lindex(temp,0),token[4])) fputs(temp,fpb);
 if(fpa!=NULL) fclose(fpa);
 sprintf(buf,"NOTICE %s :Setting CSET for channel %s\n",token[0],token[4]);
 writeln(sck,buf);
 if(token[5]==NULL || token[6]==NULL) { 
  if(fpb!=NULL) fclose(fpb); 
  system("mv cset.new cset.file");
  return 0; }
 sprintf(temp,"%s %s",token[4],token[5]);
 for(i=6;token[i]!=NULL;i++) {
  strcat(temp," ");
  strcat(temp,token[i]); }
 fputs(temp,fpb);
 fputs("\n",fpb);
 if(fpb!=NULL) fclose(fpb);
 system("mv cset.new cset.file");
}

do_finger(sck)
int sck;
{
 FILE *fp;
 char temp[512];
 if(token[4]==NULL || token[5]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !finger <user> <hostname>\n",token[0]);
  writeln(sck,buf);
  return 0; }
 sprintf(temp,"finger %s@%s > temp.finger 2> temp.finger",token[4],token[5]);
 system(temp);
 sleep(1);
 fp=fopen("temp.finger","r");
 while(fgets(temp,512,fp)!=NULL) {
  sprintf(buf,"NOTICE %s :[FINGER] %s\n",token[0],temp);
  writeln(sck,buf); }
 if(fp!=NULL) fclose(fp);
}
