#include <stdio.h>
#include "config.h"

/* writetext.c                   (C) 1997 Drow <drow@wildstar.net> */

main() 
{
 FILE *fp;
 char temp[255];
 char DATA[100]="";
 int i;
 double length=0;
 char * method;
 char * str_len;
 method = getenv("REQUEST_METHOD");
 if(strcmp(method,"POST")!=0) return 0;
 str_len = getenv("CONTENT_LENGTH");
 if(str_len!=NULL) length=atoi(str_len);
 for(i=0;i<length;i++) DATA[i]=fgetc(stdin);
 printf("Content-type: text/html\n\n");
 printf("%s sent to the bot.\n",DATA);
 printf("<br>Wait a few seconds, click on back, then goto 'Results' to see what the bot had to say. Of course there will be no result if the bot is offline or if you sent an invalid command.<br>\n");
 strcpy(temp,PATH);
 strcat(temp,"/writetext/temp.writetext");
 if((fp=fopen(temp,"w"))==NULL) exit(0);
 fputs(DATA,fp);
 fputs("\n",fp);
 fputs(getenv("REMOTE_HOST"),fp);
 fputs(" weeee \n",fp);
 fclose(fp);
 strcpy(temp,"chmod 777 ");
 strcat(temp,PATH);
 strcat(temp,"/writetext/temp.writetext\n");
 system(temp); 
}
