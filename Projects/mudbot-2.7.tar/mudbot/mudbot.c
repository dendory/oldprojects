#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "config.h"
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>
/* mudbot.c
**      The socket's core of this code has been made by wildthang
**      <danny@wildstar.net>. You can modify it but not distribute it
**      modified. This file is part of MudBot and is (C) 1997 by Drow
**      <drow@wildstar.net> All rights reserved.    
*/

int startup=1;

/* botsck[] is the socket descriptor */
int botsck[1],CONNECT=0,ROUND_TIME=7;
int servsck[1];
int chansck[1];
int botstat[1];
int signal_max_count=0;
long starttime=783665823,NOW;
char sockbuf[522],*token[256],buf[522],*linetok[256],ltok[256][30],defchan[512];
char chanbuf[522],bufc[522],servbuf[522],buff[522];
char *servtok[256];
char global_buf[512];
char input_buffer[1][200000],*input_start,*input_end;
int toks=0;
int service_off;
FILE *dumpfile=NULL;

main(int argc, char *argv[])
{ int i,res,pidnumb,pid;
   char temp[255];
   char temp2[255];
   FILE *fppid,*fddump;
   printf("Starting MudBot by Drow <drow@wildstar.net>\n");
#ifdef CHECK_ROOT
   if(getuid()==0) { printf("Do not run the bot as root!\n"); exit(0); }
#endif
#ifdef MAX_CONNECT_COUNT
   fddump=fopen(".connect.count","r");
   fgets(temp,255,fddump);
   if(lindex(temp,0)!=NULL) {
    if(atoi(lindex(temp,0))>MAX_CONNECT_COUNT) {
     printf("*** Max connect count reached. Aborting....\n");
     if(fddump!=NULL) fclose(fddump);
     fddump=fopen(".connect.count","w");
     fputs("0 0\n",fddump);
     if(fddump!=NULL) fclose(fddump);
     exit(0); }
    if(fddump!=NULL) fclose(fddump);
    fddump=fopen(".connect.count","w");
    sprintf(temp2,"%d 0\n",(atoi(lindex(temp,0))+1));
    fputs(temp2,fddump); }
   if(fddump!=NULL) fclose(fddump);
#endif
   if(argc==2) {
    if(!cas_cmp(argv[1],"-h")) {
     printf("This bot is (C) 1997 by Patrick Lambert (Drow) - See the README file\n");
     printf("Syntax: mudbot [-hvcf | <server name> <port>]\n");
     exit(0); }
    else if(!cas_cmp(argv[1],"--help")) {
     printf("This bot is (C) 1997 by Patrick Lambert (Drow) - See the README file\n");
     printf("Syntax: mudbot [-hfvc | <server name> <port>]\n");
     exit(0); }
    else if(!cas_cmp(argv[1],"-v")) {
     showver();
     exit(0); }
    else if(!cas_cmp(argv[1],"--version")) {
     showver();
     exit(0); }
    else if(!cas_cmp(argv[1],"-f")) {
     printf("Redirecting to file\n");
     freopen("output.file","w",stdout); }
    else if(!cas_cmp(argv[1],"-c")) {
     chk_config(0);
     exit(0); }
    else if(!cas_cmp(argv[1],"--check")) {
     chk_config(0);
     exit(0); }
    else printf("Unknown command: %s\n",argv[1]);
   }
   if (chdir(PATH))
   {
    printf("*** Cannot run chdir\n");
#ifdef LOGERRORS
    logerr("Cannot run chdir");
#endif
   }
   chk_uptime();
   chk_chdir();
   loadusr(USERFILE);
   srandom(time(NULL));
   strcpy(defchan,REPORTS);
   NOW=time(NULL);
/* file.c - add things to do on startup there */
   start_up();
 srandom(time(NULL));
 srand(time(NULL));
if (!argv[2])
{
 printf("Syntax: mudbot <servername> <port>\n");
 switch(random() % 4) {
 case 0:
  botsck[0]=bot_login(BOTNAME,SERVERA,DEFAULTPORT);
  break;
 case 1:
  botsck[0]=bot_login(BOTNAME,SERVERB,DEFAULTPORT); 
  break;
 case 2:
  botsck[0]=bot_login(BOTNAME,SERVERC,DEFAULTPORT); 
  break;
 case 3:
  botsck[0]=bot_login(BOTNAME,SERVERD,DEFAULTPORT); 
  break;
}
}
else if (!argv[1])
{
 switch(rand() % 4) {
 case 0:
  botsck[0]=bot_login(BOTNAME,SERVERA,DEFAULTPORT);
  break;
 case 1:
  botsck[0]=bot_login(BOTNAME,SERVERB,DEFAULTPORT);
  break;
 case 2:
  botsck[0]=bot_login(BOTNAME,SERVERC,DEFAULTPORT);
  break;
 case 3:
  botsck[0]=bot_login(BOTNAME,SERVERD,DEFAULTPORT); 
  break;
}       
}
else
{
   botsck[0]=bot_login(BOTNAME,argv[1],atoi(argv[2]));
}

           /* establish descriptor for socket */
   if(botsck[0] < 0) exit(-1);  /* socket failed */
   botstat[0]=0;
   botstat[1]=1;
   CONNECT=1;
   for(i=0;i<1;i++)	/* set socket non blocking */
   { if(( res = fcntl(botsck[i], F_GETFL, 0)) == -1);
     else if (fcntl(botsck[i],F_SETFL, res | FNDELAY) == -1);
   }
   if(( res = fcntl(servsck[0], F_GETFL, 0)) == -1);
     else if (fcntl(servsck[0],F_SETFL, res | FNDELAY) == -1);
   if(( res = fcntl(chansck[0], F_GETFL, 0)) == -1);
     else if (fcntl(chansck[0],F_SETFL, res | FNDELAY) == -1);

#ifdef BACKGROUND
  if (pid = fork()) {
    printf("Going to background (PID: %d)\n", pid);
    fppid = fopen("mudbot.pid","w");
    fprintf(fppid,"%i\n",pid);
    if(fppid!=NULL) fclose(fppid);
    close(0);
    close(1);
   for(i=0;i<1;i++) writeln(botsck[i],buf);
   exit(0);  
  }
#endif

readin();

printf("*** Dumped somehow from the network (?)\n");  
#ifdef JUMPONERROR
  do_jump(botsck[0],NULL,0);
#endif
}
   

do_jump(sck,serverid,portid)
int sck;
char serverid[200];
int portid;
{  
   char temp[200] = "";
#ifdef LOGERRORS
   logerr("Reloading");
#endif
   if(serverid!=NULL) {
   if(portid!=0) {
   if(cas_cmp(serverid,"")) {       
   printf("*** Someone made me jump!\n");
   sprintf(buf,"QUIT :%s made me jump to %s\n",token[0],token[4]);
   writeln(sck,buf);
   sleep(1);
   close(sck);
   strcpy(temp,"./mudbot ");
   strcat(temp,serverid);
   strcat(temp," ");
   strcat(temp,token[5]);
   strcat(temp,"\n");
   system(temp);
   sleep(1);
   exit(0); } } }
   close(sck);
   printf("*** Reloading!\n");
   system("./mudbot \n");
   sleep(1);
   exit(0);
}
                     
/* This function is called each time a line is read in from a socket */
/* the input line is parsed into seperate words (token[wordnum-1])   */
spitout(sckfd)
int sckfd;
{ int i,loopcnt=0;
  int length,position=0;
  char *fromhost;
  char *temp;
  char *end_of_line;
  char tempbuf[200000];
  int mysck;

  for(mysck=0;mysck<1;mysck++) if (sckfd == botsck[mysck]) break;

        /* BUFFER INPUT */
  strcat(input_buffer[mysck],sockbuf);
  input_buffer[mysck][strlen(input_buffer[mysck])+1]='\0';

        /* CHECK FOR NEWLINE */
  input_start=input_buffer[mysck];
  length=strlen(input_buffer[mysck]);
  while( (input_end=strchr(input_start,'\n')) )
  {  loopcnt++;
     *input_end='\0';
     position+= strlen(input_start);
#ifdef TERMINAL
     printf("[BOT] %s\n",input_start); 
#endif
    if(strncmp(input_start,"PI",2)==0)
    { strcpy(buf,input_start);
      strncpy(buf,"PO",2);
        writeln(sckfd,strcat(buf,"\n"));
      input_start=input_end+1;
      continue;
    } /* ping - pong */

    if(*(input_start+strlen(input_start)-1) == '\r')
       *(input_start+strlen(input_start)-1) = '\0';

    strcpy(global_buf,input_start);

    token[i=0]=strtok(input_start," ");
    while(token[++i]=strtok(NULL, " ")); token[i]=NULL;

    input_start=input_end+1;

if(token[0]!=NULL) {
 if(token[1]!=NULL) {
  if(!cas_cmp(token[0],"ERROR")) {
   if(!cas_cmp(token[1],":Closing")) sev_stuff(sckfd,0);
} } }

    if(!cas_cmp(token[1],"JOIN")) do_joined(sckfd);
#ifdef VIEW
if(token[1] != NULL) {
 if(!cas_cmp(token[1],"MODE")) client_mode(sckfd); 
 if(!cas_cmp(token[1],"QUIT")) client_quit(sckfd); }
#endif 
    if(!cas_cmp(token[1],"QUIT")) do_takenick(sckfd);
    if(!cas_cmp(token[1],"KICK")) {
     sprintf(buf,"JOIN %s\n",token[2]);
     writeln(sckfd,buf); 
#ifdef WARNINGS
     if(!cas_cmp(token[3],BOTNAME)) {
      sprintf(buf,"PRIVMSG %s :Warning: I was kicked from %s by [%s]\n",WARNINGS, token[2],token[0]);
      writeln(sckfd,buf);
     }
     if(!cas_cmp(token[3],BOTSECNAME)) {
      sprintf(buf,"PRIVMSG %s :Warning: I was kicked from %s by [%s]\n",WARNINGS,token[2],token[0]);
      writeln(sckfd,buf);
     }     
#endif
    }
#ifdef WARNINGS
    if(token[4] != NULL) {
    if(!cas_cmp(token[1],"MODE") && !cas_cmp(token[4],BOTNAME)) {
     sprintf(buf,"PRIVMSG %s :Warning: MODE change [%s] on me in %s by [%s]\n",WARNINGS,token[3],token[2],token[0]);
     writeln(sckfd,buf);
    } 
    if(!cas_cmp(token[1],"MODE") && !cas_cmp(token[4],BOTSECNAME)) {
     sprintf(buf,"PRIVMSG %s :Warning: MODE change [%s] on me in %s by [%s]\n",WARNINGS,token[3],token[2],token[0]);
     writeln(sckfd,buf);
    }    
    if(token[5] != NULL) {
    if(!cas_cmp(token[1],"MODE") && !cas_cmp(token[5],BOTNAME)) {
     sprintf(buf,"PRIVMSG %s :Warning: MODE change [%s] on me in %s by [%s]\n",WARNINGS,token[3],token[2],token[0]);
     writeln(sckfd,buf);
    }                        
    if(token[6] != NULL) {
    if(!cas_cmp(token[1],"MODE") && !cas_cmp(token[6],BOTNAME)) {
     sprintf(buf,"PRIVMSG %s :Warning: MODE change [%s] on me in %s by [%s]\n",WARNINGS,token[3],token[2],token[0]);
     writeln(sckfd,buf);
    }  
    if(token[7] != NULL) {
    if(!cas_cmp(token[1],"MODE") && !cas_cmp(token[6],BOTNAME)) {
     sprintf(buf,"PRIVMSG %s :Warning: MODE change [%s] on me in %s by [%s]\n",WARNINGS,token[3],token[2],token[0]);
     writeln(sckfd,buf);
    }      
    if(token[8] != NULL) {
    if(!cas_cmp(token[1],"MODE") && !cas_cmp(token[6],BOTNAME)) {
     sprintf(buf,"PRIVMSG %s :Warning: MODE change [%s] on me in %s by [%s]\n",WARNINGS,token[3],token[2],token[0]);
     writeln(sckfd,buf);
    }      
    } } } } }
#endif
    if((token[6] != NULL) && (token[7] != NULL) && (token[5] != NULL)) {
    if(!cas_cmp(token[1],"NOTICE")) {
    if(!cas_cmp(token[6],"Net")) {
     if(!cas_cmp(token[7],"break:")) {
#ifdef VIEW
      if(token[8]!=NULL && token[9]!=NULL) {
      printf("NET break: %s <-> %s\n",token[8],token[9]); }
#endif
      do_netbreak(sckfd); }
     if(!cas_cmp(token[7],"junction:")) {
#ifdef VIEW
       if(token[8]!=NULL && token[9]!=NULL) {
       printf("NET join: %s <-> %s\n",token[8],token[9]); }
#endif
      do_netjoin(sckfd); } } } } 

if(token[3] != NULL && token[2] != NULL) {
if(token[4] != NULL && token[5] != NULL) {
if(token[6] != NULL && token[8] != NULL) {
if(token[7] != NULL) {

#ifdef OPERVIEW
     if(!cas_cmp(token[8],"GLINE")) {
      if(!cas_cmp(token[7],"adding")) view_addgline(sckfd);
      if(!cas_cmp(token[7],"removing")) view_remgline(sckfd); }
     if(!cas_cmp(token[7],"SQUIT")) view_squit(sckfd);

#endif
#ifdef VIEWKILLS

     if(!cas_cmp(token[7],"KILL")) view_kill(sckfd); 

#endif

} } } }

    if(!token[0]) continue;
    if(!token[1]) continue;

    if(i < 3) continue;

    if(botstat[mysck])
    {  /* CONNECTION IS A SERVER CONNECTION */
    
    }   
    else
    {  /* Connection is a client connection */

      if(temp=strchr(token[0],'!')) { 
       *temp='\0'; 
       fromhost=temp+1;
       bot_parse(sckfd,fromhost,i); 
       continue; 
      }
	/* call bot_parse to check commands in the message */
      if(atoi(token[1])==109)
      { 
       printf("*** No route to host\n");
       sprintf(buf,"QUIT :No route to host\n");
       writeln(sckfd,buf);
#ifdef LOGERRORS
    logerr("No route to host");
#endif 
#ifdef JUMPONERROR
    strcpy(token[4],"");
    do_jump(sckfd);
#endif
       exit(0);
      }
      else sev_stuff(sckfd,toks);
    }
  }	/* End of buffered input */
  strcpy(input_buffer[mysck],input_start);
}

finishline(start)
int start; { int i; i=start; while (token[i]) printf(" %s",token[i++]); }



int chk_num(int start)
{ int j; j=start; while (token[j]) { j++; }
        return j;
}

do_scmd(int sck)
{int i,j,k;
 char temp[512];
        j=chk_num(0);
        strcpy(temp,"");
if (j>4)
        for(i=4;i<j;i++) {
          strcat(temp,token[i]);
          strcat(temp," ");
        }
    sprintf(buf,"%s\n",temp); writeln(sck,buf);
}


int dump_input()
{  
   struct tm tblock;
   tblock= (*localtime(&NOW));
   global_buf[strlen(global_buf)-1]='\0';
   if(dumpfile != NULL)
   {  fprintf(dumpfile,"%s %s",global_buf+60,asctime(&tblock));
      fflush(dumpfile);
   }
   return 1;
}
