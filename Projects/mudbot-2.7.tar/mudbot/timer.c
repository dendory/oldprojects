#include <stdio.h>
#include "vars.h"
#include "config.h"
/* timer.c
**      The socket's core of this code has been made by wildthang
**      <danny@wildstar.net>. You can modify it but not distribute it
**      modified. This file is part of MudBot and is (C) 1997 by Drow
**      <drow@wildstar.net> All rights reserved.    
*/

int do_timer()
{ time_t timer;
  static time_t lasttime;

  timer=time(NULL);
  lasttime=timer;
}
