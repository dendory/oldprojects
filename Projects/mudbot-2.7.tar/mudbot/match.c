/* match.c
**      The socket's core of this code has been made by wildthang
**      <danny@wildstar.net>. You can modify it but not distribute it
**      modified. This file is part of MudBot and is (C) 1997 by Drow
**      <drow@wildstar.net> All rights reserved.    
*/
/* int do_match(char *string1,char *string2)
   returns 0 if match
   returns 1 if do not match */


#include <stdio.h>
#include <ctype.h>

int match(char *check,char *orig)
{
	while(*check == '*' ||
		tolower(*check)==tolower(*orig) ||
		*check == '?')
 	if(*check == '*')
	   if(*++check) {
	   	while(*orig)
	      		if(!match(check,orig++)) return 0;
	   	return 1;
	   	}
  	   else
	   	return 0;
	   else if (!*check)
	   	return 0;
	   else if (!*orig)
	   	return 1;
	   else {
			++check;
			++orig;
		}
	return 1;
}

int cas_cmp(char *case1,char *case2)
{
        return (strcasecmp(case1,case2,strlen(case1)));
}
