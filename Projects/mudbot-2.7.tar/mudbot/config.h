/* Main config file - Dont forget to 'make clean' and 'make' after
* any change here.*/
/* print to screen stuff from the server */
#undef TERMINAL
/* command char [char] */
#define CMDCHAR '!'
/* go to background on startup [define|undef] */
#define BACKGROUND
/* time for the play command [number] */
#define PLAY_SLEEPTIME 15
/* sleep time in secs between commands.. recommended value = 1 [number]*/
#define SLEEP_TIME 1
/* umodes for the bots */
#define UMODES "+is-wd"
/* your account name (or fake if you dont use identd) */
#define ACCOUNTNAME "elfie"
/* who to /msg when the bot sees netsplits. Put a dummy channel
* or change the UMODES to -s if you dont want it reported [channel] */
#define REPORTS "#bots"
/* send warnings when kicked or modes to that channel [channel|undef] */
#undef WARNINGS
/* autobans file [filename] */
#define AUTOBAN "autoban.file"
/* local users file. [filename] */
#define LOCALFILE "local.file"
/* working dir where the files must be [path] */
#define PATH "/home/elfie/mudbot"
/* do we allow people with level 8 or more to kill? of course the
* bot need to be opered for that */
#define ALLOW_KILL
/* allow level 8 users to masskill? [define|undef] (EXPERIMENTAL) */
#define ALLOW_MASSKILL
/* do we want to allow people to rehash, make the bot oper up, and
* wallops? */
#define OPER_CMDS
/* deop everyone that gets oped by everyone except the bot [define|undef] */
#undef BITCH
/* allow level 10 to shutdown the bot [define|undef] */
#define ALLOW_EXIT
/* channels are public channels. You can use local with & [char]*/
#define CHANCHAR "#"
/* jump to default server on disconnect? [define|undef] */
#define JUMPONERROR
/* who is my master? Must be a nick [string] */
#define MASTER "drow"
/* do I report commands from level 0 users to the master? [define|undef] */
#undef SPY
/* Undernet Cservice file [filename] */
#define CSFILE "undernet.file"
/* default servers names. there are 4 defines, dont add/rem some [string]*/
#define SERVERA "okc.ok.us.undernet.org"
#define SERVERB "sandiego.ca.us.undernet.org"
#define SERVERC "okc.ok.us.undernet.org"
#define SERVERD "baltimore.md.us.undernet.org"
/* default port [int]*/
#define DEFAULTPORT 6665
/* password for the server if you need one [string|undef]*/
#undef PASS
/* news file [filename] */
#define NEWSFILE "news.file"
/* bot nick [string] */
#define BOTNAME "MudBot"
/* bot second nick [string] */
#define BOTSECNAME "MUD206"
/* bot real name [string] */
#define BOTDESC "A MudBot"
/* your URL or the bot's URL or whatever... [string|undef]*/
#define URL "http://www.mudbot.org"
/* what to play on connect. must be in raw IRC [filename]*/
#define STARTSCRIPT "script.file"
/* users file [filename] */
#define USERFILE "user.file"
/* where do we log [filename|undef] */
#undef LOGFILE_MSG
#define LOGFILE_CMD "mudbot-cmd.log"
#undef LOGFILE_PUB
/* where to report errors [filename|undef] */
#define LOGERRORS "errors.log"
/* where to put the silence list [filename] */
#define SILENCEFILE "silence.file"
/* fix mem leaks problems [define|undef] */
#define MEMLEAK
/* allow users 0 (anyone) to use the channels specific commands [define|undef]*/
#undef BAR
/* path of the html dir.. FILES IN THAT DIR WILL BE DELETED [path]*/
#define HTMLDIR "/home/elfie/public_html/mudbot"
/* Use as NickServ? must also define allowkill and opercmds [define|undef] */
#undef NICKSERV
/* make the help command for nickserv only? [define|undef] */
#undef USE_AS_NICKSERV_ONLY
/* view kill/glines/etc. made for ircu may have bugs on dal/ircd [chan|undef]*/
#define OPERVIEW "#bots"
/* Show the GLINE's reason [define|undef] */
#undef OPERVIEW_G_REASON
/* do we report even kills? (OPERVIEW must be defined) [define|undef] */
#undef VIEWKILLS
/* view kills reasons? (VIEWKILLS must be defined) [define|undef] */
#undef KILLS_REASONS
/* to see tru the bot's eyes what's going on online [undef|define]
* You can also use MudBot as your IRC client if you undef background and
* define this */
#undef VIEW
/* define this if you want to allow level 9 users to use shell commands */
#undef ALLOW_EXEC
/* use alias.file aliases? [define|undef]*/
#define USE_ALIASES
/* Allow mult aliases for a single word? [define|undef]*/
#define MULT_ALIASES
/* Kick on '-oooooo' ? [define|undef] */
#define MASSDEOP
/* Use this MudBot as FTP manager to manage this server' annonymous FTP
* server? You usualy need root to hands you management of it.[define|undef]*/
#undef FTPMGR
/* FTP root where to put the server's files in (you need root to chown it
* to your account) [path] */
#define FTPROOT "/home/ftp"
/* Use validate passwords? [define|undef] */
#define USE_VALIDATE
/* Debug option. LOGERRORS must be defined for this. [define|undef]*/
#undef LOG_ERRNO
/* Allows you to share user files. Be carefull with that [def|undef]*/
#undef SHARE_USERFILE
/* Use interactive Web interface [define|undef] (EXPERIMENTAL)*/
#undef INTER_WEB
/* CGI-BIN URL [url] */
#define CGI_BIN "/cgi-bin"
/* Use crypt passwords [define|undef] (EXPERIMENTAL) */
#define USE_CRYPT_PASSWD
/* !kb's kick message [msg] */
#define KB_MSG "Bye..."
/* reports commands in REPORTS channel [define|undef]*/
#undef REPORT_COMMANDS
/* Stop trying after how many fail connects [int] */
#define MAX_CONNECT_COUNT 30
/* Most commands wont work if set. Usefull if you want to run 1 specific
 * mudscript. [define|undef] */
#undef QUIET
/* Bind to an IP [undef|ip] */
#undef VIRTUAL
/* Flood protection level [0,1,2,3]*/
#define FLOOD_PROTECT 1
 
/* BINDS
 * Use these binds to make the bot do commands on specific actions.
 * Like if you wanted it to msg anyone who join a channel the bot's in:
 * #define BIND_JOIN "privmsg $nick :Welcome to my $channel $nick !"
 * $nick, $channel, %0, %1.. %6 are reconized by the bot.
*/
#define USE_BINDS
#undef BIND_MODE
#undef BIND_JOIN
#undef BIND_PART
#undef BIND_PRIVMSG
#undef BIND_NOTICE
/* Service server.. Allows level 8 users to do special commands [def|undef]
 * Read the README.operserv for more info */
#undef SERVICE
/* Server will link to... [server name] */
#define SERVICE_UPLINK "irc.dummy.net"
/* The service server will have name... [server name] */
#define SERVICE_SERVER_NAME "services.dummy.net"
/* Port to link to... [port] */
#define SERVICE_PORT 6667
/* Server password to send [pass] */
#define SERVICE_PASS "pass"
/* Service server description [string] */
#define SERVICE_DESC "This is MudBot's Service Server"
/* Allows masked glines [define|undef]*/
#define MASKED_GLINES
/* Gline time [time in secs] */
#define GLINE_TIME 7200
/* Use bot's help as OperServ's help */
#undef USE_AS_OPERSERV_ONLY
/* Shows everything the server received to the screen. Debug tool [def|undef]*/
#undef SERVICE_TERMINAL
/* Channel Service. Allows users to register channels [define|undef]
 * Read the README.chanserv for more info */
#undef CHANSERV
/* Server will link to... [server name] */
#define CHANSERV_UPLINK "irc.dummy.net"
/* The server will have name... [server name] */
#define CHANSERV_SERVER_NAME "channels.dummy.net"
/* Port to link to... [port] */
#define CHANSERV_PORT 6667
/* Server password to send [pass] */
#define CHANSERV_PASS "pass"
/* Service server description [string] */
#define CHANSERV_DESC "This is MudBot's Service Server"
/* Shows everything the server received to the screen. Debug tool [def|undef]*/
#undef CHANSERV_TERMINAL
