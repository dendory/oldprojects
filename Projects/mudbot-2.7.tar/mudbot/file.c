/*  File.c
**	The socket's core of this code has been made by wildthang
**      <danny@wildstar.net>. You can modify it but not distribute it
**      modified. This file is part of MudBot and is (C) 1997 by Drow
**      <drow@wildstar.net> All rights reserved.
*/
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "config.h"
#include "vars.h" 
/*
#ifndef _TIME_T
#define _TIME_T
typedef int             time_t;
#endif
*/

FILE *FP;
int user_count = 0;
int prot_count = 0;


static int logstatus = 1;

char users[100][30][50] ={ "" };
char protect[50][3][30]={ "" };
FILE *logfp;
int logstats=0;

chk_msgs(sck)
int sck;
{
 int i;
 char temp[255];
 FILE *fp;
 if(token[4]==NULL || token[5]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !readmsg <nick> <password>\n",token[0]);
  writeln(sck,buf);
  return 0; }
  for(i=0;i<user_count;i++) {
  if(!cas_cmp(users[i][2],token[4])) {
   sprintf(buf,"NOTICE %s :Checking messages for %s [%s]\n",token[0],token[4],users[i][0]);
   writeln(sck,buf);
#ifdef USE_CRYPT_PASSWD
   if(!cas_cmp(users[i][3],do_cryptpass(token[5]))) {
#else
   if(!cas_cmp(users[i][3],token[5])) {
#endif
    strcpy(temp,token[4]);
    strcat(temp,".notes");
    if((fp=fopen(temp,"r"))==NULL) return 0;
    while(fgets(temp,255,fp)!=NULL) {
     sprintf(buf,"NOTICE %s :- %s\n",token[0],temp);
     writeln(sck,buf);
    }
   }
   else {
    sprintf(buf,"NOTICE %s :Wrong password!\n",token[0]);
    writeln(sck,buf);
   }
  }
 }
 fclose(fp);
}

clr_msgs(sck)
int sck;
{ 
 int i;
 char temp[255];
 FILE *fp;
 if(token[4]==NULL || token[5]==NULL) {
  sprintf(buf,"NOTICE %s :Syntax: !clearmsg <nick> <password>\n",token[0]);
  writeln(sck,buf);
  return 0; }
  for(i=0;i<user_count;i++) {
  if(!cas_cmp(users[i][2],token[4])) {
#ifdef USE_CRYPT_PASSWD
   if(!cas_cmp(users[i][3],do_cryptpass(token[5]))) {
#else
   if(!cas_cmp(users[i][3],token[5])) {
#endif
    strcpy(temp,token[4]);
    strcat(temp,".notes");
    if((fp=fopen(temp,"w"))==NULL) return 0;
    fputs("",fp);
    sprintf(buf,"NOTICE %s :Clearing...\n",token[0]);
    writeln(sck,buf);
   }  
  }
 }
 fclose(fp);
}


do_validate(sck)
int sck;
{
 FILE *fp;
 FILE *fpa;
 char temp[255];
 time_t lt;
 int i,j,z=0;
 lt=time(NULL);
 if (token[4] == NULL) return 0;
 sprintf(buf,"NOTICE %s :Validating...\n",token[0]);
 writeln(sck,buf);
 for(i=0;i<user_count;i++)
 {
#ifdef USE_CRYPT_PASSWD
  if(!cas_cmp(users[i][3],do_cryptpass(token[4])))
#else
  if(!cas_cmp(users[i][3],token[4]))
#endif
 { z=1;
   sprintf(buf,"NOTICE %s :AUTHENTICATION SUCCESSFUL for [%s]! Please use /msg <botnick> !unvalidate <pass> before leaving IRC.\n",token[0],users[i][0]);
   writeln(sck,buf);
   fpa=fopen("stats.file","a");
   fputs("A\n",fpa);
   if(fpa!=NULL) fclose(fpa);
   strcpy(users[i][4],"1");
   strcpy(temp,users[i][2]);
   strcat(temp,".notes");
   if((fpa=fopen(temp,"r"))!=NULL) {
    if(fgets(temp,255,fpa)!=NULL) {
     if(cas_cmp(temp,"")) {
      sprintf(buf,"NOTICE %s :You have new messages.. use !readmsg to see them..\n",token[0]);
      writeln(sck,buf); } } }
   if(fpa!=NULL) fclose(fpa);
   fp=fopen("seen.file","a");
   fputs(users[i][2],fp);
   fputs(" ",fp);
   fputs(ctime(&lt),fp);
   fputs("\n",fp);
   if(fp!=NULL) fclose(fp);
  }
 }
#ifdef REPORTS
 if(z==0) {
  sprintf(buf,"PRIVMSG %s :Failed AUTH attempt by %s\n",REPORTS,token[0]);
  writeln(sck,buf); }
#endif
}     

do_up(sck)
int sck;
{
 FILE *fp;
 int i,j;
 char templ[512]="";
 if(token[4] == NULL) return 0;
 if(token[5] == NULL) return 0;    
 fp = fopen(LOCALFILE,"r");
 sprintf(buf,"NOTICE %s :Looking for access...\n",token[0]);
 writeln(sck,buf);
 for(i=0;i<user_count;i++)
 {
  if(!cas_cmp(users[i][3],token[5]))
  {
   sprintf(buf,"NOTICE %s :Access found!\n",token[0]);
   writeln(sck,buf);
   while(fgets(templ,255,fp) != NULL)
   {
    if (!cas_cmp(lindex(templ,0),users[i][2]))
    {
     if (!cas_cmp(lindex(templ,1),token[4])) { 
      sprintf(buf,"NOTICE %s :There ya go!\n",token[0]);
      writeln(sck,buf);      
      sprintf(buf,"MODE %s +o %s\n",token[4],token[0]);
      writeln(sck,buf); }
     if (lindex(templ,2)==NULL) { break; }
     if (!cas_cmp(lindex(templ,2),token[4])) {
      sprintf(buf,"NOTICE %s :There ya go!\n",token[0]);
      writeln(sck,buf);    
      sprintf(buf,"MODE %s +o %s\n",token[4],token[0]);
      writeln(sck,buf); }     
     if (lindex(templ,3)==NULL) { break; }    
     if (!cas_cmp(lindex(templ,3),token[4])) {
      sprintf(buf,"NOTICE %s :There ya go!\n",token[0]);
      writeln(sck,buf);    
      sprintf(buf,"MODE %s +o %s\n",token[4],token[0]);
      writeln(sck,buf); }     
     if (lindex(templ,4)==NULL) { break; }    
     if (!cas_cmp(lindex(templ,4),token[4])) {
      sprintf(buf,"NOTICE %s :There ya go!\n",token[0]);
      writeln(sck,buf);    
      sprintf(buf,"MODE %s +o %s\n",token[4],token[0]);
      writeln(sck,buf); }     
     if (lindex(templ,5)==NULL) { break; }  
     if (!cas_cmp(lindex(templ,5),token[4])) {
      sprintf(buf,"NOTICE %s :There ya go!\n",token[0]);
      writeln(sck,buf);    
      sprintf(buf,"MODE %s +o %s\n",token[4],token[0]);
      writeln(sck,buf); }     
    }
   }
  }
 }
if(fp!=NULL) fclose(fp);
}       

do_unvalidate(sck)
int sck;
{
 FILE *fpa;
 int i,j;
 if(token[4] == NULL) return 0;
 sprintf(buf,"NOTICE %s :UnValidating...\n",token[0]);
 writeln(sck,buf);
 for(i=0;i<user_count;i++)
 {
#ifdef USE_CRYPT_PASSWD
  if(!cas_cmp(users[i][3],do_cryptpass(token[4])))
#else
  if(!cas_cmp(users[i][3],token[4]))
#endif
  {
   sprintf(buf,"NOTICE %s :AUTHENTICATION SUCCESSFUL!\n",token[0]);
   strcpy(users[i][4],"0");
   writeln(sck,buf);
   fpa=fopen("stats.file","a");
   fputs("U\n",fpa);
   if(fpa!=NULL) fclose(fpa);
  }
 }
}   

chknick(nick)
char nick[255];
{
 int i,j=0;
 for(i=0;i<user_count;i++) { if(!cas_cmp(users[i][2],nick)) j=1; }
 return j;
}

loadusr(filename)
char filename[];
{
FILE *fp;
char line[255];
int i,j;
char *tempp;
    if( (fp = fopen(filename,"r"))==NULL) return;

    for (i=0;fgets(line, 255, fp);i++)
    {
 if(tempp = strtok(line,":"))    /* level */
  strcpy(users[i][1],tempp);

 if(tempp = strtok(NULL,":"))    /* nick */
  strcpy(users[i][2],tempp);

  if(tempp = strtok(NULL,":"))    /* u@h */
  strcpy(users[i][0],tempp);

  if(tempp = strtok(NULL,":"))    /* pass */
  strcpy(users[i][3],tempp);       

  if(tempp = strtok(NULL,":"))    /* validate */
  strcpy(users[i][4],tempp);       

 if(tempp = strtok(NULL,":"))    /* autoop */
  strcpy(users[i][5],tempp);                        

 if(tempp = strtok(NULL,":"))    /* email */
  strcpy(users[i][6],tempp);    
    }
        user_count = i;

   if(fp!=NULL) fclose(fp);


}


/* this function returns the acces level of the user@host */
int chklevel(fromhost,k)
char *fromhost;
int k;
{
 int i,j;

 if(k==(-775)) return 1;

	for(i=0;i<user_count;i++) {
		if(!match(users[i][0],fromhost)) {
		  if(!cas_cmp(users[i][4],"1")) {
                      return atoi(users[i][1]);
		} }
	}
  return 0;
}

int chkautoop(fromhost)
char *fromhost;
{int i,j;
        for(i=0;i<user_count;i++) {
                if(!match(users[i][0],fromhost)) {
    
                      return atoi(users[i][5]);
                } 
        }
  return 0;                 
}

int writelog(fromhost,type_of_log)
char *fromhost;
int type_of_log;
{
  char *t;
  int i=3;
  time_t timer;
  struct tm *tblock;
  timer = time(NULL);	
  tblock = localtime(&timer); 
  t = ctime(&timer);

#ifdef LOGFILE_MSG
  if(type_of_log==0) FP = fopen(LOGFILE_MSG,"a");
#endif
#ifdef LOGFILE_PUB
  if(type_of_log==1) FP = fopen(LOGFILE_PUB,"a");
#endif
#ifdef LOGFILE_CMD
  if(type_of_log==2) FP = fopen(LOGFILE_CMD,"a");
#endif

  fprintf(FP,"%ld %s!%s",time(NULL),token[0],fromhost);
  while (token[i]) fprintf(FP," %s",token[i++]); 
  fprintf(FP,"\n");

  fflush(FP);
 if(FP!=NULL) fclose(FP);
}

int startlog(file_name)
char *file_name;
{
  return;
}

start_up()
{ 
FILE *ifp;
time_t lt;
long uptime = time(NULL);
ifp = fopen("uptime.file","w");
lt = time(NULL);
fputs(ctime(&lt),ifp);
fprintf(ifp,"%ld",uptime);
if(ifp!=NULL) fclose(ifp);
return;
}

chk_chdir()
{
 FILE *fp;
 char templ[512]="";
 fp = fopen(USERFILE,"r");
 fgets(templ,255,fp);
 if(fp!=NULL) fclose(fp);
 if (templ == NULL) {
  printf("*** Edit your config files\n");
  exit(0); }   
 if (!cas_cmp(templ,"")) {
  printf("*** Edit your config files\n");
  exit(0); }
}
