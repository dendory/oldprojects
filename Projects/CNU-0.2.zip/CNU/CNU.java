// Compact Networking Utilities (see devplanet.fastethernet.net)
// provided under the GNU Public License (see file COPYING)
// (C) 1998 Patrick Lambert <drow@darkelf.net>

import java.awt.event.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;
// GWE SQL JDBC driver (see README)
import java.sql.*;
import gwe.sql.*;
// Telnet class (see README)
import display.*;
import socket.*;
import modules.*;

// private functions are GUI query boxes, public are the action functions
class CNU implements ActionListener, ItemListener
{
 // variables
 public boolean DEBUG = true; // extensive error messages
 public int TCP_SERVER_PORT = 2500;
 public int UDP_SERVER_PORT = 2500;
 private String version = "0.2";    // version
 private static String CONFIG_FILE = "CNU.cfg"; // config file
 private String java_version = "1.1"; // changed in makegui()

 // GUI widgets - one per window type
 Frame mainWin = null, cfgBox = null, textWin = null, buttonWin = null, infoWin = null, dialogWin = null, inputBox = null;
 Choice action = null;
 TextField t1 = null, t2 = null, t3 = null, t4 = null, t5 = null, t6 = null, t7 = null;
 TextArea textBox = null, ResultText = null;
 Checkbox checkBox = null;

 // client socket, input stream, output stream
 BufferedReader in = null;
 PrintWriter out = null;
 Socket sockfd = null;

 // settings
 private String USERNAME = "noname";
 private String PASSWORD = "";
 private String OUT_SERVER = "localhost";
 private String POP_SERVER = "mail";
 private String EMAIL = "noname@localhost";
 private String SIGNATURE = "";
 private String TEXT_EDITOR = "internal";
 private int X_LOCATION = 50, Y_LOCATION = 50;

 // for generic debuging purposes
 public void print_debug(String line)
 {
  Generic f = new Generic();
  f.DISABLE_CONTROL_BOX = true;
  if(DEBUG) f.texteditor(null, line, "Debug information", false, 450, 300);
 }

 // settings box
 private void settings()
 {
  cfgBox = new Frame("Settings");
  Button ok = new Button("Save");
  Button cancel = new Button("Cancel");
  ok.addActionListener(this);
  cancel.addActionListener(this);
  cfgBox.addWindowListener(new WinControl());
  cfgBox.setSize(300, 270);
  cfgBox.setLocation(100, 150);
  cfgBox.setLayout(new GridLayout(8, 2));
  cfgBox.add(new Label("User name:", Label.CENTER));
  t1 = new TextField(USERNAME, 15);
  cfgBox.add(t1);
  cfgBox.add(new Label("Your e-mail:", Label.CENTER));
  t2 = new TextField(EMAIL, 15);
  cfgBox.add(t2);
  cfgBox.add(new Label("X Y location:", Label.CENTER));
  t3 = new TextField(X_LOCATION + " " + Y_LOCATION, 15);
  cfgBox.add(t3);
  cfgBox.add(new Label("POP3 incoming server:", Label.CENTER));
  t6 = new TextField(POP_SERVER, 15);
  cfgBox.add(t6);
  cfgBox.add(new Label("Send mail server:", Label.CENTER));
  t4 = new TextField(OUT_SERVER, 15);
  cfgBox.add(t4);
  cfgBox.add(new Label("Text editor:", Label.CENTER));
  t7 = new TextField(TEXT_EDITOR, 15);
  cfgBox.add(t7);
  cfgBox.add(new Label("Enable debugging:", Label.CENTER));
  if(DEBUG)
  t5 = new TextField("true", 15);
  else
  t5 = new TextField("false", 15);
  cfgBox.add(t5);
  cfgBox.add(ok);
  cfgBox.add(cancel);
  cfgBox.show();
 }

 // GUI state changes (choice box)
 public void itemStateChanged(ItemEvent evt)
 {
  Generic f = new Generic();
  f.DISABLE_CONTROL_BOX = true;
  if("  About".equals(evt.getItem()))
   f.texteditor(null, "About the Compact Networking Utilities v" + version + "\n\nThis program was made with 2 main goals: portability and compactness. It can be very useful for software developers, systems admins or power users to have direct access to common protocols.\n\nThis program is provided under the GNU Public General License (see file COPYING)\n\nCopyright 1998 Patrick Lambert <drow@darkelf.net>\n\nThis product includes third parties software (see file README)\n\nYou can get the latest copy at devplanet.fastethernet.net\n", "Help: About", false, 450, 300);
  if("  Quit the program".equals(evt.getItem()))
   System.exit(0);
  if("  Change settings".equals(evt.getItem()))
   settings();
  if("  System information".equals(evt.getItem()))
   sys_info();
  if("  Text editor".equals(evt.getItem()))
  {
   if(("internal".equals(TEXT_EDITOR)))
   {
    f.DISABLE_CONTROL_BOX = false;
    f.texteditor("noname.txt", "", "Editor", true, 600, 400);
   }
   else
   {
    Runtime rt = Runtime.getRuntime();
    try
    {
     rt.exec(TEXT_EDITOR);
    }
    catch(Exception err)
    {
     f.msgbox("Could not run process", "Error", true);
     print_debug(err.getMessage());
    }
   }
  }
  if("  Change password".equals(evt.getItem()))
   ask_password();
  if("  Send mail (SMTP)".equals(evt.getItem()))
   compose_mail();
  if("  Host information".equals(evt.getItem()))
   host_info();
  if("  User information".equals(evt.getItem()))
   user_info();
  if("  Domain information".equals(evt.getItem()))
   domain_info();
  if("  User manual".equals(evt.getItem()))
  {
   String result = "";
   result += "User guide:\n\nHere is a description of all the commands available in this program. The protocol is some times specified in parenthesis.\n\n";
   result += "Change settings: You can change your settings here, including your user name, e-mail address, and mail servers. The changes will be saved in the file CNU.cfg.\n\n";
   result += "Change password: This will change your password for this session only. For security issues the password is not saved in Mail.cfg. If you don't want to enter your password every time and you are on a single-user platform, you can add \"password: your_password ;\" in Mail.cfg\n\n";
   result += "Quit the program: You can quit the program with this and close any window currently open within this program.\n\n";
   result += "System information: This will pop up a window displaying system information.\n\n";
   result += "Text editor: This will launch the internal text editor or an external one you specified in the Settings.\n\n";
   result += "Host/User/Domain information: This will query a host to get information about a user, a hostname or a domain name.\n\n";
   result += "Check e-mails (POP3): Using the POP3 protocol, the program will connect to your POP3 server and tell you if you have new mail.\n\n";
   result += "Simple server (TCP): This will start a single-thread server waiting on a TCP socket (default on port 2500) and wait for a connection. It will then show all incoming text.\n\n";
   result += "Echo server (UDP): This command will start an UDP server that will wait for packets and echo them back to the sender. Default port is 2500.\n\n";
   result += "Send mail: This simply asks you to compose a new single-part e-mail and will send it to the addresses you want.\n\n";
   result += "Telnet session: This command will open a telnet session window and allow you to connect to remote Unix server.\n\n";
   result += "IRC client: A very basic RAW IRC client will be available with this command. The commands sent with this must be raw IRC commands.\n\n";
   result += "Create packet (UDP): This will create an UDP message and send it.\n\n";
   result += "Send a query (SQL): This command will use the SQL protocol to send a query to a database and return raw information.\n\n";
   result += "This program is (C) 1998 Patrick Lambert. See the About menu choice.\n\n";
   f.texteditor(null, result, "Help", false, 450, 300);
  }
  if("  Check e-mails (POP3)".equals(evt.getItem()))
  {
   mainWin.setTitle("Querying...");
   pop_list();
   mainWin.setTitle("Ready.");
  }
  if("  Read a message (POP3)".equals(evt.getItem()))
   entry_box("E-mail number (from 1 to n) to fetch", "Get e-mail", false, false);
  if("  Delete a message (POP3)".equals(evt.getItem()))
   entry_box("E-mail number (from 1 to n) to delete", "Delete e-mail", false, false);
  if("  Send a query (SQL)".equals(evt.getItem()))
   sql_link();
  if("  Run binary".equals(evt.getItem()))
   entry_box("Enter binary file you want to run", "Run it", false, false);
  if("  Telnet session".equals(evt.getItem()))
   entry_box("Syntax: hostname port", "Start telnet", false, false);
  if("  Simple server (TCP)".equals(evt.getItem()))
   tcp_server();
  if("  Simple echo server (UDP)".equals(evt.getItem()))
   udp_server();
  if("  Simple client (IRC)".equals(evt.getItem()))
   entry_box("Syntax: server port", "Start simple IRC client", false, false);
  if("  Create packet (UDP)".equals(evt.getItem()))
   udp_client();
 }

/*
 public void make_random()
 {
  Generic f = new Generic();
  byte data[];
  try
  {
   java.security.SecureRandom seed = new java.security.SecureRandom();
   seed.setSeed(seed.generateSeed(8));
   data = new byte[10];
   seed.nextBytes(data);
   f.msgbox(new String(data), "Result:", false);
  } catch(Exception err)
  {
   f.msgbox("Error: " + err.getMessage(), "Error", false);
  }
 }
*/

 // button clicks... currently compares its label, but could also check the obj name
 public void actionPerformed(ActionEvent evt)
 {
  Generic f = new Generic();
  String line = "";
  boolean state = false;
  if(evt.getActionCommand().equals("Cancel"))
  {
   cfgBox.dispose();
  }
  if(evt.getActionCommand().equals("Cancel message"))
  {
   buttonWin.dispose();
   textWin.dispose();
  }
  if(evt.getActionCommand().equals("Send message"))
  {
   mainWin.setTitle("Sending...");
   send_mail();
   buttonWin.dispose();
   textWin.dispose();
   mainWin.setTitle("Ready.");
  }
  if(evt.getActionCommand().equals("Save"))
  {
   mainWin.setTitle("Saving...");
   USERNAME = t1.getText();
   EMAIL = t2.getText();
   TEXT_EDITOR = t7.getText();
   X_LOCATION = Integer.parseInt(f.lindex(t3.getText(), 0));
   Y_LOCATION = Integer.parseInt(f.lindex(t3.getText(), 1));
   OUT_SERVER = t4.getText();
   POP_SERVER = t6.getText();
   if("true".equals(t5.getText())) DEBUG = true;
   else DEBUG = false;
   cfgBox.dispose();
   save_settings();
   mainWin.setTitle("Ready.");
  }
  if(evt.getActionCommand().equals("Save password"))
  {
   PASSWORD = t2.getText();
   dialogWin.dispose();
  }
  if(evt.getActionCommand().equals("Query SQL db"))
  {
   query_sql("jdbc:" + t1.getText(), t2.getText(), t3.getText(), t4.getText());
  }
  if(evt.getActionCommand().equals("Check host"))
  {
   mainWin.setTitle("Querying...");
   line = t2.getText();
   state = checkBox.getState();
   dialogWin.dispose();
   get_host_info(line, state);
   mainWin.setTitle("Ready.");
  }
  if(evt.getActionCommand().equals("Check user"))
  {
   mainWin.setTitle("Querying...");
   line = t2.getText();
   dialogWin.dispose();
   get_user_info(line);
   mainWin.setTitle("Ready.");
  }
  if(evt.getActionCommand().equals("Check domain"))
  {
   mainWin.setTitle("Querying...");
   line = t2.getText();
   dialogWin.dispose();
   get_domain_info(line);
   mainWin.setTitle("Ready.");
  }
  if(evt.getActionCommand().equals("Get e-mail"))
  {
   mainWin.setTitle("Querying...");
   line = t2.getText();
   dialogWin.dispose();
   get_pop_mail(line, false);
   mainWin.setTitle("Ready.");
  }
  if(evt.getActionCommand().equals("Delete e-mail"))
  {
   mainWin.setTitle("Querying...");
   line = t2.getText();
   dialogWin.dispose();
   get_pop_mail(line, true);
   mainWin.setTitle("Ready.");
  }
  if(evt.getActionCommand().equals("Run it"))
  {
   Runtime rt = Runtime.getRuntime();
   try
   {
    rt.exec(t2.getText());
   }
   catch(Exception err)
   {
    f.msgbox("Could not run process", "Error", true);
    print_debug(err.getMessage());
   }
   dialogWin.dispose();
  }
  if(evt.getActionCommand().equals("Start telnet"))
  {
   try
   {
    telnet applet = new telnet();
    applet.params = new Hashtable();
    applet.params.put("port", f.lindex(t2.getText(), 1));
    applet.params.put("address", f.lindex(t2.getText(), 0));
    applet.params.put("VTscrollbar", "true");
    Frame frame = new Frame("The Java Telnet Application");
    frame.setLayout(new BorderLayout());
    frame.add("Center", applet);
    frame.setSize(380, 590);
    frame.addWindowListener(new WinControl());
    applet.init();
    frame.pack();
    frame.show();
    applet.start();
   } catch(Exception err)
   {
    f.msgbox("An error occured during the session", "Error", false);
   }
  }
  if(evt.getActionCommand().equals("Send!"))
  {
   out.println(t5.getText());
   if(ResultText!=null) ResultText.append("-> " + t5.getText() + "\n");
   t5.setText("");
  }
  if(evt.getActionCommand().equals("Start simple IRC client"))
  {
   dialogWin.dispose();
   irc(f.lindex(t2.getText(), 0), f.lindex(t2.getText(), 1));
  }
  if(evt.getActionCommand().equals("Send packet"))
  {
   mainWin.setTitle("Querying...");
   send_packet(t1.getText(), t2.getText(), t3.getText());
   cfgBox.dispose();
   mainWin.setTitle("Ready.");
  }
  // needed to let the menu at top level.. it seems that Dialog() likes to do the opposite
  mainWin.requestFocus();
  mainWin.toFront();
 }

 // send an UDP packet
 public void send_packet(String host, String port, String msg)
 {
  int DATA_SIZE = 1024;
  DatagramPacket packet = null;
  DatagramSocket sockfd = null;
  InetAddress remote_addr = null;
  Generic f = new Generic();
  byte[] data;
  try
  {
   remote_addr = InetAddress.getByName(host);
   sockfd = new DatagramSocket();
   data = msg.getBytes();
   packet = new DatagramPacket(data, data.length, remote_addr, Integer.parseInt(port));
   sockfd.send(packet);
  } catch(Exception err)
  {
   f.msgbox("Error: " + err.getMessage(), "Error", false);
  }
 }

 // ask info for UDP packet creation
 private void udp_client()
 {
  cfgBox = new Frame("UDP client");
  Button ok = new Button("Send packet");
  Button cancel = new Button("Cancel");
  ok.addActionListener(this);
  cancel.addActionListener(this);
  cfgBox.addWindowListener(new WinControl());
  cfgBox.setSize(350, 150);
  cfgBox.setLocation(100, 150);
  cfgBox.setLayout(new GridLayout(4, 2));
  cfgBox.add(new Label("Remote hostname:", Label.CENTER));
  t1 = new TextField("localhost", 15);
  cfgBox.add(t1);
  cfgBox.add(new Label("Remote port:", Label.CENTER));
  t2 = new TextField("2500", 15);
  cfgBox.add(t2);
  cfgBox.add(new Label("Message:", Label.CENTER));
  t3 = new TextField("", 15);
  cfgBox.add(t3);
  cfgBox.add(ok);
  cfgBox.add(cancel);
  cfgBox.show();
 }

 // start TCP server
 public void tcp_server()
 {
  Frame ResultBox = new Frame("TCP server on " + TCP_SERVER_PORT);
  TextArea ResultText = new TextArea("Starting TCP server\n", 400, 300, TextArea.SCROLLBARS_VERTICAL_ONLY);
  TCPServer myserver = new TCPServer(ResultText, TCP_SERVER_PORT);
  ResultBox.addWindowListener(new WinControl());
  ResultBox.setSize(400, 300);
  ResultBox.setLocation(100, 100);
  ResultText.setEditable(false);
  ResultBox.add(ResultText);
  ResultBox.show();
  myserver.start();
 }

 // start udp server
 public void udp_server()
 {
  Frame ResultBox = new Frame("UDP server on " + UDP_SERVER_PORT);
  TextArea ResultText = new TextArea("Starting UDP server\n", 400, 300, TextArea.SCROLLBARS_VERTICAL_ONLY);
  UDPServer myserver = new UDPServer(ResultText, UDP_SERVER_PORT);
  ResultBox.addWindowListener(new WinControl());
  ResultBox.setSize(400, 300);
  ResultBox.setLocation(100, 100);
  ResultText.setEditable(false);
  ResultBox.add(ResultText);
  ResultBox.show();
  myserver.start();
 }

 // simple query box
 private void sql_link()
 {
  cfgBox = new Frame("SQL query");
  Button ok = new Button("Query SQL db");
  Button cancel = new Button("Cancel");
  ok.addActionListener(this);
  cancel.addActionListener(this);
  cfgBox.addWindowListener(new WinControl());
  cfgBox.setSize(400, 200);
  cfgBox.setLocation(100, 150);
  cfgBox.setLayout(new GridLayout(5, 2));
  cfgBox.add(new Label("URL:", Label.CENTER));
  t1 = new TextField("mysql://localhost:3306/database_name", 15);
  cfgBox.add(t1);
  cfgBox.add(new Label("Username:", Label.CENTER));
  t2 = new TextField("", 15);
  cfgBox.add(t2);
  cfgBox.add(new Label("Password:", Label.CENTER));
  t3 = new TextField("", 15);
  t3.setEchoChar('*');
  cfgBox.add(t3);
  cfgBox.add(new Label("SQL query:", Label.CENTER));
  t4 = new TextField("", 15);
  cfgBox.add(t4);
  cfgBox.add(ok);
  cfgBox.add(cancel);
  cfgBox.show();
 }

 // actual call to the JDBC SQL driver by GWE
 public void query_sql(String url, String user, String pass, String query)
 {
  String result = "";
  int i;
  Generic f = new Generic();
  try
  {
   Class.forName("exgwe.sql.gweMysqlDriver");
   Connection con = DriverManager.getConnection(url, user, pass);
   DatabaseMetaData dmd = con.getMetaData();
   result += "Results from database:\n\n";
   result += "Driver name: " + dmd.getDriverName() + "\n";
   result += "Database product name: " + dmd.getDatabaseProductName() + "\n";
   Statement stmt = con.createStatement();
   ResultSet rs = stmt.executeQuery(query);
   ResultSetMetaData rsmd = rs.getMetaData();
   result += "Column count: " + rsmd.getColumnCount() + "\n\n";
   while(rs.next())
   {
    for(i = 1; i <= rsmd.getColumnCount(); i++)
     result += rs.getString(i) + " ";
    result += "\n";
   }
   rs.close();
   stmt.close();
   con.close();
  } catch(Exception err)
  {
   result += "Error contacting database: " + err.getMessage() + "\n\n";
  }
  f.DISABLE_CONTROL_BOX = true;
  f.texteditor(null, result, "Database info", false, 450, 300);
 }

 // displays system info
 public void sys_info()
 {
  Runtime rt = Runtime.getRuntime();
  Generic f = new Generic();
  String result = "";
  result += "Operating system: " + System.getProperty("os.name") + "\n";
  result += "Version: " + System.getProperty("os.version") + "\n";
  result += "Architecture: " + System.getProperty("os.arch") + "\n";
  result += "User: " + System.getProperty("user.name") + " @ " + System.getProperty("user.home") + "\n";
  result += "Java VM: " + System.getProperty("java.version") + " @ " + System.getProperty("java.home") + "\n";
  result += "Java VM vendor: " + System.getProperty("java.vendor") + " @ " + System.getProperty("java.vendor.url") + "\n";
  result += "Total memory in JVM: " + rt.totalMemory() + "\n";
  result += "Free memory: " + rt.freeMemory() + "\n";
  f.DISABLE_CONTROL_BOX = true;
  f.texteditor(null, result, "System information", false, 450, 300);
 }

 // entry boxes
 private void host_info()
 {
  entry_box("Which hostname do you want to query?", "Check host", false, true);
 }

 private void user_info()
 {
  entry_box("Enter a user@hostname to query", "Check user", false, false);
 }

 private void domain_info()
 {
  entry_box("Which domain do you want to query?", "Check domain", false, false);
 }

 // calls internic to know about a domain name
 public void get_domain_info(String domain)
 {
  String line = "", result = "";
  Generic f = new Generic();
  try
  {
   sockfd = new Socket("rs.internic.net", 43);
   in = new BufferedReader(new InputStreamReader(sockfd.getInputStream()));
   out = new PrintWriter(sockfd.getOutputStream(), true);
  }
  catch(Exception err)
  {
   f.msgbox("Can't connect to rs.internic.net", "Error", true);
   print_debug(err.getMessage());
   return;
  }
  try
  {
   out.println(domain);
   while((line = in.readLine()) != null)
   {
    result += line + "\n";
   }
   f.DISABLE_CONTROL_BOX = true;
   f.texteditor(null, result, "Domain info", false, 450, 300);
  }
  catch(Exception err)
  {
   f.msgbox("Can't connect to rs.internic.net", "Error", true);
   print_debug(err.getMessage());
   return;
  }
 }

 // fingers a host for user info (could it do a listing ie. @host ?)
 public void get_user_info(String str)
 {
  String line = "", result = "";
  Generic f = new Generic();
  try
  {
   sockfd = new Socket(f.lindex(str, 1, "@"), 79);
   in = new BufferedReader(new InputStreamReader(sockfd.getInputStream()));
   out = new PrintWriter(sockfd.getOutputStream(), true);
  }
  catch(Exception err)
  {
   f.msgbox("Can't connect to remote host", "Error", true);
   print_debug(err.getMessage());
   return;
  }
  try
  {
   out.println(f.lindex(str, 0, "@"));
   while((line = in.readLine()) != null)
   {
    result += line + "\n";
   }
   f.DISABLE_CONTROL_BOX = true;
   f.texteditor(null, result, "User info", false, 450, 300);
  }
  catch(Exception err)
  {
   f.msgbox("Can't connect to rs.internic.net", "Error", true);
   print_debug(err.getMessage());
   return;
  }
 }

 // checks for the IP of an host, and queries host if state == true
 public void get_host_info(String host, boolean state)
 {
  Generic f = new Generic();
  String result = "Local host information:\n";
  String line = "";
  try
  {
   result += InetAddress.getLocalHost();
   result += "\n\n";
  }
  catch(Exception err)
  {
   result += "Can't get local hostname / IP.\n\n";
  }
  result += "Remote host information:\n";
  try
  {
   result += InetAddress.getByName(host);
   result += "\n\n";
  }
  catch(Exception err)
  {
   result += "Can't get remote hostname / IP.\n\n";
  }
  if(state)
  {
   long first, last;
   first = System.currentTimeMillis();
   try
   {
    sockfd = new Socket(host, 7);
    in = new BufferedReader(new InputStreamReader(sockfd.getInputStream()));
    out = new PrintWriter(sockfd.getOutputStream(), true);
    sockfd.close();
   }
   catch(Exception err) { }
   last = System.currentTimeMillis();
   result += "\nPing delay: " + (last - first) + "ms\n\n";
   try
   {
    sockfd = new Socket(host, 80);
    in = new BufferedReader(new InputStreamReader(sockfd.getInputStream()));
    out = new PrintWriter(sockfd.getOutputStream(), true);
    result += "A web server was found on that host:\n";
    out.println("HEAD / HTTP/1.0\n");
    sockfd.setTcpNoDelay(true);
    while((line = in.readLine()) != null) result += line + "\n";
    result += "\n\n";
    sockfd.close();
   }
   catch(Exception err)
   {
    result += "No web server is running on that host.\n\n";
   }
   try
   {
    sockfd = new Socket(host, 25);
    in = new BufferedReader(new InputStreamReader(sockfd.getInputStream()));
    out = new PrintWriter(sockfd.getOutputStream(), true);
    result += "An SMTP mail server was found on that host:\n";
    result += f.lrange(in.readLine(), 1);
    result += "\n\n";
    sockfd.close();
   }
   catch(Exception err)
   {
    result += "No SMTP mail server is running on that host.\n\n";
   }
   try
   {
    sockfd = new Socket(host, 110);
    in = new BufferedReader(new InputStreamReader(sockfd.getInputStream()));
    out = new PrintWriter(sockfd.getOutputStream(), true);
    result += "A POP3 mail server was found on that host:\n";
    result += f.lrange(in.readLine(), 1);
    result += "\n\n";
    sockfd.close();
   }
   catch(Exception err)
   {
    result += "No POP3 mail server is running on that host.\n\n";
   }
  }
  f.DISABLE_CONTROL_BOX = true;
  f.texteditor(null, result, "Host information", false, 450, 300);
 }

 // ask a POP server for STAT (could also do a listing here with RETR)
 public void pop_list()
 {
  String line;
  Generic f = new Generic();
  try
  {
   sockfd = new Socket(POP_SERVER, 110);
   in = new BufferedReader(new InputStreamReader(sockfd.getInputStream()));
   out = new PrintWriter(sockfd.getOutputStream(), true);
  }
  catch(Exception err)
  {
   f.msgbox("Can't connect to POP server", "Error", true);
   print_debug(err.getMessage());
   return;
  }
  try
  {
   line = in.readLine();
   if(line.charAt(0) == '-') { pop_failed(line); return; }
   out.println("USER " + USERNAME);
   line = in.readLine();
   if(line.charAt(0) == '-') { pop_failed(line); return; }
   out.println("PASS " + PASSWORD);
   line = in.readLine();
   if(line.charAt(0) == '-') { pop_failed(line); return; }
   f.msgbox(f.lrange(line, 1), "Info", false);
   sockfd.close();
  }
  catch(IOException err)
  {
   f.msgbox("Error while talking to mail server", "Error", true);
   print_debug(err.getMessage());
  }
 }

 // RETR a message number
 public void get_pop_mail(String number, boolean delete)
 {
  String line, result = "";
  Generic f = new Generic();
  try
  {
   sockfd = new Socket(POP_SERVER, 110);
   in = new BufferedReader(new InputStreamReader(sockfd.getInputStream()));
   out = new PrintWriter(sockfd.getOutputStream(), true);
  }
  catch(Exception err)
  {
   f.msgbox("Can't connect to POP server", "Error", true);
   print_debug(err.getMessage());
   return;
  }
  try
  {
   line = in.readLine();
   if(line.charAt(0) == '-') { pop_failed(line); return; }
   out.println("USER " + USERNAME);
   line = in.readLine();
   if(line.charAt(0) == '-') { pop_failed(line); return; }
   out.println("PASS " + PASSWORD);
   line = in.readLine();
   if(line.charAt(0) == '-') { pop_failed(line); return; }
   if(delete)
   {
    out.println("DELE " + number);
    if(line.charAt(0) == '-') { pop_failed(line); return; }
   }
   else
   {
    out.println("RETR " + number);
    line = in.readLine();
    if(line.charAt(0) == '-') { pop_failed(line); return; }
    while(!".".equals(line = in.readLine()))
    {
     result += line + "\n";
    }
    f.DISABLE_CONTROL_BOX = true;
    f.texteditor(null, result, "E-mail #" + number, false, 450, 300);
   }
   sockfd.close();
  }
  catch(IOException err)
  {
   f.msgbox("Error while talking to mail server", "Error", true);
   print_debug(err.getMessage());
  }
 }

 // generic error message if we saw an error code from a mail server
 public void pop_failed(String line)
 {
  Generic f = new Generic();
  f.msgbox("Error while talking to mail server", "Error", true);
  print_debug(line);
 }

 // irc client frameworks
 public void irc(String host, String port)
 {
  Generic f = new Generic();
  try
  {  
   sockfd = new Socket(host, Integer.parseInt(port));
   in = new BufferedReader(new InputStreamReader(sockfd.getInputStream()));
   out = new PrintWriter(sockfd.getOutputStream(), true);
  }
  catch(Exception err)
  {
   f.msgbox("Could not connect to remote host", "Error", false);
   print_debug(err.getMessage());
   return;
  }
  Frame ResultBox = new Frame("TCP server on " + TCP_SERVER_PORT);
  ResultText = new TextArea("Connecting...\n", 400, 300, TextArea.SCROLLBARS_VERTICAL_ONLY);
  IRC myserver = new IRC(sockfd, in, out, ResultText);
  IRCClose wc = new IRCClose(myserver);
  ResultBox.addWindowListener(new WinControl());
  ResultBox.setSize(600, 300);
  ResultBox.setLocation(50, 100);
  ResultText.setEditable(false);
  ResultBox.add(ResultText);
  ResultBox.show();
  inputBox = new Frame("Input box");
  Button okButton = new Button("Send!");
  t5 = new TextField();
  okButton.addActionListener(this);
  inputBox.addWindowListener(wc);
  inputBox.setSize(300, 50);
  inputBox.setLocation(100, 150);
  inputBox.setLayout(new GridLayout(1, 2));
  inputBox.add(t5);
  inputBox.add(okButton);
  inputBox.show();
  out.println("USER " + USERNAME + " 1 1 :NetUtils for Java");
  out.println("NICK " + USERNAME);
  myserver.start();
 }

 // send an email to the local sendmail host
 public void send_mail()
 {
  String line, tmp = "";
  Generic f = new Generic();
  try
  {
   sockfd = new Socket(OUT_SERVER, 25);
   in = new BufferedReader(new InputStreamReader(sockfd.getInputStream()));
   out = new PrintWriter(sockfd.getOutputStream(), true);
  }
  catch(Exception err)
  {
   f.msgbox("Can't connect to POP server", "Error", true);
   print_debug(err.getMessage());
   return;
  }
  try
  {
   line = in.readLine();
   if(line.charAt(0) == '5') { pop_failed(line); return; }
   out.println("HELO localhost");
   line = in.readLine();
   if(line.charAt(0) == '5') { pop_failed(line); return; }
   out.println("MAIL FROM: " + EMAIL);
   line = in.readLine();
   if(line.charAt(0) == '5') { pop_failed(line); return; }
   if(!("".equals(t1.getText())))
   { // if TO: exists
    tmp = t1.getText() + ",";
    for(int k=0; f.lindex(tmp, k, ",")!=""; k++)
    {
     out.println("RCPT TO: " + f.lindex(tmp, k, ","));
     line = in.readLine();
     if(line.charAt(0) == '5') { pop_failed(line); return; }
    }
   }
   if(!("".equals(t2.getText())))
   { // if CC: exists
    tmp = t2.getText() + ",";
    for(int k=0; f.lindex(tmp, k, ",")!=""; k++)
    {
     out.println("RCPT TO: " + f.lindex(tmp, k, ","));
     line = in.readLine();
     if(line.charAt(0) == '5') { pop_failed(line); return; }
    }
   }
   if(!("".equals(t3.getText())))
   { // if BCC: exists
    tmp = t3.getText() + ",";
    for(int k=0; f.lindex(tmp, k, ",")!=""; k++)
    {
     out.println("RCPT TO: " + f.lindex(tmp, k, ","));
     line = in.readLine();
     if(line.charAt(0) == '5') { pop_failed(line); return; }
    }
   }
   out.println("DATA");
   line = in.readLine();
   if(line.charAt(0) == '5') { pop_failed(line); return; }
   out.println("From: " + EMAIL);
   out.println("To: " + t1.getText());
   out.println("Cc: " + t2.getText());
   out.println("Date: " + f.inetdate());
   out.println("X-Mailer: CNU");
   out.println("Subject: " + t5.getText());
   out.println(textBox.getText());
   out.println(".");
   sockfd.close();
  }
  catch(IOException err)
  {
   f.msgbox("Error while talking to mail server", "Error", true);
   print_debug(err.getMessage());
  }
 }

 // compose a single-part message
 private void compose_mail()
 {
  buttonWin = new Frame("Control box");
  textWin = new Frame("Compose text");
  textBox = new TextArea("\n\n"+SIGNATURE, 600, 400, TextArea.SCROLLBARS_VERTICAL_ONLY);
  Button send = new Button("Send message");
  Button canc = new Button("Cancel message");
  textWin.addWindowListener(new WinControl());
  buttonWin.addWindowListener(new WinControl());
  send.addActionListener(this);
  canc.addActionListener(this);
  textWin.setSize(600, 400);
  textWin.setLocation(100, 300);
  textWin.add(textBox);
  textBox.setEditable(true);
  textWin.show();
  buttonWin.setSize(400, 200);
  buttonWin.setLocation(100, 150);
  buttonWin.setLayout(new GridLayout(6, 2));
  buttonWin.add(new Label("To:", Label.CENTER));
  t1 = new TextField("", 15);
  buttonWin.add(t1);
  buttonWin.add(new Label("CC:", Label.CENTER));
  t2 = new TextField("", 15);
  buttonWin.add(t2);
  buttonWin.add(new Label("BCC:", Label.CENTER));
  t3 = new TextField("", 15);
  buttonWin.add(t3);
  buttonWin.add(new Label("From:", Label.CENTER));
  t4 = new TextField(EMAIL, 15);
  buttonWin.add(t4);
  buttonWin.add(new Label("Subject:", Label.CENTER));
  t5 = new TextField("", 15);
  buttonWin.add(t5);
  buttonWin.add(send);
  buttonWin.add(canc);
  buttonWin.show();
 }

 // from settings, saves in CONFIG_FILE
 private void save_settings()
 {
  Generic f = new Generic();
  if(!("".equals(USERNAME)))
   f.filesave(CONFIG_FILE, "username: " + USERNAME + " ;", false);
  f.filesave(CONFIG_FILE, "location: " + X_LOCATION + " " + Y_LOCATION + " ;", true);
  if(!("".equals(OUT_SERVER)))
   f.filesave(CONFIG_FILE, "out_server: " + OUT_SERVER + " ;", true);
  if(!("".equals(POP_SERVER)))
   f.filesave(CONFIG_FILE, "pop_server: " + POP_SERVER + " ;", true);
  if(!("".equals(EMAIL)))
   f.filesave(CONFIG_FILE, "email: " + EMAIL + " ;", true);
  if(!("".equals(TEXT_EDITOR)))
   f.filesave(CONFIG_FILE, "text_editor: " + TEXT_EDITOR + " ;", true);
  if(DEBUG)
   f.filesave(CONFIG_FILE, "debug: true ;", true);
  else
   f.filesave(CONFIG_FILE, "debug: false ;", true);
 }

 // reads CONFIG_FILE
 private boolean readconfig()
 {
  Generic f = new Generic();
  String line = "";
  int c;
  try
  {
   InputStream fd = new FileInputStream(CONFIG_FILE);
   while((c=fd.read()) != -1)
   {
    if((char)c == '\n' || (char)c == '\0')
    {
      // check for known param
     if("username:".equals(f.lindex(line, 0))) USERNAME = f.lindex(line, 1);
     else if("text_editor:".equals(f.lindex(line, 0))) TEXT_EDITOR = f.lindex(line, 1);
     else if("password:".equals(f.lindex(line, 0))) PASSWORD = f.lindex(line, 1);
     else if("location:".equals(f.lindex(line, 0)))
     {
      X_LOCATION = Integer.parseInt(f.lindex(line, 1));
      Y_LOCATION = Integer.parseInt(f.lindex(line, 2));
     }
     else if("out_server:".equals(f.lindex(line, 0))) OUT_SERVER = f.lindex(line, 1);
     else if("pop_server:".equals(f.lindex(line, 0))) POP_SERVER = f.lindex(line, 1);
     else if("email:".equals(f.lindex(line, 0))) EMAIL = f.lindex(line, 1);
     else if("debug:".equals(f.lindex(line, 0)) && "true".equals(f.lindex(line, 1))) DEBUG = true;
     else if("debug:".equals(f.lindex(line, 0)) && "false".equals(f.lindex(line, 1))) DEBUG = false;
     else if("#".equals(f.lindex(line, 0))) {} // comments
     else print_debug("Warning: Unknown config line: " + line);
     line = "";
    }
    line += (char)c;
   }
  }
  catch(FileNotFoundException err)
  {
   print_debug("Warning: Config file not found");
   return false;
  }
  catch(java.io.IOException err)
  {
   print_debug("I/O exception reading config file");
   return false;
  }
  return true;
 }

 // ask for password (dependants on our entry_box with setEchoChar arg)
 private void ask_password()
 {
  entry_box("Set the password for your account (" + USERNAME + ")", "Save password", true, false);
 }

 // generic entry box with args
 public void entry_box(String question, String label, boolean hide, boolean check)
 {
  dialogWin = new Frame("Question");
  Label theMessage = new Label(question, Label.CENTER);
  Button okButton = new Button(label);
  if(check) checkBox = new Checkbox("Show details", true);
  t2 = new TextField();
  if(hide) t2.setEchoChar('*');
  okButton.addActionListener(this);
  dialogWin.addWindowListener(new WinControl());
  if(check) dialogWin.setSize(question.length()*10, 160);
  else dialogWin.setSize(question.length()*10, 120);
  dialogWin.setLocation(100, 150);
  if(check) dialogWin.setLayout(new GridLayout(4, 1));
  else dialogWin.setLayout(new GridLayout(3, 1));
  dialogWin.add(theMessage);
  dialogWin.add(t2);
  if(check) dialogWin.add(checkBox);
  dialogWin.add(okButton);
  dialogWin.show();
 }

 // main menu created here
 private void makegui()
 {
  java_version = System.getProperty("java.version");
  mainWin = new Frame("Ready.");
  action = new Choice();
  mainWin.addWindowListener(new Exit());
  action.addItemListener(this);
  mainWin.setSize(270, 60);
  action.addItem("*** Compact Networking Utilities ***");
  action.addItem("  Change settings");
  action.addItem("  Change password");
  action.addItem("  Quit the program");
  action.addItem("Generic utilities:");
  action.addItem("  System information");
  action.addItem("  Text editor");
  action.addItem("  Run binary");
  action.addItem("Network utilities:");
  action.addItem("  Host information");
  action.addItem("  User information");
  action.addItem("  Domain information");
  action.addItem("In:");
  action.addItem("  Check e-mails (POP3)");
  action.addItem("  Read a message (POP3)");
  action.addItem("  Delete a message (POP3)");
  action.addItem("  Simple server (TCP)");
  action.addItem("  Simple echo server (UDP)");
  action.addItem("Out:");
  action.addItem("  Send mail (SMTP)");
  action.addItem("  Simple client (IRC)");
  action.addItem("  Create packet (UDP)");
  action.addItem("  Telnet session");
  action.addItem("Database:");
  action.addItem("  Send a query (SQL)");
  action.addItem("Help:");
  action.addItem("  About");
  action.addItem("  User manual");
  mainWin.add(action);
  mainWin.setLocation(X_LOCATION, Y_LOCATION);
  mainWin.show();
  if("".equals(PASSWORD)) ask_password();
 }

 // entry point
 public static void main(String[] args)
 {
  CNU cmc = new CNU();
  if(args.length>1) CONFIG_FILE = args[1];
  cmc.readconfig();
  cmc.makegui();
 }
}

// window state is called if you close the window
// here we want to quit the app
class Exit extends WindowAdapter implements WindowListener
{
 public void windowClosing(WindowEvent evt)
 {
  if(evt.getID() == WindowEvent.WINDOW_CLOSING) System.exit(0);
  else super.windowClosing(evt);
 }
}

// handles stoping the thread and closing inputBox
class IRCClose extends WindowAdapter implements WindowListener
{
 private IRC thread = null;

 public IRCClose(IRC thread)
 {
  this.thread = thread;
 }

 public void windowClosing(WindowEvent evt)
 {
  if(evt.getID() == WindowEvent.WINDOW_CLOSING)
  {
   thread.interrupt();
   evt.getWindow().dispose();
  }
  else super.windowClosing(evt);
 }
}

// create an UDP echo server
class UDPServer extends Thread
{
 private TextArea output = null;
 private int port = 0;
 public int DATA_SIZE = 1024;

 public UDPServer(TextArea output, int port)
 {
  this.output = output;
  this.port = port;
 }

 public void run()
 {
  DatagramPacket packet = null;
  byte[] data;
  InetAddress remote_addr;
  int remote_port = 0;
  DatagramSocket sockfd = null;
  try
  {
   sockfd = new DatagramSocket(port);
  } catch(Exception err)
  {
   output.append("\nError: " + err.getMessage() + "\n");
   this.interrupt();
   return;
  }
  while(true)
  {
   data = new byte[DATA_SIZE];
   packet = new DatagramPacket(data, DATA_SIZE);
   output.append("Waiting for a packet...\n");
   try
   {
    sockfd.receive(packet);
    remote_addr = packet.getAddress();
    remote_port = packet.getPort();
    output.append("Packet received from: " + remote_addr + ":" + remote_port + "\n");
    output.append("Packet is: " + (new String(data,0,packet.getLength())) + "\n\n");
    packet = new DatagramPacket(data, DATA_SIZE, remote_addr, remote_port);
    sockfd.send(packet);
   }
   catch(Exception err)
   {
    output.append("\nError: " + err.getMessage() + "\n");
    this.interrupt();
    return;
   }
  }//while
 }
}

// create a single-threaded TCP server
class TCPServer extends Thread
{
 private int port = 0;
 private TextArea output = null;

 public TCPServer(TextArea output, int port)
 {
  this.output = output;
  this.port = port;
 }

 public void run()
 {
  String line = "";
  ServerSocket tcp = null;
  Socket client = null;
  BufferedReader in = null;
  PrintWriter out = null;
  output.append("Waiting for connections...\n");
  while(true)
  {
   try
   {
    tcp = new ServerSocket(port);
    tcp.setSoTimeout(100000);
    client = tcp.accept();
    client.setSoTimeout(10000);
    in = new BufferedReader(new InputStreamReader(client.getInputStream()));
    out = new PrintWriter(client.getOutputStream(), true);
    output.append("Connection from: " + client.getInetAddress() + "\n");
   } catch(Exception err)
   {
    output.append("\n\nError: " + err.getMessage() + "\ngiving up...\n\n");
    this.interrupt();
    return;
   }
   try
   {
    while((line = in.readLine()) != "") output.append(line + "\n");
   } catch(Exception err)
   {
    output.append("Timeout...\n\n");
   }
   try
   {
    output.append("Closing connection...\n\n");
    client.close();
    tcp.close();
   } catch(Exception err)
   {
    output.append("\n\nError: " + err.getMessage() + "\ngiving up...\n\n");
    this.interrupt();
    return;
   }
  }//while
 }
}

// IRC client that understands most IRC standard codes
class IRC extends Thread
{
 private Generic f = new Generic();
 private Socket sockfd = null;
 private BufferedReader in = null;
 private PrintWriter out = null;
 private boolean connected = true;
 private String remote_server = "";
 private TextArea output = null;

 IRC(Socket sockfd, BufferedReader in, PrintWriter out, TextArea output)
 {
  this.sockfd = sockfd;
  this.in = in;
  this.out = out;
  this.output = output;
 }

 public void run()
 {
  String input = "";
  output.append("MAIN IRC COMMANDS: privmsg, join, part, nick, notice\n");
  try
  {
   while(true)
   {
    input = in.readLine();
    if(input == null)
    {
     output.append("Remote host has closed the connection\n");
     this.connected = false;
     this.interrupt();
     return;
    }
    if(!parse_command(input)) output.append(input + "\n");
   }
  }
  catch(Exception err)
  {
   output.append("Remote host has closed the connection");
   this.connected = false;
   this.interrupt();
   return;
  }
 }

 private boolean parse_command(String line)
 {
  String command = f.lindex(line, 0).toUpperCase();
  if("PING".equals(command)) out.println("PONG " + f.lindex(line, 1));
  else if("ERROR".equals(command))
  {
   output.append("Error from IRC server: " + f.lrange(line, 1));
   this.connected = false;
   this.interrupt();
   return false;
  }
  else if(remote_server.equals(command))
  { // server commands
   String subcommand = f.lindex(line, 1).toUpperCase();
   if("433".equals(subcommand)) output.append("Nick already in used!\n");
   else if("372".equals(subcommand)) {}
   else if("376".equals(subcommand)) {}
   else if("375".equals(subcommand)) {}
   else if("002".equals(subcommand)) {}
   else if("003".equals(subcommand)) {}
   else if("004".equals(subcommand)) {}
   else if("366".equals(subcommand)) {}
   else if("353".equals(subcommand)) output.append("Names for this channel are " + f.lrange(line, 5) + "\n");
   else output.append(f.lrange(line, 1) + "\n");
  }
  else if(command.charAt(0) == ':')
  { // users commands
   String subcommand = f.lindex(line, 1).toUpperCase();
   if("001".equals(subcommand)) remote_server = command;
   else if("433".equals(subcommand)) out.println("NICK cnu_" + (int)(Math.random()*999));
   else if("NICK".equals(subcommand)) output.append(f.lindex(line, 0) + " changed nick to: " + f.lindex(line, 2) + "\n");
   else if("PRIVMSG".equals(subcommand)) output.append(f.lindex(line, 0) + ": " + f.lrange(line, 2) + "\n");
   else if("NOTICE".equals(subcommand)) output.append("-" + f.lindex(line, 0) + ":- " + f.lrange(line, 2) + "\n");
   else output.append(line + "\n");
  }
  else return false;
  return true;
 }
}

