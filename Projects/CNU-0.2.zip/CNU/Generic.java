// Generic Classes Extension (see devplanet.fastethernet.net)
// provided under the GNU Public License (see file COPYING)
// (C) 1998 Patrick Lambert <drow@darkelf.net>

import java.text.SimpleDateFormat;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

class Generic implements ActionListener
{
 //
 // Private variables
 //
 private final double generic_ver = 0.05;
 private String filename = "";
 private Frame mainWin = null, textWin = null;
 private TextArea textBox = null;
 private Dialog dialogWin = null;
 private TextField entryBox = null;
 private final String[] days =
 { "", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
 private final String[] months =
 { "", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

 //
 // Public variables
 //

 // set this to true to quit rather than dispose of AWT boxes
 public boolean DISPOSE_EQUALS_QUIT = false; // OBSOLETE
 public boolean DISPOSE_EQUALS_QUIT_MSGBOX = false; // OBSOLETE
 public boolean DISPOSE_EQUALS_QUIT_TEXTEDITOR = false; // OBSOLETE
 // set this to true to disable the control box for the editor
 public boolean DISABLE_CONTROL_BOX = false;
 // X and Y location of windows
 public int DEFAULT_WINDOW_LOCATION_X = 100;
 public int DEFAULT_WINDOW_LOCATION_Y = 100;
 // Generic editors labels
 public String LABEL_CLEAR_TEXT = "Clear text";
 public String LABEL_SAVE_FILE = "Save file";
 public String LABEL_LOAD_FILE = "Load file";
 public String LABEL_CLOSE_EDITOR = "Close editor";
 // Flag set by graphical functions as to the state of the display
 public boolean DISPLAY_STATE = false;
 // Entry box returns input text in this string
 public String result = null;

 //
 // Private methods
 //

 // main: This class cannot be called directly
 public static void main(String[] args)
 {
  System.out.println("Generic Classes Extension");
  System.out.println("Cannot run this class as stand-alone.");
 }

 // Constructor: Will contain init features
 public void Generic()
 {
 }

 // Callback: What's called after an AWT event
 public void actionPerformed(ActionEvent evt)
 {
  String line = "", result = "";
  if(evt.getActionCommand().equals("Close"))
  {
   DISPLAY_STATE = false;
   if(DISPOSE_EQUALS_QUIT == false && DISPOSE_EQUALS_QUIT_MSGBOX == false)
    dialogWin.dispose();
   else System.exit(0);
  }
  if(evt.getActionCommand().equals(LABEL_CLOSE_EDITOR))
  {
   DISPLAY_STATE = false;
   if(DISPOSE_EQUALS_QUIT == false && DISPOSE_EQUALS_QUIT_TEXTEDITOR == false)
   {
    if(DISABLE_CONTROL_BOX == false) mainWin.dispose();
    textWin.dispose();
   }
   else System.exit(0);
  }
  if(evt.getActionCommand().equals(LABEL_LOAD_FILE))
  {
   FileDialog fDialog = new FileDialog(new Frame(), "Select file", FileDialog.LOAD);
   fDialog.show();
   filename = fDialog.getDirectory() + fDialog.getFile();
   textBox.setText(load_file(filename));
   mainWin.setTitle("Filename: " + filename);
  }
  if(evt.getActionCommand().equals("OK"))
  {
   result = entryBox.getText();
   DISPLAY_STATE = false;
   dialogWin.dispose();
  }
  if(evt.getActionCommand().equals(LABEL_CLEAR_TEXT))
  {
   textBox.setText("");
  }
  if(evt.getActionCommand().equals(LABEL_SAVE_FILE))
  {
   try
   {
    //BufferedWriter fd = new BufferedWriter(new FileWriter(filename));
    //fd.write(textBox.getText(), 0, textBox.getText().length()-1);
    OutputStream fd = new FileOutputStream(filename);
    for(int i=0;(textBox.getText().length()-1)!=i;i++)
    {
     fd.write(textBox.getText().charAt(i));
    }
    fd.close();
   }
   catch(FileNotFoundException err)
   {
    System.err.println("File not found: " + err.getMessage());
   }
   catch(java.io.IOException err)
   {
    System.err.println("I/O Exception: " + err.getMessage());
   }
  }
 }

 private String load_file(String file)
 {
  String line = "", c = "";
  try
  {
   BufferedReader fd = new BufferedReader(new FileReader(file));
   while((c=fd.readLine()) != null)
   {
    line += c;
    line += "\n";
   }
  }
  catch(FileNotFoundException err)
  {
   System.err.println("File not found: " + err.getMessage());
  }
  catch(java.io.IOException err)
  {
   System.err.println("I/O Exception: " + err.getMessage());
  }
  return line;
 }

 //
 // Public methods
 //

 // filesave: Saves a line to a file
 public void filesave(String file, String line, boolean appendfile)
 {
  try
  {
   OutputStream fd = new FileOutputStream(file, appendfile);
   for(int i=0;(line.length())!=i;i++)
   {
    fd.write(line.charAt(i));
   }
   fd.write('\n');
   fd.close();
  }
  catch(FileNotFoundException err)
  {
   System.err.println("File not found: " + err.getMessage());
  }
  catch(java.io.IOException err)
  {
   System.err.println("I/O Exception: " + err.getMessage());
  }
 }

 // inetdate: return an Internet compatible GMT date
 public String inetdate()
 {
  Generic f = new Generic();
  Calendar blah = new GregorianCalendar();
  SimpleDateFormat fmt = new SimpleDateFormat("dd MM yyyy hh:mm:ss");
  String tmp = fmt.format(new Date());
  return (days[blah.get(Calendar.DAY_OF_WEEK)] + ", " + f.lindex(tmp,0) + " " + months[Integer.parseInt(f.lindex(tmp,1))] + " " + f.lrange(tmp,2) + " GMT");
 }

 // fileread: Reads a line from a file
 public String fileread(String file, int position)
 {
  String line = "";
  int c, currentPosition = 0;
  try
  {
   InputStream fd = new FileInputStream(file);
   while((c=fd.read()) != -1)
   {
    if((char)c == '\n' || (char)c == '\0')
    {
     if(currentPosition == position) return line;
     line = "";
     currentPosition++;
    }
    line += (char)c;
   }
  }
  catch(FileNotFoundException err)
  {
   System.err.println("File not found: " + err.getMessage());
  }
  catch(java.io.IOException err)
  {
   System.err.println("I/O Exception: " + err.getMessage());
  }
  return "";
 }

 // msgbox: Provides an AWT message box
 public void msgbox(String msg, String topic, boolean exclusive)
 {
  DISPLAY_STATE = true;
  Frame parent = new Frame();
  dialogWin = new Dialog(parent, topic, exclusive);
  Label theMessage = new Label(msg, Label.CENTER);
  Button closeButton = new Button("Close");
  closeButton.addActionListener(this);
  dialogWin.addWindowListener(new WinControl());
  dialogWin.setSize(msg.length()*10, 100);
  dialogWin.setLocation(DEFAULT_WINDOW_LOCATION_X, DEFAULT_WINDOW_LOCATION_Y);
  dialogWin.setLayout(new GridLayout(2, 1));
  dialogWin.add(theMessage);
  dialogWin.add(closeButton);
  dialogWin.show();
 }

 // lrange: Returns everything after pos from str
 public String lrange(String str, int pos)
 {
  int i = 0;
  String tmp = "";
  StringTokenizer st = new StringTokenizer(str);
  for(i=0; i != pos; i++)
  {
   st.nextToken();
   if(st.hasMoreTokens() == false) return "";
  }
  while(st.hasMoreTokens() != false)
  {
   tmp = tmp + st.nextToken();
   if(st.hasMoreTokens() != false) tmp = tmp + " ";
  }
  return tmp;
 }

 // lrange: Return everything after pos from str using delim
 public String lrange(String str, int pos, String delim)
 {
  int i = 0;
  String tmp = "";
  StringTokenizer st = new StringTokenizer(str);
  for(i=0; i != pos; i++)
  {
   st.nextToken(delim);
   if(st.hasMoreTokens() == false) return "";
  }
  while(st.hasMoreTokens() != false) tmp = tmp + st.nextToken(delim) + " ";
  return tmp;
 }

 // lindex: Returns word from str at pos
 public String lindex(String str, int pos)
 {
  int i = 0;
  String tmp = "";
  StringTokenizer st = new StringTokenizer(str);
  for(i=0; i != pos; i++)
  {
   if(st.hasMoreTokens() == false) return "";
   st.nextToken();
  }
  if(st.hasMoreTokens() == false) return "";
  return st.nextToken();
 }

 // lindex: Get the word at pos from str with delim
 public String lindex(String str, int pos, String delim)
 {
  int i = 0;
  String tmp = "";
  StringTokenizer st = new StringTokenizer(str);
  for(i=0; i != pos; i++)
  {
   if(st.hasMoreTokens() == false) return "";
   st.nextToken(delim);
  }
  if(st.hasMoreTokens() == false) return "";
  return st.nextToken(delim);
 }

 // version: Returns the version number
 public double version()
 {
  return generic_ver;
 }

 // sysinfo: Prints system information to stdout
 public void sysinfo()
 {
  System.out.println("Operating system: " + System.getProperty("os.name"));
  System.out.println("Version: " + System.getProperty("os.version"));
  System.out.println("Architecture: " + System.getProperty("os.arch"));
  System.out.println("User: " + System.getProperty("user.name") + " @ " + System.getProperty("user.home"));
  System.out.println("Java VM: " + System.getProperty("java.version") + " @ " + System.getProperty("java.home"));
  System.out.println("Java VM vendor: " + System.getProperty("java.vendor") + " @ " + System.getProperty("java.vendor.url"));
 }

 // date: Returns the date and time
 public String date()
 {
  SimpleDateFormat fmt = new SimpleDateFormat("EEE MMM dd hh:mm:ss z yyyy");
  return fmt.format(new Date());
 }

 // longdate: Returns the full date and time in long format
 public String longdate()
 {
  SimpleDateFormat fmt = new SimpleDateFormat("EEEE MMMM dd yyyy zzzz GGGG '('yyyy'/'MM'/'dd')' hh:mm:ss aaaa");
  return fmt.format(new Date());
 }

 // toString: Converts an int into a string
 public String toString(int i)
 {
  return Integer.toString(i);
 }

 // toInt: Converts a String to an int
 public int toInt(String str)
 {
  return Integer.parseInt(str);
 }

 // texteditor: Simple text editor
 public void texteditor(String file, String text, String topic, boolean editable, int x, int y)
 {
  DISPLAY_STATE = true;
  mainWin = new Frame("Filename: " + file);
  textWin = new Frame(topic);
  textBox = new TextArea(text, x, y, TextArea.SCROLLBARS_VERTICAL_ONLY);
  Button newButton = new Button(LABEL_CLEAR_TEXT);
  Button loadButton = new Button(LABEL_LOAD_FILE);
  Button saveButton = new Button(LABEL_SAVE_FILE);
  Button quitButton = new Button(LABEL_CLOSE_EDITOR);
  filename = file;
  mainWin.addWindowListener(new WinControl());
  textWin.addWindowListener(new WinControl());
  textWin.setSize(x, y);
  textWin.setLocation(DEFAULT_WINDOW_LOCATION_X, DEFAULT_WINDOW_LOCATION_Y);
  textWin.add(textBox);
  textBox.setEditable(editable);
  textWin.show();
  mainWin.setSize(100, 150);
  mainWin.setLayout(new GridLayout(4, 1));
  newButton.addActionListener(this);
  loadButton.addActionListener(this);
  saveButton.addActionListener(this);
  quitButton.addActionListener(this);
  mainWin.add(newButton);
  mainWin.add(loadButton);
  mainWin.add(saveButton);
  mainWin.add(quitButton);
  mainWin.setLocation(1, 1);
  if(DISABLE_CONTROL_BOX == false) mainWin.show();
 }

 // userinput: Ask user for input
 public String userinput(String msg)
 {
  BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
  System.out.print(msg);
  System.out.print(" ");
  System.out.flush();
  try
  {
   return stdin.readLine();
  }
  catch(IOException err)
  {
   System.err.println("I/O Exception: " + err.getMessage());
   return "";
  }
 }

 // entrybox: Asks for input from a graphical box
 public void entrybox(String topic, String label)
 {
  DISPLAY_STATE = true;
  Frame parent = new Frame();
  dialogWin = new Dialog(parent, topic, true);
  Label theMessage = new Label(label, Label.CENTER);
  Button okButton = new Button("OK");
  entryBox = new TextField();
  okButton.addActionListener(this);
  dialogWin.addWindowListener(new WinControl());
  dialogWin.setSize(label.length()*10, 125);
  dialogWin.setLocation(DEFAULT_WINDOW_LOCATION_X, DEFAULT_WINDOW_LOCATION_Y);
  dialogWin.setLayout(new GridLayout(3, 1));
  dialogWin.add(theMessage);
  dialogWin.add(entryBox);
  dialogWin.add(okButton);
  dialogWin.show();
 }

 // translate a word into a long
 public long wtol(String word)
 {
  int pos = 1;
  long result = 0;
  long current = 0;
  for(int i = 0; i<word.length(); i++)
  {
   current = (int)word.charAt(i) - 32;
   result = result + current * pos;
   pos = pos * 100;
  }
  return result;
 }
}

// for window closing
class WinControl extends WindowAdapter implements WindowListener
{
 public void windowClosing(WindowEvent evt)
 {
  if(evt.getID() == WindowEvent.WINDOW_CLOSING) evt.getWindow().dispose();
  else super.windowClosing(evt);
 }
}

