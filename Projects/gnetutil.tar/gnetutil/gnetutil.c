/* Gnetutil, provided open source, created by Patrick Lambert <drow@post.com> */
#include "gnetutil.h"

int make_main_win()
{
 GtkWidget *vbox, *nb, *page, *hbox, *l;
 main_win = e_window_create("Gnetutil", 500, 300, 0, 0, exit);
 vbox = e_box_create(main_win, E_VERTICAL, 5);
 nb = e_notebook_create(vbox, E_BOTTOM);
 page = e_notebook_new_page(nb, "Lookup", "Lookup");
 hbox = e_box_create(page, E_HORIZONTAL, 5);
 l = gtk_label_new("Hostname:");
 gtk_box_pack_start(GTK_BOX(hbox), l, FALSE, FALSE, 0);
 gtk_widget_show(l);
 lookup_host = e_entry_create(hbox, "localhost");
 e_button_fixed(hbox, "Lookup", fct_lookup_run);
 lookup_textbox = e_text_create(page, FALSE, "", E_NO_FUNC);
 page = e_notebook_new_page(nb, "Traceroute", "Traceroute");
 hbox = e_box_create(page, E_HORIZONTAL, 5);
 l = gtk_label_new("Hostname:");
 gtk_box_pack_start(GTK_BOX(hbox), l, FALSE, FALSE, 0);
 gtk_widget_show(l);   
 traceroute_host = e_entry_create(hbox, "localhost");
 e_button_fixed(hbox, "Trace", fct_traceroute_run);
 traceroute_textbox = e_text_create(page, FALSE, "", E_NO_FUNC);
 page = e_notebook_new_page(nb, "Ping", "Ping");
 hbox = e_box_create(page, E_HORIZONTAL, 5);
 l = gtk_label_new("Hostname:");
 gtk_box_pack_start(GTK_BOX(hbox), l, FALSE, FALSE, 0);
 gtk_widget_show(l);
 ping_host = e_entry_create(hbox, "localhost");
 e_button_fixed(hbox, "Ping", fct_ping_run);
 ping_textbox = e_text_create(page, FALSE, "", E_NO_FUNC);
 return 0;
}

int main(int argc, char *argv[])
{
 gtk_init(&argc, &argv);
 if(make_main_win()!=-1) gtk_main();
 return 0;
}
