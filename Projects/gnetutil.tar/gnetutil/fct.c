/* Gnetutil, provided open source, created by Patrick Lambert <drow@post.com> */
#include "gnetutil.h"

void fct_lookup_shell(char *ip)
{
 FILE *fd;
 char tmp[250];
 char buf[100];
 int i=1;
 sprintf(tmp, "host %s", ip);
 fd = popen(tmp, "r");
 if(fd==NULL)
 {
  e_text_insert(lookup_textbox, "Could not run the host command.\n\n");
  return;
 }
 while(i>0)
 {
  i = fread(buf, sizeof(char), 99, fd);
  e_text_insert(lookup_textbox, buf);
  while(gtk_events_pending()) gtk_main_iteration();
 }
 pclose(fd);
 e_text_insert(lookup_textbox, "\n\n");
}

void fct_lookup_run()
{
 char tmp[250], host[100], ip[100];
 strncpy(host, sscript_resolve_ip(e_entry_get(lookup_host)), 90);
 strncpy(ip, sscript_resolve_host(e_entry_get(lookup_host)), 90);
 if(!strcmp(host,"unknown")) strncpy(host, e_entry_get(lookup_host), 90);
 sprintf(tmp, "Host name: %s\n", host);
 e_text_insert(lookup_textbox, tmp);
 sprintf(tmp, "Internet address: %s\n\n", ip);
 e_text_insert(lookup_textbox, tmp);
 if(!strcmp(host, "unknown") || !strcmp(ip, "unknown"))
 {
  sprintf(tmp, "Could not resolve specified name.\n");
  e_text_insert(lookup_textbox, tmp); 
  return;
 }
 fct_lookup_shell(host);
}

void fct_traceroute_shell(char *ip)
{
 FILE *fd;
 char tmp[250];
 char buf[100];
 int i=1;
 sprintf(tmp, "/usr/sbin/traceroute %s 2>/dev/null", ip);
 fd = popen(tmp, "r");
 if(fd==NULL)
 {
  e_text_insert(traceroute_textbox, "Could not run the traceroute command.\n\n");
  return;
 }
 while(i>0)
 {
  i = fread(buf, sizeof(char), 99, fd);
  e_text_insert(traceroute_textbox, buf);
  while(gtk_events_pending()) gtk_main_iteration();
 }
 pclose(fd);
 e_text_insert(traceroute_textbox, "\n\n");
}

void fct_traceroute_run()
{
 char tmp[250], host[100], ip[100];
 strncpy(host, sscript_resolve_ip(e_entry_get(traceroute_host)), 90);
 strncpy(ip, sscript_resolve_host(e_entry_get(traceroute_host)), 90);
 if(!strcmp(host,"unknown")) strncpy(host, e_entry_get(traceroute_host), 90);
 sprintf(tmp, "Host name: %s\n", host);
 e_text_insert(traceroute_textbox, tmp);
 sprintf(tmp, "Internet address: %s\n\n", ip);
 e_text_insert(traceroute_textbox, tmp);
 if(!strcmp(host, "unknown") || !strcmp(ip, "unknown"))
 {
  sprintf(tmp, "Could not resolve specified name.\n");
  e_text_insert(traceroute_textbox, tmp); 
  return;
 }
 fct_traceroute_shell(ip);
}

void fct_ping_shell(char *ip)
{
 FILE *fd;
 char tmp[250];
 char buf[100];
 int i=1;
 sprintf(tmp, "/bin/ping %s -c 4", ip);
 fd = popen(tmp, "r");
 if(fd==NULL)
 {
  e_text_insert(ping_textbox, "Could not run the ping command.\n\n");
  return;
 }
 while(i>0)
 {
  i = fread(buf, sizeof(char), 99, fd);
  e_text_insert(ping_textbox, buf);
  while(gtk_events_pending()) gtk_main_iteration();
 }
 pclose(fd);
 e_text_insert(ping_textbox, "\n\n");
}

void fct_ping_run()
{
 char tmp[250], host[100], ip[100];
 strncpy(host, sscript_resolve_ip(e_entry_get(ping_host)), 90);
 strncpy(ip, sscript_resolve_host(e_entry_get(ping_host)), 90);
 if(!strcmp(host,"unknown")) strncpy(host, e_entry_get(ping_host), 90);
 sprintf(tmp, "Host name: %s\n", host);
 e_text_insert(ping_textbox, tmp);
 sprintf(tmp, "Internet address: %s\n\n", ip);
 e_text_insert(ping_textbox, tmp);
 if(!strcmp(host, "unknown") || !strcmp(ip, "unknown"))
 {
  sprintf(tmp, "Could not resolve specified name.\n");
  e_text_insert(ping_textbox, tmp); 
  return;
 }
 fct_ping_shell(ip);
}
