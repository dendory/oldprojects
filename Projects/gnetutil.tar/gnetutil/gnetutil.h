/* Gnetutil, provided open source, created by Patrick Lambert <drow@post.com> */
#include <gtk/gtk.h>
#include <unistd.h>
#include "easygtk.h"
#include "sscript.h"

GtkWidget *main_win, *traceroute_textbox, *traceroute_host, *ping_host, *ping_textbox, *lookup_host, *lookup_textbox;

void fct_traceroute_run();
void fct_ping_run();
void fct_lookup_run();