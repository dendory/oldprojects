/* (C) 1998 Patrick Lambert - http://devplanet.fastethernet.net */
/* Provided under the GPL (see www.gnu.org) */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <gtk/gtk.h>

GtkTooltips *tips;
GtkWidget *window, *label, *notebook, *button, *vbox, *vbox2, *hbox, *frame, *text, *vscrollbar, *table, *text2, *window2;
GtkWidget *e1, *e2, *e3, *e4, *e5, *e6;
FILE *fd;
char line[512], global_var[512], tmp_name[100];
