/*
 * QuickPlanning is (C) 1999 Patrick Lambert <drow@darkelf.net>
 *  and provided under the GPL license
*/

#include "qp.h"

#define VERSION "1.0"

int main(int argc, char *argv[])
{
 strncpy(home, getenv("HOME"), 100);
 sprintf(temp, "mkdir %s/.qp -m700 2>/dev/null", home);
 system(temp);
 gtk_init(&argc, &argv);
 make_gui();
 load_current_date();
 gtk_main();
 return 0;
}

char *lindex(char *input_string, int word_number)
{
 char *tokens[1024];
 static char tmpstring[1024];
 int i;
 strncpy(tmpstring,input_string,1024);
 (char *)tokens[i=0] = (char *)strtok(tmpstring, " ");
 while (((char *)tokens[++i] = (char *)strtok(NULL, " ")));
 tokens[i] = NULL;
 return(tokens[word_number]);
}

void CB_exit(GtkWidget *widget, GtkWidget *entry)
{
 if(window!=NULL)
 {
  gtk_widget_destroy(window);
  window = NULL;
 }
 exit(0);
}

void CB_about_close(GtkWidget *widget, GtkWidget *entry)
{
 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
  window2 = NULL;
 }
}

void CB_about(GtkWidget *widget, GtkWidget *entry)
{
 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
 }
 window2 = gtk_dialog_new ();
 gtk_widget_set_usize (GTK_WIDGET (window2), 400, 120);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_about_close), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), "QuickPlanning");
 gtk_container_border_width (GTK_CONTAINER (window2), 0);

 label2 = gtk_label_new ("QuickPlanning is (C) 1999 Patrick Lambert <drow@darkelf.net>\nYou can get the latest version from http://devplanet.fastethernet.net\nThis program is under the GPL license");
 gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window2)->vbox),
 label2, TRUE, TRUE, 0);
 gtk_widget_show (label2);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
 GTK_SIGNAL_FUNC(CB_about_close), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window2)->action_area),
 button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window2);
}

void CB_load_ok(GtkWidget *widget, GtkWidget *entry)
{
 sprintf(date_s, "%s%s%s", gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(eb3)->entry)), gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(eb2)->entry)), gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(eb1)->entry)));
 sprintf(date_u, "Current date: %s/%s/%s", gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(eb1)->entry)), gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(eb2)->entry)), gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(eb3)->entry)));
 gtk_label_set_text(GTK_LABEL(label), date_u);
 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
  window2 = NULL;
 }
 load_agenda_file();
}

void CB_load(GtkWidget *widget, GtkWidget *entry)
{
 GList *cbitems = NULL;
 time_t lt;
 struct tm *current;
 lt = time(NULL);
 current = localtime(&lt);

 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
 }
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
 GTK_SIGNAL_FUNC(CB_about_close), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), "Load file");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_usize (window2, 400, 300);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_container_border_width (GTK_CONTAINER (window2), 5);
 gtk_widget_show (vbox);

 table = gtk_table_new(2, 2, FALSE);
 gtk_table_set_row_spacing(GTK_TABLE(table), 0, 2);
 gtk_table_set_col_spacing(GTK_TABLE(table), 0, 2);
 gtk_box_pack_start(GTK_BOX(vbox), table, TRUE, TRUE, 0);
 gtk_widget_show(table);  

 text2 = gtk_text_new(NULL, NULL);
 gtk_text_set_word_wrap(GTK_TEXT(text2), TRUE);
 gtk_text_set_editable (GTK_TEXT (text2), TRUE);
 gtk_table_attach_defaults(GTK_TABLE(table), text2, 0, 1, 0, 1);
 gtk_widget_show(text2);

 vscrollbar = gtk_vscrollbar_new(GTK_TEXT(text)->vadj);
 gtk_table_attach(GTK_TABLE(table), vscrollbar, 1, 2, 0, 1,
 GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
 gtk_widget_show(vscrollbar);
 gtk_widget_realize(text2);             

 system("cal >/tmp/.agenda");
 fd = fopen("/tmp/.agenda", "r");
 if(fd!=NULL)
 {
  while(fgets(temp, 500, fd) != NULL)
  {
   gtk_text_insert (GTK_TEXT (text2), NULL, NULL, NULL, temp, -1);
  }
  fclose(fd);
 }

 label2 = gtk_label_new ("Enter the date you want to load:");
 gtk_box_pack_start (GTK_BOX (vbox), label2, TRUE, TRUE, 0);
 gtk_widget_show (label2);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label2 = gtk_label_new ("Day:");
 gtk_box_pack_start (GTK_BOX (hbox), label2, TRUE, TRUE, 0);
 gtk_widget_show (label2);

 cbitems = NULL;
 cbitems = g_list_append(cbitems, "1");
 cbitems = g_list_append(cbitems, "2");
 cbitems = g_list_append(cbitems, "3");
 cbitems = g_list_append(cbitems, "4");
 cbitems = g_list_append(cbitems, "5");
 cbitems = g_list_append(cbitems, "6");
 cbitems = g_list_append(cbitems, "7");
 cbitems = g_list_append(cbitems, "8");
 cbitems = g_list_append(cbitems, "9");
 cbitems = g_list_append(cbitems, "10");
 cbitems = g_list_append(cbitems, "11");
 cbitems = g_list_append(cbitems, "12");
 cbitems = g_list_append(cbitems, "13");
 cbitems = g_list_append(cbitems, "14");
 cbitems = g_list_append(cbitems, "15");
 cbitems = g_list_append(cbitems, "16");
 cbitems = g_list_append(cbitems, "17");
 cbitems = g_list_append(cbitems, "18");
 cbitems = g_list_append(cbitems, "19");
 cbitems = g_list_append(cbitems, "20");
 cbitems = g_list_append(cbitems, "21");
 cbitems = g_list_append(cbitems, "22");
 cbitems = g_list_append(cbitems, "23");
 cbitems = g_list_append(cbitems, "24");
 cbitems = g_list_append(cbitems, "25");
 cbitems = g_list_append(cbitems, "26");
 cbitems = g_list_append(cbitems, "27");
 cbitems = g_list_append(cbitems, "28");
 cbitems = g_list_append(cbitems, "29");
 cbitems = g_list_append(cbitems, "30");
 cbitems = g_list_append(cbitems, "31");

 sprintf(temp, "%d", current->tm_mday);
 eb1 = gtk_combo_new ();
 gtk_combo_set_popdown_strings (GTK_COMBO (eb1), cbitems);
 gtk_entry_set_text (GTK_ENTRY (GTK_COMBO(eb1)->entry), temp);
 gtk_box_pack_start (GTK_BOX (hbox), eb1, TRUE, TRUE, 0);
 gtk_widget_show (eb1);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label2 = gtk_label_new ("Month:");
 gtk_box_pack_start (GTK_BOX (hbox), label2, TRUE, TRUE, 0);
 gtk_widget_show (label2);                                  

 cbitems = NULL;
 cbitems = g_list_append(cbitems, "1");
 cbitems = g_list_append(cbitems, "2");
 cbitems = g_list_append(cbitems, "3");
 cbitems = g_list_append(cbitems, "4");
 cbitems = g_list_append(cbitems, "5");
 cbitems = g_list_append(cbitems, "6");
 cbitems = g_list_append(cbitems, "7");
 cbitems = g_list_append(cbitems, "8");
 cbitems = g_list_append(cbitems, "9");
 cbitems = g_list_append(cbitems, "10");
 cbitems = g_list_append(cbitems, "11");
 cbitems = g_list_append(cbitems, "12");

 sprintf(temp, "%d", (current->tm_mon+1));
 eb2 = gtk_combo_new ();
 gtk_combo_set_popdown_strings (GTK_COMBO (eb2), cbitems);
 gtk_entry_set_text (GTK_ENTRY (GTK_COMBO(eb2)->entry), temp);
 gtk_box_pack_start (GTK_BOX (hbox), eb2, TRUE, TRUE, 0);
 gtk_widget_show (eb2);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label2 = gtk_label_new ("Year:");
 gtk_box_pack_start (GTK_BOX (hbox), label2, TRUE, TRUE, 0);
 gtk_widget_show (label2);                                  

 cbitems = NULL;
 cbitems = g_list_append(cbitems, "1990");
 cbitems = g_list_append(cbitems, "1991");
 cbitems = g_list_append(cbitems, "1992");
 cbitems = g_list_append(cbitems, "1993");
 cbitems = g_list_append(cbitems, "1994");
 cbitems = g_list_append(cbitems, "1995");
 cbitems = g_list_append(cbitems, "1996");
 cbitems = g_list_append(cbitems, "1997");
 cbitems = g_list_append(cbitems, "1998");
 cbitems = g_list_append(cbitems, "1999");
 cbitems = g_list_append(cbitems, "2000");
 cbitems = g_list_append(cbitems, "2001");
 cbitems = g_list_append(cbitems, "2002");
 cbitems = g_list_append(cbitems, "2003");
 cbitems = g_list_append(cbitems, "2004");
 cbitems = g_list_append(cbitems, "2005");
 cbitems = g_list_append(cbitems, "2006");
 cbitems = g_list_append(cbitems, "2007");
 cbitems = g_list_append(cbitems, "2008");
 cbitems = g_list_append(cbitems, "2009");
 cbitems = g_list_append(cbitems, "2010");

 sprintf(temp, "%d", (current->tm_year + 1900));
 eb3 = gtk_combo_new ();
 gtk_combo_set_popdown_strings (GTK_COMBO (eb3), cbitems);
 gtk_entry_set_text (GTK_ENTRY (GTK_COMBO(eb3)->entry), temp);
 gtk_box_pack_start (GTK_BOX (hbox), eb3, TRUE, TRUE, 0);
 gtk_widget_show (eb3);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
 GTK_SIGNAL_FUNC(CB_load_ok), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window2);
}

void CB_save(GtkWidget *widget, GtkWidget *entry)
{
 sprintf(temp, "%s/.qp/%s", home, date_s);
 fd = fopen(temp, "w");
 fputs(gtk_editable_get_chars(GTK_EDITABLE (text), 0, gtk_text_get_length(GTK_TEXT(text))), fd);
 fclose(fd);
}

void load_agenda_file()
{
 sprintf(temp, "%s/.qp/%s", home, date_s);
 gtk_text_freeze(GTK_TEXT(text));
 gtk_text_set_point(GTK_TEXT(text), 0);
 gtk_text_forward_delete(GTK_TEXT(text),gtk_text_get_length(GTK_TEXT(text)));
 fd = fopen(temp, "r");
 if(fd!=NULL)
 {
  while(fgets(temp, 500, fd) != NULL)
  {
   gtk_text_insert (GTK_TEXT (text), NULL, NULL, NULL, temp, -1);
  }
  fclose(fd);
 }
 gtk_text_thaw (GTK_TEXT (text));
}

void load_current_date()
{
 time_t lt;
 struct tm *current;
 lt = time(NULL);
 current = localtime(&lt);
 sprintf(date_u, "Current date: %d/%d/%d", current->tm_mday, (current->tm_mon+1), (current->tm_year + 1900));
 gtk_label_set_text(GTK_LABEL(label), date_u);
 sprintf(date_s, "%d%d%d", (current->tm_year + 1900), (current->tm_mon+1), current->tm_mday);
 load_agenda_file();
}

void make_gui()
{
 window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect(GTK_OBJECT(window), "delete_event",
  GTK_SIGNAL_FUNC(CB_exit), &window);
 gtk_container_border_width(GTK_CONTAINER(window), 5);
 gtk_window_set_title(GTK_WINDOW(window), "QuickPlanning");

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window), vbox);
 gtk_widget_show (vbox);
 gtk_widget_set_usize(GTK_WIDGET(window), 600, 250);

 label = gtk_label_new("Current date:");
 gtk_box_pack_start(GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show(label);

 table = gtk_table_new(2, 2, FALSE);
 gtk_table_set_row_spacing(GTK_TABLE(table), 0, 2);
 gtk_table_set_col_spacing(GTK_TABLE(table), 0, 2);
 gtk_box_pack_start(GTK_BOX(vbox), table, TRUE, TRUE, 0);
 gtk_widget_show(table);

 text = gtk_text_new(NULL, NULL);
 gtk_text_set_word_wrap(GTK_TEXT(text), TRUE);
 gtk_text_set_editable (GTK_TEXT (text), TRUE);
 gtk_table_attach_defaults(GTK_TABLE(table), text, 0, 1, 0, 1);
 gtk_widget_show(text);

 vscrollbar = gtk_vscrollbar_new(GTK_TEXT(text)->vadj);
 gtk_table_attach(GTK_TABLE(table), vscrollbar, 1, 2, 0, 1,
 GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
 gtk_widget_show(vscrollbar);
 gtk_widget_realize(text);

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_SPREAD);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, FALSE, FALSE, 0);
 gtk_widget_show (hbox);

 button = gtk_button_new_with_label("Save current date");
 gtk_signal_connect_object(GTK_OBJECT (button), "clicked",
 GTK_SIGNAL_FUNC(CB_save), GTK_OBJECT (window));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label("Load an other date");
 gtk_signal_connect_object(GTK_OBJECT (button), "clicked",
 GTK_SIGNAL_FUNC(CB_load), GTK_OBJECT (window));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label("About QuickPlanning"); 
 gtk_signal_connect_object(GTK_OBJECT (button), "clicked",
 GTK_SIGNAL_FUNC(CB_about), GTK_OBJECT (window));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label("Quit program"); 
 gtk_signal_connect_object(GTK_OBJECT (button), "clicked",
 GTK_SIGNAL_FUNC(CB_exit), GTK_OBJECT (window));
 gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 gtk_widget_show(window);
}
