
#include <stdio.h>
#include <gtk/gtk.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>

GtkWidget *window, *vbox, *table, *text, *vscrollbar, *label, *hbox, *button, *label2, *window2, *eb1, *eb2, *eb3, *text2;
char home[105], temp[512], date_u[105], date_s[105];
FILE *fd;

char *lindex(char *input_string, int word_number);
void load_current_date();
void load_agenda_file();
void make_gui();
void CB_exit(GtkWidget *widget, GtkWidget *entry);
void CB_about_close(GtkWidget *widget, GtkWidget *entry);
void CB_about(GtkWidget *widget, GtkWidget *entry);
void CB_load(GtkWidget *widget, GtkWidget *entry);
void CB_load_ok(GtkWidget *widget, GtkWidget *entry);
void CB_save(GtkWidget *widget, GtkWidget *entry);
