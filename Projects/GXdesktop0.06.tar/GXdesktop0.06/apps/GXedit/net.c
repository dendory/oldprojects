/* GXedit
 * Copyright 1998 Patrick Lambert <drow@wildstar.net>
 *
 * This program is free software. You can use, copy and modify it under
 * the terms of the GPL. See the file COPYING for the full GPL license.
*/

#include "gxedit.h"
#ifdef USE_NET
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h> 
#include <stdlib.h>   
#include <netdb.h>     
#include <arpa/inet.h>

char *resolve(char *string)
{
 struct hostent *hp;
 struct sockaddr_in from;
 unsigned long dest;
 memset(&from, 0, sizeof(struct sockaddr_in));
 from.sin_family = AF_INET;
 hp=gethostbyname(string);
 if(hp==NULL) return("unknown");
 else
 {
  memcpy(&from.sin_addr,hp->h_addr,hp->h_length);
  return((char *)inet_ntoa(from.sin_addr));
 }
} 

int network_fetch(char *server, char *dir)
{
 int sockfd, len, result=1, i;
 char buf[512];
 char inchar;
 struct sockaddr_in address;
 bzero(buf, 512);
 sockfd = socket(AF_INET, SOCK_STREAM, 0);
 address.sin_family = AF_INET;
 address.sin_addr.s_addr = inet_addr(resolve(server));
 address.sin_port = htons(80);   
 len = sizeof(address);
 if(connect(sockfd, (struct sockaddr *)&address, len)==-1)
 {
  print_debug("Error in connecting to server\n");
  return -1;
 }
 sprintf(buf, "GET %s\n", dir);
 write(sockfd, buf, strlen(buf));
 gtk_text_freeze(GTK_TEXT(text));
 while(result!=0)
 {
  bzero(buf, 512);
  for(i=0;(result=read(sockfd,&inchar,1))!='\0';i++)
  {
   buf[i]=inchar;
   if(inchar=='\n') break;
   if(i==510) break;
  }
  gtk_text_insert (GTK_TEXT (text), NULL, &color, NULL, buf, -1);
 }
 gtk_text_thaw(GTK_TEXT(text));
 shutdown(sockfd, 2);
 return 0;
}

int send_email(char *to, char *from, char *subject, char *data)
{
 int sockfd, len, i;
 char buf[512];
 struct sockaddr_in address;
 sockfd = socket(AF_INET, SOCK_STREAM, 0);
 address.sin_family = AF_INET;
 address.sin_addr.s_addr = inet_addr("127.0.0.1");
 address.sin_port = htons(25);
 len = sizeof(address);
 if(connect(sockfd, (struct sockaddr *)&address, len)==-1)
 {
  print_debug("Local system is not running a mail server\n");
  msgbox("Send failed. Local system is not running a mail server.");
  return -1;
 } 
 bzero(buf, 512);
 read(sockfd, buf, sizeof(buf));
 sprintf(buf, "MAIL FROM: %s\n", from);
 write(sockfd, buf, strlen(buf));
 read(sockfd, buf, sizeof(buf));
 sprintf(buf, "RCPT TO: %s\n", to);
 write(sockfd, buf, strlen(buf));
 read(sockfd, buf, sizeof(buf));
 sprintf(buf, "DATA\n");  
 write(sockfd, buf, strlen(buf));
 read(sockfd, buf, sizeof(buf));
 sprintf(buf, "Subject: %s\n", subject);
 write(sockfd, buf, strlen(buf));
 write(sockfd, data, strlen(data));
 sprintf(buf, "\n.\nQUIT\n");
 write(sockfd, buf, strlen(buf));  
 shutdown(sockfd, 2);
}
#endif
