/* GXedit
 * Copyright 1998 Patrick Lambert <drow@wildstar.net>
 *
 * This program is free software. You can use, copy and modify it under
 * the terms of the GPL. See the file COPYING for the full GPL license.
*/

#include "config.h"
#include "xpms.h"
#include <gtk/gtk.h>
#include <stdio.h>
#define ABOUT "GXedit is a simple graphical text editor made by Patrick Lambert <drow@wildstar.net>"
#define HELP1 "GXedit User Manual\n\n"
#define HELP2 "Syntax: gxedit <file>\n\n"
#define HELP3 "GXedit is a graphical, X window text editor. It reads its configuration file from ~/.gxedit and provides a nice graphical interface (using GTK) to the user.\n\n"
#define HELP4 "The configuration file is really simple, 1 meaning yes and 0 meaning no. The available colors are black, red, blue and green.\n\n"
#define HELP5 "The menus are also simple, providing common dialog windows to open and save files, for settings, and for help.\n\n"
#define HELP6 "GXedit also has networking options. You can open a text file from the web in the File->Open menu, and you can send your current text as an e-mail to someone from the Links->Send menu.\n\n"
#define HELP7 "Also in the Links menu, you can open the current text in other popular editors: Emacs and vi.\n\n"
#define HELP8 "This program will also call Xv, or any program defined in ~/.gxedit, if you try to open a GIF, TIFF or JPEG file.\n\n"
#define HELP9 "In GXedit, you can use ctrl+c to copy text, and ctrl+v to paste it. You can also use ctrl+k to delete a line of text.\n\n"
#define HELP10 "GXedit is Copyright 1998 Patrick Lambert <drow@wildstar.net> and under GPL\n"
#define HELP11 "This means that you can use, copy and modify it if the copyright notices and the no warranty notice remain, and if the software stays under GPL.\n"
#define HELP12 "See the file COPYING for the full license.\n\n"
#define HELP13 "This program is distributed without ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n\n"
#define HELP14 "You can get the latest version of this program from http://devplanet.fastethernet.net/gxdesktop.html\n"
#define HELP15 "Feel free to mail me any comments or questions.\n"
char *lindex(char *input_string, int word_number);
char *lrange(char *input_string, int starting_at);
char filename[100], home[100], line[512], global_var[512], col_name[10];
char images[100], progname[100];
int toolbar, tooltips, x_size, y_size, x_pos, y_pos, debug, no_cfg, full_tb;
size_t TS;
GdkColormap *cmap;
GdkColor color;
GtkTooltips *tips;
GtkWidget *window, *text, *button, *table, *label, *menu, *menubutton, *hbox;
GtkWidget *menubar, *menuitem, *vscrollbar, *vbox, *window2, *text2, *sep;
GtkWidget *entry_box, *cb1, *eb1, *eb2, *eb3, *eb4, *eb5, *eb6;
GtkWidget *text_debug, *dw, *submenu, *root_tree, *root_item;
FILE *fd;
