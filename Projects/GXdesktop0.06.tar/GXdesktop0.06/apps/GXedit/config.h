#define USE_NET /* use the network commands */
#undef BG_ON_START /* go to the background on start */
