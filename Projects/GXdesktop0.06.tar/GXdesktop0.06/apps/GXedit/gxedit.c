/* GXedit
 * Copyright 1998 Patrick Lambert <drow@wildstar.net>
 *
 * This program is free software. You can use, copy and modify it under
 * the terms of the GPL. See the file COPYING for the full GPL license.
*/

#include "gxedit.h"

#define VERSION "1.04"

char *lindex(char *input_string, int word_number)
{
 char *tokens[1024];
 static char tmpstring[1024];
 int i;
 strncpy(tmpstring,input_string,1024);
 (char *)tokens[i=0] = (char *)strtok(tmpstring, " ");
 while (((char *)tokens[++i] = (char *)strtok(NULL, " ")));
 tokens[i] = NULL;
 return(tokens[word_number]);
}

char *lrange(char *input_string, int starting_at)
{
 char *tokens[1024];
 static char tmpstring[1024]="";
 int i;
 char out_string[1024]="";
 strcpy(out_string,"");
 if(input_string==NULL) {
  strcpy(out_string," ");
  strcat(out_string,NULL);   
  strcpy(global_var,out_string);
  return (char *)global_var; }
 strncpy(tmpstring,input_string,1024);
 (char *)tokens[i=0] = (char *)strtok(tmpstring, " ");
 while(((char *)tokens[++i] = (char *)strtok(NULL, " ")));
 tokens[i] = NULL;
 i++;
 if(i<starting_at)
 {
  return (char *)"";
 }
 while(tokens[starting_at] != NULL)
 {
  strncat(out_string,tokens[starting_at],1024);
  strcat(out_string, " ");
  starting_at++;  
 }   
 strncpy(global_var,out_string,511);
 return (char *)global_var;
}

int print_debug(char *string)
{
 if(debug)
 gtk_text_insert (GTK_TEXT (text_debug), NULL, &color, NULL, string, -1);
}

static gushort convert_color(unsigned c)
{
 if (c==0) return(0);
 c *= 257;
 return(c > 0xffff)? 0xffff : c;
}
 
int extract_color(GdkColor *color, unsigned red, unsigned green, unsigned blue)
{
 color->red = convert_color(red);
 color->green = convert_color(green);
 color->blue = convert_color(blue);
}

static GtkWidget *new_pixmap(int type, GdkWindow *window, GdkColor *background)
{
 GtkWidget *wpixmap;
 GdkPixmap *pixmap;
 GdkBitmap *mask;
 if(type==0)
  pixmap = gdk_pixmap_create_from_xpm_d(window, &mask, background, new_xpm);
 if(type==1)
  pixmap = gdk_pixmap_create_from_xpm_d(window, &mask, background, open_xpm);
 if(type==2)
  pixmap = gdk_pixmap_create_from_xpm_d(window, &mask, background, save_xpm);
 if(type==3)
  pixmap = gdk_pixmap_create_from_xpm_d(window, &mask, background, help_xpm);
 if(type==4)
  pixmap = gdk_pixmap_create_from_xpm_d(window, &mask, background, exit_xpm);
 if(type==5)
  pixmap = gdk_pixmap_create_from_xpm_d(window, &mask, background, copy_xpm);
 if(type==6)
  pixmap = gdk_pixmap_create_from_xpm_d(window, &mask, background, paste_xpm);
 if(type==7)
  pixmap = gdk_pixmap_create_from_xpm_d(window, &mask, background, settings_xpm);
 wpixmap = gtk_pixmap_new (pixmap, mask);
 return wpixmap;
}

int CB_msgbox_close(GtkWidget *widget, GtkWidget *entry)
{
 gtk_widget_destroy(window2);
 window2 = NULL;
}

int CB_awk_callbacks(GtkWidget *widget, GtkWidget *entry)
{
 fd = fopen("/tmp/.gxedit.tmp", "w");
 if(fd==NULL)
 {
  msgbox("Can't open temporary file");
  return;
 }
 fputs((char *)gtk_editable_get_chars(GTK_EDITABLE (text), 0, gtk_text_get_length(GTK_TEXT(text))),fd);
 if(fd!=NULL) fclose(fd);
 sprintf(line, "awk '%s' /tmp/.gxedit.tmp > /tmp/.gxedit.result", gtk_entry_get_text(GTK_ENTRY(entry_box)));
 system(line);
 fd = fopen("/tmp/.gxedit.result", "r");
 if(fd==NULL)
 {
  msgbox("Can't open temporary file");
  return;
 }
 gtk_text_set_point(GTK_TEXT(text), 0);
 gtk_text_forward_delete(GTK_TEXT(text), gtk_text_get_length(GTK_TEXT(text)));
 gtk_text_freeze(GTK_TEXT(text));
 while(fgets(line,255,fd)!=NULL)
 {
  gtk_text_insert (GTK_TEXT (text), NULL, &color, NULL, line, -1);
 }
 fclose(fd);
 gtk_text_thaw(GTK_TEXT(text));
 system("rm -f /tmp/.gxedit*");
 gtk_widget_destroy(window2);
}

int CB_awk(GtkWidget *widget, GtkWidget *entry)
{
 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
 }
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_msgbox_close), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_msgbox_close), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), "Scripting");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_uposition (window2, (x_pos+100), (y_pos+100));

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_container_border_width (GTK_CONTAINER (window2), 5);
 gtk_widget_show (vbox);

 label = gtk_label_new ("Enter an awk command line:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 entry_box = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (entry_box), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), entry_box, TRUE, TRUE, 0);
 gtk_widget_show (entry_box);
 
 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_awk_callbacks), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window2);
}

int msgbox(char *string)
{
 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
 }
 window2 = gtk_dialog_new ();
 gtk_widget_set_usize (GTK_WIDGET (window2), strlen(string)+400, 100);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_msgbox_close), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_msgbox_close), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), "GXedit");
 gtk_container_border_width (GTK_CONTAINER (window2), 0);
 gtk_widget_set_uposition (window2, (x_pos+50), (y_pos+50));
 
 label = gtk_label_new (string);
 gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window2)->vbox),
  label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_msgbox_close), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window2)->action_area),
  button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window2);
}

int CB_new_gxedit(GtkWidget *widget, GtkWidget *entry)
{
 sprintf(line, "%s &", progname);
 system(line);
}

int CB_close_debug(GtkWidget *widget, GtkWidget *entry)
{
 debug = 0;
 gtk_widget_destroy(dw);
}

int CB_open_cancel(GtkWidget *widget, GtkFileSelection *fs)
{
 gtk_widget_destroy(window2);
 window2 = NULL;
}

int CB_bytes_count(GtkWidget *widget, GtkWidget *entry)
{
 sprintf(line, "Number of bytes:  %d", gtk_text_get_length(GTK_TEXT(text)));
 msgbox(line);
}

int CB_words_count(GtkWidget *widget, GtkWidget *entry)
{
 int i;
 fd = fopen("/tmp/.gxedit.count.tmp", "w");
 if(fd==NULL)
 {
  msgbox("Can't open temporary file");
  return ;
 }
 fputs((char *)gtk_editable_get_chars(GTK_EDITABLE (text), 0, gtk_text_get_length(GTK_TEXT(text))),fd);
 if(fd!=NULL) fclose(fd);
 system("cat /tmp/.gxedit.count.tmp |wc -l > /tmp/.gxedit.result");
 fd = fopen("/tmp/.gxedit.result", "r");
 fgets(line,255,fd);
 for(i=0;lindex(gtk_editable_get_chars(GTK_EDITABLE (text), 0, gtk_text_get_length(GTK_TEXT(text))),i)!=NULL;i++) { }
 sprintf(global_var, "Number of words:  %d", (i+atoi(line)));
 msgbox(global_var);
}

int CB_lines_count(GtkWidget *widget, GtkWidget *entry)
{
 fd = fopen("/tmp/.gxedit.count.tmp", "w");
 if(fd==NULL)
 {
  msgbox("Can't open temporary file");
  return ;
 }
 fputs((char *)gtk_editable_get_chars(GTK_EDITABLE (text), 0, gtk_text_get_length(GTK_TEXT(text))),fd);
 if(fd!=NULL) fclose(fd);
 system("cat /tmp/.gxedit.count.tmp |wc -l > /tmp/.gxedit.result");
 fd = fopen("/tmp/.gxedit.result", "r");
 fgets(line,255,fd);
 sprintf(global_var, "Number of lines: %s", line);
 msgbox(global_var);
 system("rm -f /tmp/.gxedit*");
}

int CB_copy(GtkWidget *widget, GtkWidget *entry)
{
 gtk_editable_copy_clipboard (GTK_EDITABLE(text), TS);
}

int CB_paste(GtkWidget *widget, GtkWidget *entry)
{
 gtk_editable_paste_clipboard (GTK_EDITABLE(text), TS);
}

int CB_spell(GtkWidget *widget, GtkWidget *entry)
{
 fd = fopen("/tmp/.gxedit.tmp", "w");
 if(fd==NULL)
 {
  msgbox("Can't open temporary file");
  return;
 }
 fputs((char *)gtk_editable_get_chars(GTK_EDITABLE (text), 0, gtk_text_get_length(GTK_TEXT(text))),fd);
 if(fd!=NULL) fclose(fd);
 system("xterm -e ispell /tmp/.gxedit.tmp");
 fd = fopen("/tmp/.gxedit.tmp", "r");
 if(fd==NULL)
 {
  msgbox("Can't open temporary file");
  return;
 }
 gtk_text_set_point(GTK_TEXT(text), 0);
 gtk_text_forward_delete(GTK_TEXT(text), gtk_text_get_length(GTK_TEXT(text)));
 gtk_text_freeze(GTK_TEXT(text));
 while(fgets(line,255,fd)!=NULL)
 {
  gtk_text_insert (GTK_TEXT (text), NULL, &color, NULL, line, -1);
 }
 fclose(fd);
 gtk_text_thaw(GTK_TEXT(text));
 system("rm -f /tmp/.gxedit*");
}

int CB_settings_save(GtkWidget *widget, GtkWidget *entry)
{
 sprintf(line, "%s/.gxedit", home);
 fd = fopen(line, "w");
 if(fd==NULL) print_debug("Can't open config file\n");
 fputs("# This is the configuration file for GXedit\n", fd);
 sprintf(line, "toolbar: %d\n", toolbar);
 fputs(line, fd);
 sprintf(line, "tooltips: %d\n", tooltips);
 fputs(line, fd);
 sprintf(line, "debug: %d\n", debug);
 fputs(line, fd);
 sprintf(line, "x_size: %s\n", gtk_entry_get_text(GTK_ENTRY(eb1)));
 fputs(line, fd);
 sprintf(line, "y_size: %s\n", gtk_entry_get_text(GTK_ENTRY(eb2)));
 fputs(line, fd);
 sprintf(line, "full_toolbar: %d\n", full_tb);
 fputs(line, fd);
 sprintf(line, "x_position: %s\n", gtk_entry_get_text(GTK_ENTRY(eb3)));
 fputs(line, fd);
 sprintf(line, "y_position: %s\n", gtk_entry_get_text(GTK_ENTRY(eb4)));
 fputs(line, fd);
 sprintf(line, "color: %s\n", gtk_entry_get_text(GTK_ENTRY(eb5)));
 fputs(line, fd);
 sprintf(line, "images: %s\n", gtk_entry_get_text(GTK_ENTRY(eb6)));
 fputs(line, fd);
 if(fd!=NULL) fclose(fd);
 gtk_widget_destroy(window2);
 window2 = NULL;
}

int CB_settings_toolbar(GtkWidget *widget, GtkWidget *entry)
{
 toolbar = GTK_TOGGLE_BUTTON(widget)->active;
}

int CB_settings_toolbar_full(GtkWidget *widget, GtkWidget *entry)
{
 full_tb = GTK_TOGGLE_BUTTON(widget)->active;
}

int CB_settings_debug(GtkWidget *widget, GtkWidget *entry)
{
 debug = GTK_TOGGLE_BUTTON(widget)->active;
}

int CB_settings_tooltips(GtkWidget *widget, GtkWidget *entry)
{
 tooltips = GTK_TOGGLE_BUTTON(widget)->active;   
}

int CB_settings(GtkWidget *widget, GtkWidget *entry)
{
 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
 }
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_open_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_open_cancel), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), "Settings");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_uposition (window2, (x_pos+100), (y_pos+100));

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 5);
 gtk_widget_show (vbox);

 cb1 = gtk_check_button_new_with_label("Show toolbar");
 gtk_signal_connect (GTK_OBJECT(cb1), "toggled",
  GTK_SIGNAL_FUNC(CB_settings_toolbar), cb1);
 gtk_box_pack_start (GTK_BOX (vbox), cb1, TRUE, TRUE, 0);
 if(toolbar) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(cb1), TRUE);
 gtk_widget_show (cb1);

 cb1 = gtk_check_button_new_with_label("Full toolbar");
 gtk_signal_connect (GTK_OBJECT(cb1), "toggled",
  GTK_SIGNAL_FUNC(CB_settings_toolbar_full), cb1);
 gtk_box_pack_start (GTK_BOX (vbox), cb1, TRUE, TRUE, 0);
 if(full_tb) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(cb1), TRUE);
 gtk_widget_show (cb1);

 cb1 = gtk_check_button_new_with_label("Show tooltips");
 gtk_signal_connect (GTK_OBJECT(cb1), "toggled",
  GTK_SIGNAL_FUNC(CB_settings_tooltips), cb1);
 gtk_box_pack_start (GTK_BOX (vbox), cb1, TRUE, TRUE, 0);
 if(tooltips) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(cb1), TRUE);
 gtk_widget_show (cb1);

 cb1 = gtk_check_button_new_with_label("Show debug window");
 gtk_signal_connect (GTK_OBJECT(cb1), "toggled",
  GTK_SIGNAL_FUNC(CB_settings_debug), cb1);
 gtk_box_pack_start (GTK_BOX (vbox), cb1, TRUE, TRUE, 0);
 if(debug) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(cb1), TRUE);
 gtk_widget_show (cb1);

 label = gtk_label_new ("X size of the main window:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 eb1 = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (eb1), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb1, TRUE, TRUE, 0);
 sprintf(line, "%d", x_size);
 gtk_entry_set_text (GTK_ENTRY (eb1), line);
 gtk_widget_show (eb1);

 label = gtk_label_new ("Y size of the main window:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 eb2 = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (eb2), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb2, TRUE, TRUE, 0);
 sprintf(line, "%d", y_size);
 gtk_entry_set_text (GTK_ENTRY (eb2), line);
 gtk_widget_show (eb2);

 label = gtk_label_new ("X position of the main window:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 eb3 = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (eb3), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb3, TRUE, TRUE, 0);
 sprintf(line, "%d", x_pos);
 gtk_entry_set_text (GTK_ENTRY (eb3), line);
 gtk_widget_show (eb3);

 label = gtk_label_new ("Y position of the main window:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 eb4 = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (eb4), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb4, TRUE, TRUE, 0);
 sprintf(line, "%d", y_pos);
 gtk_entry_set_text (GTK_ENTRY (eb4), line);
 gtk_widget_show (eb4);

 label = gtk_label_new ("Color [black, red, green, blue]:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 eb5 = gtk_entry_new();
 gtk_editable_select_region (GTK_EDITABLE (eb5), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb5, TRUE, TRUE, 0);
 gtk_entry_set_text (GTK_ENTRY (eb5), col_name);
 gtk_widget_show (eb5);

 label = gtk_label_new ("Images viewer:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);
  
 eb6 = gtk_entry_new(); 
 gtk_editable_select_region (GTK_EDITABLE (eb6), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb6, TRUE, TRUE, 0);
 gtk_entry_set_text (GTK_ENTRY (eb6), images);
 gtk_widget_show (eb6);

 sep = gtk_hseparator_new ();
 gtk_box_pack_start (GTK_BOX (vbox), sep, FALSE, TRUE, 0);
 gtk_widget_show (sep);

 hbox = gtk_hbutton_box_new();  
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, FALSE, FALSE, 0);
 gtk_widget_show (hbox);

 button = gtk_button_new_with_label ("Save settings");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_settings_save), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);

 button = gtk_button_new_with_label ("Cancel");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_open_cancel), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);
 gtk_widget_show (window2);
}

int CB_run_ok(GtkWidget *widget, GtkWidget *entry)
{
 system(gtk_entry_get_text(GTK_ENTRY(entry_box)));
 gtk_widget_destroy(window2);
 window2 = NULL;
}

int CB_print_ok(GtkWidget *widget, GtkWidget *entry)  
{
 sprintf(line, "%s /tmp/.gx.print", gtk_entry_get_text(GTK_ENTRY(entry_box)));
 system(line);
 gtk_widget_destroy(window2);
 window2 = NULL;
}

int CB_opennet_ok(GtkWidget *widget, GtkWidget *entry)
{
 char server[255], dir[255], buf[512];
 int i,j;
 bzero(server, 255);
 bzero(dir, 255);
 strncpy(buf, gtk_entry_get_text(GTK_ENTRY(entry_box)), 512);
 for(i=0;(char)buf[i]!=(char)NULL;i++)
 {
  if(buf[i]=='/') break;
  server[i]=buf[i];
 }
 j=0;
 for(i=i;(char)buf[i]!=(char)NULL;i++)
 {
  dir[j]=buf[i];
  j++;
 }
 gtk_text_set_point(GTK_TEXT(text), 0);
 gtk_text_forward_delete(GTK_TEXT(text), gtk_text_get_length(GTK_TEXT(text)));
#ifdef USE_NET
 sprintf(line, "GXedit %s - web-get.txt (from %s)", VERSION, buf);
 strcpy(filename, "web-get.txt");
 gtk_window_set_title (GTK_WINDOW (window), line);
 network_fetch(server, dir);
#endif
 gtk_widget_destroy(window2);
 window2 = NULL;
}

int CB_opennet(GtkWidget *widget, GtkWidget *entry)
{
 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
 }
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_open_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_open_cancel), &window2);  
 gtk_window_set_title (GTK_WINDOW (window2), "Open");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_uposition (window2, (x_pos+100), (y_pos+100));
  
 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_container_border_width (GTK_CONTAINER (window2), 5);
 gtk_widget_show (vbox);
  
 label = gtk_label_new ("Enter the URL to fetch (ie. www.darkelf.net/drow/my.txt):");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 entry_box = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (entry_box), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), entry_box, TRUE, TRUE, 0);
 gtk_widget_show (entry_box);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_opennet_ok), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window2);
}

int CB_print(GtkWidget *widget, GtkWidget *entry)
{
 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
 }
 fd=fopen("/tmp/.gx.print","w");
 if(fd==NULL)
 {
  print_debug("Can't open temporary file in /tmp\n");
  return -1;
 }
 fputs((char *)gtk_editable_get_chars(GTK_EDITABLE (text), 0, gtk_text_get_length(GTK_TEXT(text))),fd);
 if(fd!=NULL) fclose(fd);

 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_open_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_open_cancel), &window2);  
 gtk_window_set_title (GTK_WINDOW (window2), "Print");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_uposition (window2, (x_pos+100), (y_pos+100));

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_container_border_width (GTK_CONTAINER (window2), 5);
 gtk_widget_show (vbox);

 label = gtk_label_new ("Command to print on this system:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 entry_box = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (entry_box), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), entry_box, TRUE, TRUE, 0);
 gtk_entry_set_text (GTK_ENTRY (entry_box), "lpr");
 gtk_widget_show (entry_box);

 button = gtk_button_new_with_label ("Print");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_print_ok), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window2);
}

int CB_run(GtkWidget *widget, GtkWidget *entry)
{
 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
 }
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_open_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_open_cancel), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), "Run");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_uposition (window2, (x_pos+100), (y_pos+100));
 
 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_container_border_width (GTK_CONTAINER (window2), 5);
 gtk_widget_show (vbox);
 
 label = gtk_label_new ("Enter the shell command or file to run:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);
 
 entry_box = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (entry_box), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), entry_box, TRUE, TRUE, 0);
 gtk_widget_show (entry_box);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_run_ok), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);  
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window2);
}

int CB_exit(GtkWidget *widget, GtkWidget *entry)
{
 gtk_widget_destroy(widget);
 gtk_main_quit();
 system("rm -f /tmp/.gxedit* 2> /dev/null");
 exit(0);
 return(FALSE);
}

int CB_new(GtkWidget *widget, GtkWidget *entry)
{
 strcpy(filename, "noname.txt");
 sprintf(line, "GXedit %s - %s\n", VERSION, filename);
 gtk_window_set_title (GTK_WINDOW (window), line);
 gtk_text_set_point(GTK_TEXT(text), 0);
 gtk_text_forward_delete(GTK_TEXT(text), gtk_text_get_length(GTK_TEXT(text)));
}

int CB_open_ok(GtkWidget *widget, GtkFileSelection *fs)
{
 char buf[100], buf2[200];
 strncpy(buf,gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)),100);
 if(tolower(buf[strlen(buf)-3])=='g'
  && tolower(buf[strlen(buf)-2])=='i'
  && tolower(buf[strlen(buf)-1])=='f')
 {
  sprintf(buf2, "%s %s &", images, buf);
  system(buf2);
  gtk_widget_destroy(window2);
  window2 = NULL;
  return(FALSE);
 }
 else if(tolower(buf[strlen(buf)-3])=='j'
  && tolower(buf[strlen(buf)-2])=='p'
  && tolower(buf[strlen(buf)-1])=='g')
 {
  sprintf(buf2, "%s %s &", images, buf);
  system(buf2);
  gtk_widget_destroy(window2);
  window2 = NULL;
  return(FALSE);
 }
 else if(tolower(buf[strlen(buf)-3])=='t'
  && tolower(buf[strlen(buf)-2])=='i'
  && tolower(buf[strlen(buf)-1])=='f') 
 {
  sprintf(buf2, "%s %s &", images, buf);
  system(buf2);
  gtk_widget_destroy(window2);
  window2 = NULL;
  return(FALSE);
 }
 else if(tolower(buf[strlen(buf)-3])=='f'
  && tolower(buf[strlen(buf)-2])=='i'
  && tolower(buf[strlen(buf)-1])=='t') 
 {
  sprintf(buf2, "%s %s &", images, buf);
  system(buf2);
  gtk_widget_destroy(window2);
  window2 = NULL;
  return(FALSE);
 }
 else if(tolower(buf[strlen(buf)-3])=='b'
  && tolower(buf[strlen(buf)-2])=='m'
  && tolower(buf[strlen(buf)-1])=='p') 
 {
  sprintf(buf2, "%s %s &", images, buf);
  system(buf2);
  gtk_widget_destroy(window2);
  window2 = NULL;
  return(FALSE);
 }
 else
 {
  strcpy(filename,buf);
  sprintf(line, "GXedit %s - %s\n", VERSION, filename);
  gtk_window_set_title (GTK_WINDOW (window), line);
  gtk_text_set_point(GTK_TEXT(text), 0);
  gtk_text_forward_delete(GTK_TEXT(text), gtk_text_get_length(GTK_TEXT(text)));
  gtk_widget_destroy(window2);
  window2 = NULL;
  fd = fopen(filename,"r");
  if(fd==NULL)
  {
   print_debug("Can't open file for reading\n");
   msgbox("Can't open file for reading");
   return(FALSE);
  }
  gtk_text_freeze(GTK_TEXT(text));
  while(fgets(line,512,fd)!=NULL)
   gtk_text_insert (GTK_TEXT (text), NULL, &color, NULL, line, -1);
  gtk_text_thaw (GTK_TEXT (text));
  fclose(fd);
  return(FALSE);
 }
}

int CB_about_close(GtkWidget *widget, GtkWidget *entry)
{
 gtk_widget_destroy(window2);
 window2 = NULL;
}

int CB_open_window_ok(GtkWidget *widget, GtkFileSelection *fs)   
{
 sprintf(line, "%s %s &", progname, gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)));
 system(line);
 gtk_widget_destroy(window2);
 window2 = NULL;
}

int CB_open_window(GtkWidget *widget, GtkWidget *entry)
{ 
 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
 }
 window2 = gtk_file_selection_new ("Open file");
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_open_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_open_cancel), &window2);   
 gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION(window2)->ok_button),
  "clicked", GTK_SIGNAL_FUNC(CB_open_window_ok), window2);
 gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(window2)->cancel_button),
  "clicked", GTK_SIGNAL_FUNC(CB_open_cancel), &window2);
 gtk_widget_set_uposition (window2, (x_pos+50), (y_pos+50));
 gtk_widget_show (window2);
}

int CB_open(GtkWidget *widget, GtkWidget *entry)
{
 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
 }
 window2 = gtk_file_selection_new ("Open file");
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_open_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_open_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION(window2)->ok_button),
  "clicked", GTK_SIGNAL_FUNC(CB_open_ok), window2);
 gtk_signal_connect (GTK_OBJECT(GTK_FILE_SELECTION(window2)->cancel_button),
  "clicked", GTK_SIGNAL_FUNC(CB_open_cancel), &window2);
 gtk_widget_set_uposition (window2, (x_pos+50), (y_pos+50));
 gtk_widget_show (window2);
}

int CB_save(GtkWidget *widget, GtkWidget *entry)
{
 fd=fopen(filename,"w");
 if(fd==NULL)
 {
  print_debug("Can't open file for saving\n");
  msgbox("Saving failed\nCan't open file for writing");
  return(FALSE);
 }
 fputs((char *)gtk_editable_get_chars(GTK_EDITABLE (text), 0, gtk_text_get_length(GTK_TEXT(text))),fd);
 if(fd!=NULL) fclose(fd);
}

int CB_emacs(GtkWidget *widget, GtkWidget *entry) 
{
 fd=fopen("/tmp/.gxedit","w");
 if(fd==NULL)
 {
  print_debug("Can't open file for saving\n");
  return;
 }
 fputs((char *)gtk_editable_get_chars(GTK_EDITABLE (text), 0, gtk_text_get_length(GTK_TEXT(text))),fd);
 if(fd!=NULL) fclose(fd);
 system("emacs /tmp/.gxedit &");
}

int CB_vi(GtkWidget *widget, GtkWidget *entry)
{
 fd=fopen("/tmp/.gxedit","w");
 if(fd==NULL)
 {
  print_debug("Can't open file for saving\n");
  return;
 }
 fputs((char *)gtk_editable_get_chars(GTK_EDITABLE (text), 0, gtk_text_get_length(GTK_TEXT(text))),fd);
 if(fd!=NULL) fclose(fd);
 system("xterm -e vi /tmp/.gxedit &");
}

int CB_saveas_cancel(GtkWidget *widget, GtkFileSelection *fs)
{
 gtk_widget_destroy(window2);
 window2 = NULL;
}

int CB_saveas_ok(GtkWidget *widget, GtkFileSelection *fs)
{
 strcpy(filename,gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)));
 sprintf(line, "GXedit %s - %s\n", VERSION, filename);
 gtk_window_set_title (GTK_WINDOW (window), line);
 gtk_widget_destroy(window2);
 window2 = NULL;
 fd=fopen(filename,"w");
 if(fd==NULL)
 {
  print_debug("Can't open file for saving\n");
  msgbox("Saving failed\n Can't open file for writing");
  return(FALSE);
 }
 fputs((char *)gtk_editable_get_chars(GTK_EDITABLE (text), 0, gtk_text_get_length(GTK_TEXT(text))),fd);
 if(fd!=NULL) fclose(fd);
 return(FALSE);
} 

int CB_email_ok(GtkWidget *widget, GtkWidget *entry)
{
#ifdef USE_NET
 send_email(gtk_entry_get_text(GTK_ENTRY(eb1)),
  gtk_entry_get_text(GTK_ENTRY(eb2)),
  gtk_entry_get_text(GTK_ENTRY(eb3)),
  gtk_editable_get_chars(GTK_EDITABLE (text), 0, gtk_text_get_length(GTK_TEXT(text))));
#endif
 gtk_widget_destroy(window2);
 window2 = NULL;
}

int CB_email(GtkWidget *widget, GtkWidget *entry)
{
 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
 }
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_open_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_open_cancel), &window2);     
 gtk_window_set_title (GTK_WINDOW (window2), "Send text as an e-mail");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_uposition (window2, (x_pos+100), (y_pos+100));
  
 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_container_border_width (GTK_CONTAINER (window2), 5);
 gtk_widget_show (vbox);
  
 label = gtk_label_new ("To:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0); 
 gtk_widget_show (label);

 eb1 = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (eb1), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb1, TRUE, TRUE, 0);
 gtk_widget_show (eb1);
  
 label = gtk_label_new ("From:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);
 
 eb2 = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (eb2), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb2, TRUE, TRUE, 0);
 gtk_widget_show (eb2);

 label = gtk_label_new ("Subject:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 eb3 = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (eb3), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb3, TRUE, TRUE, 0);
 gtk_widget_show (eb3);

 button = gtk_button_new_with_label ("Send");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_email_ok), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window2);
}

int CB_saveas(GtkWidget *widget, GtkWidget *entry)
{
 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
 }
 window2 = gtk_file_selection_new ("Save file");
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_saveas_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_saveas_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION(window2)->ok_button),
  "clicked", GTK_SIGNAL_FUNC(CB_saveas_ok), window2);
 gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(window2)->cancel_button),
  "clicked", GTK_SIGNAL_FUNC(CB_saveas_cancel), &window2);
 gtk_widget_set_uposition (window2, (x_pos+50), (y_pos+50));
 gtk_widget_show (window2);
}

int CB_about(GtkWidget *widget, GtkWidget *entry)
{
 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
 }
 window2 = gtk_dialog_new ();
 gtk_widget_set_usize (GTK_WIDGET (window2), 500, 100);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_about_close), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_about_close), &window2);
 sprintf(line, "About GXedit v%s", VERSION);
 gtk_window_set_title (GTK_WINDOW (window2), line);
 gtk_container_border_width (GTK_CONTAINER (window2), 0);
 gtk_widget_set_uposition (window2, (x_pos+100), (y_pos+100));

 label = gtk_label_new (ABOUT);
 gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window2)->vbox),
  label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 button = gtk_button_new_with_label ("Close");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_about_close), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window2)->action_area),
  button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window2);
}

int CB_help(GtkWidget *widget, GtkWidget *entry)
{
 if(window2!=NULL)
 {
  gtk_widget_destroy(window2);
 }
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize (GTK_WIDGET (window2), 500, 300);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_about_close), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_about_close), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), "GXedit help");
 gtk_container_border_width (GTK_CONTAINER (window2), 0);
 gtk_widget_set_uposition (window2, (x_pos+50), (y_pos+50));
 
 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_widget_show (vbox);

 table = gtk_table_new (2, 2, FALSE);
 gtk_table_set_row_spacing (GTK_TABLE (table), 0, 2);
 gtk_table_set_col_spacing (GTK_TABLE (table), 0, 2);
 gtk_box_pack_start (GTK_BOX (vbox), table, TRUE, TRUE, 0);
 gtk_widget_show (table);
 
 text2 = gtk_text_new (NULL, NULL);
 gtk_text_set_word_wrap(GTK_TEXT (text2), TRUE);
 gtk_table_attach_defaults (GTK_TABLE (table), text2, 0, 1, 0, 1);
 gtk_widget_show (text2);
 
 vscrollbar = gtk_vscrollbar_new (GTK_TEXT (text2)->vadj);
 gtk_table_attach (GTK_TABLE (table), vscrollbar, 1, 2, 0, 1,
  GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
 gtk_widget_show (vscrollbar);
 gtk_text_freeze (GTK_TEXT (text2));
 gtk_widget_realize (text2);
 gtk_text_insert (GTK_TEXT (text2), NULL, &color, NULL, HELP1, -1);
 gtk_text_insert (GTK_TEXT (text2), NULL, &color, NULL, HELP2, -1);
 gtk_text_insert (GTK_TEXT (text2), NULL, &color, NULL, HELP3, -1);
 gtk_text_insert (GTK_TEXT (text2), NULL, &color, NULL, HELP4, -1);
 gtk_text_insert (GTK_TEXT (text2), NULL, &color, NULL, HELP5, -1);
 gtk_text_insert (GTK_TEXT (text2), NULL, &color, NULL, HELP6, -1);
 gtk_text_insert (GTK_TEXT (text2), NULL, &color, NULL, HELP7, -1);
 gtk_text_insert (GTK_TEXT (text2), NULL, &color, NULL, HELP8, -1);
 gtk_text_insert (GTK_TEXT (text2), NULL, &color, NULL, HELP9, -1);
 gtk_text_insert (GTK_TEXT (text2), NULL, &color, NULL, HELP10, -1);
 gtk_text_insert (GTK_TEXT (text2), NULL, &color, NULL, HELP11, -1);
 gtk_text_insert (GTK_TEXT (text2), NULL, &color, NULL, HELP12, -1);
 gtk_text_insert (GTK_TEXT (text2), NULL, &color, NULL, HELP13, -1);
 gtk_text_insert (GTK_TEXT (text2), NULL, &color, NULL, HELP14, -1);
 gtk_text_insert (GTK_TEXT (text2), NULL, &color, NULL, HELP15, -1);
 gtk_text_thaw (GTK_TEXT (text2));

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, FALSE, FALSE, 0);
 gtk_widget_show (hbox);   

 button = gtk_button_new_with_label ("Close");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_about_close), GTK_OBJECT (window));
 gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window2);
}

int main(int argc, char *argv[])
{
#ifdef BG_ON_START
 if(fork()) exit(0);
#endif
 strncpy(progname, argv[0], 100);
 strncpy(home, getenv("HOME"), 100);
 sprintf(line, "%s/.gxedit", home);
 gtk_init(&argc, &argv);
 cmap = gdk_colormap_get_system();
 debug=0; toolbar=1; tooltips=1; x_size=550; y_size=300, full_tb=1;
 x_pos=20; y_pos=20; strcpy(col_name,"black"); strcpy(images,"xv");
 fd = fopen(line, "r");
 if(fd!=NULL) read_cfg();
 else make_cfg();
 if(argv[1]!=NULL)
 {
  strncpy(filename, argv[1], 100);
  fd = fopen(filename, "r");
  if(fd==NULL) print_debug("Can't open file for reading\n");
 }
 else
 {
  strcpy(filename, "noname.txt");
 }
 make_gui();
 print_debug("Debug messages:\nStarting GXedit...\n");
 if(argv[1]!=NULL)
 {
  while(fgets(line,512,fd)!=NULL)
   gtk_text_insert (GTK_TEXT (text), NULL, &color, NULL, line, -1);
  gtk_text_thaw (GTK_TEXT (text));
  fclose(fd);
 }
 else gtk_text_thaw (GTK_TEXT (text));
 gtk_main();
 return(0);
}

int read_cfg()
{
 while(fgets(line,512,fd)!=NULL)
 {
  line[strlen(line)-1]=' ';
  if(!strcasecmp(lindex(line,0),"toolbar:"))
   toolbar = atoi(lindex(line,1));
  else if(!strcasecmp(lindex(line,0),"tooltips:"))
   tooltips = atoi(lindex(line,1));
  else if(!strcasecmp(lindex(line,0),"x_size:"))
   x_size = atoi(lindex(line,1));
  else if(!strcasecmp(lindex(line,0),"y_size:"))
   y_size = atoi(lindex(line,1));
  else if(!strcasecmp(lindex(line,0),"full_toolbar:"))
   full_tb = atoi(lindex(line,1));
  else if(!strcasecmp(lindex(line,0),"x_position:"))
   x_pos = atoi(lindex(line,1));
  else if(!strcasecmp(lindex(line,0),"y_position:"))
   y_pos = atoi(lindex(line,1));
  else if(!strcasecmp(lindex(line,0),"debug:"))
   debug = atoi(lindex(line,1));
  else if(!strcasecmp(lindex(line,0),"images:"))
   strncpy(images, lindex(line,1), 100);
  else if(!strcasecmp(lindex(line,0),"color:"))
  {
   strncpy(col_name, lindex(line,1), 10);
   if(!strcasecmp(lindex(line,1),"black"))
   {
    extract_color(&color, 0, 0, 0);
    gdk_color_alloc(cmap, &color);
   }
   else if(!strcasecmp(lindex(line,1),"green"))
   {
    extract_color(&color, 0, 255, 0);
    gdk_color_alloc(cmap, &color);
   }
   else if(!strcasecmp(lindex(line,1),"red"))
   {
    extract_color(&color, 255, 0, 0);
    gdk_color_alloc(cmap, &color); 
   }
   else if(!strcasecmp(lindex(line,1),"blue"))
   {
    extract_color(&color, 0, 0, 255);
    gdk_color_alloc(cmap, &color); 
   }
   else print_debug("Invalid color in config file\n");
  }
 }
 fclose(fd);
 return(0);
}

int make_cfg()
{
 fd = fopen(line, "w");
 fputs("# This is the configuration file for GXedit\n", fd);
 fputs("toolbar: 1\n", fd);
 fputs("full_toolbar: 1\n", fd);
 fputs("tooltips: 1\n", fd);
 fputs("x_size: 550\n", fd);
 fputs("y_size: 300\n", fd);
 fputs("x_position: 20\n", fd);
 fputs("y_position: 20\n", fd);
 fputs("color: black\n", fd);
 extract_color(&color, 0, 0, 0);
 gdk_color_alloc(cmap, &color);
 fputs("debug: 0\n", fd);
 fputs("images: xv\n", fd);
 fclose(fd);
 return(0);
}

int make_gui()
{
 window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize (GTK_WIDGET (window), x_size, y_size);
 gtk_signal_connect (GTK_OBJECT (window), "destroy",
  GTK_SIGNAL_FUNC(CB_exit), &window);
 gtk_signal_connect (GTK_OBJECT (window), "delete_event",
  GTK_SIGNAL_FUNC(CB_exit), &window);
 sprintf(line, "GXedit %s - %s\n", VERSION, filename);
 gtk_window_set_title (GTK_WINDOW (window), line);
 gtk_widget_set_uposition (window, x_pos, y_pos);
 gtk_container_border_width (GTK_CONTAINER (window), 0);

 if(tooltips)
 {
  tips = gtk_tooltips_new();
  gtk_object_set_data (GTK_OBJECT (window), "GXedit", tips);
 }

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window), vbox);
 gtk_widget_show (vbox);
  
 menubar = gtk_menu_bar_new();
 gtk_box_pack_start (GTK_BOX (vbox), menubar, FALSE, TRUE, 0);
 gtk_widget_show (menubar);

 submenu = gtk_menu_new();

 menuitem = gtk_menu_item_new_with_label("New text file");
 gtk_menu_append(GTK_MENU(submenu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_new), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "New text file", "");

 menuitem = gtk_menu_item_new_with_label("New window");
 gtk_menu_append(GTK_MENU(submenu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_new_gxedit), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Open a new GXedit", "");

 menubutton = gtk_menu_item_new_with_label("New");
 gtk_widget_show(menubutton);

 menu = gtk_menu_new();
  
 menuitem = gtk_menu_item_new_with_label("New");
 gtk_menu_item_set_submenu (GTK_MENU_ITEM (menuitem), submenu);
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_widget_show(menuitem);

 submenu = gtk_menu_new();
 
 menuitem = gtk_menu_item_new_with_label("Open file...");
 gtk_menu_append(GTK_MENU(submenu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_open), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Open a text file", "");

#ifdef USE_NET
 menuitem = gtk_menu_item_new_with_label("Open from the web");   
 gtk_menu_append(GTK_MENU(submenu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_opennet), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Open a text from the web", "");
#endif

 menuitem = gtk_menu_item_new_with_label("Open in a new window");
 gtk_menu_append(GTK_MENU(submenu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_open_window), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Open a text file in a new window", "");

 menubutton = gtk_menu_item_new_with_label("Open");
 gtk_widget_show(menubutton);

 menuitem = gtk_menu_item_new_with_label("Open");
 gtk_menu_item_set_submenu (GTK_MENU_ITEM (menuitem), submenu);
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_widget_show(menuitem);

 menuitem = gtk_menu_item_new_with_label("Save");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_save), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Save the current file", "");

 menuitem = gtk_menu_item_new_with_label("Save as...");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_saveas), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Save under an other name", "");

 menuitem = gtk_menu_item_new_with_label("Print");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_print), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Print file", "");

 menuitem = gtk_menu_item_new();
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_widget_show(menuitem);

 menuitem = gtk_menu_item_new_with_label("Exit GXedit");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_exit), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Quit GXedit", "");

 menubutton = gtk_menu_item_new_with_label("File");
 gtk_widget_show(menubutton);
 
 gtk_menu_item_set_submenu(GTK_MENU_ITEM(menubutton), menu);
 gtk_menu_bar_append(GTK_MENU_BAR(menubar), menubutton);

 menu = gtk_menu_new();

 menuitem = gtk_menu_item_new_with_label("Copy");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_copy), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Copy selected text", "");

 menuitem = gtk_menu_item_new_with_label("Paste");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_paste), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Paste text", "");

 menubutton = gtk_menu_item_new_with_label("Edit");
 gtk_widget_show(menubutton);
 
 gtk_menu_item_set_submenu(GTK_MENU_ITEM(menubutton), menu);
 gtk_menu_bar_append(GTK_MENU_BAR(menubar), menubutton);

 menu = gtk_menu_new();

#ifdef USE_NET
 menuitem = gtk_menu_item_new_with_label("Send as e-mail");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_email), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Send the current text as e-mail", "");
#endif

 menuitem = gtk_menu_item_new_with_label("Open in Emacs");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_emacs), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Open this text in Emacs", "");

 menuitem = gtk_menu_item_new_with_label("Open in vi");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_vi), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Open this text in vi", "");

 menubutton = gtk_menu_item_new_with_label("Links"); 
 gtk_widget_show(menubutton);
 
 gtk_menu_item_set_submenu(GTK_MENU_ITEM(menubutton), menu);
 gtk_menu_bar_append(GTK_MENU_BAR(menubar), menubutton);

 menu = gtk_menu_new();

 menuitem = gtk_menu_item_new_with_label("Settings");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_settings), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Set options", "");

 menuitem = gtk_menu_item_new_with_label("Shell command");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_run), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Run a shell command", "");

 menuitem = gtk_menu_item_new_with_label("Check spelling");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_spell), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Check the spelling of words", "");

 menuitem = gtk_menu_item_new_with_label("Scripting command");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_awk), GTK_OBJECT(window));
 gtk_widget_show(menuitem);  
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Apply an awk scripting command on the current text", "");

 menuitem = gtk_menu_item_new();
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_widget_show(menuitem);

 menuitem = gtk_menu_item_new_with_label("Lines count");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_lines_count), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Count the number of lines", "");

 menuitem = gtk_menu_item_new_with_label("Words count");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_words_count), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Count the number of words", "");

 menuitem = gtk_menu_item_new_with_label("Bytes count");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_bytes_count), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Count the number of bytes", "");

 menubutton = gtk_menu_item_new_with_label("Options");
 gtk_widget_show(menubutton);

 gtk_menu_item_set_submenu(GTK_MENU_ITEM(menubutton), menu);
 gtk_menu_bar_append(GTK_MENU_BAR(menubar), menubutton);

 menu = gtk_menu_new();

 menuitem = gtk_menu_item_new_with_label("Getting started");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_help), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "Help on GXedit", "");

 menuitem = gtk_menu_item_new_with_label("About GXedit");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_about), GTK_OBJECT(window));
 gtk_widget_show(menuitem);
 if(tooltips)
  gtk_tooltips_set_tip(tips, menuitem, "About GXedit", "");

 menubutton = gtk_menu_item_new_with_label("Help");
 gtk_widget_show(menubutton);
 
 gtk_menu_item_set_submenu(GTK_MENU_ITEM(menubutton), menu);
 gtk_menu_bar_append(GTK_MENU_BAR(menubar), menubutton);

 if(toolbar)
 {
  gtk_window_set_policy (GTK_WINDOW (window), FALSE, TRUE, TRUE);
  gtk_widget_realize (window);

  hbox = gtk_toolbar_new (GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);
  gtk_box_pack_start (GTK_BOX (vbox), hbox, FALSE, FALSE, 0);

  if(tooltips)
  {
   gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "New", "Start a new text", 
   "", new_pixmap (0, window->window, &color),
   GTK_SIGNAL_FUNC(CB_new), GTK_OBJECT(window));

   gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Open", "Open a text file", 
   "", new_pixmap (1, window->window, &color),
   GTK_SIGNAL_FUNC(CB_open), GTK_OBJECT(window));

   gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Save", "Save to the current file",
   "", new_pixmap (2, window->window, &color),
   GTK_SIGNAL_FUNC(CB_save), GTK_OBJECT(window));

   gtk_toolbar_append_space (GTK_TOOLBAR(hbox));

   if(full_tb)
   {
    gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Copy", "Copy text",
    "", new_pixmap (5, window->window, &color),
    GTK_SIGNAL_FUNC(CB_copy), GTK_OBJECT(window));

    gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Paste", "Paste text",
    "", new_pixmap (6, window->window, &color),   
    GTK_SIGNAL_FUNC(CB_paste), GTK_OBJECT(window));

    gtk_toolbar_append_space (GTK_TOOLBAR(hbox));

    gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Settings", "Change settings",
    "", new_pixmap (7, window->window, &color),   
    GTK_SIGNAL_FUNC(CB_settings), GTK_OBJECT(window));
   }

   gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Help", "Getting started",
   "", new_pixmap (3, window->window, &color),
   GTK_SIGNAL_FUNC(CB_help), GTK_OBJECT(window));

   gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Exit", "Quit GXedit",
   "", new_pixmap (4, window->window, &color),
   GTK_SIGNAL_FUNC(CB_exit), GTK_OBJECT(window));
  }
  else
  {
   gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "New", NULL,
   "", new_pixmap (0, window->window, &color),  
   GTK_SIGNAL_FUNC(CB_new), GTK_OBJECT(window));
  
   gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Open", NULL,
   "", new_pixmap (1, window->window, &color),   
   GTK_SIGNAL_FUNC(CB_open), GTK_OBJECT(window));
 
   gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Save", NULL,
   "", new_pixmap (2, window->window, &color),   
   GTK_SIGNAL_FUNC(CB_save), GTK_OBJECT(window));
 
   gtk_toolbar_append_space (GTK_TOOLBAR(hbox));

   if(full_tb)
   {
    gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Copy", "Copy text",
    "", new_pixmap (5, window->window, &color),
    GTK_SIGNAL_FUNC(CB_copy), GTK_OBJECT(window));
    
    gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Paste", "Paste text",
    "", new_pixmap (6, window->window, &color),
    GTK_SIGNAL_FUNC(CB_paste), GTK_OBJECT(window));
   
    gtk_toolbar_append_space (GTK_TOOLBAR(hbox));
   
    gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Settings", "Change settings",
    "", new_pixmap (7, window->window, &color),
    GTK_SIGNAL_FUNC(CB_settings), GTK_OBJECT(window));
   }

   gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Help", NULL,
   "", new_pixmap (3, window->window, &color),
   GTK_SIGNAL_FUNC(CB_help), GTK_OBJECT(window));
   
   gtk_toolbar_append_item (GTK_TOOLBAR (hbox), "Exit", NULL,
   "", new_pixmap (4, window->window, &color),
   GTK_SIGNAL_FUNC(CB_exit), GTK_OBJECT(window));
  }
  gtk_widget_show (hbox);
 }

 table = gtk_table_new (2, 2, FALSE);
 gtk_table_set_row_spacing (GTK_TABLE (table), 0, 2);
 gtk_table_set_col_spacing (GTK_TABLE (table), 0, 2);
 gtk_box_pack_start (GTK_BOX (vbox), table, TRUE, TRUE, 0);
 gtk_widget_show (table);

 text = gtk_text_new (NULL, NULL);
 gtk_text_set_editable (GTK_TEXT (text), TRUE);
 gtk_text_set_word_wrap(GTK_TEXT (text), TRUE);
 gtk_table_attach_defaults (GTK_TABLE (table), text, 0, 1, 0, 1);
 gtk_widget_show (text);

 vscrollbar = gtk_vscrollbar_new (GTK_TEXT (text)->vadj);
 gtk_table_attach (GTK_TABLE (table), vscrollbar, 1, 2, 0, 1,
  GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
 gtk_widget_show (vscrollbar);
 gtk_text_freeze (GTK_TEXT (text));
 gtk_widget_realize (text);

 gtk_widget_show (window);

 if(debug)
 {
  dw = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_usize (GTK_WIDGET (dw), 500, 150);
  gtk_signal_connect (GTK_OBJECT (dw), "destroy",
   GTK_SIGNAL_FUNC(CB_close_debug), &dw);
  gtk_signal_connect (GTK_OBJECT (dw), "delete_event",
   GTK_SIGNAL_FUNC(CB_close_debug), &dw);
  gtk_window_set_title (GTK_WINDOW (dw), "Debug messages:");
  gtk_widget_set_uposition (dw, (x_pos+100), (y_pos+200));
  gtk_container_border_width (GTK_CONTAINER (dw), 0);

  hbox = gtk_vbox_new (FALSE, 10);
  gtk_container_border_width (GTK_CONTAINER (hbox), 0);
  gtk_container_add (GTK_CONTAINER (dw), hbox);
  gtk_widget_show (hbox);

  table = gtk_table_new (2, 2, FALSE);
  gtk_table_set_row_spacing (GTK_TABLE (table), 0, 2);
  gtk_table_set_col_spacing (GTK_TABLE (table), 0, 2);
  gtk_box_pack_start (GTK_BOX (hbox), table, TRUE, TRUE, 0);
  gtk_widget_show (table);

  text_debug = gtk_text_new (NULL, NULL);
  gtk_text_set_word_wrap(GTK_TEXT (text_debug), TRUE);  
  gtk_table_attach_defaults (GTK_TABLE (table), text_debug, 0, 1, 0, 1);
  gtk_widget_show (text_debug);

  vscrollbar = gtk_vscrollbar_new (GTK_TEXT (text_debug)->vadj);
  gtk_table_attach (GTK_TABLE (table), vscrollbar, 1, 2, 0, 1,
   GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_widget_show (vscrollbar);
  gtk_text_freeze (GTK_TEXT (text_debug));
  gtk_widget_realize (text_debug);
  gtk_text_thaw (GTK_TEXT (text_debug));
  gtk_widget_show (dw);
 }
}
