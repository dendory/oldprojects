#include <gtk/gtk.h>
#include <stdio.h>
int gl_type;
char temp[255];
GtkWidget *window, *window2, *button, *label, *vbox, *hbox, *sep;
