/* GXzip - Part of GXdesktop
 * Copyright 1998 Patrick Lambert <drow@wildstar.net>
 *
 * This program is free software. You can use, copy and modify it under
 * the terms of the GPL. See the file COPYING for the full GPL license.
*/

#include "gxzip.h"

int CB_exit(GtkWidget *widget, GtkWidget *entry)
{
 gtk_widget_destroy(widget);
 gtk_main_quit();   
 exit(0);
}

int CB_compress_cancel(GtkWidget *widget, GtkFileSelection *fs)
{
 gtk_widget_destroy(window2);
}

int CB_compress_ok(GtkWidget *widget, GtkFileSelection *fs)
{
 if(gl_type==0)
 sprintf(temp,"gzip %s",gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)));
 if(gl_type==1)
 sprintf(temp,"zip %s",gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)));
 if(gl_type==2)
 sprintf(temp,"compress %s",gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)));
 if(gl_type==3)
 sprintf(temp,"gzip -d %s",gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)));
 if(gl_type==4)
 sprintf(temp,"unzip %s",gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)));
 if(gl_type==5)
 sprintf(temp,"uncompress %s",gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)));
 system(temp);
 gtk_widget_destroy(window2);
 gtk_widget_destroy(window);
 exit(0);
}

int CB_compress(gint type, GtkWidget *entry)
{
 gl_type = type;
 window2 = gtk_file_selection_new ("File...");
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_compress_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_compress_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION(window2)->ok_button),
  "clicked", GTK_SIGNAL_FUNC(CB_compress_ok), window2);
 gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(window2)->cancel_button),
  "clicked", GTK_SIGNAL_FUNC(CB_compress_cancel), &window2);
 gtk_widget_set_uposition (window2, 120, 120);
 gtk_widget_show (window2);
}

int make_gui()
{
 window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize (GTK_WIDGET (window), 300, 300);
 gtk_signal_connect (GTK_OBJECT (window), "destroy",
  GTK_SIGNAL_FUNC(CB_exit), &window);
 gtk_signal_connect (GTK_OBJECT (window), "delete_event",
  GTK_SIGNAL_FUNC(CB_exit), &window);
 gtk_window_set_title (GTK_WINDOW (window), "Compression / Uncompression");
 gtk_widget_set_uposition (window, 100, 100);
 gtk_container_border_width (GTK_CONTAINER (window), 2);
 gtk_widget_realize(window);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window), vbox);
 gtk_container_border_width (GTK_CONTAINER (window), 5);
 gtk_widget_show (vbox);

 label = gtk_label_new ("Compression and uncompression utilities");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 sep = gtk_hseparator_new ();
 gtk_box_pack_start (GTK_BOX (vbox), sep, FALSE, TRUE, 0);  
 gtk_widget_show (sep);

 button = gtk_button_new_with_label ("Gzip a file");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_compress), (gpointer) 0);
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 button = gtk_button_new_with_label ("Zip a file");   
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_compress), (gpointer) 1);
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 button = gtk_button_new_with_label ("Compress a file");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_compress), (gpointer) 2);
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 sep = gtk_hseparator_new ();
 gtk_box_pack_start (GTK_BOX (vbox), sep, FALSE, TRUE, 0);
 gtk_widget_show (sep);

 button = gtk_button_new_with_label ("UnGzip a file");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_compress), (gpointer) 3);
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 button = gtk_button_new_with_label ("UnZip a file");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_compress), (gpointer) 4);
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 button = gtk_button_new_with_label ("UnCompress a file");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_compress), (gpointer) 5);
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 sep = gtk_hseparator_new ();
 gtk_box_pack_start (GTK_BOX (vbox), sep, FALSE, TRUE, 0);
 gtk_widget_show (sep);

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, FALSE, FALSE, 0);
 gtk_widget_show (hbox);

 button = gtk_button_new_with_label ("Cancel");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_exit), GTK_OBJECT (window));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button); 
 gtk_widget_show (window);
}

int main(int argc, char *argv[])
{
 gtk_init(&argc, &argv);
 make_gui();
 gtk_main();
}
