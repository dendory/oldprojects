/* (C) Copyright 1998 Patrick Lambert <drow@wildstar.net>
 *
 * This program is free software. You can use, copy and modify it under
 * the terms of the GPL. See the file COPYING for the full GPL license.
*/ 

#include <gtk/gtk.h>
#include <stdio.h>

int i;
FILE *fd;
char temp[512];
GtkWidget *window, *vbox, *label, *button, *entry_box, *hbox, *text, *table, *vscrollbar;
FILE *output;    /* --output -o */
char title[512]; /* --title, -t */
int pos;         /* --position, -p */
int size;        /* --size, -s */
int append;      /* --append-eol, -eol */
