/* GXlpr - part of the GXdesktop
 * Copyright 1998 Patrick Lambert <drow@wildstar.net>
 * 
 * This program is free software. You can use, copy and modify it under
 * the terms of the GPL. See the file COPYING for the full GPL license.
*/

#include "gxprint.h"

char *lindex(char *input_string, int word_number)
{
 char *tokens[1024];
 static char tmpstring[1024];
 int i;
 strncpy(tmpstring,input_string,1024);
 (char *)tokens[i=0] = (char *)strtok(tmpstring, " ");
 while (((char *)tokens[++i] = (char *)strtok(NULL, " ")));
 tokens[i] = NULL;
 return(tokens[word_number]);
}

int main(int argc, char *argv[])
{
 strncpy(home, getenv("HOME"), 100);
 gtk_init(&argc, &argv);
 read_cfg();
 flag_c = 0;
 flag_d = 0;
 flag_f = 0;
 flag_g = 0;
 flag_l = 0;
 flag_n = 0;
 flag_p = 0;
 flag_t = 0;
 flag_v = 0;
 make_gui();
 fill_box();
 gtk_text_thaw (GTK_TEXT (text));
 gtk_main();
 return(0);
}

int read_cfg()
{
 sprintf(temp, "%s/.gxlpr", home);
 fd = fopen(temp, "r");
 if(fd==NULL)
 {
  x_pos = 10;
  y_pos = 10;
  x_size = 450;
  y_size = 450;
 }
 else
 {
  while(fgets(temp,255,fd)!=NULL)
  {
   if(!strcasecmp(lindex(temp,0),"x_position:"))
    x_pos = atoi(lindex(temp,1));
   if(!strcasecmp(lindex(temp,0),"y_position:"))
    y_pos = atoi(lindex(temp,1));
   if(!strcasecmp(lindex(temp,0),"x_size:"))
    x_size = atoi(lindex(temp,1));
   if(!strcasecmp(lindex(temp,0),"y_size:"))
    y_size = atoi(lindex(temp,1));
  }
  fclose(fd);
 }
}

int fill_box()
{
 system("lpq > /tmp/.gxlpr.tmp");
 fd = fopen("/tmp/.gxlpr.tmp", "r");
 if(fd==NULL)
 {
  printf("Can't read print queue\n");
  exit(1);
 }
 while(fgets(temp,255,fd)!=NULL)
 {
  if(strcasecmp(lindex(temp,0),"Rank"))
  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL, temp, -1);
 }
 fclose(fd);
 system("rm -f /tmp/.gxlpr.tmp");
}

int CB_exit(GtkWidget *widget, GtkWidget *entry)
{
 gtk_widget_destroy(widget);
 gtk_main_quit();
 exit(0);
}

int CB_about_close(GtkWidget *widget, GtkWidget *entry)
{
 gtk_widget_destroy(window);
}

int CB_print(GtkWidget *widget, GtkWidget *entry)
{
 strcpy(temp,"lpr ");
 if(flag_c) strcat(temp, "-c ");
 if(flag_d) strcat(temp, "-d ");
 if(flag_f) strcat(temp, "-f ");
 if(flag_g) strcat(temp, "-g ");
 if(flag_l) strcat(temp, "-l ");
 if(flag_n) strcat(temp, "-n ");
 if(flag_p) strcat(temp, "-p ");
 if(flag_t) strcat(temp, "-t ");
 if(flag_v) strcat(temp, "-v ");
 strcat(temp,gtk_entry_get_text(GTK_ENTRY(entry_box)));
 system(temp);
 gtk_main_quit();
 exit(0);
}
  
int CB_refresh(GtkWidget *widget, GtkWidget *entry)
{
 gtk_text_set_point(GTK_TEXT(text), 0);
 gtk_text_forward_delete(GTK_TEXT(text), gtk_text_get_length(GTK_TEXT(text)));
 fill_box();
}

int CB_about(GtkWidget *widget, GtkWidget *entry)
{
 window = gtk_dialog_new ();
 gtk_widget_set_usize (GTK_WIDGET (window), 400, 100);
 gtk_signal_connect (GTK_OBJECT (window), "destroy",
  GTK_SIGNAL_FUNC(CB_about_close), &window);
 gtk_signal_connect (GTK_OBJECT (window), "delete_event",
  GTK_SIGNAL_FUNC(CB_about_close), &window);
 gtk_window_set_title (GTK_WINDOW (window), "GXlpr");
 gtk_container_border_width (GTK_CONTAINER (window), 0);
 gtk_widget_set_uposition (window, (x_pos+100), (y_pos+100));
  
 label = gtk_label_new ("GXlpr v0.2 by Patrick Lambert <drow@wildstar.net>");
 gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window)->vbox),
  label, TRUE, TRUE, 0);
 gtk_widget_show (label);
 
 button = gtk_button_new_with_label ("Close");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_about_close), GTK_OBJECT (window));
 gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window)->action_area),
  button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window);
}

int CB_flag_c(GtkWidget *widget, GtkWidget *entry)
{
 if(flag_c) flag_c = 0;
 else flag_c = 1;
 if(flag_c) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(bc), TRUE);
}

int CB_flag_d(GtkWidget *widget, GtkWidget *entry)
{
 if(flag_d) flag_d = 0;
 else flag_d = 1;
 if(flag_d) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(bd), TRUE);
}

int CB_flag_f(GtkWidget *widget, GtkWidget *entry)
{
 if(flag_f) flag_f = 0;
 else flag_f = 1;
 if(flag_f) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(bf), TRUE);
}

int CB_flag_g(GtkWidget *widget, GtkWidget *entry)
{
 if(flag_g) flag_g = 0;
 else flag_g = 1;
 if(flag_g) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(bg), TRUE);
}

int CB_flag_l(GtkWidget *widget, GtkWidget *entry)
{
 if(flag_l) flag_l = 0;
 else flag_l = 1;
 if(flag_l) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(bl), TRUE);
}

int CB_flag_n(GtkWidget *widget, GtkWidget *entry)
{
 if(flag_n) flag_n = 0;
 else flag_n = 1;
 if(flag_n) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(bn), TRUE);
}

int CB_flag_p(GtkWidget *widget, GtkWidget *entry)
{
 if(flag_p) flag_p = 0;
 else flag_p = 1;
 if(flag_p) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(bp), TRUE);
}

int CB_flag_t(GtkWidget *widget, GtkWidget *entry)
{
 if(flag_t) flag_t = 0;
 else flag_t = 1;
 if(flag_t) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(bt), TRUE);
}

int CB_flag_v(GtkWidget *widget, GtkWidget *entry)
{
 if(flag_v) flag_v = 0;
 else flag_v = 1;
 if(flag_v) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(bv), TRUE);
}

int make_gui()
{
 window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize (GTK_WIDGET (window), x_size, y_size);
 gtk_signal_connect (GTK_OBJECT (window), "destroy",
  GTK_SIGNAL_FUNC(CB_exit), &window);
 gtk_signal_connect (GTK_OBJECT (window), "delete_event",
  GTK_SIGNAL_FUNC(CB_exit), &window);
 gtk_window_set_title (GTK_WINDOW (window), "GXlpr interface");
 gtk_widget_set_uposition (window, x_pos, y_pos);
 gtk_container_border_width (GTK_CONTAINER (window), 0);

 vbox = gtk_vbox_new(FALSE, 5);
 gtk_container_border_width(GTK_CONTAINER(vbox), 5);
 gtk_container_add(GTK_CONTAINER(window), vbox);
 gtk_widget_show(vbox);

 menubar = gtk_menu_bar_new();
 gtk_box_pack_start (GTK_BOX (vbox), menubar, FALSE, TRUE, 0);
 gtk_widget_show (menubar);

 menu = gtk_menu_new();
 
 menuitem = gtk_menu_item_new_with_label("Refresh");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_refresh), GTK_OBJECT(window));
 gtk_widget_show(menuitem);

 menuitem = gtk_menu_item_new_with_label("About");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_about), GTK_OBJECT(window));
 gtk_widget_show(menuitem);

 menuitem = gtk_menu_item_new();
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_widget_show(menuitem);

 menuitem = gtk_menu_item_new_with_label("Exit");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_exit), GTK_OBJECT(window));
 gtk_widget_show(menuitem);

 menubutton = gtk_menu_item_new_with_label("File");
 gtk_widget_show(menubutton);
 
 gtk_menu_item_set_submenu(GTK_MENU_ITEM(menubutton), menu);
 gtk_menu_bar_append(GTK_MENU_BAR(menubar), menubutton);

 hbox = gtk_hbox_new (FALSE, 10);
 gtk_container_border_width (GTK_CONTAINER (hbox), 10); 
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 table = gtk_table_new (2, 2, FALSE);
 gtk_table_set_row_spacing (GTK_TABLE (table), 0, 2);
 gtk_table_set_col_spacing (GTK_TABLE (table), 0, 2);
 gtk_box_pack_start (GTK_BOX (hbox), table, TRUE, TRUE, 0);
 gtk_widget_show (table);

 text = gtk_text_new (NULL, NULL);
 gtk_text_set_editable (GTK_TEXT (text), TRUE);
 gtk_text_set_word_wrap(GTK_TEXT (text), TRUE);
 gtk_table_attach_defaults (GTK_TABLE (table), text, 0, 1, 0, 1);
 gtk_widget_show (text);

 vscrollbar = gtk_vscrollbar_new (GTK_TEXT (text)->vadj);
 gtk_table_attach (GTK_TABLE (table), vscrollbar, 1, 2, 0, 1,
  GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
 gtk_widget_show (vscrollbar);
 gtk_text_freeze (GTK_TEXT (text));
 gtk_widget_realize (text);
 gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL, "Current print queue:\n", -1);

 vbox2 = gtk_vbox_new (FALSE, 10);
 gtk_container_border_width (GTK_CONTAINER (vbox2), 10);
 gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 0);
 gtk_widget_show (vbox2);

 bc = gtk_check_button_new_with_label("Assume cifplot data");
 gtk_signal_connect (GTK_OBJECT(bc), "toggled",
  GTK_SIGNAL_FUNC(CB_flag_c), bc);
 gtk_box_pack_start (GTK_BOX (vbox2), bc, TRUE, TRUE, 0);
 gtk_widget_show (bc);

 bd = gtk_check_button_new_with_label("Assume TeX data");
 gtk_signal_connect (GTK_OBJECT(bd), "toggled",
  GTK_SIGNAL_FUNC(CB_flag_d), bd); 
 gtk_box_pack_start (GTK_BOX (vbox2), bd, TRUE, TRUE, 0);
 gtk_widget_show (bd);

 bf = gtk_check_button_new_with_label("Convert from FORTRAN cr");
 gtk_signal_connect (GTK_OBJECT(bf), "toggled",
  GTK_SIGNAL_FUNC(CB_flag_f), bf); 
 gtk_box_pack_start (GTK_BOX (vbox2), bf, TRUE, TRUE, 0);
 gtk_widget_show (bf);

 bg = gtk_check_button_new_with_label("File has plot data");
 gtk_signal_connect (GTK_OBJECT(bg), "toggled",
  GTK_SIGNAL_FUNC(CB_flag_g), bg); 
 gtk_box_pack_start (GTK_BOX (vbox2), bg, TRUE, TRUE, 0);
 gtk_widget_show (bg);

 bl = gtk_check_button_new_with_label("Remove page breaks");
 gtk_signal_connect (GTK_OBJECT(bl), "toggled",
  GTK_SIGNAL_FUNC(CB_flag_l), bl); 
 gtk_box_pack_start (GTK_BOX (vbox2), bl, TRUE, TRUE, 0);
 gtk_widget_show (bl); 

 bn = gtk_check_button_new_with_label("File has ditroff data");
 gtk_signal_connect (GTK_OBJECT(bn), "toggled",
  GTK_SIGNAL_FUNC(CB_flag_n), bn); 
 gtk_box_pack_start (GTK_BOX (vbox2), bn, TRUE, TRUE, 0);
 gtk_widget_show (bn); 

 bp = gtk_check_button_new_with_label("File has troff data");
 gtk_signal_connect (GTK_OBJECT(bp), "toggled",
  GTK_SIGNAL_FUNC(CB_flag_p), bp); 
 gtk_box_pack_start (GTK_BOX (vbox2), bp, TRUE, TRUE, 0);
 gtk_widget_show (bp); 

 bt = gtk_check_button_new_with_label("Format the file with pr(1)");
 gtk_signal_connect (GTK_OBJECT(bt), "toggled",
  GTK_SIGNAL_FUNC(CB_flag_t), bt); 
 gtk_box_pack_start (GTK_BOX (vbox2), bt, TRUE, TRUE, 0);
 gtk_widget_show (bt); 

 bv = gtk_check_button_new_with_label("File has a raster image");
 gtk_signal_connect (GTK_OBJECT(bv), "toggled",
  GTK_SIGNAL_FUNC(CB_flag_v), bv); 
 gtk_box_pack_start (GTK_BOX (vbox2), bv, TRUE, TRUE, 0);
 gtk_widget_show (bv); 

 separator = gtk_hseparator_new();
 gtk_container_add(GTK_CONTAINER(vbox), separator);
 gtk_widget_show(separator);

 entry_box = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (entry_box), 0, -1);
 gtk_entry_set_text (GTK_ENTRY (entry_box), "file to print");
 gtk_box_pack_start (GTK_BOX (vbox), entry_box, TRUE, TRUE, 0);
 gtk_widget_show (entry_box);

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_end (GTK_BOX (vbox), hbox, FALSE, FALSE, 0);
 gtk_widget_show (hbox);

 button = gtk_button_new_with_label("Print");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_print), GTK_OBJECT(window));
 gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 gtk_widget_show (window);
}
