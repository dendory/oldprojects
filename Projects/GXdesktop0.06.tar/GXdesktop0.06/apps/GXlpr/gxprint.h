/* GXlpr - part of the GXdesktop
 * Copyright 1998 Patrick Lambert <drow@wildstar.net>
 *
 * This program is free software. You can use, copy and modify it under
 * the terms of the GPL. See the file COPYING for the full GPL license.
*/

#include <gtk/gtk.h>
#include <stdio.h>
FILE *fd;
char home[100], temp[255];
int x_pos, y_pos, x_size, y_size;
int flag_c, flag_d, flag_f, flag_g, flag_l, flag_n, flag_p, flag_t, flag_v;
GtkWidget *window, *text, *menu, *menuitem, *menubar, *text, *vbox, *button;
GtkWidget *label, *menubutton, *menuitem, *table, *separator, *hbox, *vscrollbar;
GtkWidget *bc, *bd, *bf, *bg, *bl, *bn, *bp, *bt, *bv, *vbox2, *entry_box;
