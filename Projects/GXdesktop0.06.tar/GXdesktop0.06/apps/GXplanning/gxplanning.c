/* GXplanning - A part of GXdesktop
 * Copyright 1998 Patrick Lambert <drow@wildstar.net>
 *
 * This program is free software. You can use, copy and modify it under
 * the terms of the GPL. See the file COPYING for the full GPL license.
*/

#include "gxplanning.h"

char *lindex(char *input_string, int word_number)
{
 char *tokens[1024];
 static char tmpstring[1024];
 int i;
 strncpy(tmpstring,input_string,1024);
 (char *)tokens[i=0] = (char *)strtok(tmpstring, " ");
 while (((char *)tokens[++i] = (char *)strtok(NULL, " ")));
 tokens[i] = NULL;
 return(tokens[word_number]);
}

int CB_exit(GtkWidget *widget, GtkWidget *entry)
{
 if(fd!=NULL) fclose(fd);
 gtk_widget_destroy(widget);
 gtk_main_quit();
 exit(0);
 return(FALSE);
}

int CB_save_cancel(GtkWidget *widget, GtkFileSelection *fs)
{
 gtk_widget_destroy(window2);
 window2 = NULL;
}

int CB_save_ok(GtkWidget *widget, GtkFileSelection *fs)
{
 fd=fopen(gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)),"w");
 gtk_widget_destroy(window2);
 window2 = NULL;
 if(fd==NULL)   
 {
  msgbox("Error", "Saving failed\n Can't open file for writing"); 
  return(FALSE);
 }
 fputs((char *)gtk_editable_get_chars(GTK_EDITABLE (text), 0, gtk_text_get_length(GTK_TEXT(text))),fd);
 if(fd!=NULL) fclose(fd);
 return(FALSE); 
}

int CB_save(GtkWidget *widget, GtkWidget *entry)
{
 window2 = gtk_file_selection_new ("Save file");
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_save_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_save_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION(window2)->ok_button),
  "clicked", GTK_SIGNAL_FUNC(CB_save_ok), window2);
 gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(window2)->cancel_button),
  "clicked", GTK_SIGNAL_FUNC(CB_save_cancel), &window2);
 gtk_widget_set_uposition (window2, 100, 100);
 gtk_widget_show (window2);
}

int CB_print(GtkWidget *widget, GtkWidget *entry)
{
 if(fd!=NULL) fclose(fd);
 fd = fopen("/tmp/.gxplanning.prn", "r");
 fputs((char *)gtk_editable_get_chars(GTK_EDITABLE (text), 0, gtk_text_get_length(GTK_TEXT(text))),fd);
 if(fd!=NULL) fclose(fd);
 system("lpr /tmp/.gxplanning.prn");
}

int CB_month(GtkWidget *widget, GtkWidget *entry)
{
 int i;
 char day[10];
 gtk_text_set_point(GTK_TEXT(text), 0);
 gtk_text_forward_delete(GTK_TEXT(text), gtk_text_get_length(GTK_TEXT(text)));
 if(fd!=NULL) fclose(fd);
 sprintf(temp, "cal %s %s > /tmp/.gxplanning.cal", a2, a1);
 system(temp);
 fd = fopen("/tmp/.gxplanning.cal", "r");
 while(fgets(temp,255,fd)!=NULL)
 gtk_text_insert(GTK_TEXT (text), NULL, &text->style->black, NULL, temp, -1);
 if(fd!=NULL) fclose(fd);
 for(i=1;i<32;i++)
 {
  sprintf(a3, "%d", i);
  if(fd!=NULL) fclose(fd);
  sprintf(temp, "%s/.gxplanning", home);
  fd = fopen(temp, "r");
  sprintf(temp, "### %s/%s/%s:\n",a1,a2,a3);
  gtk_text_insert(GTK_TEXT (text), NULL, &text->style->black, NULL, temp, -1);
  while(fgets(temp,255,fd)!=NULL)   
  {
   if(lindex(temp,0)!=NULL)
   if(!strcasecmp(lindex(temp,0),"###") &&
    !strcasecmp(lindex(temp,1),a1) &&
    !strcasecmp(lindex(temp,2),a2) &&
    !strcasecmp(lindex(temp,3),a3))
   {
    while(fgets(temp,255,fd)!=NULL)
    {
     if(lindex(temp,0)!=NULL && !strcasecmp(lindex(temp,0),"###")) break;
     gtk_text_insert(GTK_TEXT (text), NULL, &text->style->black, NULL, temp, -1);
    }
   }
  }
 }
}

int daily_planning()
{
 window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize (GTK_WIDGET (window), 500, 200);
 gtk_signal_connect (GTK_OBJECT (window), "destroy",
  GTK_SIGNAL_FUNC(CB_exit), &window);
 gtk_signal_connect (GTK_OBJECT (window), "delete_event",
  GTK_SIGNAL_FUNC(CB_exit), &window);
 sprintf(temp, "Daily planning for %s/%s/%s", a1, a2, a3);
 gtk_window_set_title (GTK_WINDOW (window), temp);
 gtk_widget_set_uposition (window, 100, 100);
 gtk_container_border_width (GTK_CONTAINER (window), 2);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 5);
 gtk_widget_show (vbox);

 table = gtk_table_new (2, 2, FALSE);
 gtk_table_set_row_spacing (GTK_TABLE (table), 0, 2);
 gtk_table_set_col_spacing (GTK_TABLE (table), 0, 2);
 gtk_box_pack_start (GTK_BOX (vbox), table, TRUE, TRUE, 0);
 gtk_widget_show (table);

 text = gtk_text_new (NULL, NULL);
 gtk_text_set_word_wrap(GTK_TEXT (text), TRUE);
 gtk_table_attach_defaults (GTK_TABLE (table), text, 0, 1, 0, 1);
 gtk_widget_show (text);

 vscrollbar = gtk_vscrollbar_new (GTK_TEXT (text)->vadj);
 gtk_table_attach (GTK_TABLE (table), vscrollbar, 1, 2, 0, 1,
  GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
 gtk_widget_show (vscrollbar);
 gtk_text_freeze (GTK_TEXT (text));
 gtk_widget_realize (text);

 /* loop reading db */
 while(fgets(temp,255,fd)!=NULL)
 {
  if(lindex(temp,0)!=NULL)
  if(!strcasecmp(lindex(temp,0),"###") &&
   !strcasecmp(lindex(temp,1),a1) &&
   !strcasecmp(lindex(temp,2),a2) &&
   !strcasecmp(lindex(temp,3),a3))
  {
   stuff = 1;
   while(fgets(temp,255,fd)!=NULL)
   {
    if(lindex(temp,0)!=NULL && !strcasecmp(lindex(temp,0),"###")) break;
    gtk_text_insert(GTK_TEXT (text), NULL, &text->style->black, NULL, temp, -1);
   }
  }
 } /* end of loop */

 if(!stuff) gtk_text_insert(GTK_TEXT (text), NULL, &text->style->black, NULL, "This is your daily planning.\nThere is nothing in my database for this date.\n", -1);
 gtk_text_thaw (GTK_TEXT (text));

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, FALSE, FALSE, 0);
 gtk_widget_show (hbox);

 button = gtk_button_new_with_label ("Monthly planning");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_month), GTK_OBJECT (window));
 gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 button = gtk_button_new_with_label ("Save");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_save), GTK_OBJECT (window));
 gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 button = gtk_button_new_with_label ("Print");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_print), GTK_OBJECT (window));
 gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 button = gtk_button_new_with_label ("Close");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_exit), GTK_OBJECT (window));
 gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window);
}

int CB_add_it(GtkWidget *widget, GtkWidget *entry)
{
 if(fd!=NULL) fclose(fd);
 sprintf(temp, "%s/.gxplanning", home);
 fd = fopen(temp, "a");
 sprintf(temp, "### %s %s %s ;\n",
 gtk_entry_get_text(GTK_ENTRY(eb1)),
 gtk_entry_get_text(GTK_ENTRY(eb2)),
 gtk_entry_get_text(GTK_ENTRY(eb3)));
 fputs(temp, fd);
 fputs((char *)gtk_editable_get_chars(GTK_EDITABLE (text), 0, gtk_text_get_length(GTK_TEXT(text))),fd);
 fputs("\n### end of text part ;\n", fd);
 if(fd!=NULL) fclose(fd);
 gtk_widget_destroy(widget);
 gtk_main_quit();
 exit(0);
}

int add_stuff()
{
 window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize (GTK_WIDGET (window), 500, 300);
 gtk_signal_connect (GTK_OBJECT (window), "destroy",  
  GTK_SIGNAL_FUNC(CB_exit), &window);
 gtk_signal_connect (GTK_OBJECT (window), "delete_event",
  GTK_SIGNAL_FUNC(CB_exit), &window);
 gtk_window_set_title (GTK_WINDOW (window), "Adding an event");
 gtk_widget_set_uposition (window, 100, 100);   
 gtk_container_border_width (GTK_CONTAINER (window), 2);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 5);
 gtk_widget_show (vbox);

 label = gtk_label_new ("Add a comment in your daily planning:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 sep = gtk_hseparator_new ();
 gtk_box_pack_start (GTK_BOX (vbox), sep, TRUE, TRUE, 0);
 gtk_widget_show (sep);

 hbox = gtk_hbox_new (FALSE, 10);
 gtk_container_border_width (GTK_CONTAINER (hbox), 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Date: Year (ie. 1998):");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);
   
 eb1 = gtk_entry_new();
 gtk_editable_select_region (GTK_EDITABLE (eb1), 0, -1);  
 gtk_box_pack_start (GTK_BOX (hbox), eb1, TRUE, TRUE, 0);
 gtk_widget_show (eb1);

 hbox = gtk_hbox_new (FALSE, 10);
 gtk_container_border_width (GTK_CONTAINER (hbox), 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Month (ie. 5):");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);
 
 eb2 = gtk_entry_new();
 gtk_editable_select_region (GTK_EDITABLE (eb2), 0, -1);
 gtk_box_pack_start (GTK_BOX (hbox), eb2, TRUE, TRUE, 0);
 gtk_widget_show (eb2);

 hbox = gtk_hbox_new (FALSE, 10);
 gtk_container_border_width (GTK_CONTAINER (hbox), 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);

 label = gtk_label_new ("Day (ie. 27):");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);
 
 eb3 = gtk_entry_new();
 gtk_editable_select_region (GTK_EDITABLE (eb3), 0, -1);
 gtk_box_pack_start (GTK_BOX (hbox), eb3, TRUE, TRUE, 0);
 gtk_widget_show (eb3);

 table = gtk_table_new (2, 2, FALSE);
 gtk_table_set_row_spacing (GTK_TABLE (table), 0, 2);
 gtk_table_set_col_spacing (GTK_TABLE (table), 0, 2);
 gtk_box_pack_start (GTK_BOX (vbox), table, TRUE, TRUE, 0);
 gtk_widget_show (table);
 
 text = gtk_text_new (NULL, NULL);
 gtk_text_set_word_wrap(GTK_TEXT (text), TRUE);
 gtk_table_attach_defaults (GTK_TABLE (table), text, 0, 1, 0, 1);
 gtk_text_set_editable (GTK_TEXT (text), TRUE);
 gtk_widget_show (text);

 vscrollbar = gtk_vscrollbar_new (GTK_TEXT (text)->vadj);
 gtk_table_attach (GTK_TABLE (table), vscrollbar, 1, 2, 0, 1,
  GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
 gtk_widget_show (vscrollbar);
 gtk_text_freeze (GTK_TEXT (text));
 gtk_widget_realize (text);
 gtk_text_thaw (GTK_TEXT (text));

 sep = gtk_hseparator_new ();
 gtk_box_pack_start (GTK_BOX (vbox), sep, TRUE, TRUE, 0);
 gtk_widget_show (sep);

 button = gtk_button_new_with_label ("Save");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_add_it), GTK_OBJECT (window));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);
 gtk_widget_show (window);
}

int CB_msgbox_close(GtkWidget *widget, GtkWidget *entry)
{
 gtk_widget_destroy(widget);
 gtk_main_quit();
}

int msgbox(char *title, char *string)
{
 window2 = gtk_dialog_new ();
 gtk_widget_set_usize (GTK_WIDGET (window2), strlen(string)+400, 100);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_msgbox_close), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_msgbox_close), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), title);
 gtk_container_border_width (GTK_CONTAINER (window2), 0);
 gtk_widget_set_uposition (window2, 100, 200);

 label = gtk_label_new (string);
 gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window2)->vbox),
  label, TRUE, TRUE, 0);
 gtk_widget_show (label);
  
 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_msgbox_close), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window2)->action_area),
  button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window2);
}

int main(int argc, char *argv[])
{
 stuff = 0;
 strncpy(home, getenv("HOME"), 100);
 sprintf(temp, "%s/.gxplanning", home);
 gtk_init(&argc, &argv);
 fd = fopen(temp, "r");
 if(fd==NULL)
 {
  fd = fopen(temp, "a");
  fputs("# start of the file\n", fd);
  if(fd!=NULL) fclose(fd);
  fd = fopen(temp, "r");
  if(fd==NULL)
  {
   msgbox("Error", "Can't open planning file");
   gtk_main();
   exit(1);
  }
 }
 if(argv[1]==NULL)
 {
  msgbox("Error", "This program should be called from GXdesktop\nSyntax: gxplanning <choice>");
  gtk_main();
  exit(1);
 }
 if(!strcasecmp(argv[1],"daily"))
 {
  strcpy(a1, argv[2]);
  strcpy(a2, argv[3]);
  strcpy(a3, argv[4]);
  daily_planning();
 }
 else add_stuff();
 gtk_main();
 return(0);
}
