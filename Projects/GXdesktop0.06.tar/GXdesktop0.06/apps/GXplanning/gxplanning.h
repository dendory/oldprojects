#include <gtk/gtk.h>
#include <stdio.h>

FILE *fd;
GtkWidget *window, *window2, *label, *button, *hbox, *vbox, *text, *table, *vscrollbar, *sep;
GtkWidget *eb1, *eb2, *eb3;
char temp[255], home[100];
int stuff;
char a1[10], a2[10], a3[10];
