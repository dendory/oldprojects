/* GXdesktop
 * Copyright 1998 Patrick Lambert <drow@wildstar.net>
 *
 * This program is free software. You can use, copy and modify it under
 * the terms of the GPL. See the file COPYING for the full GPL license.
*/

#include "gxdesktop.h"

#define VERSION "0.06"

char *lindex(char *input_string, int word_number)
{
 char *tokens[1024];
 static char tmpstring[1024];
 int i;
 strncpy(tmpstring,input_string,1024);
 (char *)tokens[i=0] = (char *)strtok(tmpstring, " ");
 while (((char *)tokens[++i] = (char *)strtok(NULL, " ")));
 tokens[i] = NULL;
 return(tokens[word_number]);
}

char *lrange(char *input_string, int starting_at)
{ 
 char *tokens[1024];
 static char tmpstring[1024]="";
 int i;
 char out_string[1024]="";
 strcpy(out_string,"");
 if(input_string==NULL) {
  strcpy(out_string," ");
  strcat(out_string,NULL);
  strcpy(global_var,out_string);
  return (char *)global_var; }
 strncpy(tmpstring,input_string,1024);
 (char *)tokens[i=0] = (char *)strtok(tmpstring, " ");
 while(((char *)tokens[++i] = (char *)strtok(NULL, " ")));
 tokens[i] = NULL;
 i++;
 if(i<starting_at)
 {
  return (char *)"";
 }
 while(tokens[starting_at] != NULL)
 {
  strncat(out_string,tokens[starting_at],1024);
  strcat(out_string, " ");
  starting_at++;
 }
 strncpy(global_var,out_string,511);
 return (char *)global_var;
} 

static GtkWidget *new_pixmap(char *file, GdkWindow *window, GdkColor *background)
{
 GtkWidget *wpixmap;
 GdkPixmap *pixmap;
 GdkBitmap *mask;
 if(file!=NULL)
 {
  pixmap = gdk_pixmap_create_from_xpm(window, &mask, background, file);
  wpixmap = gtk_pixmap_new (pixmap, mask);
  return wpixmap;
 }
}

int CB_run_cancel(GtkWidget *widget, GtkWidget *entry)
{
 gtk_widget_destroy(widget);
 window2 = NULL;
}

int fs_cancel(GtkWidget *widget, GtkWidget *entry)
{ 
 gtk_widget_destroy(window2);
 window2 = NULL;
}

int CB_call(GtkWidget *widget, gint number)
{
 int i;
 sprintf(temp, "%s/.gxdesktop", home);
 fd = fopen(temp, "r");
 while(fgets(temp,255,fd)!=NULL)
 {
  temp[strlen(temp)-1]=' ';
  if(lindex(temp,0)==NULL) { }
  else if(!strcasecmp(lindex(temp,0),"button:"))
  {
   if(atoi(lindex(temp,1))==number)
   {
    for(i=2;lindex(temp,i)!=NULL;i++)
    {
     if(*(lindex(temp,i)+strlen(lindex(temp,i))-1)=='\"') break;
    }
    i++;
    strncpy(temp2,lrange(temp,(i+1)),255);
    bzero(temp, 255);
    for(i=0;lindex(temp2,i)!=NULL;i++)
    {
     if(!strcasecmp(lindex(temp2,i),config.key)) strcat(temp,config.data);
     else strcat(temp,lindex(temp2,i));
     strcat(temp," ");
    }
    system(temp);
   }
  }
  else if(!strcasecmp(lindex(temp,0),"menu:"))
  {
   if(atoi(lindex(temp,1))==number)   
   {
    for(i=2;lindex(temp,i)!=NULL;i++)
    {
     if(*(lindex(temp,i)+strlen(lindex(temp,i))-1)=='\"') break;
    }
    strncpy(temp2,lrange(temp,(i+1)),255);
    bzero(temp, 255);
    for(i=0;lindex(temp2,i)!=NULL;i++)
    {
     if(!strcasecmp(lindex(temp2,i),config.key)) strcat(temp,config.data);
     else strcat(temp,lindex(temp2,i));
     strcat(temp," ");
    }
    system(temp);
   }
  }
  else if(!strcasecmp(lindex(temp,0),"sub-menu-item:"))
  {
   if(atoi(lindex(temp,1))==number)   
   {
    for(i=2;lindex(temp,i)!=NULL;i++)
    {
     if(*(lindex(temp,i)+strlen(lindex(temp,i))-1)=='\"') break;
    }
    strncpy(temp2,lrange(temp,(i+1)),255);
    bzero(temp, 255);
    for(i=0;lindex(temp2,i)!=NULL;i++)
    {
     if(!strcasecmp(lindex(temp2,i),config.key)) strcat(temp,config.data);
     else strcat(temp,lindex(temp2,i));
     strcat(temp," ");
    }
    system(temp);
   }
  }
 }
 fclose(fd);
}

int CB_exit(GtkWidget *widget, GtkWidget *entry)
{
 gtk_widget_destroy(widget);
 gtk_main_quit();
 exit(0);
 return(FALSE);
}

int CB_planning(GtkWidget *widget, GtkWidget *entry)
{
 struct tm *current;
 lt = time(NULL);
 current = localtime(&lt);
 sprintf(temp, "gxplanning daily 19%d %d %d &", current->tm_year, (current->tm_mon+1), current->tm_mday);
 system(temp);
}

int CB_planning_daily_ok(GtkWidget *widget, GtkWidget *entry)
{
 sprintf(temp, "gxplanning daily %s %s %s &",
  gtk_entry_get_text(GTK_ENTRY(eb1)),
  gtk_entry_get_text(GTK_ENTRY(eb2)),
  gtk_entry_get_text(GTK_ENTRY(eb3)));
 system(temp);
 gtk_widget_destroy(widget);
}

int CB_planning_daily(GtkWidget *widget, GtkWidget *entry)
{
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_run_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_run_cancel), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), "See a day's planning");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_usize (window2, 300, 150);
 gtk_widget_set_uposition (window2, 100, 100);
  
 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_container_border_width (GTK_CONTAINER (window2), 5);
 gtk_widget_show (vbox);

 hbox = gtk_hbox_new (FALSE, 10);
 gtk_container_border_width (GTK_CONTAINER (hbox), 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);
 
 label = gtk_label_new ("Date: Year (ie. 1998):");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 eb1 = gtk_entry_new();
 gtk_editable_select_region (GTK_EDITABLE (eb1), 0, -1);
 gtk_box_pack_start (GTK_BOX (hbox), eb1, TRUE, TRUE, 0);
 gtk_widget_show (eb1);

 hbox = gtk_hbox_new (FALSE, 10);
 gtk_container_border_width (GTK_CONTAINER (hbox), 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);
 
 label = gtk_label_new ("Month (ie. 5):");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);
 
 eb2 = gtk_entry_new();
 gtk_editable_select_region (GTK_EDITABLE (eb2), 0, -1);
 gtk_box_pack_start (GTK_BOX (hbox), eb2, TRUE, TRUE, 0);
 gtk_widget_show (eb2);

 hbox = gtk_hbox_new (FALSE, 10);
 gtk_container_border_width (GTK_CONTAINER (hbox), 0);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 0);
 gtk_widget_show (hbox);
 
 label = gtk_label_new ("Day (ie. 27):");
 gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 eb3 = gtk_entry_new();
 gtk_editable_select_region (GTK_EDITABLE (eb3), 0, -1);
 gtk_box_pack_start (GTK_BOX (hbox), eb3, TRUE, TRUE, 0);
 gtk_widget_show (eb3);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_planning_daily_ok), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button); 
 gtk_widget_show (window2);
}

int CB_planning_add(GtkWidget *widget, GtkWidget *entry)
{
 system("gxplanning add &");
}

int CB_run_ok(GtkWidget *widget, GtkWidget *entry)
{
 system(gtk_entry_get_text(GTK_ENTRY(entry_box)));
 gtk_widget_destroy(window2);
 window2 = NULL;
}

int CB_settings_close(gint choice, GtkWidget *entry)
{
 gtk_widget_destroy(window2);
 if(choice)
 {
  sprintf(temp, "%s &", progname);
  system(temp);
  exit(0);
 }
}

int CB_browse_1_ok(GtkWidget *widget, GtkFileSelection *fs)
{
 gtk_entry_set_text (GTK_ENTRY(eb3),
  gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)));
 gtk_widget_destroy(window2);
}

int CB_browse_2_ok(GtkWidget *widget, GtkFileSelection *fs)
{
 gtk_entry_set_text (GTK_ENTRY(eb4),
  gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)));
 gtk_widget_destroy(window2);
}

int CB_browse_1(GtkWidget *widget, GtkWidget *entry)
{
 window2 = gtk_file_selection_new ("Browse");
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(fs_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(fs_cancel), &window2);   
 gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION(window2)->ok_button),
  "clicked", GTK_SIGNAL_FUNC(CB_browse_1_ok), window2);
 gtk_signal_connect (GTK_OBJECT(GTK_FILE_SELECTION(window2)->cancel_button),
  "clicked", GTK_SIGNAL_FUNC(fs_cancel), &window2);
 gtk_widget_set_uposition (window2, 100, 100);
 gtk_widget_show (window2);
}

int CB_browse_2(GtkWidget *widget, GtkWidget *entry)
{
 window2 = gtk_file_selection_new ("Browse");
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(fs_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(fs_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION(window2)->ok_button),
  "clicked", GTK_SIGNAL_FUNC(CB_browse_2_ok), window2);
 gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(window2)->cancel_button),
  "clicked", GTK_SIGNAL_FUNC(fs_cancel), &window2);
 gtk_widget_set_uposition (window2, 100, 100);
 gtk_widget_show (window2);
}

int CB_settings_button_add_ok(GtkWidget *widget, GtkWidget *entry)
{
 sprintf(temp, "%s/.gxdesktop", home);
 fd = fopen(temp, "a");
 sprintf(temp, "button: %d \"%s\" %s %s &\n",
  atoi(gtk_entry_get_text(GTK_ENTRY(eb1))),
  gtk_entry_get_text(GTK_ENTRY(eb2)),
  gtk_entry_get_text(GTK_ENTRY(eb3)),
  gtk_entry_get_text(GTK_ENTRY(eb4)));
 fputs(temp, fd);
 fclose(fd);
 gtk_widget_destroy(widget);
}

int CB_settings_button_add(GtkWidget *widget, GtkWidget *entry)
{
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_run_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_run_cancel), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), "Add a button");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_uposition (window2, 100, 100);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_container_border_width (GTK_CONTAINER (window2), 5);
 gtk_widget_show (vbox);
  
 label = gtk_label_new ("Button ID number:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);
 
 eb1 = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (eb1), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb1, TRUE, TRUE, 0);
 gtk_widget_show (eb1);

 label = gtk_label_new ("Button name:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 eb2 = gtk_entry_new (); 
 gtk_editable_select_region (GTK_EDITABLE (eb2), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb2, TRUE, TRUE, 0);
 gtk_widget_show (eb2);

 label = gtk_label_new ("Icon xpm:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);
 
 eb3 = gtk_entry_new (); 
 gtk_editable_select_region (GTK_EDITABLE (eb3), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb3, TRUE, TRUE, 0);
 gtk_widget_show (eb3);

 button = gtk_button_new_with_label ("Browse...");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_browse_1), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
 
 label = gtk_label_new ("Command (no trailing &):");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);
 
 eb4 = gtk_entry_new (); 
 gtk_editable_select_region (GTK_EDITABLE (eb4), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb4, TRUE, TRUE, 0);
 gtk_widget_show (eb4);

 button = gtk_button_new_with_label ("Browse...");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_browse_2), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
 
 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_settings_button_add_ok), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
 gtk_widget_show(window2);
}

int CB_settings_menu_add_ok(GtkWidget *widget, GtkWidget *entry)
{
 sprintf(temp, "%s/.gxdesktop", home);
 fd = fopen(temp, "a");
 sprintf(temp, "menu: %d \"%s\" %s &\n",
  atoi(gtk_entry_get_text(GTK_ENTRY(eb1))),
  gtk_entry_get_text(GTK_ENTRY(eb2)),
  gtk_entry_get_text(GTK_ENTRY(eb3)));
 fputs(temp, fd);
 fclose(fd);
 gtk_widget_destroy(widget);
}

int CB_settings_button_del_ok(GtkWidget *widget, GtkWidget *entry)
{
 sprintf(temp, "%s/.gxdesktop", home);
 fd = fopen(temp, "r");
 fd2 = fopen("/tmp/.gxdesktop", "w"); 
 if(fd2==NULL)   
 {
  msgbox("Error", "Can't open temporary file");
  return;
 }
 while(fgets(temp,255,fd)!=NULL)
 {
  if(lindex(temp,0)!=NULL)
  if(strcasecmp(lindex(temp,0),"button:") ||
  strcasecmp(lindex(temp,1),gtk_entry_get_text(GTK_ENTRY(eb1))))
  {
   fputs(temp, fd2);
  }
 }
 fclose(fd);  
 fclose(fd2);
 sprintf(temp, "%s/.gxdesktop", home);
 sprintf(temp2, "mv /tmp/.gxdesktop %s", temp);
 system(temp2);
 gtk_widget_destroy(widget);
}

int CB_settings_button_del(GtkWidget *widget, GtkWidget *entry)
{
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_run_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_run_cancel), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), "Remove a button");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_uposition (window2, 100, 100);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_container_border_width (GTK_CONTAINER (window2), 5);
 gtk_widget_show (vbox);
  
 label = gtk_label_new ("Button ID:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 eb1 = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (eb1), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb1, TRUE, TRUE, 0);
 gtk_widget_show (eb1);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_settings_button_del_ok), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
 gtk_widget_show(window2);
}

int CB_settings_menu_del_ok(GtkWidget *widget, GtkWidget *entry)
{
 sprintf(temp, "%s/.gxdesktop", home);
 fd = fopen(temp, "r");
 fd2 = fopen("/tmp/.gxdesktop", "w");
 if(fd2==NULL)
 {
  msgbox("Error", "Can't open temporary file");
  return;
 }
 while(fgets(temp,255,fd)!=NULL)
 {
  if(lindex(temp,0)!=NULL)
  if(strcasecmp(lindex(temp,0),"menu:") ||
  strcasecmp(lindex(temp,1),gtk_entry_get_text(GTK_ENTRY(eb1))))
  fputs(temp, fd2);
 }
 fclose(fd);
 fclose(fd2);
 sprintf(temp, "%s/.gxdesktop", home);
 sprintf(temp2, "mv /tmp/.gxdesktop %s", temp);
 system(temp2);
 gtk_widget_destroy(widget);
}

int CB_settings_menu_del(GtkWidget *widget, GtkWidget *entry)
{
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_run_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_run_cancel), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), "Remove a menu");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_uposition (window2, 100, 100);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_container_border_width (GTK_CONTAINER (window2), 5);
 gtk_widget_show (vbox);
  
 label = gtk_label_new ("Menu ID:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);
 
 eb1 = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (eb1), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb1, TRUE, TRUE, 0);
 gtk_widget_show (eb1);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_settings_menu_del_ok), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
 gtk_widget_show(window2);
}

int CB_settings_menu_add(GtkWidget *widget, GtkWidget *entry)
{
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_run_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_run_cancel), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), "Add a menu");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_uposition (window2, 100, 100);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_container_border_width (GTK_CONTAINER (window2), 5);
 gtk_widget_show (vbox);

 label = gtk_label_new ("Menu ID number:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 eb1 = gtk_entry_new ();  
 gtk_editable_select_region (GTK_EDITABLE (eb1), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb1, TRUE, TRUE, 0);
 gtk_widget_show (eb1);

 label = gtk_label_new ("Menu name:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);
 
 eb2 = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (eb2), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb2, TRUE, TRUE, 0);
 gtk_widget_show (eb2);

 label = gtk_label_new ("Command (no trailing &):");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);
 
 eb3 = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (eb3), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), eb3, TRUE, TRUE, 0);
 gtk_widget_show (eb3);

 button = gtk_button_new_with_label ("Browse...");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_browse_1), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_settings_menu_add_ok), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show(button);
 gtk_widget_show(window2);
}

int CB_settings_edit(GtkWidget *widget, GtkWidget *entry)
{
 sprintf(temp, "gxedit %s/.gxdesktop &", home);
 system(temp);
}

int CB_settings_lock(GtkWidget *gtklist, gpointer func_data)
{
 GList *dlist;
 dlist = GTK_LIST(gtklist)->selection;
 while (dlist)
 {
  GtkObject *list_item;
  gchar *item_data_string;
  list_item = GTK_OBJECT(dlist->data);
  item_data_string = gtk_object_get_data(list_item, list_item_data_key1);
   
  sprintf(temp, "%s/.gxdesktop", home);
  fd = fopen(temp, "r");
  fd2 = fopen("/tmp/.gxdesktop", "w");
  if(fd2==NULL)
  {
   msgbox("Error", "Can't open temporary file");
   return;
  }
  while(fgets(temp,255,fd)!=NULL)
  {
   if(lindex(temp,0)!=NULL)
   if(strcasecmp(lindex(temp,0),"screen_lock:")) fputs(temp, fd2);
   else
   {
    fputs("screen_lock: ", fd2);
    fputs(item_data_string, fd2);
    fputs("\n", fd2);
   }
  }
  fclose(fd);
  fclose(fd2);
  sprintf(temp, "%s/.gxdesktop", home);
  sprintf(temp2, "mv /tmp/.gxdesktop %s", temp);
  system(temp2);
    
  dlist = dlist->next;
 }
}

int CB_settings_screen(GtkWidget *gtklist, gpointer func_data)
{
 GList *dlist;
 dlist = GTK_LIST(gtklist)->selection;
 while (dlist)
 {
  GtkObject *list_item;
  gchar *item_data_string;
  list_item = GTK_OBJECT(dlist->data);
  item_data_string = gtk_object_get_data(list_item, list_item_data_key2);

  sprintf(temp, "%s/.gxdesktop", home);
  fd = fopen(temp, "r");   
  fd2 = fopen("/tmp/.gxdesktop", "w");
  if(fd2==NULL)
  {
   msgbox("Error", "Can't open temporary file");
   return;
  }
  while(fgets(temp,255,fd)!=NULL)
  {
   if(lindex(temp,0)!=NULL)
   if(strcasecmp(lindex(temp,0),"screen_saver:")) fputs(temp, fd2);
   else
   {
    fputs("screen_saver: ", fd2);
    fputs(item_data_string, fd2);
    fputs("\n", fd2);
   }
  }
  fclose(fd);
  fclose(fd2);
  sprintf(temp, "%s/.gxdesktop", home);
  sprintf(temp2, "mv /tmp/.gxdesktop %s", temp);
  system(temp2);

  dlist = dlist->next;  
 }
}

int CB_settings(GtkWidget *widget, GtkWidget *entry)
{
 int i;
 char *string;
 char *screen_choices = "ant bat blot bouboule bounce braid bug clock demon eyes flag flame forest galaxy geometry grav helix hop hyper image kaleid laser life life1d life3d lissie marquee maze mountain nose petal puzzle pyro qix rock rotor shape slip 
 sphere spiral spline swarm swirl triangle wator world worm blank random";
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_run_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_run_cancel), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), "Settings");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_usize (window2, 300, 350);
 gtk_widget_set_uposition (window2, 100, 100);

 vbox2 = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox2);   
 gtk_container_border_width (GTK_CONTAINER (vbox2), 5);
 gtk_widget_show (vbox2);

 notebook = gtk_notebook_new ();
 gtk_widget_set_usize (notebook, 300, 300);
 gtk_notebook_set_tab_pos (GTK_NOTEBOOK (notebook), GTK_POS_TOP);
 gtk_box_pack_start (GTK_BOX (vbox2), notebook, TRUE, TRUE, 0);
 gtk_widget_show (notebook);

 frame = gtk_frame_new ("Buttons and menus configuration");
 gtk_container_border_width (GTK_CONTAINER (frame), 10);
 gtk_widget_set_usize (frame, 300, 300);
 gtk_widget_show (frame);

 label = gtk_label_new ("Toolbar");
 gtk_notebook_append_page (GTK_NOTEBOOK (notebook), frame, label);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (frame), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 5);
 gtk_widget_show (vbox);

 button = gtk_button_new_with_label ("Add a menu item");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_settings_menu_add), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 button = gtk_button_new_with_label ("Remove a menu item");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_settings_menu_del), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 button = gtk_button_new_with_label ("Add a button");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_settings_button_add), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 button = gtk_button_new_with_label ("Remove a button");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_settings_button_del), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 button = gtk_button_new_with_label ("Edit configuration");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_settings_edit), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 frame = gtk_frame_new ("Screensaver and screen lock");
 gtk_container_border_width (GTK_CONTAINER (frame), 10);
 gtk_widget_set_usize (frame, 500, 270);
 gtk_widget_show (frame);

 label = gtk_label_new ("Screen");
 gtk_notebook_append_page (GTK_NOTEBOOK (notebook), frame, label);

 hbox = gtk_hbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (frame), hbox);
 gtk_container_border_width (GTK_CONTAINER (hbox), 5);
 gtk_widget_show (hbox);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (hbox), vbox, TRUE, TRUE, 0);
 gtk_container_border_width (GTK_CONTAINER (vbox), 5);
 gtk_widget_show (vbox);

 label = gtk_label_new ("Screen saver:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 scrolled_window = gtk_scrolled_window_new(NULL, NULL);
 gtk_widget_set_usize(scrolled_window, 250, 150);
 gtk_container_add(GTK_CONTAINER(vbox), scrolled_window);
 gtk_widget_show(scrolled_window);

 gtklist1 = gtk_list_new();
 gtk_container_add(GTK_CONTAINER(scrolled_window), gtklist1);
 gtk_widget_show(gtklist1);
 gtk_signal_connect(GTK_OBJECT(gtklist1), "selection_changed",
 GTK_SIGNAL_FUNC(CB_settings_screen), NULL);

 for(i=0;lindex(screen_choices,i)!=NULL;i++)
 {
  label = gtk_label_new(lindex(screen_choices,i));
  list_item1 = gtk_list_item_new();
  gtk_container_add(GTK_CONTAINER(list_item1), label);
  gtk_widget_show(label);
  gtk_container_add(GTK_CONTAINER(gtklist1), list_item1);
  gtk_widget_show(list_item1);
  gtk_label_get(GTK_LABEL(label), &string);
  gtk_object_set_data(GTK_OBJECT(list_item1), list_item_data_key1, string);
 }

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_box_pack_start (GTK_BOX (hbox), vbox, TRUE, TRUE, 0);
 gtk_container_border_width (GTK_CONTAINER (vbox), 5);
 gtk_widget_show (vbox);
 
 label = gtk_label_new ("Lock screen:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 scrolled_window = gtk_scrolled_window_new(NULL, NULL);
 gtk_widget_set_usize(scrolled_window, 250, 150);
 gtk_container_add(GTK_CONTAINER(vbox), scrolled_window);
 gtk_widget_show(scrolled_window);
  
 gtklist2 = gtk_list_new();
 gtk_container_add(GTK_CONTAINER(scrolled_window), gtklist2);
 gtk_widget_show(gtklist2);   
 gtk_signal_connect(GTK_OBJECT(gtklist2), "selection_changed",
 GTK_SIGNAL_FUNC(CB_settings_lock), NULL);

 for(i=0;lindex(screen_choices,i)!=NULL;i++)
 {
  label = gtk_label_new(lindex(screen_choices,i));
  list_item2 = gtk_list_item_new();
  gtk_container_add(GTK_CONTAINER(list_item2), label);
  gtk_widget_show(label);
  gtk_container_add(GTK_CONTAINER(gtklist2), list_item2);
  gtk_widget_show(list_item2);
  gtk_label_get(GTK_LABEL(label), &string);
  gtk_object_set_data(GTK_OBJECT(list_item2), list_item_data_key2, string);
 }

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_container_border_width (GTK_CONTAINER (hbox), 5);
 gtk_box_pack_start (GTK_BOX (vbox2), hbox, FALSE, FALSE, 0);
 gtk_widget_show (hbox);

 button = gtk_button_new_with_label ("Apply");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked", 
  GTK_SIGNAL_FUNC(CB_settings_close), (gpointer) 1);
 gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 button = gtk_button_new_with_label ("Close"); 
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_settings_close), (gpointer) 0);
 gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 gtk_widget_show(window2);
}

int CB_run(GtkWidget *widget, GtkWidget *entry)
{
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_run_cancel), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_run_cancel), &window2);  
 gtk_window_set_title (GTK_WINDOW (window2), "Run");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_uposition (window2, 100, 100);
  
 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_container_border_width (GTK_CONTAINER (window2), 5);
 gtk_widget_show (vbox);
  
 label = gtk_label_new ("Enter the shell command or file to run:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);
 
 entry_box = gtk_entry_new ();
 gtk_editable_select_region (GTK_EDITABLE (entry_box), 0, -1);
 gtk_box_pack_start (GTK_BOX (vbox), entry_box, TRUE, TRUE, 0);
 gtk_widget_show (entry_box);

 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_run_ok), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window2);
}

int CB_info_close(GtkWidget *widget, GtkWidget *entry)
{
 gtk_widget_destroy(widget);
}

int CB_run_gxzip(GtkWidget *widget, GtkWidget *entry) 
{
 system("gxzip &");
}

int CB_run_gxedit(GtkWidget *widget, GtkWidget *entry)
{
 system("gxedit &");
}

int CB_info_system(gint type, GtkWidget *entry)   
{
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize (GTK_WIDGET (window2), 400, 200);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_info_close), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_info_close), &window2);
 if(type)
 gtk_window_set_title (GTK_WINDOW (window2), "CPU information:");
 else
 gtk_window_set_title (GTK_WINDOW (window2), "Memory information:");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_uposition (window2, 100, 100);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 5);
 gtk_widget_show (vbox);

 table = gtk_table_new (2, 2, FALSE);
 gtk_table_set_row_spacing (GTK_TABLE (table), 0, 2);
 gtk_table_set_col_spacing (GTK_TABLE (table), 0, 2);
 gtk_box_pack_start (GTK_BOX (vbox), table, TRUE, TRUE, 0);
 gtk_widget_show (table);

 text = gtk_text_new (NULL, NULL);
 gtk_text_set_word_wrap(GTK_TEXT (text), TRUE);
 gtk_table_attach_defaults (GTK_TABLE (table), text, 0, 1, 0, 1);
 gtk_widget_show (text);

 vscrollbar = gtk_vscrollbar_new (GTK_TEXT (text)->vadj);
 gtk_table_attach (GTK_TABLE (table), vscrollbar, 1, 2, 0, 1,
  GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
 gtk_widget_show (vscrollbar);
 gtk_text_freeze (GTK_TEXT (text));
 gtk_widget_realize (text);

 if(type)
 fd = fopen("/proc/cpuinfo", "r");
 else
 fd = fopen("/proc/meminfo", "r");

 if(fd==NULL)
 {
  gtk_text_insert (GTK_TEXT(text), NULL, &text->style->black, NULL, "This system does not appear to support /proc\n", -1);
 }
 else
 {
  while(fgets(temp,255,fd)!=NULL)
  {
   gtk_text_insert (GTK_TEXT(text), NULL, &text->style->black, NULL, temp, -1);
  }
  fclose(fd);
 }

 button = gtk_button_new_with_label ("Close");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_info_close), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0); 
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window2);
}

int CB_info(GtkWidget *widget, GtkWidget *entry)
{
 window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize (GTK_WIDGET (window2), 450, 200);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_info_close), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",  
  GTK_SIGNAL_FUNC(CB_info_close), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), "Information");
 gtk_container_border_width (GTK_CONTAINER (window2), 2);
 gtk_widget_set_uposition (window2, 100, 100);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window2), vbox);
 gtk_container_border_width (GTK_CONTAINER (vbox), 5);
 gtk_widget_show (vbox);

 sprintf(temp, "This is GXdesktop v%s by Patrick Lambert <drow@wildstar.net>", VERSION);
 label = gtk_label_new (temp);
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 label = gtk_label_new ("See http://devplanet.fastethernet.net/gxdesktop.html for more on GXdesktop");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 label = gtk_label_new ("The current time is:");
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 lt=time(NULL);
 label = gtk_label_new (ctime(&lt));
 gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
 gtk_widget_show (label);

 hbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(hbox), GTK_BUTTONBOX_END);
 gtk_button_box_set_spacing(GTK_BUTTON_BOX(hbox), 5);
 gtk_box_pack_start (GTK_BOX (vbox), hbox, FALSE, FALSE, 0);
 gtk_widget_show (hbox);

 button = gtk_button_new_with_label ("CPU info");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_info_system), (gpointer) 1);   
 gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 button = gtk_button_new_with_label ("Memory info");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_info_system), (gpointer) 0);
 gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 0);
 gtk_widget_show (button);

 button = gtk_button_new_with_label ("Close");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_info_close), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);

 gtk_widget_show (window2);
}

int CB_screen_saver(GtkWidget *widget, GtkWidget *entry)
{
 sprintf(temp, "xlock -nolock -mode %s &", config.screen_saver);
 system(temp);
}

int CB_lock_screen(GtkWidget *widget, GtkWidget *entry)
{
 sprintf(temp, "xlock -mode %s &", config.screen_lock);
 system(temp);
}

int CB_run_gxprint(GtkWidget *widget, GtkWidget *entry)
{
 system("gxprint &");
}

int CB_msgbox_close(GtkWidget *widget, GtkWidget *entry)
{
 gtk_widget_destroy(widget);
 gtk_main_quit();
}

int msgbox(char *title, char *string)
{
 window2 = gtk_dialog_new ();
 gtk_widget_set_usize (GTK_WIDGET (window2), strlen(string)+400, 100);
 gtk_signal_connect (GTK_OBJECT (window2), "destroy",
  GTK_SIGNAL_FUNC(CB_msgbox_close), &window2);
 gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
  GTK_SIGNAL_FUNC(CB_msgbox_close), &window2);
 gtk_window_set_title (GTK_WINDOW (window2), title);
 gtk_container_border_width (GTK_CONTAINER (window2), 0);
 gtk_widget_set_uposition (window2, 100, 200);

 label = gtk_label_new (string);
 gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window2)->vbox),
  label, TRUE, TRUE, 0);
 gtk_widget_show (label);
  
 button = gtk_button_new_with_label ("OK");
 gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
  GTK_SIGNAL_FUNC(CB_msgbox_close), GTK_OBJECT (window2));
 gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window2)->action_area),
  button, TRUE, TRUE, 0);
 GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
 gtk_widget_grab_default (button);
 gtk_widget_show (button);
 gtk_widget_show (window2); 
}

int make_gui()
{
 int i;
 window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_widget_set_usize (GTK_WIDGET (window), config.x_size, config.y_size);
 gtk_signal_connect (GTK_OBJECT (window), "destroy",
  GTK_SIGNAL_FUNC(CB_exit), &window);
 gtk_signal_connect (GTK_OBJECT (window), "delete_event",
  GTK_SIGNAL_FUNC(CB_exit), &window);
 gtk_window_set_title (GTK_WINDOW (window), "GXdesktop");
 gtk_widget_set_uposition (window, config.x_pos, config.y_pos);
 gtk_container_border_width (GTK_CONTAINER (window), 0);
 gtk_widget_realize (window);

 vbox = gtk_vbox_new (FALSE, 0);
 gtk_container_add (GTK_CONTAINER (window), vbox);
 gtk_widget_show (vbox);

 menubar = gtk_menu_bar_new();
 gtk_box_pack_start (GTK_BOX (vbox), menubar, FALSE, TRUE, 0);
 gtk_widget_show (menubar);

 menu = gtk_menu_new();

 menuitem = gtk_menu_item_new_with_label("Run...");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_run), GTK_OBJECT(window));
 gtk_widget_show(menuitem);

 menuitem = gtk_menu_item_new();
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_widget_show(menuitem);

 if(config.show_gxedit)
 {
  menuitem = gtk_menu_item_new_with_label("Text editor");
  gtk_menu_append(GTK_MENU(menu), menuitem);
  gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
   GTK_SIGNAL_FUNC(CB_run_gxedit), GTK_OBJECT(window));
  gtk_widget_show(menuitem);
 }

 if(config.show_gxlpr)
 {
  menuitem = gtk_menu_item_new_with_label("Print a file");
  gtk_menu_append(GTK_MENU(menu), menuitem);
  gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
   GTK_SIGNAL_FUNC(CB_run_gxprint), GTK_OBJECT(window));
  gtk_widget_show(menuitem);
 }

 if(config.show_gxzip)
 {
  menuitem = gtk_menu_item_new_with_label("(Un)Compress a file");
  gtk_menu_append(GTK_MENU(menu), menuitem);
  gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
   GTK_SIGNAL_FUNC(CB_run_gxzip), GTK_OBJECT(window));
  gtk_widget_show(menuitem);
 }

 if(config.show_gxplanning)
 {
  submenu = gtk_menu_new();

  menuitem = gtk_menu_item_new_with_label("Check today's planning");
  gtk_menu_append(GTK_MENU(submenu), menuitem);
  gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_planning), GTK_OBJECT(window));
  gtk_widget_show(menuitem);

  menuitem = gtk_menu_item_new_with_label("Look at an other date");
  gtk_menu_append(GTK_MENU(submenu), menuitem);
  gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_planning_daily), GTK_OBJECT(window));
  gtk_widget_show(menuitem);

  menuitem = gtk_menu_item_new_with_label("Add comments");
  gtk_menu_append(GTK_MENU(submenu), menuitem);
  gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_planning_add), GTK_OBJECT(window));
  gtk_widget_show(menuitem);

  menubutton = gtk_menu_item_new_with_label("Planning");
  gtk_widget_show(menubutton);

  menuitem = gtk_menu_item_new_with_label("Planning");
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (menuitem), submenu);
  gtk_menu_append(GTK_MENU(menu), menuitem);
  gtk_widget_show(menuitem);
 }

 if(config.show_screen)
 {
  submenu = gtk_menu_new();
  
  menuitem = gtk_menu_item_new_with_label("Screen saver");
  gtk_menu_append(GTK_MENU(submenu), menuitem);
  gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_screen_saver), GTK_OBJECT(window));
  gtk_widget_show(menuitem);

  menuitem = gtk_menu_item_new_with_label("Lock screen");
  gtk_menu_append(GTK_MENU(submenu), menuitem);
  gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_lock_screen), GTK_OBJECT(window));
  gtk_widget_show(menuitem);

  menubutton = gtk_menu_item_new_with_label("Screen");
  gtk_widget_show(menubutton);

  menuitem = gtk_menu_item_new_with_label("Screen");
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (menuitem), submenu);
  gtk_menu_append(GTK_MENU(menu), menuitem);
  gtk_widget_show(menuitem);
 }

/* menu loop */
 sprintf(temp, "%s/.gxdesktop", home);
 fd = fopen(temp, "r");
 while(fgets(temp,255,fd)!=NULL)
 {
  if(lindex(temp,0)==NULL) { }
  else if(!strcasecmp(lindex(temp,0),"menu:"))
  {
   bzero(temp2, 255);
   for(i=2;lindex(temp,i)!=NULL;i++)
   {
    strcat(temp2,lindex(temp,i));
    if(*(lindex(temp,i)+strlen(lindex(temp,i))-1)=='\"') break;
    strcat(temp2," ");
   }
   temp2[0]=' ';
   temp2[strlen(temp2)-1]=' ';
   menuitem = gtk_menu_item_new_with_label(temp2);
   gtk_menu_append(GTK_MENU(menu), menuitem);
   gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
    GTK_SIGNAL_FUNC(CB_call), (gpointer) atoi(lindex(temp,1)));
   gtk_widget_show(menuitem);
  }
  else if(!strcasecmp(lindex(temp,0),"sub-menu-start:"))
  {
   submenu = gtk_menu_new();
  }
  else if(!strcasecmp(lindex(temp,0),"sub-menu-set:"))
  {
   menubutton = gtk_menu_item_new_with_label(lindex(temp,1));
   gtk_widget_show(menubutton);

   menuitem = gtk_menu_item_new_with_label(lindex(temp,1));
   gtk_menu_item_set_submenu (GTK_MENU_ITEM (menuitem), submenu);
   gtk_menu_append(GTK_MENU(menu), menuitem);
   gtk_widget_show(menuitem);
  }
  else if(!strcasecmp(lindex(temp,0),"sub-menu-item:"))
  { 
   bzero(temp2, 255);
   for(i=2;lindex(temp,i)!=NULL;i++)
   {
    strcat(temp2,lindex(temp,i));
    if(*(lindex(temp,i)+strlen(lindex(temp,i))-1)=='\"') break;
    strcat(temp2," ");
   }
   temp2[0]=' ';
   temp2[strlen(temp2)-1]=' ';
   menuitem = gtk_menu_item_new_with_label(temp2);
   gtk_menu_append(GTK_MENU(submenu), menuitem);
   gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",   
   GTK_SIGNAL_FUNC(CB_call), (gpointer) atoi(lindex(temp,1)));
   gtk_widget_show(menuitem);
  }
 }
 fclose(fd);
/* end loop */

 menuitem = gtk_menu_item_new();
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_widget_show(menuitem);

 menuitem = gtk_menu_item_new_with_label("Settings");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_settings), GTK_OBJECT(window));
 gtk_widget_show(menuitem);

 menuitem = gtk_menu_item_new_with_label("Info");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_info), GTK_OBJECT(window));
 gtk_widget_show(menuitem);

 menuitem = gtk_menu_item_new_with_label("Exit");
 gtk_menu_append(GTK_MENU(menu), menuitem);
 gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
  GTK_SIGNAL_FUNC(CB_exit), GTK_OBJECT(window));
 gtk_widget_show(menuitem);

 menubutton = gtk_menu_item_new_with_label("Desk");
 gtk_widget_show(menubutton);

 gtk_menu_item_set_submenu(GTK_MENU_ITEM(menubutton), menu);
 gtk_menu_bar_append(GTK_MENU_BAR(menubar), menubutton);

 if(config.side==1)
 bar = gtk_toolbar_new (GTK_ORIENTATION_VERTICAL, GTK_TOOLBAR_BOTH);
 else
 bar = gtk_toolbar_new (GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);

 gtk_box_pack_start (GTK_BOX (vbox), bar, FALSE, FALSE, 0);

/* button loop */
 sprintf(temp, "%s/.gxdesktop", home);
 fd = fopen(temp, "r");
 while(fgets(temp,255,fd)!=NULL)
 {
  temp[strlen(temp)-1]=' ';
  if(lindex(temp,0)==NULL) { }
  else if(!strcasecmp(lindex(temp,0),"space:"))
  {
   gtk_toolbar_append_space(GTK_TOOLBAR(bar));
  }
  else if(!strcasecmp(lindex(temp,0),"button:"))
  {
   fd2 = fopen(lindex(temp,3), "r");
   bzero(temp2, 255);
   for(i=2;lindex(temp,i)!=NULL;i++)
   {
    strcat(temp2,lindex(temp,i));
    if(*(lindex(temp,i)+strlen(lindex(temp,i))-1)=='\"') break;
    strcat(temp2," ");
   }
   temp2[0]=' ';
   temp2[strlen(temp2)-1]=' ';
   if(fd2!=NULL)
   {
    fclose(fd2);
    gtk_toolbar_append_item (GTK_TOOLBAR (bar), temp2, NULL, NULL,
    new_pixmap (lindex(temp,3), window->window, &window->style->bg[GTK_STATE_NORMAL]),
    GTK_SIGNAL_FUNC(CB_call), (gpointer) atoi(lindex(temp,1)));
   }
   else
   {
    gtk_toolbar_append_item (GTK_TOOLBAR (bar), temp2, NULL, NULL,
    NULL, GTK_SIGNAL_FUNC(CB_call), (gpointer) atoi(lindex(temp,1)));
   }
  }
 }
 fclose(fd);
/* end loop */

 gtk_widget_show (bar);
 gtk_widget_show (window);
}

int read_cfg()
{
 while(fgets(temp,255,fd)!=NULL)
 {
  temp[strlen(temp)-1]=' ';
  if(lindex(temp,0)==NULL) { }
  else if(!strcasecmp(lindex(temp,0),"x_size:"))
  config.x_size = atoi(lindex(temp,1));
  else if(!strcasecmp(lindex(temp,0),"y_size:"))
  config.y_size = atoi(lindex(temp,1));
  else if(!strcasecmp(lindex(temp,0),"x_position:"))
  config.x_pos = atoi(lindex(temp,1));
  else if(!strcasecmp(lindex(temp,0),"y_position:"))
  config.y_pos = atoi(lindex(temp,1));
  else if(!strcasecmp(lindex(temp,0),"screen_saver:"))
  strncpy(config.screen_saver, lindex(temp,1), 20);
  else if(!strcasecmp(lindex(temp,0),"screen_lock:"))
  strncpy(config.screen_lock, lindex(temp,1), 20);
  else if(!strcasecmp(lindex(temp,0),"show_screen:"))
  config.show_screen = atoi(lindex(temp,1));
  else if(!strcasecmp(lindex(temp,0),"show_editor:"))
  config.show_gxedit = atoi(lindex(temp,1));
  else if(!strcasecmp(lindex(temp,0),"set"))
  {
   sprintf(config.key,"$%s",lindex(temp,1));
   strcpy(config.data,lrange(temp,2));
  }
  else if(!strcasecmp(lindex(temp,0),"show_planning:"))
  config.show_gxplanning = atoi(lindex(temp,1));
  else if(!strcasecmp(lindex(temp,0),"show_print:"))
  config.show_gxlpr = atoi(lindex(temp,1));
  else if(!strcasecmp(lindex(temp,0),"show_compress:"))
  config.show_gxzip = atoi(lindex(temp,1));
  else if(!strcasecmp(lindex(temp,0),"planning_on_start:"))
  config.plan = atoi(lindex(temp,1));
  else if(!strcasecmp(lindex(temp,0),"side:"))
  {
   if(!strcasecmp(lindex(temp,1),"horizontal"))
   config.side = 0;
   else if(!strcasecmp(lindex(temp,1),"vertical"))
   config.side = 1;
  }
  else if(!strcasecmp(lindex(temp,0),"#")) { }
  else if(!strcasecmp(lindex(temp,0),"button:")) { }
  else if(!strcasecmp(lindex(temp,0),"sub-menu-start:")) { }
  else if(!strcasecmp(lindex(temp,0),"menu:")) { }
  else if(!strcasecmp(lindex(temp,0),"sub-menu-set:")) { }
  else if(!strcasecmp(lindex(temp,0),"sub-menu-item:")) { }
  else printf("Unknown configuration line: %s\n",lrange(temp,0));
 }
 fclose(fd);
}

int main(int argc, char *argv[])
{
 struct tm *current;
 strncpy(progname, argv[0], 100);
 strncpy(progname, argv[0], 100);
 strncpy(home, getenv("HOME"), 100);
 gtk_init(&argc, &argv);
 sprintf(temp, "%s/.gxdesktop", home);
 fd = fopen(temp, "r");
 if(fd==NULL)
 {
  msgbox("Error", "Can't open ~/.gxdesktop config file.\nYou can get a sample one from the /sample directory.");
  gtk_main();
  exit(1);
 }
 read_cfg();
 make_gui();
 if(config.plan)
 {
  lt = time(NULL);   
  current = localtime(&lt);   
  sprintf(temp, "gxplanning daily 19%d %d %d &", current->tm_year, (current->tm_mon+1), current->tm_mday);
  system(temp);
 }
 gtk_main();
 return(0);
}
