#include <gtk/gtk.h>
#include <stdio.h>
#include <sys/time.h>
FILE *fd, *fd2;
char temp[255], home[100], progname[100], global_var[255], progname[100];
char temp2[255];
struct configure {
 int x_size;
 int y_size;
 int x_pos;
 int y_pos;
 int side;
 int plan;
 char screen_saver[20];
 char screen_lock[20];
 int show_gxedit;
 int show_gxplanning;
 int show_gxzip;
 int show_gxlpr;
 int show_screen;
 char key[50];
 char data[100];
} config;
GtkWidget *window, *window2, *hbox, *vbox, *button, *label, *notebook;
GtkWidget *menubar, *menuitem, *menu, *menubutton, *bar, *entry_box, *frame;
GtkWidget *eb1, *eb2, *eb3, *eb4, *submenu, *table, *vscrollbar, *text, *vbox2;
GtkWidget *scrolled_window, *list_item1, *gtklist1, *list_item2, *gtklist2;
time_t lt;
const gchar *list_item_data_key1="list_item_data";
const gchar *list_item_data_key2="list_item_data";
