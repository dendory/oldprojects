#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char *lrange(char *input_string, int starting_at)
{
 char *tokens[1024];
 static char tmpstring[1024]="";
 int i;
 char out_string[1024]="";
 strcpy(out_string,"");
 if(input_string==NULL) {
  strcpy(out_string," ");  
  strcat(out_string,NULL);
  return strdup(out_string); }
 strncpy(tmpstring,input_string,1024);
 (char *)tokens[i=0] = (char *)strtok(tmpstring, " ");
 while(((char *)tokens[++i] = (char *)strtok(NULL, " ")));
 tokens[i] = NULL;
 i++;
 if(i<starting_at)
 {
  return (char *)"";
 }
 while(tokens[starting_at] != NULL)
 {
  strncat(out_string,tokens[starting_at],1024);
  strcat(out_string, " ");
  starting_at++;
 }
 return strdup(out_string);
}

char *lindex(char *input_string, int word_number)
{  
 char *tokens[1024];
 static char tmpstring[1024];
 int i;
 strncpy(tmpstring,input_string,1024);
 (char *)tokens[i=0] = (char *)strtok(tmpstring, " ");
 while (((char *)tokens[++i] = (char *)strtok(NULL, " ")));
 tokens[i] = NULL;
 return(tokens[word_number]);
}

int main(int argc, char *argv[])
{
 FILE *fd, *out;
 char line[512], temp[1024];

 fd = fopen("configure.libdep", "r");
 if(fd==NULL)
 {
  printf("configure.libdep not found\n");
  exit(1);
 }

 out = fopen("configure", "w");
 if(out==NULL)
 {
  printf("Can't open configure for output\n");
  exit(1);
 }

 printf("Parsing configure.libdep...\n");
 fputs("#!/bin/sh\n\n", out);
 fputs("# main defines\n", out);
 fputs("./libdep.sh c \"-Wall -O -I.\" \"-L.\" -clean\n", out);
 fputs("if [ \"$?\" = \"5\" ]; then\n", out);
 fputs("exit\n", out);
 fputs("fi\n", out);
 fputs("echo \"$*\" > .libdep.args\n", out);
 fputs("# conditional libraries\n", out);

 while(fgets(line, 500, fd)!=NULL)
 {
  line[strlen(line)-1]=' ';
  if(!strcmp(lindex(line,0),"RUN:"))
  {
   fputs(lrange(line,1), out);
   fputs("\n", out);
  }
  if(!strcmp(lindex(line,0),"PRINT:"))
  {
   sprintf(temp, "echo \"%s\"\n", lrange(line,1));
   fputs(temp, out);
  }
  if(!strcmp(lindex(line,0),"TESTLIB:"))
  {
   sprintf(temp, "TRY=`grep \"%s\" .libdep.args`\n", lindex(line,1));
   fputs(temp, out);
   fputs("if [ \"$TRY\" = \"\" ]; then\n", out);
   sprintf(temp, "./libdep.sh %s\n", lrange(line,1));
   fputs(temp, out);
   fputs("if [ \"$?\" = \"5\" ]; then\n", out);
   fputs("exit\n", out);
   fputs("fi\nfi\n", out);
  }
  if(!strcmp(lindex(line,0),"ASK:"))
  {
   sprintf(temp, "echo \"%s [y/n]\"\n", lrange(line,1));
   fputs(temp, out);
   fputs("read ans\n", out);
   fputs("if [ \"$ans\" = \"y\" ]; then\n", out);
   fgets(line, 500, fd);
   sprintf(temp, "./libdep c %s\n", line);
   fputs(temp, out);
   fputs("fi\n", out);
  }
 }

 fputs("# output creation\n", out);
 fputs("echo \"Creating Makefile\"\n", out);
 fputs("echo -n \"CFLAGS = \" > Makefile\n", out);
 fputs("cat .libdep.cflags >> Makefile\n", out);
 fputs("echo \"\" >> Makefile\n", out);
 fputs("echo -n \"LIBS = \" >> Makefile\n", out);
 fputs("cat .libdep.libs >> Makefile\n", out);
 fputs("echo \"\" >> Makefile\n", out);
 fputs("cat Makefile.libdep >> Makefile\n", out);
 printf("Done...\n");
 fclose(fd);
 fclose(out);
 system("chmod +x configure");
 return 0;
}
