#!/bin/sh
echo "Creating a .desktop file for your application, allowing it to be added to the GNOME menu. Setting name to sample.desktop"
echo "Enter the name of the application:"
read ans
echo "[Desktop Entry]" > sample.desktop
echo -n "Name=" >> sample.desktop
echo $ans >> sample.desktop
echo "Enter a comment for that application:"
read ans
echo -n "Comment=" >> sample.desktop
echo $ans >> sample.desktop
echo "Enter the command line:"
read ans
echo -n "Exec=" >> sample.desktop
echo $ans >> sample.desktop
echo "Terminal=0" >> sample.desktop
echo "Type=Application" >> sample.desktop
echo "All done. Simply rename and put in /usr/share/gnome/apps/Applications"

