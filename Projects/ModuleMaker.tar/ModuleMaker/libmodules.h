/* (C) 1999 Patrick Lambert <drow@darkelf.net> - Provided under the LGPL */
#include <dlfcn.h>
#include <stdio.h>
#define MM_VERSION "0.01"

char *MM_MODULES_DIR;
char *MM_APP_SERIAL;
char MM_TMP[512];
void *MM_HANDLE;
