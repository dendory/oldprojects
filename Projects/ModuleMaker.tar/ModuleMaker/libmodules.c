/* (C) 1999 Patrick Lambert <drow@darkelf.net> - Provided under the LGPL */
#include "libmodules.h"

#define mm_run(func_name) (dlsym(MM_HANDLE, func_name))

void mm_error(char *msg)
{
 fprintf(stderr, "ModulesMaker: %s\n", msg);
}

int mm_check_serial()
{
 return MM_APP_SERIAL;
}

void mm_reg_app(char *modules_dir)
{
 MM_APP_SERIAL = rand();
 MM_MODULES_DIR = modules_dir;
}

int mm_load_module(char *module_name)
{
 if(strlen(MM_MODULES_DIR)>50)
 {
  mm_error("Modules directory too long");
  return -1;
 }
 if(strlen(module_name)>50)
 {
  mm_error("Module name too long");
  return -1;
 }
 if(!MM_HANDLE)
 {
  mm_error("A module is already open");
  return -1;
 }
 sprintf(MM_TMP, "%s/%s.mod", MM_MODULES_DIR, module_name);
 MM_HANDLE = dlopen(MM_TMP, RTLD_LAZY);
 if(!MM_HANDLE)
 {
  mm_error((char*)dlerror());
  return -1;
 }
 return 0;
}

void mm_unload_module()
{
 if(!MM_HANDLE)
 {
  mm_error("No module is open");
  return;
 }
 dlclose(MM_HANDLE);
}

