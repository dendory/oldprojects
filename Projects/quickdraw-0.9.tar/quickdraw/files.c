/* (C) 1999-2000 Patrick Lambert (drow@post.com) - Provided under GPL */
#include "quickdraw.h"

gint qd_new_drawing_cb(GnomeDialog *dialog, int but) /* create new page and draw area */
{
 GtkWidget *s_w;
 int i;
 if(but==1) /* cancel */
 {
  gnome_dialog_close(dialog);
  return -1;
 }
 if(!strcmp(e_entry_get(qd_entry), "")) /* empty name */
 {
  gnome_dialog_close(dialog);
  gnome_error_dialog("The name can't be empty");
  return -1;
 }
 if(strlen(e_entry_get(qd_entry))>32) /* max 32 chars */
 {
  gnome_dialog_close(dialog);
  gnome_error_dialog("The name must be less than 32 chars");
  return -1; 
 }
 for(i=0; i<QD_MAXD; i++) /* name must be unique */
 {
  if(qd_drawing[i].used == TRUE)
  {
   if(!strcasecmp(qd_drawing[i].filename, e_entry_get(qd_entry)))
   {
    gnome_dialog_close(dialog);
    gnome_error_dialog("The name must be unique");
    return -1;
   }
  } 
 }
 for(i=0; i<QD_MAXD; i++) /* find a few entry */
 {
  if(qd_drawing[i].used == FALSE) break;
 }
 if(qd_drawing[i].used == TRUE) /* is entry out of range? */
 {
  gnome_dialog_close(dialog);
  gnome_error_dialog("No more drawing space available"); 
  return -1;
 }

 qd_drawing[i].used = TRUE; /* default vars, create draw area */
 qd_drawing[i].modified = FALSE;
 strcpy(qd_drawing[i].filename, e_entry_get(qd_entry));

 srandom(time(NULL)); /* create a tmp file to save everything */
 sprintf(qd_drawing[i].tempsave, "%s/.QD_%d_%s", tmp_dir, random() % 10000, e_entry_get(qd_entry));
 qd_drawing[i].fd = fopen(qd_drawing[i].tempsave, "w");
 if(qd_drawing[i].fd == NULL)
 {
  gnome_error_dialog("Could not open temp file! Quit this program and set TMP_DIR to a proper location");
  return -1;
 }
 fprintf(qd_drawing[i].fd, "%s\n", qd_drawing[i].filename);
  
 qd_drawing[i].page = e_notebook_new_page(qd_notebook, qd_drawing[i].filename, qd_drawing[i].filename);
 gtk_widget_push_visual(gdk_imlib_get_visual());
 gtk_widget_push_colormap(gdk_imlib_get_colormap());

 s_w = e_scrolled_create(qd_drawing[i].page);
 qd_drawing[i].table = gtk_table_new(3, 2, FALSE);
 e_set_size(qd_drawing[i].table, 1024, 768); 
 gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(s_w), qd_drawing[i].table); 
  
 qd_drawing[i].area = gtk_event_box_new();
 gtk_table_attach(GTK_TABLE(qd_drawing[i].table), qd_drawing[i].area, 1, 2, 1, 2, GTK_EXPAND|GTK_FILL, GTK_FILL, 0, 0);
 gtk_widget_unrealize(GTK_WIDGET(qd_drawing[i].area));
 gtk_widget_set_events(qd_drawing[i].area, GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK);
 gtk_signal_connect(GTK_OBJECT(qd_drawing[i].area), "button_press_event",
 GTK_SIGNAL_FUNC(qd_event), NULL);

 qd_drawing[i].hruler = gtk_hruler_new();
 gtk_ruler_set_metric(GTK_RULER(qd_drawing[i].hruler), GTK_PIXELS);
 gtk_ruler_set_range(GTK_RULER(qd_drawing[i].hruler), 0, 1024, 0, 1024);
 gtk_signal_connect_object(GTK_OBJECT(qd_drawing[i].area), "motion_notify_event",
 (GtkSignalFunc)E_EVENT_METHOD(qd_drawing[i].hruler, motion_notify_event), GTK_OBJECT(qd_drawing[i].hruler));
 gtk_table_attach(GTK_TABLE(qd_drawing[i].table), qd_drawing[i].hruler, 1, 2, 0, 1,
 GTK_EXPAND|GTK_SHRINK|GTK_FILL, GTK_FILL, 0, 0 );

 qd_drawing[i].vruler = gtk_vruler_new();
 gtk_ruler_set_metric(GTK_RULER(qd_drawing[i].vruler), GTK_PIXELS);
 gtk_ruler_set_range(GTK_RULER(qd_drawing[i].vruler), 0, 768, 10, 768);
 gtk_signal_connect_object(GTK_OBJECT(qd_drawing[i].area), "motion_notify_event",
 (GtkSignalFunc)E_EVENT_METHOD(qd_drawing[i].vruler, motion_notify_event), GTK_OBJECT(qd_drawing[i].vruler));
 gtk_table_attach(GTK_TABLE(qd_drawing[i].table), qd_drawing[i].vruler, 0, 1, 1, 2,
 GTK_FILL, GTK_EXPAND|GTK_SHRINK|GTK_FILL, 0, 0);
 gtk_widget_show(qd_drawing[i].area);
 gtk_widget_show(qd_drawing[i].hruler);
 gtk_widget_show(qd_drawing[i].vruler);
 gtk_widget_show(qd_drawing[i].table);

 qd_drawing[i].canvas = gnome_canvas_new();
 gtk_widget_pop_colormap();
 gtk_widget_pop_visual();
 gtk_container_add(GTK_CONTAINER(qd_drawing[i].area), qd_drawing[i].canvas);
 gnome_canvas_set_scroll_region(GNOME_CANVAS(qd_drawing[i].canvas), 0, 0, 1024, 768);
 qd_drawing[i].group = gnome_canvas_root(GNOME_CANVAS(qd_drawing[i].canvas));
 gtk_widget_show(qd_drawing[i].canvas);
 gnome_dialog_close(dialog);
 /* FIXME: we need to get gtk to redraw the notebook */
 return 0;
}

void qd_new_drawing() /* ask for new drawing name */
{
 GtkWidget *dialog;
 dialog = gnome_dialog_new("New Drawing", GNOME_STOCK_BUTTON_OK, GNOME_STOCK_BUTTON_CANCEL, NULL);
 gnome_dialog_set_parent(GNOME_DIALOG(dialog), GTK_WINDOW(qd_app));
 e_label_create(GNOME_DIALOG(dialog)->vbox, "New drawing name:");
 qd_entry = e_entry_create(GNOME_DIALOG(dialog)->vbox, "New Drawing");
 gtk_signal_connect(GTK_OBJECT(dialog), "clicked", GTK_SIGNAL_FUNC(qd_new_drawing_cb), NULL);
 gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);
 gtk_widget_show(dialog);
}

void qd_open_draw_line(gint i, gint x0, gint y0, gint x1, gint y1, double w, gint f, gint l, gchar *c)
{
 GnomeCanvasPoints *points;
 GnomeCanvasItem *item;
 points = gnome_canvas_points_new(2);
 points->coords[0] = x0;
 points->coords[1] = y0;
 points->coords[2] = x1;
 points->coords[3] = y1;
 item = gnome_canvas_item_new(qd_drawing[i].group, gnome_canvas_line_get_type(), "points", points, "width_units", w, "first_arrowhead", f, "last_arrowhead", l, "arrow_shape_a", 10.0, "arrow_shape_b", 10.0, "arrow_shape_c", 10.0, "fill_color", c, NULL);
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 gnome_canvas_points_unref(points);
 fprintf(qd_drawing[i].fd, "draw_line %d %d %d %d %f %d %d %s ;\n", x0, y0, x1, y1, w, f, l, c);
}

void qd_open_draw_rect(gint i, double x0, double y0, double x1, double y1, double w, gchar *c, gchar *o)
{
 GnomeCanvasItem *item;
 item = gnome_canvas_item_new(qd_drawing[i].group, gnome_canvas_rect_get_type(), "x1", (double)x0, "y1", (double)y0, "x2", (double)x1, "y2", (double)y1, "fill_color", c, "outline_color", o, "width_units", w, NULL);
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 fprintf(qd_drawing[i].fd, "draw_rect %f %f %f %f %f %s %s ;\n", (double)x0, (double)y1, (double)x1, (double)y1, w, c, o);
}

void qd_open_parse(GnomeDialog *dialog, int but)
{
 int i;
 gchar tmp[1024];
 FILE *fd;
 if(but==1)
 {
  gnome_dialog_close(dialog);
  return;
 }
 if(qd_new_drawing_cb(dialog, 0)==-1) return;
 i = qd_cur_page();
 sprintf(tmp, "%s/%s", qd_project_dir, qd_drawing[i].filename);
 fd = fopen(tmp, "r");
 if(fd==NULL)
 {
  gnome_error_dialog("Could not open the drawing!");
  return;
 }
 fgets(tmp, 1000, fd);
 while(fgets(tmp, 1000, fd)!=NULL)
 {
  if(!strcmp(e_lindex(tmp,0),"draw_line"))
  {
   qd_open_draw_line(i, atoi(e_lindex(tmp,1)), atoi(e_lindex(tmp,2)), atoi(e_lindex(tmp,3)), atoi(e_lindex(tmp,4)), atof(e_lindex(tmp,5)), atoi(e_lindex(tmp,6)), atoi(e_lindex(tmp,7)), e_lindex(tmp,8));
  }
  else if(!strcmp(e_lindex(tmp,0),"draw_poly"))
  {
   qd_open_draw_line(i, atoi(e_lindex(tmp,1)), atoi(e_lindex(tmp,2)), atoi(e_lindex(tmp,3)), atoi(e_lindex(tmp,4)), atoi(e_lindex(tmp,5)), 0, 0, e_lindex(tmp,6));
  }
  else if(!strcmp(e_lindex(tmp,0),"draw_rect"))
  {
   qd_open_draw_rect(i, atof(e_lindex(tmp,1)), atof(e_lindex(tmp,2)), atof(e_lindex(tmp,3)), atof(e_lindex(tmp,4)), atof(e_lindex(tmp,5)), e_lindex(tmp,6), e_lindex(tmp,7));
  }
 }
 fclose(fd);
}

void qd_open_drawing() /* open a saved drawing */
{
 GtkWidget *dialog;
 dialog = gnome_dialog_new("Open Drawing", GNOME_STOCK_BUTTON_OK, GNOME_STOCK_BUTTON_CANCEL, NULL);
 gnome_dialog_set_parent(GNOME_DIALOG(dialog), GTK_WINDOW(qd_app));
 e_label_create(GNOME_DIALOG(dialog)->vbox, "Enter a drawing name:");
 qd_entry = e_entry_create(GNOME_DIALOG(dialog)->vbox, "");
 gtk_signal_connect(GTK_OBJECT(dialog), "clicked", GTK_SIGNAL_FUNC(qd_open_parse), NULL);
 gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);
 gtk_widget_show(dialog);
}

void qd_save_drawing() /* save the currently focused page */
{
 gint i = qd_cur_page();
 gchar tmp[strlen(qd_drawing[i].tempsave)+strlen(qd_drawing[i].filename)+100];
 fclose(qd_drawing[i].fd);
 sprintf(tmp, "cp \"%s\" \"%s/%s\" >/dev/null 2>&1", qd_drawing[i].tempsave, qd_project_dir, qd_drawing[i].filename);
 system(tmp);
 fopen(qd_drawing[i].tempsave, "a");
 sprintf(tmp, "%s saved to %s", qd_drawing[i].filename, qd_project_dir);
 gnome_ok_dialog(tmp);
}

void qd_save_as_drawing() /* save under new name */
{
}

void qd_close_drawing_2() /* close the page */
{
 int i = qd_cur_page();
 gtk_widget_destroy(qd_drawing[i].page->parent);
 qd_drawing[i].used = FALSE;
 fclose(qd_drawing[i].fd);
}

void qd_close_drawing_cb(int but) /* user wants to close even if modified */
{
 if(but==0) qd_close_drawing_2();
}

void qd_close_drawing() /* close current drawing */
{
 int i = qd_cur_page();
 GtkWidget *dialog;
 if(i==-1) return;
 if(qd_drawing[i].modified == FALSE) qd_close_drawing_2(); /* drawing wasnt modified */
 else /* it was modified */
 {
  dialog = gnome_question_dialog_modal_parented("The drawing has been modified. Are you sure you want to close?", GTK_SIGNAL_FUNC(qd_close_drawing_cb), &dialog, GTK_WINDOW(qd_app));
 }
}

void qd_print_drawing() /* print currently focused drawing */
{
}

