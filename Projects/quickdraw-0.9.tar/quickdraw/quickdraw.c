/* (C) 1999-2000 Patrick Lambert (drow@post.com) - Provided under GPL */
#include "quickdraw.h"

int main(int argc, char *argv[]) /* main, call qd_main_win */
{
 gnome_init(QD_PROGRAM, QD_VERSION, argc, argv);
 qd_main_win();
 gtk_main();
 return 0;
}

void qd_main_win() /* make the interface and call other functions */
{
 GtkWidget *frame;
 gchar tmp[70];
 if(getenv("HOME")==NULL || strlen(getenv("HOME"))>40)
 {
  printf("Quick Draw PL requires a valid HOME variable\n");
  exit(1);
 }
 sprintf(qd_project_dir, "%s/drawings", getenv("HOME"));
 sprintf(tmp, "mkdir -p %s", qd_project_dir);
 system(tmp);
 qd_app = gnome_app_new(QD_PROGRAM, QD_PROGRAM);
 gtk_window_set_policy(GTK_WINDOW(qd_app), TRUE, TRUE, FALSE);
 e_set_size(GTK_WIDGET(qd_app), 600, 400);
 gtk_window_set_position(GTK_WINDOW(qd_app), GTK_WIN_POS_CENTER);
 gtk_signal_connect(GTK_OBJECT(qd_app), "delete_event", GTK_SIGNAL_FUNC(qd_exit), NULL);
 qd_add_menus();
 qd_add_toolbars();
 frame = gtk_frame_new(NULL);
 gtk_frame_set_shadow_type(GTK_FRAME(frame), GTK_SHADOW_IN);
 gnome_app_set_contents(GNOME_APP(qd_app), frame);
 qd_notebook = e_notebook_create(frame, E_BOTTOM);
 qd_statusbar = gnome_appbar_new(FALSE, TRUE, GNOME_PREFERENCES_NEVER);
 gnome_app_set_statusbar(GNOME_APP(qd_app), qd_statusbar);
 gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Ready.");
 gtk_widget_show_all(qd_app);
 qd_state = QD_STATE_NULL; /* original state and default drawing vars values */
 qd_dpoly_x0 = -1;
 if(getenv("TMP_DIR")!=NULL && strlen(getenv("TMP_DIR"))<30) strcpy(tmp_dir, getenv("TMP_DIR"));
 else strcpy(tmp_dir, "/tmp");
}

void qd_exit() /* clean up and quit */
{
 gchar eexec[strlen(tmp_dir)+30];
 sprintf(eexec, "rm -f %s/.QD* >/dev/null 2>&1", tmp_dir);
 system(eexec);
 gtk_main_quit();
 exit(0);
}

int qd_cur_page() /* return the currently focused page */
{
 int i;
 gchar *tmp;
 if(GTK_NOTEBOOK(qd_notebook)->cur_page == NULL) return -1;
 gtk_label_get(GTK_LABEL(GTK_NOTEBOOK(qd_notebook)->cur_page->tab_label), &tmp);
 for(i=0; i<=QD_MAXD; i++)
 {
  if(!strcasecmp(qd_drawing[i].filename, tmp)) return i;
 }
 return -1;
}
         