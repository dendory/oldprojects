/* (C) 1999-2000 Patrick Lambert (drow@post.com) - Provided under GPL */
#include "quickdraw.h"

static GnomeUIInfo file_menu[] = {
 GNOMEUIINFO_MENU_NEW_ITEM("_New drawing", "Create a new drawing", qd_new_drawing, NULL),
 GNOMEUIINFO_MENU_OPEN_ITEM(qd_open_drawing, NULL),
 GNOMEUIINFO_MENU_SAVE_ITEM(qd_save_drawing, NULL),
/*
 GNOMEUIINFO_MENU_SAVE_AS_ITEM(qd_save_as_drawing, NULL),
 GNOMEUIINFO_SEPARATOR,
*/
 GNOMEUIINFO_MENU_CLOSE_ITEM(qd_close_drawing, NULL),
/*
 GNOMEUIINFO_MENU_PRINT_ITEM(qd_print_drawing, NULL),
*/
 GNOMEUIINFO_SEPARATOR,
 GNOMEUIINFO_MENU_EXIT_ITEM(qd_exit, NULL),
 GNOMEUIINFO_END
};

static GnomeUIInfo tools_menu[] = {
 GNOMEUIINFO_ITEM_NONE("_Line", "Draw a line", qd_draw_line),
 GNOMEUIINFO_ITEM_NONE("_Polygon", "Draw a polygon", qd_draw_poly),
 GNOMEUIINFO_ITEM_NONE("_Rectangle", "Draw a rectangle", qd_draw_rect),
 GNOMEUIINFO_SEPARATOR,
 GNOMEUIINFO_MENU_PROPERTIES_ITEM(qd_draw_options, NULL),
 GNOMEUIINFO_END
};

static GnomeUIInfo help_menu[] = {
 GNOMEUIINFO_MENU_ABOUT_ITEM(qd_about, NULL),
 GNOMEUIINFO_END
};

static GnomeUIInfo menu[] = {
 GNOMEUIINFO_MENU_FILE_TREE(file_menu),
 GNOMEUIINFO_SUBTREE("_Tools", tools_menu),
 GNOMEUIINFO_MENU_HELP_TREE(help_menu),
 GNOMEUIINFO_END
};

void qd_add_menus() /* simply create the menus */
{
 gnome_app_create_menus_with_data(GNOME_APP(qd_app), menu, qd_app);
}
