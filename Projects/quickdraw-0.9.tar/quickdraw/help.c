/* (C) 1999-2000 Patrick Lambert (drow@post.com) - Provided under GPL */
#include "quickdraw.h"

void qd_about()
{
 GtkWidget *dialog;
 const gchar *authors[] = {
  "Patrick Lambert <drow@post.com>",
  NULL
 };
 dialog = gnome_about_new(QD_PROGRAM, QD_VERSION, "(C) Copyright 1999 Patrick Lambert", authors, "This software program allows users to make simple drawings, open and save them, in an object-based program.\n\nThis program is under the GPL, and may be used and copied in accordance with the terms in that license.\n\nThe latest copy of this program is available from http://www.linsupport.com", "logo.xpm");
 gnome_dialog_set_parent(GNOME_DIALOG(dialog), GTK_WINDOW(qd_app));
 gtk_widget_show(dialog);
}
