/* (C) 1999-2000 Patrick Lambert (drow@post.com) - Provided under GPL */
#include "quickdraw.h"

/* options, with default values */
double opt_line_width = 2.0;
gboolean opt_line_farrow = FALSE;
gboolean opt_line_larrow = FALSE;
gchar opt_line_color[100] = "black";
double opt_poly_width = 2.0;
gchar opt_poly_color[100] = "black";
double opt_rect_width = 2.0;
gchar opt_rect_outline[100] = "black";
gchar opt_rect_color[100] = "tan";

void qd_event() /* function for all click events, to draw shapes */
{
 int i = qd_cur_page(), x, y;
 x = GTK_RULER(qd_drawing[i].hruler)->position;
 y = GTK_RULER(qd_drawing[i].vruler)->position;
 qd_drawing[i].modified = TRUE;
 if(qd_state==QD_STATE_LINE_0)
 {
  qd_dline_i0 = i;
  qd_dline_x0 = x;
  qd_dline_y0 = y;
  qd_state = QD_STATE_LINE_1;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Line: Click where you want the second point");
 }
 else if(qd_state==QD_STATE_LINE_1)
 {
  qd_dline_i1 = i;
  qd_dline_x1 = x;
  qd_dline_y1 = y;
  qd_state = QD_STATE_NULL;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), QD_READY_MSG);
  if(qd_dline_i0 != qd_dline_i1)
  {
   gnome_error_dialog("The two points for a line must be on the same drawing");
   return;
  }
  qd_line_do_it();       
 }
 else if(qd_state==QD_STATE_RECT_0)
 {
  qd_drect_i0 = i;
  qd_drect_x0 = x;
  qd_drect_y0 = y;
  qd_state = QD_STATE_RECT_1;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Rectangle: Click where you want the bottom, right point");
 }
 else if(qd_state==QD_STATE_RECT_1)
 {
  qd_drect_i1 = i;
  qd_drect_x1 = x;
  qd_drect_y1 = y;
  qd_state = QD_STATE_NULL;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), QD_READY_MSG);
  if(qd_drect_i0 != qd_drect_i1)
  {
   gnome_error_dialog("The two points for a rectangle must be on the same drawing");
   return;
  }
  qd_rect_do_it();
 }
 else if(qd_state==QD_STATE_POLY)
 {
  if(qd_dpoly_x0==-1)
  {
   qd_dpoly_x0 = x;
   qd_dpoly_y0 = y;
   qd_dpoly_i0 = i;
   qd_dpoly_x1 = x;
   qd_dpoly_y1 = y;
   qd_dpoly_i1 = i;
  }
  else
  {
   qd_dpoly_x0 = qd_dpoly_x1;
   qd_dpoly_y0 = qd_dpoly_y1;
   qd_dpoly_i0 = qd_dpoly_i1;
   qd_dpoly_x1 = x;
   qd_dpoly_y1 = y;
   qd_dpoly_i1 = i;
   if(qd_dpoly_i0 != qd_dpoly_i1)
   {
    gnome_error_dialog("The points for a polygon must be on the same drawing");
    return;
   }
   qd_poly_do_it();
  }
 }
}

gint qd_obj_event(GnomeCanvasItem *item, GdkEvent *event, gpointer data)
{   /* move, lower, and destroy click events */
 static double x, y;
 GdkCursor *fleur;
 double new_x, new_y;
 static int dragging;
 double item_x, item_y;
 item_x = event->button.x;
 item_y = event->button.y;
 gnome_canvas_item_w2i(item->parent, &item_x, &item_y);
 switch(event->type)
 {
  case GDK_BUTTON_PRESS:
   switch(event->button.button)
   {
    case 1:
     if(event->button.state & GDK_SHIFT_MASK) /* shift click, delete item */
     {
      gtk_object_destroy(GTK_OBJECT(item));
     }
     else if(event->button.state & GDK_CONTROL_MASK) /* ctrl click, lower */
     {
      gnome_canvas_item_lower_to_bottom(item);
     }
     else
     {
      gnome_canvas_item_raise_to_top(item);
      x = item_x;
      y = item_y;
      fleur = gdk_cursor_new(GDK_FLEUR);
      gnome_canvas_item_grab(item, GDK_POINTER_MOTION_MASK|GDK_BUTTON_RELEASE_MASK, fleur, event->button.time);
      gdk_cursor_destroy(fleur);
      dragging = TRUE;
     }
     break;
    default:
     break;
   }
   break;
  case GDK_MOTION_NOTIFY:
   if(dragging && (event->motion.state & GDK_BUTTON1_MASK))
   {
    new_x = item_x;
    new_y = item_y;
    gnome_canvas_item_move(item, new_x - x, new_y - y);
    x = new_x;
    y = new_y;
   }
   break;
  case GDK_BUTTON_RELEASE:
   gnome_canvas_item_ungrab(item, event->button.time);
   dragging = FALSE;
   break;
  default:
   break;
 }
 return FALSE;
}

/*
* deprecated
*void qd_draw_polygon()
*{
* int i = qd_cur_page();
* GnomeCanvasPoints *points;
* GnomeCanvasItem *item;
* if(i==-1) return;
* points = gnome_canvas_points_new(4);
* points->coords[0] = 100.0;
* points->coords[1] = 100.0;
* points->coords[2] = 400.0;
* points->coords[3] = 400.0;
* points->coords[4] = 200.0;
* points->coords[5] = 600.0;
* points->coords[6] = 500.0;
* points->coords[7] = 200.0;
* item = gnome_canvas_item_new(qd_drawing[i].group, gnome_canvas_polygon_get_type(), "points", points, "fill_color", "tan", "outline_color", "black", "width_units", 1.0, NULL);
* gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
* gnome_canvas_points_unref(points);
*}
*/

void qd_draw_line() /* point 1 for line */
{
 int i = qd_cur_page();
 if(i==-1) return;
 qd_state = QD_STATE_LINE_0;
 gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Line: Click where you want the first point.");
}

void qd_line_do_it() /* called from event hdl, we have both points */
{
 GnomeCanvasPoints *points;
 GnomeCanvasItem *item;
 points = gnome_canvas_points_new(2);
 points->coords[0] = qd_dline_x0;
 points->coords[1] = qd_dline_y0;
 points->coords[2] = qd_dline_x1;
 points->coords[3] = qd_dline_y1;
 item = gnome_canvas_item_new(qd_drawing[qd_dline_i0].group, gnome_canvas_line_get_type(), "points", points, "width_units", opt_line_width, "first_arrowhead", opt_line_farrow, "last_arrowhead", opt_line_larrow, "arrow_shape_a", 10.0, "arrow_shape_b", 10.0, "arrow_shape_c", 10.0, "fill_color", opt_line_color, NULL);
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 gnome_canvas_points_unref(points);
 fprintf(qd_drawing[qd_dline_i0].fd, "draw_line %d %d %d %d %f %d %d %s ;\n", qd_dline_x0, qd_dline_y0, qd_dline_x1, qd_dline_y1, opt_line_width, opt_line_farrow, opt_line_larrow, opt_line_color);
}

void qd_draw_rect() /* draw a rect, point 1 */
{
 int i = qd_cur_page();
 if(i==-1) return;
 qd_state = QD_STATE_RECT_0;
 gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Rectangle: Click where you want the top, left corner.");
}

void qd_rect_do_it() /* called from event hdl, we have both points */
{
 GnomeCanvasItem *item;
 item = gnome_canvas_item_new(qd_drawing[qd_drect_i0].group, gnome_canvas_rect_get_type(), "x1", (double)qd_drect_x0, "y1", (double)qd_drect_y0, "x2", (double)qd_drect_x1, "y2", (double)qd_drect_y1, "fill_color", opt_rect_color, "outline_color", opt_rect_outline, "width_units", opt_rect_width, NULL);
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 fprintf(qd_drawing[qd_dline_i0].fd, "draw_rect %f %f %f %f %f %s %s ;\n", (double)qd_drect_x0, (double)qd_drect_y0, (double)qd_drect_x1, (double)qd_drect_y1, opt_rect_width, opt_rect_color, opt_rect_outline);
}

void qd_draw_poly() /* first point for a poly */
{
 int i = qd_cur_page();
 if(i==-1) return;
 if(qd_state==QD_STATE_POLY)
 {
  fprintf(qd_drawing[qd_dpoly_i0].fd, "end_poly ;\n");
  qd_state = QD_STATE_NULL;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), QD_READY_MSG);
  qd_dpoly_x0 = -1;
 }
 else
 {
  qd_state = QD_STATE_POLY;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Polygon: Click for the next point, select Polygon to end");
 }
}

void qd_poly_do_it() /* called from event hdl, we have an other point */
{
 GnomeCanvasPoints *points;
 GnomeCanvasItem *item;
 points = gnome_canvas_points_new(2);
 points->coords[0] = qd_dpoly_x0;
 points->coords[1] = qd_dpoly_y0;
 points->coords[2] = qd_dpoly_x1;
 points->coords[3] = qd_dpoly_y1;
 item = gnome_canvas_item_new(qd_drawing[qd_dpoly_i0].group, gnome_canvas_line_get_type(), "points", points, "width_units", opt_poly_width, "fill_color", opt_poly_color, NULL);
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 gnome_canvas_points_unref(points);
 fprintf(qd_drawing[qd_dpoly_i0].fd, "draw_poly %d %d %d %d %f %s ;\n", qd_dpoly_x0, qd_dpoly_y0, qd_dpoly_x1, qd_dpoly_y1, opt_poly_width, opt_poly_color);
}

void qd_options_ok(GtkWidget *w, int but) /* options window button clicked */
{
 if(but==0)
 {
  opt_line_width = atof(e_entry_get(opt_e1));
  opt_line_farrow = e_checkbutton_get(opt_c1);
  opt_line_larrow = e_checkbutton_get(opt_c2);
  strncpy(opt_line_color, e_entry_get(opt_e2), 95);
  opt_poly_width = atof(e_entry_get(opt_e3));
  strncpy(opt_poly_color, e_entry_get(opt_e4), 95);
  opt_rect_width = atof(e_entry_get(opt_e5));
  strncpy(opt_rect_outline, e_entry_get(opt_e6), 95);
  strncpy(opt_rect_color, e_entry_get(opt_e7), 95);
 }
 gtk_widget_destroy(qd_pbox);
 if(!strcmp(opt_line_color,"") || !strcmp(opt_poly_color,"") || !strcmp(opt_rect_color,"") || !strcmp(opt_rect_outline,""))
 { /* if they are left empty, and the drawing is saved, qd wont be able to reopen it */
  gnome_error_dialog("Could not save options, one or more entries are empty. Please change them.");
  return;
 }
}

void qd_draw_options() /* options dialog */
{
 GtkWidget *p1, *p2, *p3, *vbox, *hbox, *nb;
 gchar tmp[100];
 qd_pbox = gnome_dialog_new("Properties", GNOME_STOCK_BUTTON_OK, GNOME_STOCK_BUTTON_CANCEL, NULL);
 gnome_dialog_set_parent(GNOME_DIALOG(qd_pbox), GTK_WINDOW(qd_app));
 gnome_dialog_set_default(GNOME_DIALOG(qd_pbox), 1);
 gtk_window_set_modal(GTK_WINDOW(qd_pbox), TRUE);
 gtk_signal_connect(GTK_OBJECT(qd_pbox), "clicked", GTK_SIGNAL_FUNC(qd_options_ok), NULL);
 nb = e_notebook_create(GNOME_DIALOG(qd_pbox)->vbox, E_TOP);
 p1 = e_notebook_new_page(nb, "Line", "Properties for Line");
 vbox = e_box_create(p1, E_VERTICAL, 5);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Line width:");
 sprintf(tmp, "%f", opt_line_width);
 opt_e1 = e_entry_create(hbox, tmp);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Line color:");
 opt_e2 = e_entry_create(hbox, opt_line_color);
 opt_c1 = e_checkbutton_create(vbox, "Show a first arrow", opt_line_farrow, E_NO_FUNC);
 opt_c2 = e_checkbutton_create(vbox, "Show an ending arrow", opt_line_larrow, E_NO_FUNC);
 p2 = e_notebook_new_page(nb, "Polygon", "Properties for Polygon");
 vbox = e_box_create(p2, E_VERTICAL, 5);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Polygon line width:");
 sprintf(tmp, "%f", opt_poly_width);
 opt_e3 = e_entry_create(hbox, tmp);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Polygon outline color:");
 opt_e4 = e_entry_create(hbox, opt_poly_color);
 p3 = e_notebook_new_page(nb, "Rectangle", "Properties for Rectangle");
 vbox = e_box_create(p3, E_VERTICAL, 5);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Rectangle line width:");
 sprintf(tmp, "%f", opt_rect_width);
 opt_e5 = e_entry_create(hbox, tmp);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Rectangle outline color:");
 opt_e6 = e_entry_create(hbox, opt_rect_outline);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Rectangle color:");       
 opt_e7 = e_entry_create(hbox, opt_rect_color); 
 gtk_widget_show_all(qd_pbox);
}
