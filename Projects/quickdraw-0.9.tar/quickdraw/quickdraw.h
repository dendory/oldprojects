/* (C) 1999-2000 Patrick Lambert (drow@post.com) - Provided under GPL */
#include <gnome.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include "easygtk.h"

#define QD_MAXD 7 /* max drawings */
#define QD_PROGRAM "Quick Draw PL" /* program name */
#define QD_VERSION "0.9" /* current version */
#define QD_READY_MSG "Ready. Click to move a shape, shift+click to delete, ctrl+click to lower"
#define QD_STATE_NULL 1000
#define QD_STATE_LINE_0 1001
#define QD_STATE_LINE_1 1002
#define QD_STATE_RECT_0 1003
#define QD_STATE_RECT_1 1004
#define QD_STATE_POLY 1005

struct qd_drawings {
 gint used;
 gint modified;
 GtkWidget *page, *canvas, *area, *table, *hruler, *vruler;
 GnomeCanvasGroup *group;
 gchar filename[33]; /* drawing name */
 gchar tempsave[67]; /* tmp save name */
 FILE *fd; /* stream to tmp file */
} qd_drawing[QD_MAXD+1]; /* drawing struct */
gint qd_dline_i0, qd_dline_x0, qd_dline_y0, qd_dline_i1, qd_dline_x1, qd_dline_y1;
gint qd_drect_i0, qd_drect_x0, qd_drect_y0, qd_drect_i1, qd_drect_x1, qd_drect_y1;
gint qd_dpoly_i0, qd_dpoly_x0, qd_dpoly_y0, qd_dpoly_i1, qd_dpoly_x1, qd_dpoly_y1;
gint qd_state;
gchar tmp_dir[31];
gchar qd_project_dir[50];

GtkWidget *qd_app, *qd_notebook, *qd_entry, *qd_statusbar, *qd_pbox;
GtkWidget *opt_e1, *opt_c1, *opt_c2, *opt_e2, *opt_e3, *opt_e4, *opt_e5, *opt_e6, *opt_e7;

void qd_main_win();
void qd_exit();
void qd_add_menus();
void qd_add_toolbars();
void qd_open_drawing();
void qd_new_drawing();
void qd_save_drawing();
void qd_save_as_drawing();
void qd_close_drawing();
void qd_print_drawing();
void qd_about();
void qd_add_menus();
void qd_add_toolbars();
int qd_cur_page();
void qd_draw_poly();
void qd_poly_do_it();
void qd_event();
void qd_line_do_it();
void qd_draw_line();
void qd_rect_do_it();
void qd_draw_rect();
void qd_draw_options();
gint qd_obj_event(GnomeCanvasItem *item, GdkEvent *event, gpointer data);
