/* (C) 1999-2000 Patrick Lambert (drow@post.com) - Provided under GPL */
#include "quickdraw.h"

GnomeUIInfo toolbar[] = {
 GNOMEUIINFO_ITEM_STOCK("New", "Create a new drawing", qd_new_drawing, GNOME_STOCK_PIXMAP_NEW),
 GNOMEUIINFO_ITEM_STOCK("Open", "Open a drawing", qd_open_drawing, GNOME_STOCK_PIXMAP_OPEN),
 GNOMEUIINFO_ITEM_STOCK("Save", "Save current drawing", qd_save_drawing, GNOME_STOCK_PIXMAP_SAVE),
 GNOMEUIINFO_ITEM_STOCK("Close", "Close the current drawing", qd_close_drawing, GNOME_STOCK_PIXMAP_CLOSE),
 GNOMEUIINFO_SEPARATOR,
 GNOMEUIINFO_ITEM_STOCK("Line", "Draw a line", qd_draw_line, GNOME_STOCK_PIXMAP_UP),
 GNOMEUIINFO_ITEM_STOCK("Polygon", "Draw a polygon", qd_draw_poly, GNOME_STOCK_PIXMAP_JUMP_TO),
 GNOMEUIINFO_ITEM_STOCK("Rectangle", "Draw a rectangle", qd_draw_rect, GNOME_STOCK_PIXMAP_TABLE_FILL),
 GNOMEUIINFO_ITEM_STOCK("Properties", "Set shapes properties", qd_draw_options, GNOME_STOCK_PIXMAP_PROPERTIES),
 GNOMEUIINFO_SEPARATOR,
 GNOMEUIINFO_ITEM_STOCK("About", "About Quick Draw PL", qd_about, GNOME_STOCK_PIXMAP_ABOUT),
 GNOMEUIINFO_ITEM_STOCK("Exit", "Exit the application", qd_exit, GNOME_STOCK_PIXMAP_EXIT),
 GNOMEUIINFO_END
};

void qd_add_toolbars() /* simply create toolbars */
{
 gnome_app_create_toolbar_with_data(GNOME_APP(qd_app), toolbar, qd_app);
}
