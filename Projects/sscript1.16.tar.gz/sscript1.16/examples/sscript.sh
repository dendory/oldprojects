server no-connection ;
port 0 ;
debug 0 ;
chop 0 ;
virtual 0 ;
# Note: you must start this script with an absolute path:
# ../sscript /home/login/sscript1.13/examples/sscript.sh
clear ;
print SSS (Socket Script Shell) - Enter shell commands, program names, or scommand <Socket Script command>
loop start 1 ;
cwd 50 ;
uname 51 ;
set 52 [SSS@ $word 51 1 ]
parse ! 52 ;
print $word 52 0 PWD: $word 50 0 Ready.
ask 100 ;
wordlength 100 101 ;
ifword 101 0 0 $goto pass_11 ;
ifword 100 0 scommand $goto scommand
ifword 100 0 exit $exit
ifword 100 0 cd $goto cd
run 100 ;
sub pass_11 ;
loop end 1 ;
exit ;
sub scommand ;
set 101 $string 100 1
command 101 ;
loop end 1 ;
sub cd ;
set 101 $word 100 1
chdir 101 ;
loop end 1 ;
