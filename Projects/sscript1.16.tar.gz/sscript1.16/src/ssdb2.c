/*
(C) 1998-99 Patrick Lambert <drow@fastethernet.net>

This program is under the GPL

This program is distributed without ANY WARRANTY, without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR   
PURPOSE.

Latest version of Socket Script is always available from
http://devplanet.fastethernet.net/sscript.html
*/

#include <sys/types.h>
#include <stdio.h>
#include <strings.h>
#include <errno.h>
#include <netdb.h>
#include <sys/file.h>
#include "sscript.h"

ssdb2_cl(char in[1024][512])
{
 int i,j,current_number=0;
 FILE *fp,*fp2;
 char ltemp[255],ltemp2[255],ltemp3[255],line[255];
 if(!strcasecmp(lindex(temp,2),"create"))
 {
  sprintf(ltemp,"%s.ssdb2",lindex(temp,3));
  fp=fopen(ltemp,"w");
  sprintf(ltemp,"%d\n",atoi(lindex(in[atoi(lindex2(temp,4))],0)));
  fputs(ltemp,fp);
  for(i=1;i<(atoi(lindex(in[atoi(lindex2(temp,4))],0))+1);i++)
  {
   sprintf(ltemp,"number = %d\n",i);
   fputs(ltemp,fp);
   for(j=1;lindex(in[atoi(lindex2(temp,4))],j)!=(int)NULL;j++)
   {
    sprintf(ltemp,"%s = \n",lindex(in[atoi(lindex2(temp,4))],j));
    fputs(ltemp,fp);
   }
  }
  if(fp!=NULL) fclose(fp);
 }
 if(!strcasecmp(lindex(temp,2),"find"))
 {
  sprintf(ltemp,"%s.ssdb2",lindex(temp,3));
  fp=fopen(ltemp,"r");
  strcpy(in[atoi(lindex2(temp,6))],"0");
  while(fgets(line,255,fp)!=NULL)
  {
   if(!strcasecmp(lindex(line,0),"number")) current_number = atoi(lindex2(line,2));
   if(!strcasecmp(lindex(line,0),lindex2(temp,4)))
   {
    strcpy(ltemp2,"");
    for(j=2;lindex(line,j)!=NULL;j++)
    {
     strcat(ltemp2,lindex(line,j));
    }
    ltemp2[strlen(ltemp2)-1]=' ';
    sprintf(ltemp3,"*%s*",lindex(in[atoi(lindex2(temp,5))],0));
    if(!match(ltemp3,ltemp2))
    {
     if(atoi(in[atoi(lindex2(temp,6))])>0)
     {
      strcpy(in[atoi(lindex2(temp,6))],"Too many matches");
      return -1;
     }
     sprintf(in[atoi(lindex2(temp,6))],"%d",current_number);
    }
   }
  }
  if(fp!=NULL) fclose(fp);
 }
 if(!strcasecmp(lindex(temp,2),"get"))
 {
  sprintf(ltemp,"%s.ssdb2",lindex(temp,3));
  fp=fopen(ltemp,"r");
  strcpy(in[atoi(lindex2(temp,6))],"");
  while(fgets(line,255,fp)!=NULL)
  {
    if(!strcasecmp(lindex(line,0),"number") && atoi(lindex2(line,2))==atoi(in[atoi(lindex(temp,5))]))
   {
    while(fgets(line,255,fp)!=NULL)
    {
     if(!strcasecmp(lindex(line,0),lindex2(temp,4)))
     {
      strcpy(in[atoi(lindex2(temp,6))],lrange(line,2));
      break;
     }
    }
   }
  }
  if(!strcasecmp(in[atoi(lindex2(temp,6))],""))
   strcpy(in[atoi(lindex2(temp,6))],"Not found");
  if(fp!=NULL) fclose(fp);
 }
 if(!strcasecmp(lindex(temp,2),"add"))
 {
  sprintf(ltemp,"%s.ssdb2",lindex(temp,3));
  fp=fopen(ltemp,"r");
  sprintf(ltemp,"%s.ssdb2.new",lindex(temp,3));
  fp2=fopen(ltemp,"w");
  while(fgets(line,255,fp)!=NULL)
  {
   fputs(line,fp2);
   if(!strcasecmp(lindex(line,0),"number") && atoi(lindex2(line,2))==atoi(in[atoi(lindex(temp,5))])) break;
  }
  while(fgets(line,255,fp)!=NULL)
  {
   if(!strcasecmp(lindex(line,0),lindex2(temp,4))) break;
   fputs(line,fp2);
  }
  sprintf(ltemp2,"%s = %s\n",lindex(temp,4),in[atoi(lindex2(temp,6))]);
  fputs(ltemp2,fp2);
  while(fgets(line,255,fp)!=NULL)
  {
   fputs(line,fp2);
  }
  if(fp!=NULL) fclose(fp);
  if(fp2!=NULL) fclose(fp2);
  sprintf(ltemp,"mv %s.ssdb2.new %s.ssdb2",lindex(temp,3),lindex(temp,3));
  system(ltemp);
 }
}
