/* Made with config */
/* Change empty strings with <NO-STRING> */
#define HANDLE_EMPTY_STRINGS
/* Get remote IP when running a server-oriented script */
#define GET_REMOTE_IP
/* Fork on starting of server-oriented scripts */
#define FORK_START
#define IPFW "/sbin/ipfwadm"
#define LOGFILE "syslog"
#define CL_GUI_TK_PATH "/usr/bin/wish"
#define PERL_BIN "/usr/bin/perl"
/* This is the dir where SScript puts temp files. It should be onwed by you with read permission by you only */
#define TEMP_DIR "/tmp"
/* Show the header when starting SScript */
#undef HEADER
#define EDITOR "pico"
/* Run in graphical mode */
#define GUI
#define GTK
/* define ONE of the following to set a custom GUI color set */
#undef RES_STANDARD
#define RES_3D
#undef RES_COLORFUL
