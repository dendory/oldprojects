/* $Id: phtoelm.h,v 1.13 1994/11/08 13:30:50 a904209 Exp a904209 $
*/
extern int phone_append PROTO((darray_ptr p,int ch));
unsigned phone_to_elm PROTO((char *s, int n, darray_ptr elm));

