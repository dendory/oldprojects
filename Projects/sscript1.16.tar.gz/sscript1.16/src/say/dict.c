#include <config.h>
#include "proto.h"
#include <stdio.h>
#include "phones.h"

void *dict;
char **dialect = ph_am;

unsigned char *
dict_find(s, n)
char *s;
unsigned n;
{
 return NULL;
}

int
dict_init(argc, argv)
int argc;
char *argv[];
{
 return argc;
}

void
dict_term()
{

}

