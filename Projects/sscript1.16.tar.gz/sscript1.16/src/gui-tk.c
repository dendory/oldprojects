/*
(C) 1998-99 Patrick Lambert <drow@fastethernet.net>

This program is under the GPL

This program is distributed without ANY WARRANTY, without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR   
PURPOSE.

Latest version of Socket Script is always available from
http://devplanet.fastethernet.net/sscript.html
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <strings.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <sys/file.h>
#include <signal.h>
#include "sscript.h"  

gui_tk_cl(int sockfd, char in[1024][512])
{
 int i,blocking=0,row=0,process=-1;
 char temp5[255],temp6[255],temp7[255],filetmp[255],filetmp2[255];
 FILE *fd;
 sprintf(filetmp,"%s/.gui-tk.tmp",TMP_DIR);
 fd=fopen(filetmp,"w");
 fputs("<NO-STRING>\n",fd);
 if(fd!=NULL) fclose(fd);
 sprintf(filetmp2,"%s/.gui-tk-bin.tk",TMP_DIR);
 fd=fopen(filetmp2,"w");
 sprintf(temp5,"#!%s\n",CL_GUI_TK_PATH);
 fputs(temp5,fd);
 fputs("# GUI-TK LIB from SScript\n",fd);
 fputs("wm title . \"Socket Script\"\nwm geometry . +100+100\n",fd);
 for(i=2;lindex(temp,i)!=NULL;i++)
 {
  if(!strcasecmp(lindex(temp,i),"-nonblocking")) blocking=1;
  if(!strcasecmp(lindex(temp,i),"-info"))
  {
   i++;
   sprintf(temp6,"label .l%d -text \"",row);
   for(i=i;lindex(temp,i)!=NULL;i++)
   {
    strcpy(temp7,lindex(temp,i));
    if(temp7[0]=='-') break;
    strcat(temp6,lindex(temp,i));
    strcat(temp6," ");
   }
   strcat(temp6,"\"\n");
   fputs(temp6,fd);
   sprintf(temp6,"grid .l%d -row %d -column 0\n",row,row);
   fputs(temp6,fd);
   row++;
  }
  if(!strcasecmp(lindex(temp,i),"-entry"))
  {
   sprintf(temp6,"entry .e%d -textvariable e%d \n",row,row);
   fputs(temp6,fd);
   sprintf(temp6,"grid .e%d -row %d -column 0\n",row,row);
   fputs(temp6,fd);
   row++;
  }
  if(!strcasecmp(lindex(temp,i),"-processbutton"))
  {
   i++;
   sprintf(temp6,"button .b%d -text \"%s\" -command {process $e%s}\n",row,lindex(temp,i),lindex(temp,(i+1)));
   i++;i++;
   process=atoi(lindex(temp,i));
   i++;
   fputs(temp6,fd);
   sprintf(temp6,"grid .b%d -row %d -column 0\n",row,row);
   fputs(temp6,fd);
   row++;
  }
  if(!strcasecmp(lindex(temp,i),"-cancelbutton"))
  {
   i++;
   sprintf(temp6,"button .b%d -text \"%s\" -command {exit}\n",row,lindex(temp,i));
   fputs(temp6,fd);
   sprintf(temp6,"grid .b%d -row %d -column 0\n",row,row);
   fputs(temp6,fd);
   row++;
  }
 }
 fputs("\n\nproc process {what} {\n",fd);
 fputs("if {$what==\"\"} {\nexit\n}\n",fd);
 sprintf(filetmp,"set fd [open \"%s/.gui-tk.tmp\" w]\n",TMP_DIR);
 fputs(filetmp,fd);
 fputs("puts $fd \"$what \"\n",fd);
 fputs("close $fd\nexit\n}\n",fd);
 if(fd!=NULL) fclose(fd);
 sprintf(filetmp,"chmod +x %s/.gui-tk-bin.tk \n",TMP_DIR);
 system(filetmp);
 if(blocking)
 {
  sprintf(filetmp,"%s/.gui-tk-bin.tk &\n",TMP_DIR);
  system(filetmp);
 }
 else
 {
  sprintf(filetmp,"%s/.gui-tk-bin.tk\n",TMP_DIR);
  system(filetmp);
 }
 if(process!=-1)
 {
  sprintf(filetmp,"%s/.gui-tk.tmp",TMP_DIR);
  fd=fopen(filetmp,"r");
  fgets(temp6,255,fd);
  strcpy(in[process],temp6);
  if(fd!=NULL) fclose(fd);
 }
 return 0;
}
