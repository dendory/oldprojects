/*
(C) 1998-99 Patrick Lambert <drow@fastethernet.net>

This program is under the GPL

This program is distributed without ANY WARRANTY, without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE.

Latest version of Socket Script is always available from
http://devplanet.fastethernet.net/sscript.html
*/

#include "sscript.h"
#include <stdio.h>
#include <string.h>

int parse_html(char *newline)
{
 int i=0, title=0, center=0;
 if(lindex(newline,i)==NULL) return -1;
 for(i=0;lindex(newline,i)!=NULL;i++)
 {
  if(*lindex(newline,i)!='<' && title==0) printf("%s ",lindex(newline,i));
  else
  {
   if(!match("<TITLE*",lindex(newline,i)))
   {
    title=1;
    while(match("*>*",lindex(newline,i)))
    { i++; if(lindex(newline,i)==NULL) { continous=1; return -1; } }
   }
   else if(!match("</TITLE*",lindex(newline,i)))
   {
    title=0;
    while(match("*>*",lindex(newline,i)))
    { i++; if(lindex(newline,i)==NULL) { continous=1; return -1; } }
   }
   else if(!match("<BR*",lindex(newline,i)))
   {
    if(center) printf("\n          ");
    else printf("\n");
    while(match("*>*",lindex(newline,i)))
    { i++; if(lindex(newline,i)==NULL) { continous=1; return -1; } }
   }
   else if(!match("<A*",lindex(newline,i)))
   {
    printf("[LINK]");
    while(match("*>*",lindex(newline,i)))
    { i++; if(lindex(newline,i)==NULL) { continous=1; return -1; } }
   }
   else if(!match("<LI*",lindex(newline,i)))
   {
    printf("* ");
    while(match("*>*",lindex(newline,i)))
    { i++; if(lindex(newline,i)==NULL) { continous=1; return -1; } }
   }
   else if(!match("<IMG*",lindex(newline,i)))
   {
    printf("[IMAGE] ");
    while(match("*>*",lindex(newline,i)))
    { i++; if(lindex(newline,i)==NULL) { continous=1; return -1; } }
   }
   else if(!match("<CENTER*",lindex(newline,i)))
   {
    center=1;
    printf("          ");
    while(match("*>*",lindex(newline,i)))
    { i++; if(lindex(newline,i)==NULL) { continous=1; return -1; } }
   }
   else if(!match("</CENTER*",lindex(newline,i)))
   {
    center=0;
    while(match("*>*",lindex(newline,i)))
    { i++; if(lindex(newline,i)==NULL) { continous=1; return -1; } }
   }
   else if(!match("<HR*",lindex(newline,i)))
   {
    printf("\n------------------------------------------------------------------------\n");
    while(match("*>*",lindex(newline,i)))
    { i++; if(lindex(newline,i)==NULL) { continous=1; return -1; } }
   }
   else if(!match("</P*",lindex(newline,i)))
   {
    if(center) printf("\n\n          ");
    else printf("\n\n");
    while(match("*>*",lindex(newline,i)))
    { i++; if(lindex(newline,i)==NULL) { continous=1; return -1; } }
   }
   else if(!match("</HTML*",lindex(newline,i)))
   {
    printf("\n");
    return 0;
   }
   else
   {
    while(match("*>*",lindex(newline,i)))
    { i++; if(lindex(newline,i)==NULL) { continous=1; return -1; } }
   }
  }
 }
 return 0;
}

int make_js()
{
 FILE *jsd;
 if(!strcasecmp(lindex(temp,2),"scrolling"))
 {
#ifndef GTK
  lasterror=105;
  return -1;
#else
  query("Scrolling label\nEnter the label:");
#endif
  printf("Making %s...\n",lindex(temp,3));
  jsd = fopen(lindex(temp,3),"w");
  if(jsd==NULL) return -1;
  fputs("<html><head><title>This is a sample page</title>\n",jsd);
  fputs("<script language=\"JavaScript\">\n<!--\n",jsd);
  fputs("function scroll_bar(seed)\n",jsd);
  fputs("{\n",jsd);
  fputs(" var msg = \"",jsd);
  fputs(queryGlVar,jsd);
  fputs(" \"\n",jsd);
  fputs(" var out = \" \";\n",jsd);
  fputs(" var c = 1;\n",jsd);
  fputs(" if(seed > 100)\n",jsd);
  fputs(" {\n",jsd);
  fputs("  seed--;\n",jsd);
  fputs("  var cmd = \"scroll_bar(\" + seed + \")\";\n",jsd);
  fputs("  timerTwo = window.setTimeout(cmd,100);\n",jsd);
  fputs(" }\n",jsd);
  fputs(" else if(seed <= 100 && seed > 0) {\n",jsd);
  fputs(" for(c = 0 ; c < seed ; c++)\n",jsd);
  fputs(" {\n",jsd);
  fputs("  out += \" \";\n",jsd);
  fputs(" }\n",jsd);
  fputs("  out += msg;\n",jsd);
  fputs("  seed--;\n",jsd);
  fputs("  var cmd = \"scroll_bar(\" + seed + \")\";\n",jsd);
  fputs("  window.status = out;\n",jsd);
  fputs("  timerTwo = window.setTimeout(cmd, 100);\n",jsd);
  fputs(" }\n",jsd);
  fputs(" else if(seed <= 0)\n",jsd);
  fputs(" {\n",jsd);
  fputs("  if(-seed < msg.length)\n",jsd); 
  fputs("  { \n",jsd);
  fputs("   out += msg.substring(-seed, msg.length);\n",jsd);
  fputs("   seed--;\n",jsd);
  fputs("   var cmd = \"scroll_bar(\" + seed + \")\";\n",jsd);
  fputs("   window.status = out;\n",jsd);
  fputs("   timerTwo = window.setTimeout(cmd, 100);\n",jsd);
  fputs("  }\n",jsd);
  fputs("  else\n",jsd);
  fputs("  {\n",jsd);
  fputs("   window.status=\" \";\n",jsd);
  fputs("   timerTwo = window.setTimeout(\"scroll_bar(100)\", 75);\n",jsd);
  fputs("  }\n",jsd);
  fputs(" }\n",jsd);
  fputs("}\n",jsd);
  fputs("//------>\n",jsd);
  fputs("</script></head><body bgcolor=#FFFFFF text=#000000>\n",jsd);
  fputs("<center><h2>This is a sample page</h2></center></body></html>\n",jsd);
  fclose(jsd);
 }
 if(!strcasecmp(lindex(temp,2),"entry"))
 {  
#ifndef GTK
  lasterror=105;    
  return -1;
#else
  query("Scrolling text in an entry box\nEnter the label:");
#endif
  printf("Making %s...\n",lindex(temp,3));
  jsd = fopen(lindex(temp,3),"w");
  if(jsd==NULL) return -1;
  fputs("<html><head><title>This is a sample page</title>\n",jsd);
  fputs("<script language=\"JavaScript\">\n",jsd);
  fputs("<!--\n",jsd);
  fputs("var posBan1 = 0, ban1, waitBan1, msgBan1;\n",jsd);
  fputs("function banner(banwait)\n",jsd);
  fputs("{\n",jsd);
  fputs(" waitBan1 = banwait;\n",jsd);
  fputs(" if(posBan1 >= msgBan1.length) posBan1 = 0;\n",jsd);
  fputs(" else if (posBan1 == 0)\n",jsd);
  fputs(" {\n",jsd);
  fputs("  msgBan1 = '      ' + msgBan1;\n",jsd);
  fputs("  while (msgBan1.length < 128)\n",jsd);
  fputs("  msgBan1 += '      ' + msgBan1;\n",jsd);
  fputs(" }\n",jsd);
  fputs(" document.formBan1.fb.value = msgBan1.substring(posBan1, posBan1+msgBan1.length);\n",jsd);
  fputs(" posBan1++;\n",jsd);
  fputs(" ban1 = setTimeout(\"banner(waitBan1)\", banwait);\n",jsd);
  fputs("}\n",jsd);
  fputs("//-->  \n",jsd);
  fputs("</script></head>\n",jsd);
  fputs("<body bgcolor=#FFFFFF text=#000000 onLoad=\"msgBan1='",jsd);
  fputs(queryGlVar,jsd);
  fputs("'; banner(100);\" onUnload=\"clearTimeout(ban1)\">\n",jsd);
  fputs("<center><h2>This is a sample page</h2></center>\n",jsd);
  fputs("<form name=\"formBan1\"><input type=\"text\" name=\"fb\" size=\"50\"><br></form></center>\n",jsd);
  fputs("</body></html>\n",jsd);
  fclose(jsd);
 }
 return 0;
}
