/*
(C) 1998-99 Patrick Lambert <drow@fastethernet.net>

This program is under the GPL

This program is distributed without ANY WARRANTY, without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR   
PURPOSE.

Latest version of Socket Script is always available from
http://devplanet.fastethernet.net/sscript.html
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <strings.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <sys/file.h>
#include <signal.h>
#include "sscript.h"  

ssdb_cl(int sockfd, char in[1024][512])
{
 int number_of_headers,i,j,matched=0;
 char db[255],db2[255],db3[255],db4[255],new1[255],new2[255],blah[255];
 FILE *fd, *fdb, *newfd;
 if(!strcasecmp(lindex(temp,2),"create"))
 {
  number_of_headers=atoi(lindex(temp,3));
  sprintf(db,"%s.ssdb",lindex(temp,4));
  fd=fopen(db,"w");
  for(i=5;i!=(number_of_headers+5);i++)
  {
   fputs(lindex(temp,i),fd);
   fputs(" ;\n",fd);
   sprintf(db,"%s.%s.ssdb",lindex(temp,4),lindex(temp,i));
   fdb=fopen(db,"w");
   if(fdb!=NULL) fclose(fdb);
  }
  if(fd!=NULL) fclose(fd);
 }
 if(!strcasecmp(lindex(temp,2),"add"))
 {
  sprintf(db,"%s.%s.ssdb",lindex(temp,3),lindex(temp,4));
  fd=fopen(db,"a");
  fputs(in[atoi(lindex(temp,5))],fd);
  fputs("\n",fd);
  if(fd!=NULL) fclose(fd);
 }
 if(!strcasecmp(lindex(temp,2),"listheaders"))
 {
  sprintf(db,"%s.ssdb",lindex(temp,3));
  fd=fopen(db,"r");
  strcpy(db2,"");
  i=0;
  while(fgets(db,255,fd)!=NULL)
  {
   i++;
   strcat(db2,lindex(db,0));
   strcat(db2," | ");
  }
  sprintf(db,"%s%d",db2,i);
  strcpy(in[atoi(lindex(temp,4))],db);
  if(fd!=NULL) fclose(fd);
 }
 if(!strcasecmp(lindex(temp,2),"get"))
 {
  sprintf(db,"%s.%s.ssdb",lindex(temp,3),lindex(temp,4));
  fd=fopen(db,"r");
  for(i=0;i<atoi(in[atoi(lindex(temp,5))]);i++) fgets(db2,255,fd);
  db2[strlen(db2)-1]=' ';
  strcpy(in[atoi(lindex(temp,6))],db2);
  if(fd!=NULL) fclose(fd);
 }
 if(!strcasecmp(lindex(temp,2),"list"))
 {
  sprintf(db,"%s.%s.ssdb",lindex(temp,3),lindex(temp,4));
  fd=fopen(db,"r");
  j=0;
  while(fgets(db2,255,fd)!=NULL)
  {
   j++;
   if(!strcasecmp(lindex(db2,0),lindex2(in[atoi(lindex(temp,5))],0)))
   break;
  }
  if(fd!=NULL) fclose(fd);
  sprintf(db3,"%d ",j);
  sprintf(db,"%s.ssdb",lindex(temp,3));
  fd=fopen(db,"r");
  while(fgets(db2,255,fd)!=NULL)
  {
   sprintf(db,"%s.%s.ssdb",lindex(temp,3),lindex2(db2,0));
   fdb=fopen(db,"r");
   for(i=0;i!=j;i++) fgets(db4,255,fdb);
   db4[strlen(db4)-1]=' ';
   strcat(db3,"| ");
   strcat(db3,db4);
   if(fdb!=NULL) fclose(fdb);
  }
  strcpy(in[atoi(lindex(temp,6))],db3);
 }
 if(!strcasecmp(lindex(temp,2),"remove"))
 {
  sprintf(db,"%s.%s.ssdb",lindex(temp,3),lindex(temp,4));
  fd=fopen(db,"r");
  j=0;
  while(fgets(db2,255,fd)!=NULL)
  {
   j++;
   if(!strcasecmp(lindex(db2,0),lindex2(in[atoi(lindex(temp,5))],0)))
   {
    matched=1;
    break;
   }
  }
  if(matched!=1) j=-1;
  if(fd!=NULL) fclose(fd);
  sprintf(db3,"%d ",j);
  sprintf(db,"%s.ssdb",lindex(temp,3));
  fd=fopen(db,"r");
  while(fgets(db2,255,fd)!=NULL)
  {
   sprintf(db,"%s.%s.ssdb",lindex(temp,3),lindex2(db2,0));
   fdb=fopen(db,"r");
   sprintf(new1,"%s.%s.ssdb-new",lindex(temp,3),lindex2(db2,0));
   newfd=fopen(new1,"w");
   i=0;
   while(fgets(db4,255,fdb)!=NULL)
   {
    i++;
    if(i!=j) fputs(db4,newfd);
   }
   if(newfd!=NULL) fclose(newfd);
   if(fdb!=NULL) fclose(fdb);
   sprintf(new2,"mv %s.%s.ssdb-new %s.%s.ssdb",lindex(temp,3),lindex2(db2,0),lindex(temp,3),lindex2(db2,0));
   system(new2);
  }
  strcpy(in[atoi(lindex(temp,6))],db3);
 } 
}
