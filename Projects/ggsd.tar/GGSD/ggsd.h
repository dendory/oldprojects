/*
 GGSD (Generic Graphical Server Daemon) (C) Patrick Lambert <drow@darkelf.net>
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <syslog.h>
#include <pwd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#ifdef USE_GUI
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#endif

#define GGSD_EXIT_ERROR 101
#define GGSD_EXIT_OK 102

#define GGSD_PARAM 201
#define GGSD_RUN 202
#define GGSD_BIND 203

int GGSD_LOG_SYSLOG = 0;

char logfile[112] = "/var/log/ggsd.log";
char script[112] = "ggsd.scr";
char allow_list[1024] = "";
char deny_list[1024] = "";
char temp[1024], line[512], global_var[512];
int portnum = 4005, nofork = 0, nogui = 0, allow_first = 0;
int from_len, listen_len, len, pid;
struct sockaddr_in listen_addr;
struct sockaddr_in from_addr;
struct sockaddr_in address;
int sockfd, sockfd2, opt = 1;
int uid = -1;

void statusd_report(char *msg, int type, int when);
void usage();
void print_log(char *msg);
void output();
void start_server();
void get_report();
void ggsd_report(char *msg, int type, int when);
void print_status();
int match(char *ip1, char *ip2);
int check_address(char *ip);
char *lindex(char *input_string, int word_number);
char *lrange(char *input_string, int word_number);

#ifdef USE_GUI
void make_gui();
void gui_exit(GtkWidget *w, GtkWidget *e);
void gui_cb1(GtkWidget *w, GtkWidget *e);
void gui_ok(GtkWidget *w, GtkWidget *e);
GtkWidget *window, *vbox, *hbox, *cb1, *cb2, *label, *eb1, *eb2, *eb3, *eb4, *eb5, *eb6, *button;
#endif

