/* (C) 1999-2000 Patrick Lambert (drow@post.com) - Provided under GPL */
#include "qd.h"

gint qd_new_drawing_cb(char *name) /* create new page and draw area */
{
 GtkWidget *s_w;
 int i, j;
 if(!strcmp(name, "")) /* empty name */
 {
  if(GTK_IS_WIDGET(qd_browse)) gtk_widget_destroy(qd_browse);
  gnome_error_dialog("The name can't be empty");
  return -1;
 }
 if(strlen(name)>32) /* max 32 chars */
 {
  if(GTK_IS_WIDGET(qd_browse)) gtk_widget_destroy(qd_browse);
  gnome_error_dialog("The name must be less than 32 chars");
  return -1; 
 }
 for(i=0; i<QD_MAXD; i++) /* name must be unique */
 {
  if(qd_drawing[i].used == TRUE)
  {
   if(!strcasecmp(qd_drawing[i].filename, name))
   {
    if(GTK_IS_WIDGET(qd_browse)) gtk_widget_destroy(qd_browse);
    gnome_error_dialog("The name must be unique");
    return -1;
   }
  } 
 }
 for(i=0; i<QD_MAXD; i++) /* find a new entry */
 {
  if(qd_drawing[i].used == FALSE) break;
 }
 if(qd_drawing[i].used == TRUE) /* is entry out of range? */
 {
  if(GTK_IS_WIDGET(qd_browse)) gtk_widget_destroy(qd_browse);
  gnome_error_dialog("No more drawing space available"); 
  return -1;
 }

 qd_drawing[i].used = TRUE; /* default vars, create draw area */
 qd_drawing[i].modified = FALSE;
 strcpy(qd_drawing[i].filename, name);

 qd_drawing[i].page = e_notebook_new_page(qd_notebook, qd_drawing[i].filename, qd_drawing[i].filename);

 gtk_widget_push_visual(gdk_imlib_get_visual());
 gtk_widget_push_colormap(gdk_imlib_get_colormap());

 s_w = e_scrolled_create(qd_drawing[i].page);
 qd_drawing[i].table = gtk_table_new(3, 2, FALSE);
 e_set_size(qd_drawing[i].table, 1024, 768); 
 gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(s_w), qd_drawing[i].table); 
  
 qd_drawing[i].area = gtk_event_box_new();
 gtk_table_attach(GTK_TABLE(qd_drawing[i].table), qd_drawing[i].area, 1, 2, 1, 2, GTK_EXPAND|GTK_FILL, GTK_FILL, 0, 0);
 gtk_widget_unrealize(GTK_WIDGET(qd_drawing[i].area));
 gtk_widget_set_events(qd_drawing[i].area, GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK);
 gtk_signal_connect(GTK_OBJECT(qd_drawing[i].area), "button_press_event",
 GTK_SIGNAL_FUNC(qd_event), NULL);

 qd_drawing[i].hruler = gtk_hruler_new();
 gtk_ruler_set_metric(GTK_RULER(qd_drawing[i].hruler), GTK_PIXELS);
 gtk_ruler_set_range(GTK_RULER(qd_drawing[i].hruler), 0, 1024, 0, 1024);
 gtk_signal_connect_object(GTK_OBJECT(qd_drawing[i].area), "motion_notify_event",
 (GtkSignalFunc)E_EVENT_METHOD(qd_drawing[i].hruler, motion_notify_event), GTK_OBJECT(qd_drawing[i].hruler));
 gtk_table_attach(GTK_TABLE(qd_drawing[i].table), qd_drawing[i].hruler, 1, 2, 0, 1,
 GTK_EXPAND|GTK_SHRINK|GTK_FILL, GTK_FILL, 0, 0 );

 qd_drawing[i].vruler = gtk_vruler_new();
 gtk_ruler_set_metric(GTK_RULER(qd_drawing[i].vruler), GTK_PIXELS);
 gtk_ruler_set_range(GTK_RULER(qd_drawing[i].vruler), 0, 768, 10, 768);
 gtk_signal_connect_object(GTK_OBJECT(qd_drawing[i].area), "motion_notify_event",
 (GtkSignalFunc)E_EVENT_METHOD(qd_drawing[i].vruler, motion_notify_event), GTK_OBJECT(qd_drawing[i].vruler));
 gtk_table_attach(GTK_TABLE(qd_drawing[i].table), qd_drawing[i].vruler, 0, 1, 1, 2,
 GTK_FILL, GTK_EXPAND|GTK_SHRINK|GTK_FILL, 0, 0);
 gtk_widget_show(qd_drawing[i].area);
 gtk_widget_show(qd_drawing[i].hruler);
 gtk_widget_show(qd_drawing[i].vruler);
 gtk_widget_show(qd_drawing[i].table);

 qd_drawing[i].canvas = gnome_canvas_new();
 gtk_widget_pop_colormap();
 gtk_widget_pop_visual();
 gtk_container_add(GTK_CONTAINER(qd_drawing[i].area), qd_drawing[i].canvas);
 gnome_canvas_set_scroll_region(GNOME_CANVAS(qd_drawing[i].canvas), 0, 0, 1024, 768);
 qd_drawing[i].group = gnome_canvas_root(GNOME_CANVAS(qd_drawing[i].canvas));
 gtk_widget_show(qd_drawing[i].canvas);

 for(j=0;j<QD_ITEMS;j++) qd_drawing[i].item[j].used = 0;
 /* FIXME: we need to get gtk to redraw the notebook */
 return i;
}

void qd_new_drawing_2(GnomeDialog *dialog, int but)
{
 if(but==1) /* cancel */
 {
  gnome_dialog_close(dialog);
  return;
 }
 qd_new_drawing_cb(e_entry_get(qd_entry));
 gnome_dialog_close(dialog);
}

void qd_new_drawing() /* ask for new drawing name */
{
 GtkWidget *dialog;
 dialog = gnome_dialog_new("New Drawing", GNOME_STOCK_BUTTON_OK, GNOME_STOCK_BUTTON_CANCEL, NULL);
 gnome_dialog_set_parent(GNOME_DIALOG(dialog), GTK_WINDOW(qd_app));
 e_label_create(GNOME_DIALOG(dialog)->vbox, "New drawing name:");
 qd_entry = e_entry_create(GNOME_DIALOG(dialog)->vbox, "New Drawing");
 gtk_signal_connect(GTK_OBJECT(dialog), "clicked", GTK_SIGNAL_FUNC(qd_new_drawing_2), NULL);
 gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);
 gtk_widget_show(dialog);
}

void qd_open_draw_line(gint i, char *id, gint x0, gint y0, gint x1, gint y1, double w, gint f, gint l, gchar *c)
{
 gint j;
 gchar tmp[150];
 GnomeCanvasPoints *points;
 GnomeCanvasItem *item;
 points = gnome_canvas_points_new(2);
 points->coords[0] = x0;
 points->coords[1] = y0;
 points->coords[2] = x1;
 points->coords[3] = y1;
 item = gnome_canvas_item_new(qd_drawing[i].group, gnome_canvas_line_get_type(), "points", points, "width_units", w, "first_arrowhead", f, "last_arrowhead", l, "arrow_shape_a", 10.0, "arrow_shape_b", 10.0, "arrow_shape_c", 10.0, "fill_color", c, NULL);
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 gnome_canvas_points_unref(points);
 if((j=free_item(i)) == -1) return;
 qd_drawing[i].item[j].used = 1;
 sprintf(tmp, "%p", item);
 strcpy(qd_drawing[i].item[j].id, tmp);
 strcpy(qd_drawing[i].item[j].type, "line");
 sprintf(tmp, "%f %d %d %s", w, f, l, c);
 strcpy(qd_drawing[i].item[j].param, tmp);
 qd_drawing[i].item[j].x0 = x0;
 qd_drawing[i].item[j].y0 = y0;
 qd_drawing[i].item[j].x1 = x1;
 qd_drawing[i].item[j].y1 = y1;
}

void qd_open_draw_rect(gint i, char *id, double x0, double y0, double x1, double y1, double w, gchar *c, gchar *o)
{
 gint j;
 gchar tmp[150];
 GnomeCanvasItem *item;
 if(strcasecmp(c,"grey"))
 item = gnome_canvas_item_new(qd_drawing[i].group, gnome_canvas_rect_get_type(), "x1", (double)x0, "y1", (double)y0, "x2", (double)x1, "y2", (double)y1, "fill_color", c, "outline_color", o, "width_units", w, NULL);
 else
 item = gnome_canvas_item_new(qd_drawing[i].group, gnome_canvas_rect_get_type(), "x1", (double)x0, "y1", (double)y0, "x2", (double)x1, "y2", (double)y1, "fill_color", NULL, "outline_color", o, "width_units", w, NULL); 
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 if((j=free_item(i)) == -1) return;
 qd_drawing[i].item[j].used = 1;
 sprintf(tmp, "%p", item);
 strcpy(qd_drawing[i].item[j].id, tmp);
 strcpy(qd_drawing[i].item[j].type, "rect");
 sprintf(tmp, "%f %s %s", w, c, o);
 strcpy(qd_drawing[i].item[j].param, tmp);
 qd_drawing[i].item[j].x0 = (int)x0;
 qd_drawing[i].item[j].y0 = (int)y0;         
 qd_drawing[i].item[j].x1 = (int)x1;
 qd_drawing[i].item[j].y1 = (int)y1;           
}

void qd_open_draw_elli(gint i, char *id, double x0, double y0, double x1, double y1, double w, gchar *c, gchar *o)
{
 gint j;
 gchar tmp[150];
 GnomeCanvasItem *item;
 if(strcasecmp(c,"grey"))
 item = gnome_canvas_item_new(qd_drawing[i].group, gnome_canvas_ellipse_get_type(), "x1", (double)x0, "y1", (double)y0, "x2", (double)x1, "y2", (double)y1, "fill_color", c, "outline_color", o, "width_units", w, NULL);
 else
 item = gnome_canvas_item_new(qd_drawing[i].group, gnome_canvas_ellipse_get_type(), "x1", (double)x0, "y1", (double)y0, "x2", (double)x1, "y2", (double)y1, "fill_color", NULL, "outline_color", o, "width_units", w, NULL); 
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 if((j=free_item(i)) == -1) return;
 qd_drawing[i].item[j].used = 1;
 sprintf(tmp, "%p", item);
 strcpy(qd_drawing[i].item[j].id, tmp);
 strcpy(qd_drawing[i].item[j].type, "ellipse");
 sprintf(tmp, "%f %s %s", w, c, o);
 strcpy(qd_drawing[i].item[j].param, tmp);
 qd_drawing[i].item[j].x0 = (int)x0;
 qd_drawing[i].item[j].y0 = (int)y0;         
 qd_drawing[i].item[j].x1 = (int)x1;
 qd_drawing[i].item[j].y1 = (int)y1;           
}

void qd_open_draw_text(gint i, char *id, double x, double y, double x1, double y1, gchar *font, gchar *text)
{
 gint j;
 gchar tmp[150];
 GnomeCanvasItem *item;
 *(text+strlen(text)-2)=' ';
 *(text+strlen(text)-3)=' ';
 item = gnome_canvas_item_new(qd_drawing[i].group, gnome_canvas_text_get_type(), "x", (double)x, "y", (double)y, "text", text, "font", font, "anchor", GTK_ANCHOR_NORTH_WEST, NULL);
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 if((j=free_item(i)) == -1) return;
 qd_drawing[i].item[j].used = 1;
 sprintf(tmp, "%p", item);
 strcpy(qd_drawing[i].item[j].id, tmp);
 strcpy(qd_drawing[i].item[j].type, "text");
 sprintf(tmp, "%s %s", font, text);
 strcpy(qd_drawing[i].item[j].param, tmp);
 qd_drawing[i].item[j].x0 = (int)x;
 qd_drawing[i].item[j].y0 = (int)y;         
 qd_drawing[i].item[j].x1 = (int)x;
 qd_drawing[i].item[j].y1 = (int)y;           
}

void qd_open_draw_image(gint i, char *id, double x, double y, double x1, double y1, gchar *image)
{
 gint j;
 gchar tmp[150];
 GnomeCanvasItem *item;
 GdkImlibImage *im;
 im = gdk_imlib_load_image(image);
 if(im==NULL) return;
 item = gnome_canvas_item_new(qd_drawing[i].group, gnome_canvas_image_get_type(), "x", (double)x, "y", (double)y, "image", im, "anchor", GTK_ANCHOR_NORTH_WEST, "width", (double)im->rgb_width, "height", (double)im->rgb_height, NULL);
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 if((j=free_item(i)) == -1) return;
 qd_drawing[i].item[j].used = 1;
 sprintf(tmp, "%p", item);
 strcpy(qd_drawing[i].item[j].id, tmp);
 strcpy(qd_drawing[i].item[j].type, "image");
 sprintf(tmp, "%s", image);
 strcpy(qd_drawing[i].item[j].param, tmp);
 qd_drawing[i].item[j].x0 = (int)x;
 qd_drawing[i].item[j].y0 = (int)y;         
 qd_drawing[i].item[j].x1 = (int)x;
 qd_drawing[i].item[j].y1 = (int)y;           
}

void qd_open_cancel()
{
 gtk_widget_destroy(qd_browse);
}

void qd_open_parse()
{
 int i;
 gchar tmp[1024];
 FILE *fd;
 if((i=qd_new_drawing_cb(name_path(e_browse_get(qd_browse))))==-1) return;
 gtk_widget_destroy(qd_browse);
 sprintf(tmp, "%s/%s", qd_project_dir, qd_drawing[i].filename);
 fd = fopen(tmp, "r");
 if(fd==NULL)
 {
  gnome_error_dialog("Could not open the drawing");
  return;
 }
 while(fgets(tmp, 1000, fd)!=NULL)
 {
  if(!strcmp(e_lindex_delim(tmp,0,";"),"line"))
  {
   qd_open_draw_line(i, e_lindex_delim(tmp,1,";"), atoi(e_lindex_delim(tmp,2,";")), atoi(e_lindex_delim(tmp,3,";")), atoi(e_lindex_delim(tmp,4,";")), atoi(e_lindex_delim(tmp,5,";")), atof(e_lindex(e_lindex_delim(tmp,6,";"),0)), atoi(e_lindex(e_lindex_delim(tmp,6,";"),1)), atoi(e_lindex(e_lindex_delim(tmp,6,";"),2)), e_lindex(e_lindex_delim(tmp,6,";"),3));
  }
  else if(!strcmp(e_lindex_delim(tmp,0,";"),"poly"))
  {
   qd_open_draw_line(i, e_lindex_delim(tmp,1,";"), atoi(e_lindex_delim(tmp,2,";")), atoi(e_lindex_delim(tmp,3,";")), atoi(e_lindex_delim(tmp,4,";")), atoi(e_lindex_delim(tmp,5,";")), atof(e_lindex(e_lindex_delim(tmp,6,";"),0)), 0, 0, e_lindex(e_lindex_delim(tmp,6,";"),0));
  }
  else if(!strcmp(e_lindex_delim(tmp,0,";"),"rect"))
  {
   qd_open_draw_rect(i, e_lindex_delim(tmp,1,";"), atof(e_lindex_delim(tmp,2,";")), atof(e_lindex_delim(tmp,3,";")), atof(e_lindex_delim(tmp,4,";")), atof(e_lindex_delim(tmp,5,";")), atof(e_lindex(e_lindex_delim(tmp,6,";"),0)), e_lindex(e_lindex_delim(tmp,6,";"),1), e_lindex(e_lindex_delim(tmp,6,";"),2));
  }
  else if(!strcmp(e_lindex_delim(tmp,0,";"),"ellipse"))
  {
   qd_open_draw_elli(i, e_lindex_delim(tmp,1,";"), atof(e_lindex_delim(tmp,2,";")), atof(e_lindex_delim(tmp,3,";")), atof(e_lindex_delim(tmp,4,";")), atof(e_lindex_delim(tmp,5,";")), atof(e_lindex(e_lindex_delim(tmp,6,";"),0)), e_lindex(e_lindex_delim(tmp,6,";"),1), e_lindex(e_lindex_delim(tmp,6,";"),2));
  }
  else if(!strcmp(e_lindex_delim(tmp,0,";"),"text"))
  {
   qd_open_draw_text(i, e_lindex_delim(tmp,1,";"), atof(e_lindex_delim(tmp,2,";")), atof(e_lindex_delim(tmp,3,";")), atof(e_lindex_delim(tmp,4,";")), atof(e_lindex_delim(tmp,5,";")), e_lindex(e_lindex_delim(tmp,6,";"),0), e_lrange(e_lindex_delim(tmp,7,";"),1));
  }
  else if(!strcmp(e_lindex_delim(tmp,0,";"),"image"))
  {
   qd_open_draw_image(i, e_lindex_delim(tmp,1,";"), atof(e_lindex_delim(tmp,2,";")), atof(e_lindex_delim(tmp,3,";")), atof(e_lindex_delim(tmp,4,";")), atof(e_lindex_delim(tmp,5,";")), e_lindex_delim(tmp,6,";"));
  }
 }
 fclose(fd);
}

void qd_open_drawing() /* open a saved drawing */
{
 gchar tmp[strlen(qd_project_dir)+5];
 qd_browse = e_browse_create("Open Drawing", qd_open_parse, qd_open_cancel);
 sprintf(tmp, "%s/", qd_project_dir);
 gtk_file_selection_set_filename(GTK_FILE_SELECTION(qd_browse), tmp);
 gtk_window_set_modal(GTK_WINDOW(qd_browse), TRUE);
}

void qd_save_drawing() /* save the currently focused page */
{
 gint i=qd_cur_page(), j;
 gchar tmp[150];
 FILE *fd;
 if(i==-1) return;
 sprintf(tmp, "%s/%s", qd_project_dir, qd_drawing[i].filename);
 fd = fopen(tmp, "w");
 if(fd==NULL)
 {
  sprintf(tmp, "Could not open %s/%s for saving", qd_project_dir, qd_drawing[i].filename);
  gnome_error_dialog(tmp);
  return;
 }
 for(j=0;j<QD_ITEMS;j++)
 {
  if(qd_drawing[i].item[j].used != 0)
  {
   fprintf(fd, "%s;%s;%d;%d;%d;%d;%s;\n", qd_drawing[i].item[j].type, qd_drawing[i].item[j].id, qd_drawing[i].item[j].x0, qd_drawing[i].item[j].y0, qd_drawing[i].item[j].x1, qd_drawing[i].item[j].y1, qd_drawing[i].item[j].param);
  }
 }
 fclose(fd);
 sprintf(tmp, "%s saved to %s", qd_drawing[i].filename, qd_project_dir);
 qd_drawing[i].modified = 0;
 gnome_ok_dialog(tmp);
}

void qd_close_drawing_2() /* close the page */
{
 int i = qd_cur_page();
 gtk_widget_destroy(qd_drawing[i].page->parent);
 qd_drawing[i].used = FALSE;
}

void qd_close_drawing_cb(int but) /* user wants to close even if modified */
{
 if(but==0) qd_close_drawing_2();
}

void qd_close_drawing() /* close current drawing */
{
 int i = qd_cur_page();
 GtkWidget *dialog;
 if(i==-1) return;
 if(qd_drawing[i].modified == FALSE) qd_close_drawing_2(); /* drawing wasnt modified */
 else /* it was modified */
 {
  dialog = gnome_question_dialog_modal_parented("The drawing has been modified. Are you sure you want to close?", GTK_SIGNAL_FUNC(qd_close_drawing_cb), &dialog, GTK_WINDOW(qd_app));
 }
}

void qd_print_drawing() /* print currently focused drawing */
{
}

