/* (C) 1999-2000 Patrick Lambert (drow@post.com) - Provided under GPL */
#include "qd.h"

static GnomeUIInfo file_menu[] = {
 GNOMEUIINFO_MENU_NEW_ITEM("_New drawing", "Create a new drawing", qd_new_drawing, NULL),
 GNOMEUIINFO_MENU_OPEN_ITEM(qd_open_drawing, NULL),
 GNOMEUIINFO_MENU_SAVE_ITEM(qd_save_drawing, NULL),
 GNOMEUIINFO_MENU_CLOSE_ITEM(qd_close_drawing, NULL),
 GNOMEUIINFO_ITEM_NONE("_Load library", "Load a library", qd_lib_load),
 GNOMEUIINFO_SEPARATOR,
 GNOMEUIINFO_MENU_EXIT_ITEM(qd_exit, NULL),
 GNOMEUIINFO_END
};

static GnomeUIInfo tools_menu[] = {
 GNOMEUIINFO_ITEM_NONE("_Line", "Draw a line", qd_draw_line),
 GNOMEUIINFO_ITEM_NONE("_Polygon", "Draw a polygon", qd_draw_poly),
 GNOMEUIINFO_ITEM_NONE("_Rectangle", "Draw a rectangle", qd_draw_rect),
 GNOMEUIINFO_ITEM_NONE("_Ellipse", "Draw an ellipse", qd_draw_elli),
 GNOMEUIINFO_ITEM_NONE("_Text", "Draw some text", qd_draw_text),
 GNOMEUIINFO_ITEM_NONE("_Image", "Draw an image file", qd_draw_image),
 GNOMEUIINFO_SEPARATOR,
 GNOMEUIINFO_MENU_PROPERTIES_ITEM(qd_draw_options, NULL),
 GNOMEUIINFO_END
};

static GnomeUIInfo debug_menu[] = {
 GNOMEUIINFO_ITEM_NONE("_Object table", "Print the object table", qd_debug),
 GNOMEUIINFO_ITEM_NONE("_Manual delete", "Delete an object", qd_debug_delete),
 GNOMEUIINFO_SEPARATOR,
 GNOMEUIINFO_ITEM_NONE("Zoom _in", "Zoom in the drawing", qd_zoom_in),
 GNOMEUIINFO_ITEM_NONE("Zoom _out", "Zoom out the drawing", qd_zoom_out),
 GNOMEUIINFO_ITEM_NONE("_Normal view", "Zoom at 100%", qd_zoom_1),
 GNOMEUIINFO_END
};

static GnomeUIInfo help_menu[] = {
 GNOMEUIINFO_ITEM_NONE("_Instructions", "Get some information", qd_instruct),
 GNOMEUIINFO_SEPARATOR,
 GNOMEUIINFO_MENU_ABOUT_ITEM(qd_about, NULL),
 GNOMEUIINFO_END
};

static GnomeUIInfo menu[] = {
 GNOMEUIINFO_MENU_FILE_TREE(file_menu),
 GNOMEUIINFO_SUBTREE("_Shapes", tools_menu),
#ifdef DEBUG
 GNOMEUIINFO_SUBTREE("_Debug", debug_menu),
#endif
 GNOMEUIINFO_MENU_HELP_TREE(help_menu),
 GNOMEUIINFO_END
};

void qd_add_menus() /* simply create the menus */
{
 gnome_app_create_menus_with_data(GNOME_APP(qd_app), menu, qd_app);
}
