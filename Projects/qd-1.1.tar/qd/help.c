/* (C) 1999-2000 Patrick Lambert (drow@post.com) - Provided under GPL */
#include "qd.h"

void qd_about()
{
 GtkWidget *dialog;
 const gchar *authors[] = {
  "Patrick Lambert <drow@post.com>",
  NULL
 };
 dialog = gnome_about_new(QD_PROGRAM, QD_VERSION, "(C) Copyright 1999-2000 Patrick Lambert", authors, "This software program allows users to make object oriented drawings, open and save them, and modify them.\n\nThis program is under the GPL, and may be used and copied in accordance with the terms in that license.\n\nThe latest copy of this program is available from http://www.linsupport.com", "logo.xpm");
 gnome_dialog_set_parent(GNOME_DIALOG(dialog), GTK_WINDOW(qd_app));
 gtk_widget_show(dialog);
}

void qd_instruct()
{
 e_show_textbox("Instructions", "Quadrant Draw is an object oriented drawing program. It allows you to create drawings with standard shapes such as rectangles, lines, ellipses, images and text, and with third party libraries.\n\nYou can save and reload your drawings. The saved file is in text format, allowing you to create your own drawing by hand or with scripts, to be loaded into Quadrant Draw.\n\nThe list of available shapes is on the left of the main window, and instructions as to how they work will appear in the status bar. The software is intuitive and easy to use.\n", gtk_widget_destroy);
}
