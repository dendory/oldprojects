/* (C) 1999-2000 Patrick Lambert (drow@post.com) - Provided under GPL */
#include "qd.h"

void qd_lib_clicked(GtkWidget *button, gpointer data)
{
 if(qd_cur_page()==-1) return;
 strncpy(qd_curlibxpm, (char*)data, 149);
 qd_state = QD_STATE_LIBXPM;
 gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Library: Click where you want to insert the object");
}

void qd_lib_actual(gchar *name)
{
 GtkWidget *win, *sw, *box, *box2, *icon, *button;
 FILE *fd;
 gchar buf[102], tmp[250];
 fd = fopen(name, "r");
 if(fd==NULL)
 {
  if(GTK_IS_WIDGET(qd_browse)) gtk_widget_destroy(qd_browse);
  gnome_error_dialog("Could not open specified library file");
  return;
 }
 fgets(buf, 100, fd);
 if(strcasecmp(e_lindex(buf,0),"qd_lib"))
 {
  fclose(fd);
  gnome_error_dialog("Selected file is not a valid library");
  return;
 }
 fgets(buf, 100, fd);
 win = e_window_create(e_lindex_delim(buf,0,";"), 400, 100, 1, 1, gtk_widget_destroy);
 sw = e_scrolled_create(win);
 box = gtk_vbox_new(FALSE, 0);
 gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(sw), box);
 gtk_container_border_width(GTK_CONTAINER(box), 2);
 gtk_widget_show(box);
 box2 = e_box_create(box, E_HORIZONTAL, 0);
 while(fgets(buf, 100, fd)!=NULL)
 {
  if(!strcasecmp(e_lindex_delim(buf,0,";"),"newline"))
  {
   box2 = e_box_create(box, E_HORIZONTAL, 0);  
  }
  else
  {
   sprintf(tmp, "%s/%s", base_path(name), e_lindex_delim(buf,0,";"));
   icon = e_icon_create(win,tmp);
   button = gtk_button_new();
   gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(qd_lib_clicked), (gpointer)g_strdup(tmp));
   gtk_container_add(GTK_CONTAINER(button), icon);
   gtk_box_pack_start(GTK_BOX(box2), button, FALSE, FALSE, 0);
   gtk_widget_show(button);
   gtk_widget_show(icon);
  }
 }
 fclose(fd);
}

void qd_lib_load_cancel()
{
 gtk_widget_destroy(qd_browse);
}

void qd_lib_load_ok()
{
 gchar *tmp = e_browse_get(qd_browse);
 qd_lib_actual(tmp);
 if(GTK_IS_WIDGET(qd_browse)) gtk_widget_destroy(qd_browse);
}

void qd_lib_load()
{
 gchar tmp[150];
 qd_browse = e_browse_create("Select info file", qd_lib_load_ok, qd_lib_load_cancel);
 sprintf(tmp, "%s/libraries/", getenv("HOME"));
 gtk_file_selection_set_filename(GTK_FILE_SELECTION(qd_browse), tmp);
 gtk_window_set_modal(GTK_WINDOW(qd_browse), TRUE);
}

void qd_lib_auto()
{
 FILE *fd;
 gchar tmp[150], buf[102];
 sprintf(tmp, "%s/libraries/autoload.inf", getenv("HOME"));
 fd = fopen(tmp, "r");
 if(fd==NULL)
 {
  sprintf(tmp, "mkdir -p %s/libraries", getenv("HOME"));
  system(tmp);
  sprintf(tmp, "touch %s/libraries/autoload.inf", getenv("HOME"));
  system(tmp);
 }
 else
 {
  while(fgets(buf, 100, fd)!=NULL)
  {
   sprintf(tmp, "%s/libraries/%s/control.inf", getenv("HOME"), e_lindex_delim(buf,0,";"));
   qd_lib_actual(g_strdup(tmp));
  }
  fclose(fd);
 }
}
