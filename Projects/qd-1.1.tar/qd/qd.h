/* (C) 1999-2000 Patrick Lambert (drow@post.com) - Provided under GPL */
#include <gnome.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include "easygtk.h"

#define QD_MAXD 7 /* max drawings */
#define QD_ITEMS 501 /* max items on a drawing */
#define QD_PROGRAM "Quadrant Draw" /* program name */
#define QD_VERSION "1.1" /* current version */
#define QD_READY_MSG "Ready. Click to move a shape, shift+click to delete, ctrl+click to lower"
#define QD_STATE_NULL 1000
#define QD_STATE_LINE_0 1001
#define QD_STATE_LINE_1 1002
#define QD_STATE_RECT_0 1003
#define QD_STATE_RECT_1 1004
#define QD_STATE_POLY 1005
#define QD_STATE_ELLI_0 1006
#define QD_STATE_ELLI_1 1007
#define QD_STATE_TEXT 1008
#define QD_STATE_IMAGE 1009
#define QD_STATE_LIBXPM 1010

struct qd_items {
 gint used;
 gchar id[50];
 gchar type[50];
 gint x0, y0, x1, y1;
 gchar param[150];
};

struct qd_drawings {
 gint used;
 gint modified;
 GtkWidget *page, *canvas, *area, *table, *hruler, *vruler;
 GnomeCanvasGroup *group;
 gchar filename[33]; /* drawing name */
 struct qd_items item[QD_ITEMS];
} qd_drawing[QD_MAXD+1]; /* drawing struct */

gint qd_dline_i0, qd_dline_x0, qd_dline_y0, qd_dline_i1, qd_dline_x1, qd_dline_y1;
gint qd_drect_i0, qd_drect_x0, qd_drect_y0, qd_drect_i1, qd_drect_x1, qd_drect_y1;
gint qd_dpoly_i0, qd_dpoly_x0, qd_dpoly_y0, qd_dpoly_i1, qd_dpoly_x1, qd_dpoly_y1;
gint qd_delli_i0, qd_delli_x0, qd_delli_y0, qd_delli_i1, qd_delli_x1, qd_delli_y1;
gint qd_dtext_i, qd_dtext_x, qd_dtext_y;
gint qd_dimage_i, qd_dimage_x, qd_dimage_y;
gint qd_state, qd_xa, qd_xb, qd_ya, qd_yb;
gchar tmp_dir[31];
gchar qd_project_dir[50];
gchar qd_curlibxpm[150];

GtkWidget *qd_app, *qd_notebook, *qd_entry, *qd_statusbar, *qd_pbox, *qd_browse, *qd_fontwin;
GtkWidget *opt_e1, *opt_c1, *opt_c2, *opt_e2, *opt_e3, *opt_e4, *opt_e5, *opt_e6, *opt_e7, *opt_e8, *opt_e9, *opt_e10;

void qd_main_win();
void qd_exit();
void qd_add_menus();
void qd_add_toolbars();
void qd_open_drawing();
void qd_new_drawing();
void qd_save_drawing();
void qd_save_as_drawing();
void qd_close_drawing();
void qd_print_drawing();
void qd_about();
void qd_add_menus();
void qd_add_toolbars();
int qd_cur_page();
void qd_draw_poly();
void qd_poly_do_it();
void qd_event();
void qd_line_do_it();
void qd_draw_line();
void qd_rect_do_it();
void qd_draw_rect();
void qd_draw_elli();
void qd_elli_do_it();
void qd_draw_text();
void qd_text_do_it();
void qd_text_font();
void qd_draw_image();
void qd_image_do_it();
void qd_image_cancel();
void qd_draw_options();
gint qd_obj_event(GnomeCanvasItem *item, GdkEvent *event, gpointer data);
char *base_path(char *str);
char *name_path(char *str);
gint free_item(gint drawing);
void print_items(gint drawing);
void qd_debug();
void qd_instruct();
void qd_debug_delete();
void qd_zoom_in();
void qd_zoom_out();
void qd_zoom_1();
void qd_lib_load();
void qd_lib_actual(gchar *name);
void qd_lib_auto();
void qd_libxpm_do_it();
