/* (C) 1999-2000 Patrick Lambert (drow@post.com) - Provided under GPL */
#include "qd.h"

/* options, with default values */
double opt_line_width = 2.0;
gboolean opt_line_farrow = FALSE;
gboolean opt_line_larrow = FALSE;
gchar opt_line_color[100] = "black";
double opt_poly_width = 2.0;
gchar opt_poly_color[100] = "black";
double opt_rect_width = 2.0;
gchar opt_rect_outline[100] = "black";
gchar opt_rect_color[100] = "tan";
double opt_elli_width = 2.0;
gchar opt_elli_outline[100] = "black";
gchar opt_elli_color[100] = "tan";
gchar opt_text_font[100] = "-misc-fixed-*-*-*-*-*-*-*-*-*-*-*-*";

double cur_zoom = 1.0;

void qd_event() /* function for all click events, to draw shapes */
{
 GtkWidget *dialog;
 int i = qd_cur_page(), x, y;
 x = GTK_RULER(qd_drawing[i].hruler)->position;
 y = GTK_RULER(qd_drawing[i].vruler)->position;
 qd_drawing[i].modified = TRUE;
 if(qd_state==QD_STATE_LINE_0)
 {
  qd_dline_i0 = i;
  qd_dline_x0 = x;
  qd_dline_y0 = y;
  qd_state = QD_STATE_LINE_1;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Line: Click where you want the second point");
 }
 else if(qd_state==QD_STATE_LINE_1)
 {
  qd_dline_i1 = i;
  qd_dline_x1 = x;
  qd_dline_y1 = y;
  qd_state = QD_STATE_NULL;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), QD_READY_MSG);
  if(qd_dline_i0 != qd_dline_i1)
  {
   gnome_error_dialog("The two points for a line must be on the same drawing");
   return;
  }
  qd_line_do_it();       
 }
 else if(qd_state==QD_STATE_TEXT)
 {
  qd_dtext_i = i;
  qd_dtext_x = x;
  qd_dtext_y = y;
  qd_state = QD_STATE_NULL;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), QD_READY_MSG);
  dialog = gnome_dialog_new("Enter Text", GNOME_STOCK_BUTTON_OK, GNOME_STOCK_BUTTON_CANCEL, NULL);
  gnome_dialog_set_parent(GNOME_DIALOG(dialog), GTK_WINDOW(qd_app));
  e_label_create(GNOME_DIALOG(dialog)->vbox, "Enter your text:");
  qd_entry = e_entry_create(GNOME_DIALOG(dialog)->vbox, "");
  e_button_fixed(GNOME_DIALOG(dialog)->vbox, "Font", qd_text_font);
  gtk_signal_connect(GTK_OBJECT(dialog), "clicked", GTK_SIGNAL_FUNC(qd_text_do_it), NULL);
  gtk_widget_show(dialog);
 }
 else if(qd_state==QD_STATE_LIBXPM)
 {
  qd_dimage_i = i;
  qd_dimage_x = x;
  qd_dimage_y = y;
  qd_state = QD_STATE_NULL;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), QD_READY_MSG);
  qd_libxpm_do_it();
 }
 else if(qd_state==QD_STATE_IMAGE)
 {
  qd_dimage_i = i;
  qd_dimage_x = x;
  qd_dimage_y = y;
  qd_state = QD_STATE_NULL;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), QD_READY_MSG);
  qd_browse = e_browse_create("Select your image", qd_image_do_it, qd_image_cancel);
 }
 else if(qd_state==QD_STATE_RECT_0)
 {
  qd_drect_i0 = i;
  qd_drect_x0 = x;
  qd_drect_y0 = y;
  qd_state = QD_STATE_RECT_1;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Rectangle: Click where you want the bottom, right point");
 }
 else if(qd_state==QD_STATE_RECT_1)
 {
  qd_drect_i1 = i;
  qd_drect_x1 = x;
  qd_drect_y1 = y;
  qd_state = QD_STATE_NULL;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), QD_READY_MSG);
  if(qd_drect_i0 != qd_drect_i1)
  {
   gnome_error_dialog("The two points for a rectangle must be on the same drawing");
   return;
  }
  qd_rect_do_it();
 }
 else if(qd_state==QD_STATE_ELLI_0)
 {
  qd_delli_i0 = i;
  qd_delli_x0 = x;
  qd_delli_y0 = y;
  qd_state = QD_STATE_ELLI_1;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Ellipse: Click where you want the bottom, right point");
 }
 else if(qd_state==QD_STATE_ELLI_1)
 {
  qd_delli_i1 = i;
  qd_delli_x1 = x;
  qd_delli_y1 = y;
  qd_state = QD_STATE_NULL;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), QD_READY_MSG);
  if(qd_drect_i0 != qd_drect_i1)
  {
   gnome_error_dialog("The two points for an ellipse must be on the same drawing");
   return;
  }
  qd_elli_do_it();
 }
 else if(qd_state==QD_STATE_POLY)
 {
  if(qd_dpoly_x0==-1)
  {
   qd_dpoly_x0 = x;
   qd_dpoly_y0 = y;
   qd_dpoly_i0 = i;
   qd_dpoly_x1 = x;
   qd_dpoly_y1 = y;
   qd_dpoly_i1 = i;
  }
  else
  {
   qd_dpoly_x0 = qd_dpoly_x1;
   qd_dpoly_y0 = qd_dpoly_y1;
   qd_dpoly_i0 = qd_dpoly_i1;
   qd_dpoly_x1 = x;
   qd_dpoly_y1 = y;
   qd_dpoly_i1 = i;
   if(qd_dpoly_i0 != qd_dpoly_i1)
   {
    gnome_error_dialog("The points for a polygon must be on the same drawing");
    return;
   }
   qd_poly_do_it();
  }
 }
}

gint qd_obj_event(GnomeCanvasItem *item, GdkEvent *event, gpointer data)
{ /* move, lower, and destroy click events */
 static double x, y;
 GdkCursor *fleur;
 gint i=qd_cur_page(),j;
 gchar tmp[100];
 double new_x, new_y;
 static int dragging;
 double item_x, item_y;
 item_x = event->button.x;
 item_y = event->button.y;
 gnome_canvas_item_w2i(item->parent, &item_x, &item_y);
 switch(event->type)
 {
  case GDK_BUTTON_PRESS:
   switch(event->button.button)
   {
    case 1:
     if(event->button.state & GDK_SHIFT_MASK) /* shift click, delete item */
     {
      sprintf(tmp, "%p", item);
      for(j=0;j<QD_ITEMS;j++)
      {
       if(!strcmp(qd_drawing[i].item[j].id,tmp)) qd_drawing[i].item[j].used = 0;
      }
      gtk_object_destroy(GTK_OBJECT(item));
     }
     else if(event->button.state & GDK_CONTROL_MASK) /* ctrl click, lower */
     {
      gnome_canvas_item_lower_to_bottom(item);
     }
     else
     {
      gnome_canvas_item_raise_to_top(item);
      x = item_x;
      y = item_y;
      qd_xa = (int)x;
      qd_ya = (int)y;
      fleur = gdk_cursor_new(GDK_FLEUR);
      gnome_canvas_item_grab(item, GDK_POINTER_MOTION_MASK|GDK_BUTTON_RELEASE_MASK, fleur, event->button.time);
      gdk_cursor_destroy(fleur);
      dragging = TRUE;
     }
     break;
    default:
     break;
   }
   break;
  case GDK_MOTION_NOTIFY:
   if(dragging && (event->motion.state & GDK_BUTTON1_MASK))
   {
    new_x = item_x;
    new_y = item_y;
    gnome_canvas_item_move(item, new_x - x, new_y - y);
    x = new_x;
    y = new_y;
   }
   break;
  case GDK_BUTTON_RELEASE:
   gnome_canvas_item_ungrab(item, event->button.time);
   qd_xb = (int)x;
   qd_yb = (int)y;
   sprintf(tmp, "%p", item);
   for(j=0;j<QD_ITEMS;j++)
   {
    if(!strcmp(qd_drawing[i].item[j].id,tmp))
    {
     qd_drawing[i].item[j].x0 = qd_xb - (qd_xa - qd_drawing[i].item[j].x0);    
     qd_drawing[i].item[j].y0 = qd_yb - (qd_ya - qd_drawing[i].item[j].y0);
     qd_drawing[i].item[j].x1 = qd_xb + (qd_drawing[i].item[j].x1 - qd_xa);
     qd_drawing[i].item[j].y1 = qd_yb + (qd_drawing[i].item[j].y1 - qd_ya);
    }
   }
   dragging = FALSE;
   break;
  default:
   break;
 }
 return FALSE;
}

/*
* deprecated
*void qd_draw_polygon()
*{
* int i = qd_cur_page();
* GnomeCanvasPoints *points;
* GnomeCanvasItem *item;
* if(i==-1) return;
* points = gnome_canvas_points_new(4);
* points->coords[0] = 100.0;
* points->coords[1] = 100.0;
* points->coords[2] = 400.0;
* points->coords[3] = 400.0;
* points->coords[4] = 200.0;
* points->coords[5] = 600.0;
* points->coords[6] = 500.0;
* points->coords[7] = 200.0;
* item = gnome_canvas_item_new(qd_drawing[i].group, gnome_canvas_polygon_get_type(), "points", points, "fill_color", "tan", "outline_color", "black", "width_units", 1.0, NULL);
* gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
* gnome_canvas_points_unref(points);
*}
*/

void qd_draw_line() /* point 1 for line */
{
 int i = qd_cur_page();
 if(i==-1) return;
 qd_state = QD_STATE_LINE_0;
 gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Line: Click where you want the first point.");
}

void qd_line_do_it() /* called from event hdl, we have both points */
{
 gint i;
 gchar tmp[100];
 GnomeCanvasPoints *points;
 GnomeCanvasItem *item;
 points = gnome_canvas_points_new(2);
 points->coords[0] = qd_dline_x0;
 points->coords[1] = qd_dline_y0;
 points->coords[2] = qd_dline_x1;
 points->coords[3] = qd_dline_y1;
 item = gnome_canvas_item_new(qd_drawing[qd_dline_i0].group, gnome_canvas_line_get_type(), "points", points, "width_units", opt_line_width, "first_arrowhead", opt_line_farrow, "last_arrowhead", opt_line_larrow, "arrow_shape_a", 10.0, "arrow_shape_b", 10.0, "arrow_shape_c", 10.0, "fill_color", opt_line_color, NULL);
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 gnome_canvas_points_unref(points);
 if((i=free_item(qd_dline_i0)) == -1) return;
 qd_drawing[qd_dline_i0].item[i].used = 1;
 sprintf(tmp, "%p", item);
 strcpy(qd_drawing[qd_dline_i0].item[i].id, tmp);
 strcpy(qd_drawing[qd_dline_i0].item[i].type, "line");
 sprintf(tmp, "%f %d %d %s", opt_line_width, opt_line_farrow, opt_line_larrow, opt_line_color);
 strcpy(qd_drawing[qd_dline_i0].item[i].param, tmp);
 qd_drawing[qd_dline_i0].item[i].x0 = qd_dline_x0;
 qd_drawing[qd_dline_i0].item[i].y0 = qd_dline_y0;
 qd_drawing[qd_dline_i0].item[i].x1 = qd_dline_x1;
 qd_drawing[qd_dline_i0].item[i].y1 = qd_dline_y1;  
}

void qd_draw_rect() /* draw a rect, point 1 */
{
 int i = qd_cur_page();
 if(i==-1) return;
 qd_state = QD_STATE_RECT_0;
 gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Rectangle: Click where you want the top, left corner.");
}

void qd_draw_elli() /* draw an ellipse, point 1 */
{
 int i = qd_cur_page();
 if(i==-1) return;
 qd_state = QD_STATE_ELLI_0;
 gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Ellipse: Click where you want the top, left corner.");
}

void qd_draw_text() /* draw some text */
{
 int i = qd_cur_page();
 if(i==-1) return;
 qd_state = QD_STATE_TEXT;
 gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Text: Click where you want the top, left corner.");
}

void qd_draw_image() /* draw an image file */
{
 int i = qd_cur_page();
 if(i==-1) return;
 qd_state = QD_STATE_IMAGE;
 gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Image: Click where you want the top, left corner.");
}

void qd_rect_do_it() /* called from event hdl, we have both points */
{
 gint i;
 gchar tmp[100];
 GnomeCanvasItem *item;
 if(strcasecmp(opt_rect_color,"grey"))
 item = gnome_canvas_item_new(qd_drawing[qd_drect_i0].group, gnome_canvas_rect_get_type(), "x1", (double)qd_drect_x0, "y1", (double)qd_drect_y0, "x2", (double)qd_drect_x1, "y2", (double)qd_drect_y1, "fill_color", opt_rect_color, "outline_color", opt_rect_outline, "width_units", opt_rect_width, NULL);
 else
 item = gnome_canvas_item_new(qd_drawing[qd_drect_i0].group, gnome_canvas_rect_get_type(), "x1", (double)qd_drect_x0, "y1", (double)qd_drect_y0, "x2", (double)qd_drect_x1, "y2", (double)qd_drect_y1, "fill_color", NULL, "outline_color", opt_rect_outline, "width_units", opt_rect_width, NULL);
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 if((i=free_item(qd_drect_i0)) == -1) return;
 qd_drawing[qd_drect_i0].item[i].used = 1;
 sprintf(tmp, "%p", item);
 strcpy(qd_drawing[qd_drect_i0].item[i].id, tmp);
 strcpy(qd_drawing[qd_drect_i0].item[i].type, "rect");
 sprintf(tmp, "%f %s %s", opt_rect_width, opt_rect_color, opt_rect_outline);
 strcpy(qd_drawing[qd_drect_i0].item[i].param, tmp);
 qd_drawing[qd_drect_i0].item[i].x0 = (int)qd_drect_x0;
 qd_drawing[qd_drect_i0].item[i].y0 = (int)qd_drect_y0;
 qd_drawing[qd_drect_i0].item[i].x1 = (int)qd_drect_x1;
 qd_drawing[qd_drect_i0].item[i].y1 = (int)qd_drect_y1;
}

void qd_text_do_it(GnomeDialog *dialog, int but) /* called from dialog box */
{
 gint i;
 gchar tmp[100];
 GnomeCanvasItem *item;
 if(but==1) /* cancel */
 {
  gnome_dialog_close(dialog);
  return;
 }
 item = gnome_canvas_item_new(qd_drawing[qd_dtext_i].group, gnome_canvas_text_get_type(), "x", (double)qd_dtext_x, "y", (double)qd_dtext_y, "text", e_entry_get(qd_entry), "anchor", GTK_ANCHOR_NORTH_WEST, "font", opt_text_font, NULL);
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 if((i=free_item(qd_dtext_i)) == -1) return;
 qd_drawing[qd_dtext_i].item[i].used = 1;
 sprintf(tmp, "%p", item);
 strcpy(qd_drawing[qd_dtext_i].item[i].id, tmp);
 strcpy(qd_drawing[qd_dtext_i].item[i].type, "text");
 sprintf(tmp, "%s %s", opt_text_font, e_entry_get(qd_entry));
 strcpy(qd_drawing[qd_dtext_i].item[i].param, tmp);
 qd_drawing[qd_dtext_i].item[i].x0 = (int)qd_dtext_x;
 qd_drawing[qd_dtext_i].item[i].y0 = (int)qd_dtext_y;
 qd_drawing[qd_dtext_i].item[i].x1 = (int)qd_dtext_x;
 qd_drawing[qd_dtext_i].item[i].y1 = (int)qd_dtext_y;
 gnome_dialog_close(dialog);
}

void qd_image_cancel()
{
 gtk_widget_destroy(qd_browse);
}

void qd_image_do_it() /* called from dialog box */
{
 gint i;
 gchar tmp[100];
 GnomeCanvasItem *item;
 GdkImlibImage *im;
 im = gdk_imlib_load_image(e_browse_get(qd_browse));
 if(im==NULL)
 {
  gtk_widget_destroy(qd_browse);
  return;
 }
 item = gnome_canvas_item_new(qd_drawing[qd_dimage_i].group, gnome_canvas_image_get_type(), "x", (double)qd_dimage_x, "y", (double)qd_dimage_y, "image", im, "anchor", GTK_ANCHOR_NORTH_WEST, "width", (double)im->rgb_width, "height", (double)im->rgb_height, NULL);
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 if((i=free_item(qd_dimage_i)) == -1) return;
 qd_drawing[qd_dimage_i].item[i].used = 1;
 sprintf(tmp, "%p", item);
 strcpy(qd_drawing[qd_dimage_i].item[i].id, tmp);
 strcpy(qd_drawing[qd_dimage_i].item[i].type, "image");
 sprintf(tmp, "%s", e_browse_get(qd_browse));
 strcpy(qd_drawing[qd_dimage_i].item[i].param, tmp);
 qd_drawing[qd_dimage_i].item[i].x0 = (int)qd_dimage_x;
 qd_drawing[qd_dimage_i].item[i].y0 = (int)qd_dimage_y;
 qd_drawing[qd_dimage_i].item[i].x1 = (int)qd_dimage_x;
 qd_drawing[qd_dimage_i].item[i].y1 = (int)qd_dimage_y;
 gtk_widget_destroy(qd_browse);
}

void qd_libxpm_do_it() /* images in the libs */
{
 gint i;
 gchar tmp[100];
 GnomeCanvasItem *item;
 GdkImlibImage *im;
 im = gdk_imlib_load_image(qd_curlibxpm);
 if(im==NULL) return;
 item = gnome_canvas_item_new(qd_drawing[qd_dimage_i].group, gnome_canvas_image_get_type(), "x", (double)qd_dimage_x, "y", (double)qd_dimage_y, "image", im, "anchor", GTK_ANCHOR_NORTH_WEST, "width", (double)im->rgb_width, "height", (double)im->rgb_height, NULL);
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 if((i=free_item(qd_dimage_i)) == -1) return;
 qd_drawing[qd_dimage_i].item[i].used = 1;
 sprintf(tmp, "%p", item);
 strcpy(qd_drawing[qd_dimage_i].item[i].id, tmp);
 strcpy(qd_drawing[qd_dimage_i].item[i].type, "image");
 sprintf(tmp, "%s", qd_curlibxpm);
 strcpy(qd_drawing[qd_dimage_i].item[i].param, tmp);
 qd_drawing[qd_dimage_i].item[i].x0 = (int)qd_dimage_x;
 qd_drawing[qd_dimage_i].item[i].y0 = (int)qd_dimage_y;
 qd_drawing[qd_dimage_i].item[i].x1 = (int)qd_dimage_x;
 qd_drawing[qd_dimage_i].item[i].y1 = (int)qd_dimage_y;
}

void qd_text_font_cancel()
{
 gtk_widget_destroy(qd_fontwin);
}

void qd_text_font_ok()
{
 strcpy(opt_text_font, e_font_get(qd_fontwin));
 gtk_widget_destroy(qd_fontwin);
}

void qd_text_font()
{
 qd_fontwin = e_font_create("Select a font", qd_text_font_ok, qd_text_font_cancel);
 gtk_window_set_modal(GTK_WINDOW(qd_fontwin), TRUE);
}

void qd_elli_do_it() /* called from event hdl, we have both points */
{
 gint i;
 gchar tmp[100];
 GnomeCanvasItem *item;
 if(strcasecmp(opt_elli_color,"grey"))
 item = gnome_canvas_item_new(qd_drawing[qd_delli_i0].group, gnome_canvas_ellipse_get_type(), "x1", (double)qd_delli_x0, "y1", (double)qd_delli_y0, "x2", (double)qd_delli_x1, "y2", (double)qd_delli_y1, "fill_color", opt_elli_color, "outline_color", opt_elli_outline, "width_units", opt_elli_width, NULL);
 else
 item = gnome_canvas_item_new(qd_drawing[qd_delli_i0].group, gnome_canvas_ellipse_get_type(), "x1", (double)qd_delli_x0, "y1", (double)qd_delli_y0, "x2", (double)qd_delli_x1, "y2", (double)qd_delli_y1, "fill_color", NULL, "outline_color", opt_elli_outline, "width_units", opt_elli_width, NULL);
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 if((i=free_item(qd_delli_i0)) == -1) return;
 qd_drawing[qd_delli_i0].item[i].used = 1;
 sprintf(tmp, "%p", item);
 strcpy(qd_drawing[qd_delli_i0].item[i].id, tmp);
 strcpy(qd_drawing[qd_delli_i0].item[i].type, "ellipse");
 sprintf(tmp, "%f %s %s", opt_elli_width, opt_elli_color, opt_elli_outline);
 strcpy(qd_drawing[qd_delli_i0].item[i].param, tmp);
 qd_drawing[qd_delli_i0].item[i].x0 = (int)qd_delli_x0;
 qd_drawing[qd_delli_i0].item[i].y0 = (int)qd_delli_y0;
 qd_drawing[qd_delli_i0].item[i].x1 = (int)qd_delli_x1;
 qd_drawing[qd_delli_i0].item[i].y1 = (int)qd_delli_y1;
}

void qd_draw_poly() /* first point for a poly */
{
 int i = qd_cur_page();
 if(i==-1) return;
 if(qd_state==QD_STATE_POLY)
 {
  qd_state = QD_STATE_NULL;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), QD_READY_MSG);
  qd_dpoly_x0 = -1;
 }
 else
 {
  qd_state = QD_STATE_POLY;
  gnome_appbar_set_default(GNOME_APPBAR(qd_statusbar), "Polygon: Click for the next point, select Polygon to end");
 }
}

void qd_poly_do_it() /* called from event hdl, we have an other point */
{
 gint i;
 gchar tmp[100];
 GnomeCanvasPoints *points;
 GnomeCanvasItem *item;
 points = gnome_canvas_points_new(2);
 points->coords[0] = qd_dpoly_x0;
 points->coords[1] = qd_dpoly_y0;
 points->coords[2] = qd_dpoly_x1;
 points->coords[3] = qd_dpoly_y1;
 item = gnome_canvas_item_new(qd_drawing[qd_dpoly_i0].group, gnome_canvas_line_get_type(), "points", points, "width_units", opt_poly_width, "fill_color", opt_poly_color, NULL);
 gtk_signal_connect(GTK_OBJECT(item), "event", (GtkSignalFunc) qd_obj_event, NULL);
 gnome_canvas_points_unref(points);
 if((i=free_item(qd_dpoly_i0)) == -1) return;
 qd_drawing[qd_dpoly_i0].item[i].used = 1;
 sprintf(tmp, "%p", item);
 strcpy(qd_drawing[qd_dpoly_i0].item[i].id, tmp);
 strcpy(qd_drawing[qd_dpoly_i0].item[i].type, "line");
 sprintf(tmp, "%f 0 0 %s", opt_poly_width, opt_poly_color);
 strcpy(qd_drawing[qd_dpoly_i0].item[i].param, tmp);
 qd_drawing[qd_dpoly_i0].item[i].x0 = qd_dpoly_x0;
 qd_drawing[qd_dpoly_i0].item[i].y0 = qd_dpoly_y0;
 qd_drawing[qd_dpoly_i0].item[i].x1 = qd_dpoly_x1;
 qd_drawing[qd_dpoly_i0].item[i].y1 = qd_dpoly_y1;
}

void qd_options_ok(GtkWidget *w, int but) /* options window button clicked */
{
 if(but==0)
 {
  opt_line_width = atof(e_entry_get(opt_e1));
  opt_line_farrow = e_checkbutton_get(opt_c1);
  opt_line_larrow = e_checkbutton_get(opt_c2);
  strncpy(opt_line_color, e_entry_get(opt_e2), 95);
  opt_poly_width = atof(e_entry_get(opt_e3));
  strncpy(opt_poly_color, e_entry_get(opt_e4), 95);
  opt_rect_width = atof(e_entry_get(opt_e5));
  strncpy(opt_rect_outline, e_entry_get(opt_e6), 95);
  strncpy(opt_rect_color, e_entry_get(opt_e7), 95);
  opt_elli_width = atof(e_entry_get(opt_e8));
  strncpy(opt_elli_outline, e_entry_get(opt_e9), 95);
  strncpy(opt_elli_color, e_entry_get(opt_e10), 95);
 }
 gtk_widget_destroy(qd_pbox);
 if(!strcmp(opt_line_color,"") || !strcmp(opt_poly_color,"") || !strcmp(opt_rect_color,"") || !strcmp(opt_rect_outline,"") || !strcmp(opt_elli_color,"") || !strcmp(opt_elli_outline,""))
 { /* if they are left empty, and the drawing is saved, qd wont be able to reopen it */
  gnome_error_dialog("Could not save options, one or more entries are empty. Please change them.");
  return;
 }
}

void qd_draw_options() /* options dialog */
{
 GtkWidget *p1, *p2, *p3, *p4, *vbox, *hbox, *nb;
 gchar tmp[100];
 qd_pbox = gnome_dialog_new("Properties", GNOME_STOCK_BUTTON_OK, GNOME_STOCK_BUTTON_CANCEL, NULL);
 gnome_dialog_set_parent(GNOME_DIALOG(qd_pbox), GTK_WINDOW(qd_app));
 gnome_dialog_set_default(GNOME_DIALOG(qd_pbox), 1);
 gtk_window_set_modal(GTK_WINDOW(qd_pbox), TRUE);
 gtk_signal_connect(GTK_OBJECT(qd_pbox), "clicked", GTK_SIGNAL_FUNC(qd_options_ok), NULL);
 nb = e_notebook_create(GNOME_DIALOG(qd_pbox)->vbox, E_TOP);
 p1 = e_notebook_new_page(nb, "Line", "Properties for Line");
 vbox = e_box_create(p1, E_VERTICAL, 5);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Line width:");
 sprintf(tmp, "%f", opt_line_width);
 opt_e1 = e_entry_create(hbox, tmp);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Line color:");
 opt_e2 = e_entry_create(hbox, opt_line_color);
 opt_c1 = e_checkbutton_create(vbox, "Show a first arrow", opt_line_farrow, E_NO_FUNC);
 opt_c2 = e_checkbutton_create(vbox, "Show an ending arrow", opt_line_larrow, E_NO_FUNC);
 p2 = e_notebook_new_page(nb, "Polygon", "Properties for Polygon");
 vbox = e_box_create(p2, E_VERTICAL, 5);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Polygon line width:");
 sprintf(tmp, "%f", opt_poly_width);
 opt_e3 = e_entry_create(hbox, tmp);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Polygon outline color:");
 opt_e4 = e_entry_create(hbox, opt_poly_color);
 p3 = e_notebook_new_page(nb, "Rectangle", "Properties for Rectangle");
 vbox = e_box_create(p3, E_VERTICAL, 5);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Rectangle line width:");
 sprintf(tmp, "%f", opt_rect_width);
 opt_e5 = e_entry_create(hbox, tmp);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Rectangle outline color:");
 opt_e6 = e_entry_create(hbox, opt_rect_outline);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Rectangle color:");       
 opt_e7 = e_entry_create(hbox, opt_rect_color); 
 p4 = e_notebook_new_page(nb, "Ellipse", "Properties for Ellipse");
 vbox = e_box_create(p4, E_VERTICAL, 5);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Ellipse line width:");
 sprintf(tmp, "%f", opt_elli_width);
 opt_e8 = e_entry_create(hbox, tmp);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Ellipse outline color:");
 opt_e9 = e_entry_create(hbox, opt_elli_outline);
 hbox = e_box_create(vbox, E_HORIZONTAL, 0);
 e_label_create(hbox, "Ellipse color:");       
 opt_e10 = e_entry_create(hbox, opt_elli_color); 
 gtk_widget_show_all(qd_pbox);
}

gint free_item(gint drawing)
{
 gint i;
 for(i=0;i<QD_ITEMS;i++)
 {
  if(qd_drawing[drawing].item[i].used == 0) break;
 }
 if(qd_drawing[drawing].item[i].used != 0)
 {
  gnome_error_dialog("Item buffer is full");
  return -1;
 }
 return i;
}

void qd_debug()
{
 if(qd_cur_page()==-1) return;
 print_items(qd_cur_page());
}

void print_items(gint drawing)
{
 gint i;
 for(i=0;i<QD_ITEMS;i++)
 {
  if(qd_drawing[drawing].item[i].used != 0)
  {
   printf("| %d | %s | %s | %d,%d %d,%d | %s |\n", i, qd_drawing[drawing].item[i].type, qd_drawing[drawing].item[i].id, qd_drawing[drawing].item[i].x0, qd_drawing[drawing].item[i].y0, qd_drawing[drawing].item[i].x1, qd_drawing[drawing].item[i].y1, qd_drawing[drawing].item[i].param);
  }
 }
}

void qd_debug_delete_cb(GnomeDialog *dialog, int num)
{
 if(num==1)
 {
  gnome_dialog_close(dialog);
  return;
 }
 qd_drawing[qd_cur_page()].item[atoi(e_entry_get(qd_entry))].used = 0;
 gnome_dialog_close(dialog);
}

void qd_debug_delete()
{
 GtkWidget *dialog;
 dialog = gnome_dialog_new("Debug", GNOME_STOCK_BUTTON_OK, GNOME_STOCK_BUTTON_CANCEL, NULL);
 gnome_dialog_set_parent(GNOME_DIALOG(dialog), GTK_WINDOW(qd_app));
 e_label_create(GNOME_DIALOG(dialog)->vbox, "Enter an object number:");
 qd_entry = e_entry_create(GNOME_DIALOG(dialog)->vbox, "");
 gtk_signal_connect(GTK_OBJECT(dialog), "clicked", GTK_SIGNAL_FUNC(qd_debug_delete_cb), NULL);
 gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);
 gtk_widget_show(dialog);
}

void qd_zoom_in()
{
 int i=qd_cur_page();
 if(i==-1) return;
 cur_zoom = cur_zoom + (double)0.1;
 gnome_canvas_set_pixels_per_unit(GNOME_CANVAS(qd_drawing[i].canvas), cur_zoom);
}

void qd_zoom_out()
{
 int i=qd_cur_page();
 if(i==-1) return;  
 cur_zoom = cur_zoom - (double)0.1;
 gnome_canvas_set_pixels_per_unit(GNOME_CANVAS(qd_drawing[i].canvas), cur_zoom);
}

void qd_zoom_1()
{
 int i=qd_cur_page();
 if(i==-1) return;  
 cur_zoom = (double)1.0;
 gnome_canvas_set_pixels_per_unit(GNOME_CANVAS(qd_drawing[i].canvas), cur_zoom);
}
 