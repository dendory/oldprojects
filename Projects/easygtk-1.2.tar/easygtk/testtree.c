#include "easygtk.h"
GtkWidget *win, *box, *tree, *subtree;
void printit()
{
 printf("%s\n", e_tree_get());
}

int main(int argc, char *argv[])
{
 gtk_init(&argc, &argv);
 win = e_window_create("test tree", 100, 200, 100, 100, exit);
 box = e_box_create(win, E_VERTICAL, 2);
 tree = e_tree_create(box);
 subtree = e_tree_insert_subtree(tree, "Basic");
 e_tree_insert_item(subtree, "test 0", printit);
 e_tree_insert_item(subtree, "test 1", printit);
 subtree = e_tree_insert_subtree(tree, "Adv");
 e_tree_insert_item(subtree, "test 2", printit);
 gtk_main();
 return 0;
}
