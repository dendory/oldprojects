/* (C) 1999 Patrick Lambert <drow@post.com> */
#include "easygtk.h"
#include <unistd.h>
#include <sys/stat.h>
#define HELP_TEXT "Linux Backup\n\nLinux Backup is a backup utility for workstations. It allows you to backup selected directories into a backup file.\n\nLinux Backup uses the TAR utility to create and extract backups. It supports compression, incremential updates and multi volume floppies. You can use floppy disks to create backups, but it is not recommended because floppies are unreliable.\n\nYou can mount a ZIP disk, remote hard disk, or use a tape backup. For floppies, you need to mount the first floppy before starting the backup, and mount the others when requested.\n\nThis program is under the GNU General Public License (GPL) and AS-IS with no warranty. You can get a copy of the GPL at http://www.gnu.org\n\nLinux Backup was created and is maintained by Patrick Lambert <drow@post.com>\n\nGet your latest version of Linux Backup at one of these fine sites:\nhttp://devplanet.fastethernet.net\nhttp://users.linuxbox.com/~drow\nhttp://mirrors.darkelf.net\n"

/* vars */
char home[112];
char temp[512];
char current_dir[1024];
char target[112];
char tmp_name[54];
char backup[112];
int compress, update, floppies;
FILE *fd;

/* widgets */
GtkWidget *main_win, *vbox, *hbox, *page, *tb, *nb, *project_struct, *bck_list, *rst_list, *cmp_list, *bck_entry, *browse, *bckwin, *cb, *target_entry, *ucb, *fcb, *rstwin, *restore_path, *vbox2, *df_text;

/* functions */
void cb_exit();
void make_main_win();
void cb_dir_sel();
void cb_add_dir();
void cb_rem_dir();
void cb_bck_list_sel();
void cb_bck_save_set();
void cb_bck_load_set();
char *bck_get_entry(int i);
void add_to_bck_list(char *data);
void start_backup();
void cb_start_backup_cancel();
void cb_start_backup_ok();
void cb_log();
void add_to_rst_list(char *data);
void load_restore();
void restore_backup();
void compare_file();
void add_to_cmp_list(char *data);
void check_df();
void mount_fd();
void umount_fd();
