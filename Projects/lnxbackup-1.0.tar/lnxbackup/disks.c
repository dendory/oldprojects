/* (C) 1999 Patrick Lambert <drow@post.com> */
#include "lnxbackup.h"

void check_df()
{
 e_text_delete(df_text);
 strncpy(tmp_name, tempnam(NULL,".lbk"), 50);
 sprintf(temp, "df -h -a > %s", tmp_name);
 system(temp);
 fd = fopen(tmp_name, "r");
 if(fd==NULL) return;
 while(fgets(temp, 500, fd)!=NULL)
 {
  e_text_insert(df_text, temp);
 }
 fclose(fd);
}

void mount_fd()
{
 system("mount /mnt/floppy");
}

void umount_fd()
{
 system("umount /mnt/floppy");
}
