/* (C) 1999 Patrick Lambert <drow@post.com> */
#include "lnxbackup.h"

/* get entry from backup list */
char *bck_get_entry(int i)
{
 char *line;
 gtk_clist_get_text(GTK_CLIST(bck_list), i, 0, &line);
 return g_strdup(line);
}

/* save current backuping set */
void cb_bck_save_set()
{
 int i;
 sprintf(temp, "%s/%s", home, e_entry_get(bck_entry));
 fd = fopen(temp, "w");
 if(fd==NULL)
 {
  e_show_message("Error", "Could not open backup set in your home directory", gtk_widget_destroy);
  return;
 }
 fputs(e_entry_get(bck_entry), fd);
 fputs(" ;\n", fd);
 fputs(target, fd);
 fputs(" ;\n", fd);
 sprintf(temp, "%d", compress);
 fputs(temp, fd);
 fputs(" ;\n", fd);
 sprintf(temp, "%d", update);
 fputs(temp, fd);
 fputs(" ;\n", fd);
 sprintf(temp, "%d", floppies);
 fputs(temp, fd);
 fputs(" ;\n", fd);
 for(i=0; gtk_clist_get_cell_type(GTK_CLIST(bck_list), i, 0)!=-1; i++)
 {
  fputs(bck_get_entry(i), fd);
  fputs(" ;\n", fd);
 }
 fclose(fd);
}

/* load the selected set for backuping */
void cb_bck_load_ok()
{
 chdir(home); /* we go back to home */
 gtk_clist_clear(GTK_CLIST(bck_list));
 fd = fopen(e_browse_get(browse), "r");
 if(fd==NULL)
 {
  e_show_message("Error", "Could not load backup set", gtk_widget_destroy);
  return;
 }
 fgets(temp, 500, fd);
 gtk_entry_set_text(GTK_ENTRY(bck_entry), e_lindex(temp,0));
 fgets(temp, 500, fd);
 strcpy(target, e_lindex(temp,0));
 fgets(temp, 500, fd);
 compress = atoi(e_lindex(temp,0));
 fgets(temp, 500, fd);
 update = atoi(e_lindex(temp,0));
 fgets(temp, 500, fd);
 floppies = atoi(e_lindex(temp,0));
 while(fgets(temp, 500, fd)!=NULL)
 {
  add_to_bck_list(e_lindex(temp,0));
 }
 fclose(fd);
 gtk_widget_destroy(browse);
}

/* cancel the load of a set */
void cb_bck_load_cancel()
{
 gtk_widget_destroy(browse);
}

/* load a set for backuping */
void cb_bck_load_set()
{
 chdir(home); /* since blk files are saved in the home */
 browse = e_browse_create("Select LBK file to load", cb_bck_load_ok, cb_bck_load_cancel);
}

/* start backup */
void cb_start_backup_ok()
{
 int i;
 if(compress && update)
 {
  e_show_message("Error", "Can't update compressed archives", gtk_widget_destroy);
  return;
 }
 if(compress && floppies)
 {
  e_show_message("Error", "Can't use multi volume on compressed archives", gtk_widget_destroy);
  return;
 }
 strncpy(tmp_name, tempnam(NULL,".lbk"), 50);
 chdir("/"); /* because tar removes the initial / and all our dirs are relative to / */
 strncpy(target, e_entry_get(target_entry), 100);
 fd = fopen(tmp_name, "w");
 if(fd==NULL)
 {
  e_show_message("Error", "Can't open temporary file", gtk_widget_destroy);
  return;
 }
 for(i=0; gtk_clist_get_cell_type(GTK_CLIST(bck_list), i, 0)!=-1; i++)
 {
  fputs(bck_get_entry(i), fd);
  fputs("\n", fd);
 }
 fclose(fd);
 if(!floppies)
 {
  if(update)
  {
   if(compress) sprintf(temp, "%s -uzf %s `cat %s` > %s/backup_log 2>&1",TAR, target, tmp_name, home);
   else sprintf(temp, "%s -uf %s `cat %s` > %s/backup_log 2>&1",TAR, target, tmp_name, home);
  }
  else
  {
   if(compress) sprintf(temp, "%s -czf %s `cat %s` > %s/backup_log 2>&1",TAR, target, tmp_name, home);
   else sprintf(temp, "%s -cf %s `cat %s` > %s/backup_log 2>&1",TAR, target, tmp_name, home);
  }
 }
 else
 {
  if(update)
  {
   if(compress) sprintf(temp, "xterm -e %s -uvMz -L 1400 -f %s `cat %s` &",TAR, target, tmp_name);
   else sprintf(temp, "xterm -e %s -uvM -L 1400 -f %s `cat %s` &",TAR, target, tmp_name);
  }
  else
  {
   if(compress) sprintf(temp, "xterm -e %s -cvMz -L 1400 -f %s `cat %s` &",TAR, target, tmp_name);
   else sprintf(temp, "xterm -e %s -cvM -L 1440 -f %s `cat %s` &",TAR, target, tmp_name);
  }
 }
 system(temp);
 chdir(home);
 if(!floppies) e_show_message("Message", "Backup file created. Log is in ~/backup_log", gtk_widget_destroy);
 gtk_widget_destroy(bckwin);
}

/* dont start backup */
void cb_start_backup_cancel()
{
 gtk_widget_destroy(bckwin);
}

/* compression checkbox */
void cb_change_compress()
{
 compress = e_checkbutton_get(cb);
 if(compress == 1)
 {
  sprintf(temp, "%s.tgz", e_entry_get(target_entry));
  gtk_entry_set_text(GTK_ENTRY(target_entry), temp);
 }
 else
 {
  sprintf(temp, "%s.tar", e_entry_get(target_entry));
  gtk_entry_set_text(GTK_ENTRY(target_entry), temp);
 }
}

/* update checkbox */
void cb_change_update()
{
 update = e_checkbutton_get(ucb);
}

/* floppies checkbox */
void cb_change_floppies()
{
 floppies = e_checkbutton_get(fcb);
}

/* start backup screen */
void start_backup()
{
 bckwin = e_window_create("Start backup", 300, 170, 0, 0, gtk_widget_destroy);
 vbox = e_box_create(bckwin, E_VERTICAL, 10);
 cb = e_checkbutton_create(vbox, "Use compression", compress, cb_change_compress);
 ucb = e_checkbutton_create(vbox, "Update archive", update, cb_change_update);
 fcb = e_checkbutton_create(vbox, "Use multiple floppies", floppies, cb_change_floppies);
 target_entry = e_entry_create(vbox, target);
 e_buttonbox_create(vbox, E_SPREAD, "Start", "Cancel", cb_start_backup_ok, cb_start_backup_cancel);
}

/* cancel load for restore */
void cb_load_restore_cancel()
{
 gtk_widget_destroy(browse);
}

/* load file for restoring */
void cb_load_restore_ok()
{
 struct stat stat_buf;
 gtk_clist_clear(GTK_CLIST(rst_list));
 strncpy(tmp_name, tempnam(NULL,".lbk"), 50);
 strncpy(backup, e_browse_get(browse), 100);
 if(backup[strlen(backup)-1]=='z' || backup[strlen(backup)-1]=='Z')
 {
  sprintf(temp, "%s -tzf %s > %s 2> %s/backup_log",TAR, backup, tmp_name, home);
 }
 else
 {
  sprintf(temp, "%s -tf %s > %s 2> %s/backup_log",TAR, backup, tmp_name, home);
 }
 system(temp);
 fd = fopen(tmp_name, "r");
 if(fd==NULL)
 {
  e_show_message("Error", "Could not open temporary file", gtk_widget_destroy);
  return;
 }
 while(fgets(temp, 500, fd)!=NULL)
 {
  add_to_rst_list(e_lindex(temp,0));
 }
 fclose(fd);
 sprintf(temp, "%s/backup_log", home);
 stat(g_strdup(temp), &stat_buf);
 if(stat_buf.st_size>0)
 {
  e_show_message("Error", "An error occurred. See the log file.", gtk_widget_destroy);
 }
 gtk_widget_destroy(browse);
}

/* load backup for future restoring */
void load_restore()
{
 browse = e_browse_create("Select TAR, TGZ or TAR.GZ file", cb_load_restore_ok, cb_load_restore_cancel);
}

/* restore loaded backup */
void restore_backup_normal()
{
 chdir(e_entry_get(restore_path));
 if(backup[strlen(backup)-1]=='z' || backup[strlen(backup)-1]=='Z')
 {
  sprintf(temp, "%s -xzf %s > %s/backup_log 2>&1",TAR, backup, home);
 }
 else
 {
  sprintf(temp, "%s -xf %s > %s/backup_log, 2>&1",TAR, backup, home);
 }
 system(temp);
 e_show_message("Message", "Restore completed. Log is in ~/backup_log", gtk_widget_destroy);
 chdir(home);
 gtk_widget_destroy(rstwin);
}

/* restore multi volume backup */
void restore_backup_multi()
{
 chdir(e_entry_get(restore_path));
 if(backup[strlen(backup)-1]=='z' || backup[strlen(backup)-1]=='Z')
 {
  e_show_message("Error", "Can't use multi volume on compressed archives", gtk_widget_destroy);
  return;
 }
 else
 {
  sprintf(temp, "xterm -e %s -xvMf %s",TAR, backup);
 }
 system(temp);
 e_show_message("Message", "Restore completed", gtk_widget_destroy);
 chdir(home);
 gtk_widget_destroy(rstwin);
}

/* cancel restore */
void cb_restore_backup()
{
 gtk_widget_destroy(rstwin);
}

/* is it a multi volume */
void restore_backup()
{
 rstwin = e_window_create("Restore current archive", 300, 100, 0, 0, gtk_widget_destroy); 
 sprintf(temp, "Is %s a multi volume archive?", backup);
 vbox = e_box_create(rstwin, E_VERTICAL, 5);
 e_label_create(vbox, temp);
 e_buttonbox_create(vbox, E_SPREAD, "Yes", "No", restore_backup_multi, restore_backup_normal);
}

/* compare backup file */
void cb_compare_ok()
{
 struct stat stat_buf;
 chdir("/");
 gtk_clist_clear(GTK_CLIST(cmp_list));
 strncpy(tmp_name, tempnam(NULL,".lbk"), 50);
 strncpy(backup, e_browse_get(browse), 100);
 if(backup[strlen(backup)-1]=='z' || backup[strlen(backup)-1]=='Z')
 {
  sprintf(temp, "%s -dzf %s > %s 2> %s/backup_log",TAR, backup, tmp_name, home);
 }
 else
 {
  sprintf(temp, "%s -df %s > %s 2> %s/backup_log",TAR, backup, tmp_name, home);
 }
 system(temp);
 fd = fopen(tmp_name, "r");
 if(fd==NULL)
 {
  e_show_message("Error", "Could not open temporary file", gtk_widget_destroy);
  return;
 }
 while(fgets(temp, 500, fd)!=NULL)
 {
  add_to_cmp_list(temp);
 }
 fclose(fd);
 chdir(home);
 sprintf(temp, "%s/backup_log", home);
 stat(g_strdup(temp), &stat_buf);
 if(stat_buf.st_size>0)
 {
  e_show_message("Error", "An error occurred. See the log file.", gtk_widget_destroy);
 }
 gtk_widget_destroy(browse);
}

/* cancel compare */
void cb_compare_cancel()
{
 gtk_widget_destroy(browse);
}

/* browse for a backup to compare */
void compare_file()
{
 browse = e_browse_create("Select TAR, TGZ or TAR.GZ file", cb_compare_ok, cb_compare_cancel);
}
