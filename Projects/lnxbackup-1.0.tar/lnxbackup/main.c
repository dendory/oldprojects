/* (C) 1999 Patrick Lambert <drow@post.com> */
#include "lnxbackup.h"

int main(int argc, char *argv[])
{
 gtk_init(&argc, &argv);
 if(getenv("HOME")==NULL)
 {
  printf("Your HOME environment variable is not set.\n");
  exit(1);
 }
 strncpy(home, getenv("HOME"), 100);
 chdir(home);
 strcpy(target, "/mnt/floppy/mybackup.tar");
 make_main_win();
 gtk_main();
 return(0);
}

void cb_help()
{
 GtkWidget *help_win;
 help_win = e_window_create("Help", 400, 300, 0, 0, gtk_widget_destroy);
 vbox = e_box_create(help_win, E_VERTICAL, 5);
 e_text_create(vbox, FALSE, HELP_TEXT, E_NO_FUNC);
}

void cb_exit()
{
 exit(0);
}

void make_main_win()
{
 sprintf(temp, "Linux Backup v%s", VERSION);
 main_win = e_window_create(temp, 640, 450, 0, 0, cb_exit);
 vbox = e_box_create(main_win, E_VERTICAL, 5);
 nb = e_notebook_create(vbox, E_TOP);

/* backup page */
 page = e_notebook_new_page(nb, "Backup", "Create a backup");
 tb = e_toolbar_create(page, E_HORIZONTAL);
 gtk_toolbar_set_button_relief(GTK_TOOLBAR(tb), GTK_RELIEF_NORMAL);
 e_toolbar_insert(tb, "Load a set", "Load a backup set", NULL, cb_bck_load_set);
 e_toolbar_insert(tb, "Save current set", "Save current backup set", NULL, cb_bck_save_set);
 e_toolbar_insert(tb, "Start backup", "Start the backup process", NULL, start_backup);
 e_toolbar_insert(tb, "Get Help", "Get help", NULL, cb_help);
 e_toolbar_insert(tb, "View log", "View last backup log", NULL, cb_log);
 e_toolbar_insert(tb, "Quit", "Quit Linux Backup", NULL, cb_exit);
 hbox = e_box_create(page, E_HORIZONTAL, 2);
 e_label_create(hbox, "Backup set:");
 bck_entry = e_entry_create(hbox, "Untitled.lbk");
 hbox = e_box_create(page, E_HORIZONTAL, 2);
 vbox = e_box_create(hbox, E_VERTICAL, 2);
 e_set_size(vbox, 150, 300);
 project_struct = gtk_file_selection_new("PROJECT STRUCT");

 GTK_WIDGET(GTK_FILE_SELECTION(project_struct)->dir_list)->parent->parent = NULL;
 gtk_box_pack_start(GTK_BOX(vbox), GTK_FILE_SELECTION(project_struct)->dir_list->parent, TRUE, TRUE, 0);
 gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(project_struct)->dir_list), "select_row", GTK_SIGNAL_FUNC(cb_dir_sel), NULL);
 gtk_widget_show(GTK_FILE_SELECTION(project_struct)->dir_list->parent);

 vbox = e_box_create(hbox, E_VERTICAL, 10);
 e_set_size(vbox, 40, 300);
 e_button_create(vbox, "->", cb_add_dir);
 e_button_create(vbox, "<-", cb_rem_dir);

 vbox = e_box_create(hbox, E_VERTICAL, 2);
 e_set_size(vbox, 400, 300);
 bck_list = e_list_create(vbox, 1, E_NO_FUNC);
 e_list_setup(bck_list, 0, "Selected directories", 400);
 
/* restore page */
 page = e_notebook_new_page(nb, "Restore", "Restore files from a backup");
 tb = e_toolbar_create(page, E_HORIZONTAL);
 gtk_toolbar_set_button_relief(GTK_TOOLBAR(tb), GTK_RELIEF_NORMAL);
 e_toolbar_insert(tb, "Load a backup", "Load a backup tar/gz file", NULL, load_restore);
 e_toolbar_insert(tb, "Restore", "Restore the backup to the system", NULL, restore_backup);
 e_toolbar_insert(tb, "Get Help", "Get help", NULL, cb_help);
 e_toolbar_insert(tb, "View log", "View last backup log", NULL, cb_log);
 e_toolbar_insert(tb, "Quit", "Quit Linux Backup", NULL, cb_exit);
 hbox = e_box_fixed(page, E_HORIZONTAL, 10);
 e_set_size(hbox, 640, 40);
 e_label_create(hbox, "Restore path:");
 restore_path = e_entry_create(hbox, "/");
 vbox = e_box_create(page, E_VERTICAL, 2);
 e_set_size(vbox, 400, 300);
 rst_list = e_list_create(vbox, 1, E_NO_FUNC);
 e_list_setup(rst_list, 0, "Backup content", 400);

/* comparaison page */
 page = e_notebook_new_page(nb, "Compare", "Compare a backup with current files");
 tb = e_toolbar_create(page, E_HORIZONTAL);
 gtk_toolbar_set_button_relief(GTK_TOOLBAR(tb), GTK_RELIEF_NORMAL);
 e_toolbar_insert(tb, "Compare a backup", "Load a backup and compare it", NULL, compare_file);
 e_toolbar_insert(tb, "Get Help", "Get help", NULL, cb_help);
 e_toolbar_insert(tb, "View log", "View last backup log", NULL, cb_log);
 e_toolbar_insert(tb, "Quit", "Quit Linux Backup", NULL, cb_exit);
 vbox = e_box_create(page, E_VERTICAL, 2);
 e_set_size(vbox, 400, 320);
 cmp_list = e_list_create(vbox, 1, E_NO_FUNC);
 e_list_setup(cmp_list, 0, "Backup content", 400);

/* disks page */
 page = e_notebook_new_page(nb, "Disks", "Disks summary and operation");
 df_text = e_text_create(page, FALSE, "", E_NO_FUNC);
 e_button_fixed(page, "Refresh above values", check_df);
 e_button_fixed(page, "Mount /mnt/floppy", mount_fd);
 e_button_fixed(page, "UnMount /mnt/floppy", umount_fd);
 check_df();
}
