/* (C) 1999 Patrick Lambert <drow@post.com> */
#include "lnxbackup.h"

void cb_dir_sel()
{
 strncpy(current_dir, gtk_file_selection_get_filename(GTK_FILE_SELECTION(project_struct)), 1000);
}

void cb_add_dir()
{
 add_to_bck_list(current_dir);
}

void add_to_bck_list(char *data)
{
 char *the_dir[] = { data };
 e_list_insert(bck_list, the_dir);
}

void cb_rem_dir()
{
 e_list_remove(bck_list); 
}

void cb_log()
{
 sprintf(temp, "xterm -e less %s/backup_log &", home);
 system(temp);
}

void add_to_rst_list(char *data)
{
 char *the_dir[] = { data };
 e_list_insert(rst_list, the_dir);
}

void add_to_cmp_list(char *data)
{
 char *the_dir[] = { data };
 e_list_insert(cmp_list, the_dir);
}
