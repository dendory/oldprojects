#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <strings.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <sys/file.h>
#include <signal.h>
#include "sscript.h"  

/* utils cl (C) 1998 Drow <drow@wildstar.net>
 * See sscript.doc for copyright information */

utils_cl(int sockfd, char in[1024][1024])
{
 char salt[3],temp6[255];
 salt[0]='z';
 salt[1]='0';
 salt[2]='\0';
 if(!cas_cmp(lindex(temp,2),"perl"))
 {
  sprintf(temp6,"%s -le '%s' > .perl.results",PERL_BIN,in[atoi(lindex(temp,3))]);
  system(temp6);
 }
/*
 if(!cas_cmp(lindex(temp,2),"crypt"))
 {
  strcpy(in[atoi(lindex(temp,4))],(char *)crypt(in[atoi(lindex(temp,3))],salt));
 }
*/
 if(!cas_cmp(lindex(temp,2),"localhost"))
 {
  strcpy(temp6,"");
  gethostname(temp6,sizeof(temp6));
  strcpy(in[atoi(lindex(temp,3))],temp6);
 }
}
