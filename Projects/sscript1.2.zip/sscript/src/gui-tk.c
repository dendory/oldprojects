#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <strings.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <sys/file.h>
#include <signal.h>
#include "sscript.h"  

/* gui-tk cl (C) 1998 Drow <drow@wildstar.net>
 * See sscript.doc for copyright information */

gui_tk_cl(int sockfd, char in[1024][1024])
{
 int i,blocking=0,row=0,process=-1;
 char temp5[255],temp6[255],temp7[255];
 FILE *fd;
#ifdef USE_TMP
 fd=fopen("/tmp/gui-tk.tmp","w");
#else
 fd=fopen("gui-tk.tmp","w");
#endif
 fputs("<NO-STRING>\n",fd);
 if(fd!=NULL) fclose(fd);
#ifdef USE_TMP
 fd=fopen("/tmp/gui-tk-bin.tk","w");
#else
 fd=fopen("gui-tk-bin.tk","w");
#endif
 fputs("# GUI-TK LIB from SScript\n",fd);
 fputs("wm title . \"Socket Script\"\nwm geometry . +100+100\n",fd);
 for(i=2;lindex(temp,i)!=NULL;i++)
 {
  if(!cas_cmp(lindex(temp,i),"-nonblocking")) blocking=1;
  if(!cas_cmp(lindex(temp,i),"-info"))
  {
   i++;
   sprintf(temp6,"label .l%d -text \"",row);
   for(i=i;lindex(temp,i)!=NULL;i++)
   {
    strcpy(temp7,lindex(temp,i));
    if(temp7[0]=='-') break;
    strcat(temp6,lindex(temp,i));
    strcat(temp6," ");
   }
   strcat(temp6,"\"\n");
   fputs(temp6,fd);
   sprintf(temp6,"grid .l%d -row %d -column 0\n",row,row);
   fputs(temp6,fd);
   row++;
  }
  if(!cas_cmp(lindex(temp,i),"-entry"))
  {
   sprintf(temp6,"entry .e%d -textvariable e%d \n",row,row);
   fputs(temp6,fd);
   sprintf(temp6,"grid .e%d -row %d -column 0\n",row,row);
   fputs(temp6,fd);
   row++;
  }
  if(!cas_cmp(lindex(temp,i),"-processbutton"))
  {
   i++;
   sprintf(temp6,"button .b%d -text \"%s\" -command {process $e%s}\n",row,lindex(temp,i),lindex(temp,(i+1)));
   i++;i++;
   process=atoi(lindex(temp,i));
   i++;
   fputs(temp6,fd);
   sprintf(temp6,"grid .b%d -row %d -column 0\n",row,row);
   fputs(temp6,fd);
   row++;
  }
  if(!cas_cmp(lindex(temp,i),"-cancelbutton"))
  {
   i++;
   sprintf(temp6,"button .b%d -text \"%s\" -command {exit}\n",row,lindex(temp,i));
   fputs(temp6,fd);
   sprintf(temp6,"grid .b%d -row %d -column 0\n",row,row);
   fputs(temp6,fd);
   row++;
  }
 }
 fputs("\n\nproc process {what} {\n",fd);
 fputs("if {$what==\"\"} {\nexit\n}\n",fd);
#ifdef USE_TMP
 fputs("set fd [open \"/tmp/gui-tk.tmp\" w]\n",fd);
#else
 fputs("set fd [open \"gui-tk.tmp\" w]\n",fd);
#endif
 fputs("puts $fd \"$what \"\n",fd);
 fputs("close $fd\nexit\n}\n",fd);
 if(fd!=NULL) fclose(fd);
#ifdef USE_TMP
 if(blocking)  system("%s /tmp/gui-tk-bin.tk &\n",TCLPATH);
 else system("%s /tmp/gui-tk-bin.tk\n",TCLPATH);
#else
 if(blocking)  system("%s gui-tk-bin.tk &\n",TCLPATH);
 else system("%s gui-tk-bin.tk\n",TCLPATH);
#endif
 if(process!=-1)
 {
#ifdef USE_TMP
  fd=fopen("/tmp/gui-tk.tmp","r");
#else
  fd=fopen("gui-tk.tmp","r");
#endif
  fgets(temp6,255,fd);
  strcpy(in[process],temp6);
  if(fd!=NULL) fclose(fd);
 }
 return 0;
}
