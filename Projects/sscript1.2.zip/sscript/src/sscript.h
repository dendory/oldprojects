char *lindex(char *input_string, int word_number);
char *lindex2(char *input_string, int word_number);
char *lrange(char *input_string, int starting_at);
char cron[255];
char global_var[512];
char logfilename[255];
char temp[255];
int set_signals_off,pid,lang;
/* Changes empty scripts to <NO-STRING> to prevent SEG FAULT */
#define HANDLE_EMPTY_STRINGS
/* Get remote IP on server-side scripts */
#define GET_REMOTE_IP 
/* Log file */
#define LOGFILE "sscript.log"
/* wish's path */
#define TCLPATH "c:\\tcl\\wish"
/* Perl's path */
#define PERL_BIN "c:\\perl\\bin\\perl"
/* Use /tmp rather than $PWD to put temp files */
#undef USE_TMP
/* Show version, debug status, and connecting information at startup */
#define HEADER
/* If you are in an X Window System environment */
#undef GUI
/* Default editor for composer */
#define EDITOR "notepad"
